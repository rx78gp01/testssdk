From e5233fa70e9f5c3cc51d48f9b4670f2313570489 Mon Sep 17 00:00:00 2001
From: Hauke Mehrtens <hauke@hauke-m.de>
Date: Thu, 25 Jul 2024 22:05:11 +0200
Subject: [PATCH] ath79: Fix PHY access over ag71xx driver

.ndo_do_ioctl is not called any more. For PHY MII ioctl handling, the
kernel calls .ndo_eth_ioctl now.

The SIOCSIFHWADDR and SIOCGIFHWADDR operation are handled in the generic
code in the same way just with more input validation.

See upstream Linux kernel commit:
https://git.kernel.org/linus/a76053707dbf0dc020a73b4d90cd952409ef3691

Reported-by: Cthulhu88 in https://forum.openwrt.org/t/ethernet-leds-control-for-tp-link-tl-wr1043nd-v2-v3/202378
Link: https://github.com/openwrt/openwrt/pull/16005
(cherry picked from commit f86273e742b9f01565018494733d38438e7f0098)
Link: https://github.com/openwrt/openwrt/pull/16023
Signed-off-by: Hauke Mehrtens <hauke@hauke-m.de>
---
 .../net/ethernet/atheros/ag71xx/ag71xx_main.c | 31 +++----------------
 1 file changed, 4 insertions(+), 27 deletions(-)

diff --git a/target/linux/ath79/files/drivers/net/ethernet/atheros/ag71xx/ag71xx_main.c b/target/linux/ath79/files/drivers/net/ethernet/atheros/ag71xx/ag71xx_main.c
index 06ebbd8ea3893f..4fb328a4704d89 100644
--- a/target/linux/ath79/files/drivers/net/ethernet/atheros/ag71xx/ag71xx_main.c
+++ b/target/linux/ath79/files/drivers/net/ethernet/atheros/ag71xx/ag71xx_main.c
@@ -1162,33 +1162,10 @@ static int ag71xx_do_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
 {
 	struct ag71xx *ag = netdev_priv(dev);
 
+	if (ag->phy_dev == NULL)
+		return -ENODEV;
 
-	switch (cmd) {
-	case SIOCSIFHWADDR:
-		if (copy_from_user
-			(dev->dev_addr, ifr->ifr_data, sizeof(dev->dev_addr)))
-			return -EFAULT;
-		return 0;
-
-	case SIOCGIFHWADDR:
-		if (copy_to_user
-			(ifr->ifr_data, dev->dev_addr, sizeof(dev->dev_addr)))
-			return -EFAULT;
-		return 0;
-
-	case SIOCGMIIPHY:
-	case SIOCGMIIREG:
-	case SIOCSMIIREG:
-		if (ag->phy_dev == NULL)
-			break;
-
-		return phy_mii_ioctl(ag->phy_dev, ifr, cmd);
-
-	default:
-		break;
-	}
-
-	return -EOPNOTSUPP;
+	return phy_mii_ioctl(ag->phy_dev, ifr, cmd);
 }
 
 static void ag71xx_oom_timer_handler(struct timer_list *t)
@@ -1502,7 +1479,7 @@ static const struct net_device_ops ag71xx_netdev_ops = {
 	.ndo_open		= ag71xx_open,
 	.ndo_stop		= ag71xx_stop,
 	.ndo_start_xmit		= ag71xx_hard_start_xmit,
-	.ndo_do_ioctl		= ag71xx_do_ioctl,
+	.ndo_eth_ioctl		= ag71xx_do_ioctl,
 	.ndo_tx_timeout		= ag71xx_tx_timeout,
 	.ndo_change_mtu		= ag71xx_change_mtu,
 	.ndo_set_mac_address	= eth_mac_addr,
