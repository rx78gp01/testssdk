diff --git a/feeds/packages/kernel/ovpn-dco/patches/0005-Update-linux-compat.h.patch b/feeds/packages/kernel/ovpn-dco/patches/0005-Update-linux-compat.h.patch
new file mode 100644
index 0000000..7c907dc
--- /dev/null
+++ b/feeds/packages/kernel/ovpn-dco/patches/0005-Update-linux-compat.h.patch
@@ -0,0 +1,16 @@
+diff --git a/linux-compat.h b/linux-compat.h
+index 26eb48f..c4e7991 100644
+--- a/linux-compat.h
++++ b/linux-compat.h
+@@ -55,7 +55,7 @@
+ 
+ #endif /* LINUX_VERSION_CODE < KERNEL_VERSION(6, 2, 0) && RHEL_RELEASE_CODE < RHEL_RELEASE_VERSION(9, 3) */
+ 
+-#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 19, 0) && SUSE_PRODUCT_CODE < SUSE_PRODUCT(1, 15, 5, 0)
++#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 15, 221) && SUSE_PRODUCT_CODE < SUSE_PRODUCT(1, 15, 5, 0)
+ 
+ /**
+  * commit 58caed3dacb4 renamed to netif_napi_add_tx_weight,
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

