diff --git a/target/linux/generic/pending-5.15/778-net-l2tp-drop-flow-hash-on-forward.patch b/target/linux/generic/pending-5.15/778-net-l2tp-drop-flow-hash-on-forward.patch
deleted file mode 100644
index a2c0edcbbf580..0000000000000
--- a/target/linux/generic/pending-5.15/778-net-l2tp-drop-flow-hash-on-forward.patch
+++ /dev/null
@@ -1,31 +0,0 @@
-From 4a44a52f16ccd3d03e0cb5fb437a5eb31a5f9f05 Mon Sep 17 00:00:00 2001
-From: David Bauer <mail@david-bauer.net>
-Date: Mon, 26 Feb 2024 21:39:34 +0100
-Subject: [PATCH] net l2tp: drop flow hash on forward
-
-Drop the flow-hash of the skb when forwarding to the L2TP netdev.
-
-This avoids the L2TP qdisc from using the flow-hash from the outer
-packet, which is identical for every flow within the tunnel.
-
-This does not affect every platform but is specific for the ethernet
-driver. It depends on the platform including L4 information in the
-flow-hash.
-
-Signed-off-by: David Bauer <mail@david-bauer.net>
----
- net/l2tp/l2tp_eth.c | 3 +++
- 1 file changed, 3 insertions(+)
-
---- a/net/l2tp/l2tp_eth.c
-+++ b/net/l2tp/l2tp_eth.c
-@@ -136,6 +136,9 @@ static void l2tp_eth_dev_recv(struct l2t
- 	/* checksums verified by L2TP */
- 	skb->ip_summed = CHECKSUM_NONE;
- 
-+	/* drop outer flow-hash */
-+	skb_clear_hash(skb);
-+
- 	skb_dst_drop(skb);
- 	nf_reset_ct(skb);
- 
