diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .212
-LINUX_KERNEL_HASH-5.15.212 = c396aeebc90c7aecb7f7abdf504c19b372c9926eb0cf0e91f9f09d7d870b65fe
+LINUX_VERSION-5.15 = .220
+LINUX_KERNEL_HASH-5.15.220 = b5b2992505120ac864cd9ccf7cc44541684df46c5a0b09ccdec93fb7f9aa6723
