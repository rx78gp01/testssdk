diff --git a/include/kernel-5.15 b/include/kernel-5.15
index 84a0d0a1bffe1..4a82b9c9b3b43 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .160
-LINUX_KERNEL_HASH-5.15.160 = f41e718e33b88f269a6b6a7653e5e9824c4ba541f6ffe5bf26ecc37c540a1b05
+LINUX_VERSION-5.15 = .161
+LINUX_KERNEL_HASH-5.15.161 = d629f78680dc4b65e3d78b61406fb7757b960c83c206e63ad8c2606b3e3c474c
