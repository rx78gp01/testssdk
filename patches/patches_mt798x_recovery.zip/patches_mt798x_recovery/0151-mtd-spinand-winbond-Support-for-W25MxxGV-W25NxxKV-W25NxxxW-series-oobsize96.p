diff --git a/target/linux/generic/backport-5.15/893-v6.7-mtd-spinand-winbond-add-support-for-serial-NAND-flas.patch b/target/linux/generic/backport-5.15/893-v6.7-mtd-spinand-winbond-add-support-for-serial-NAND-flas.patch
new file mode 100644
index 0000000..87c09fc
--- /dev/null
+++ b/target/linux/generic/backport-5.15/893-v6.7-mtd-spinand-winbond-add-support-for-serial-NAND-flas.patch
@@ -0,0 +1,76 @@
+From c7f07f5c4c7379fbc7da623c6b5d3e65e72f454e Mon Sep 17 00:00:00 2001
+From: Sridharan S N <quic_sridsn@quicinc.com>
+Date: Thu, 12 Oct 2023 12:11:34 +0530
+Subject: [PATCH] mtd: spinand: winbond: add support for serial NAND flash
+
+Add support for W25N01JW, W25N02JWZEIF, W25N512GW,
+W25N02KWZEIR and W25N01GWZEIG.
+
+W25N02KWZEIR has 8b/512b on-die ECC capability and other
+four has 4b/512b on-die ECC capability.
+
+Signed-off-by: Sridharan S N <quic_sridsn@quicinc.com>
+Signed-off-by: Md Sadre Alam <quic_mdalam@quicinc.com>
+Signed-off-by: Miquel Raynal <miquel.raynal@bootlin.com>
+Link: https://lore.kernel.org/linux-mtd/20231012064134.4068621-1-quic_sridsn@quicinc.com
+---
+ drivers/mtd/nand/spi/winbond.c | 45 ++++++++++++++++++++++++++++++++++
+ 1 file changed, 45 insertions(+)
+
+diff --git a/drivers/mtd/nand/spi/winbond.c b/drivers/mtd/nand/spi/winbond.c
+index f507e37..1a47302 100644
+--- a/drivers/mtd/nand/spi/winbond.c
++++ b/drivers/mtd/nand/spi/winbond.c
+@@ -169,6 +169,51 @@ static const struct spinand_info winbond_spinand_table[] = {
+ 					      &update_cache_variants),
+ 		     0,
+ 		     SPINAND_ECCINFO(&w25n02kv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N01JW",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xbc, 0x21),
++		     NAND_MEMORG(1, 2048, 64, 64, 1024, 20, 1, 1, 1),
++		     NAND_ECCREQ(4, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25m02gv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N02JWZEIF",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xbf, 0x22),
++		     NAND_MEMORG(1, 2048, 64, 64, 1024, 20, 1, 2, 1),
++		     NAND_ECCREQ(4, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25n02kv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N512GW",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xba, 0x20),
++		     NAND_MEMORG(1, 2048, 64, 64, 512, 10, 1, 1, 1),
++		     NAND_ECCREQ(4, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25n02kv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N02KWZEIR",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xba, 0x22),
++		     NAND_MEMORG(1, 2048, 128, 64, 2048, 40, 1, 1, 1),
++		     NAND_ECCREQ(8, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25n02kv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N01GWZEIG",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xba, 0x21),
++		     NAND_MEMORG(1, 2048, 64, 64, 1024, 20, 1, 1, 1),
++		     NAND_ECCREQ(4, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25m02gv_ooblayout, w25n02kv_ecc_get_status)),
+ };
+ 
+ static int winbond_spinand_init(struct spinand_device *spinand)
+-- 
diff --git a/target/linux/generic/backport-5.15/895-v6.9-mtd-spinand-winbond-add-support-for-W25N04KV.patch b/target/linux/generic/backport-5.15/895-v6.9-mtd-spinand-winbond-add-support-for-W25N04KV.patch
new file mode 100644
index 0000000..93e4228
--- /dev/null
+++ b/target/linux/generic/backport-5.15/895-v6.9-mtd-spinand-winbond-add-support-for-W25N04KV.patch
@@ -0,0 +1,54 @@
+From 6224c3435c47e63297f5a7615b240312493b6483 Mon Sep 17 00:00:00 2001
+From: Zhi-Jun You <hujy652@gmail.com>
+Date: Sun, 7 Jan 2024 14:41:20 +0000
+Subject: [PATCH] mtd: spinand: winbond: add support for W25N04KV
+
+Add support for W25N04KV.
+
+W25N04KV has 8-bit on-die ECC.
+
+Signed-off-by: Zhi-Jun You <hujy652@gmail.com>
+Signed-off-by: Miquel Raynal <miquel.raynal@bootlin.com>
+Link: https://lore.kernel.org/linux-mtd/20240107144120.532-1-hujy652@gmail.com
+---
+ drivers/mtd/nand/spi/winbond.c | 12 ++++++++++++
+ 1 file changed, 12 insertions(+)
+
+diff --git a/drivers/mtd/nand/spi/winbond.c b/drivers/mtd/nand/spi/winbond.c
+index 1a47302..ba7c813 100644
+--- a/drivers/mtd/nand/spi/winbond.c
++++ b/drivers/mtd/nand/spi/winbond.c
+@@ -15,6 +15,8 @@
+ 
+ #define WINBOND_CFG_BUF_READ		BIT(3)
+ 
++#define W25N04KV_STATUS_ECC_5_8_BITFLIPS	(3 << 4)
++
+ static SPINAND_OP_VARIANTS(read_cache_variants,
+ 		SPINAND_PAGE_READ_FROM_CACHE_QUADIO_OP(0, 2, NULL, 0),
+ 		SPINAND_PAGE_READ_FROM_CACHE_X4_OP(0, 1, NULL, 0),
+@@ -118,6 +120,7 @@ static int w25n02kv_ecc_get_status(struct spinand_device *spinand,
+ 		return -EBADMSG;
+ 
+ 	case STATUS_ECC_HAS_BITFLIPS:
++	case W25N04KV_STATUS_ECC_5_8_BITFLIPS:
+ 		/*
+ 		 * Let's try to retrieve the real maximum number of bitflips
+ 		 * in order to avoid forcing the wear-leveling layer to move
+@@ -214,6 +217,15 @@ static const struct spinand_info winbond_spinand_table[] = {
+ 					      &update_cache_variants),
+ 		     0,
+ 		     SPINAND_ECCINFO(&w25m02gv_ooblayout, w25n02kv_ecc_get_status)),
++	SPINAND_INFO("W25N04KV",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xaa, 0x23),
++		     NAND_MEMORG(1, 2048, 128, 64, 4096, 40, 2, 1, 1),
++		     NAND_ECCREQ(8, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25n02kv_ooblayout, w25n02kv_ecc_get_status)),
+ };
+ 
+ static int winbond_spinand_init(struct spinand_device *spinand)
+-- 
diff --git a/target/linux/mediatek/patches-5.15/999-2330-mtd-spinand-winbond-add-support-for-W25N01KV.patch b/target/linux/mediatek/patches-5.15/999-2330-mtd-spinand-winbond-add-support-for-W25N01KV.patch
new file mode 100644
index 0000000..d5c23ac
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-2330-mtd-spinand-winbond-add-support-for-W25N01KV.patch
@@ -0,0 +1,45 @@
+diff --git a/drivers/mtd/nand/spi/winbond.c b/drivers/mtd/nand/spi/winbond.c
+index ba7c813..3cc7f69 100644
+--- a/drivers/mtd/nand/spi/winbond.c
++++ b/drivers/mtd/nand/spi/winbond.c
+@@ -105,6 +105,23 @@ static const struct mtd_ooblayout_ops w25n02kv_ooblayout = {
+ 	.free = w25n02kv_ooblayout_free,
+ };
+ 
++static int w25n01kv_ooblayout_ecc(struct mtd_info *mtd, int section,
++				  struct mtd_oob_region *region)
++{
++	if (section > 3)
++		return -ERANGE;
++
++	region->offset = 64 + (8 * section);
++	region->length = 7;
++
++	return 0;
++}
++
++static const struct mtd_ooblayout_ops w25n01kv_ooblayout = {
++	.ecc = w25n01kv_ooblayout_ecc,
++	.free = w25n02kv_ooblayout_free,
++};
++
+ static int w25n02kv_ecc_get_status(struct spinand_device *spinand,
+ 				   u8 status)
+ {
+@@ -163,6 +180,15 @@ static const struct spinand_info winbond_spinand_table[] = {
+ 					      &update_cache_variants),
+ 		     0,
+ 		     SPINAND_ECCINFO(&w25m02gv_ooblayout, NULL)),
++	SPINAND_INFO("W25N01KV",
++		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xae, 0x21),
++		     NAND_MEMORG(1, 2048, 96, 64, 1024, 20, 1, 1, 1),
++		     NAND_ECCREQ(4, 512),
++		     SPINAND_INFO_OP_VARIANTS(&read_cache_variants,
++					      &write_cache_variants,
++					      &update_cache_variants),
++		     0,
++		     SPINAND_ECCINFO(&w25n01kv_ooblayout, w25n02kv_ecc_get_status)),
+ 	SPINAND_INFO("W25N02KV",
+ 		     SPINAND_ID(SPINAND_READID_METHOD_OPCODE_DUMMY, 0xaa, 0x22),
+ 		     NAND_MEMORG(1, 2048, 128, 64, 2048, 40, 1, 1, 1),
+-- 
-- 

