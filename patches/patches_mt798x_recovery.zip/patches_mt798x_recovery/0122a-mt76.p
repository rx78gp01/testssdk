diff --git a/package/kernel/mt76/Makefile b/package/kernel/mt76/Makefile
index 548492e9194c3..f2339e942a324 100644
--- a/package/kernel/mt76/Makefile
+++ b/package/kernel/mt76/Makefile
@@ -8,9 +8,9 @@ PKG_LICENSE_FILES:=
 
 PKG_SOURCE_URL:=https://github.com/openwrt/mt76
 PKG_SOURCE_PROTO:=git
-PKG_SOURCE_DATE:=2024-04-03
-PKG_SOURCE_VERSION:=1e336a8582dce2ef32ddd440d423e9afef961e71
-PKG_MIRROR_HASH:=f3801af80d5f9c1aa266c9401d4dfa2d501df0382c81fd249150e17dddc70936
+PKG_SOURCE_DATE:=2024-05-17
+PKG_SOURCE_VERSION:=513c131c6309712a51502870b041f45b4bd6a6d4
+PKG_MIRROR_HASH:=skip
 
 PKG_MAINTAINER:=Felix Fietkau <nbd@nbd.name>
 PKG_USE_NINJA:=0
