diff --git a/include/kernel-5.15 b/include/kernel-5.15
index 84a0d0a1bffe1..4a82b9c9b3b43 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .158
-LINUX_KERNEL_HASH-5.15.158 = f9071c83a4fd8b80af026b48cfc1869bfa25883f9148b92b5dc1e1e1e26dd5c6
+LINUX_VERSION-5.15 = .159
+LINUX_KERNEL_HASH-5.15.159 = 3478fe50225e9c88e09cf114f38e3fb71e82d9fdcc356aa1257d721199b341c5
