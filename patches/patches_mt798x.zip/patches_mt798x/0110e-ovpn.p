diff --git a/feeds/packages/net/openvpn/patches/201.patch b/feeds/packages/net/openvpn/patches/201.patch
new file mode 100644
index 0000000..9384b4a
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/201.patch
@@ -0,0 +1,52 @@
+From 5591af17694d98054da2cdf4cfd42508a8a4fb8e Mon Sep 17 00:00:00 2001
+From: Frank Lichtenheld <frank@lichtenheld.com>
+Date: Mon, 25 Mar 2024 08:14:48 +0100
+Subject: [PATCH] phase2_tcp_server: fix Coverity issue 'Dereference after null
+ check'
+
+As Coverity says:
+Either the check against null is unnecessary, or there may be a null
+pointer dereference.
+In phase2_tcp_server: Pointer is checked against null but then
+dereferenced anyway
+
+There is only one caller (link_socket_init_phase2) and it already has
+an ASSERT(sig_info). So use that here was well.
+
+v2:
+ - fix cleanly by actually asserting that sig_info is defined
+
+Change-Id: I8ef199463d46303129a3f563fd9eace780a58b8a
+Signed-off-by: Frank Lichtenheld <frank@lichtenheld.com>
+Acked-by: Arne Schwabe <arne-openvpn@rfc2549.org>
+Message-Id: <20240325071448.12143-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg28452.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit e8c629fe64c67ea0a8454753be99db44df7ce53e)
+---
+ src/openvpn/socket.c | 5 +++--
+ 1 file changed, 3 insertions(+), 2 deletions(-)
+
+diff --git a/src/openvpn/socket.c b/src/openvpn/socket.c
+index 16cd8a09efd..f9f084a304a 100644
+--- a/src/openvpn/socket.c
++++ b/src/openvpn/socket.c
+@@ -2007,7 +2007,8 @@ static void
+ phase2_tcp_server(struct link_socket *sock, const char *remote_dynamic,
+                   struct signal_info *sig_info)
+ {
+-    volatile int *signal_received = sig_info ? &sig_info->signal_received : NULL;
++    ASSERT(sig_info);
++    volatile int *signal_received = &sig_info->signal_received;
+     switch (sock->mode)
+     {
+         case LS_MODE_DEFAULT:
+@@ -2033,7 +2034,7 @@ phase2_tcp_server(struct link_socket *sock, const char *remote_dynamic,
+                                         false);
+             if (!socket_defined(sock->sd))
+             {
+-                register_signal(sig_info, SIGTERM, "socket-undefiled");
++                register_signal(sig_info, SIGTERM, "socket-undefined");
+                 return;
+             }
+             tcp_connection_established(&sock->info.lsa->actual);
diff --git a/feeds/packages/net/openvpn/patches/202.patch b/feeds/packages/net/openvpn/patches/202.patch
new file mode 100644
index 0000000..83dfbf3
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/202.patch
@@ -0,0 +1,49 @@
+From e36359aa7e5193ad002768e90ae660896a5a0fa6 Mon Sep 17 00:00:00 2001
+From: Arne Schwabe <arne@rfc2549.org>
+Date: Tue, 26 Mar 2024 11:38:53 +0100
+Subject: [PATCH] Add bracket in fingerprint message and do not warn about
+ missing verification
+
+Github: fixes OpenVPN/openvpn#516
+
+Change-Id: Ia73d53002f4ba2658af18c17cce1b68f79de5781
+Signed-off-by: Arne Schwabe <arne-openvpn@rfc2549.org>
+Acked-by: Frank Lichtenheld <frank@lichtenheld.com>
+Message-Id: <20240326103853.494572-1-frank@lichtenheld.com>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg28474.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit 4b95656536be1f402a55ef5dffe140fa78e7eb51)
+---
+ src/openvpn/init.c       | 3 ++-
+ src/openvpn/ssl_verify.c | 4 ++--
+ 2 files changed, 4 insertions(+), 3 deletions(-)
+
+diff --git a/src/openvpn/init.c b/src/openvpn/init.c
+index 9f43b629dd0..7e231ec5680 100644
+--- a/src/openvpn/init.c
++++ b/src/openvpn/init.c
+@@ -3632,7 +3632,8 @@ do_option_warnings(struct context *c)
+         && !o->tls_verify
+         && o->verify_x509_type == VERIFY_X509_NONE
+         && !(o->ns_cert_type & NS_CERT_CHECK_SERVER)
+-        && !o->remote_cert_eku)
++        && !o->remote_cert_eku
++        && !(o->verify_hash_depth == 0 && o->verify_hash))
+     {
+         msg(M_WARN, "WARNING: No server certificate verification method has been enabled.  See http://openvpn.net/howto.html#mitm for more info.");
+     }
+diff --git a/src/openvpn/ssl_verify.c b/src/openvpn/ssl_verify.c
+index c7d7799345c..930769b7796 100644
+--- a/src/openvpn/ssl_verify.c
++++ b/src/openvpn/ssl_verify.c
+@@ -718,8 +718,8 @@ verify_cert(struct tls_session *session, openvpn_x509_cert_t *cert, int cert_dep
+             const char *hex_fp = format_hex_ex(BPTR(&cert_fp), BLEN(&cert_fp),
+                                                0, 1, ":", &gc);
+             msg(D_TLS_ERRORS, "TLS Error: --tls-verify/--peer-fingerprint"
+-                "certificate hash verification failed. (got "
+-                "fingerprint: %s", hex_fp);
++                "certificate hash verification failed. (got certificate "
++                "fingerprint: %s)", hex_fp);
+             goto cleanup;
+         }
+     }
diff --git a/feeds/packages/net/openvpn/patches/203.patch b/feeds/packages/net/openvpn/patches/203.patch
new file mode 100644
index 0000000..524a4a5
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/203.patch
@@ -0,0 +1,102 @@
+From f50c67707ed033040c93a6b5d4efbbd2c0933459 Mon Sep 17 00:00:00 2001
+From: Lev Stipakov <lev@openvpn.net>
+Date: Fri, 29 Mar 2024 11:37:39 +0100
+Subject: [PATCH] misc.c: remove unused code
+
+Commit
+
+  3a4fb1 "Ensure --auth-nocache is handled during renegotiation"
+
+has changed the behavior of set_auth_token(), but left unused parameter
+
+  struct user_pass *up
+
+Remove this parameter and amend comments accordingly. Also remove
+unused function definition from misc.h.
+
+Signed-off-by: Lev Stipakov <lev@openvpn.net>
+Acked-by: Frank Lichtenheld <frank@lichtenheld.com>
+
+Change-Id: Ic440f2c8d46dfcb5ff41ba2f33bf28bb7286eec4
+Message-Id: <20240329103739.28254-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg28503.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit 4c71e816031f564f834df695b3fa717ea22720d2)
+---
+ src/openvpn/misc.c |  8 ++------
+ src/openvpn/misc.h | 12 ++----------
+ src/openvpn/ssl.c  |  2 +-
+ 3 files changed, 5 insertions(+), 17 deletions(-)
+
+diff --git a/src/openvpn/misc.c b/src/openvpn/misc.c
+index edc8572b703..00940efd4c7 100644
+--- a/src/openvpn/misc.c
++++ b/src/openvpn/misc.c
+@@ -491,19 +491,15 @@ purge_user_pass(struct user_pass *up, const bool force)
+ }
+ 
+ void
+-set_auth_token(struct user_pass *up, struct user_pass *tk, const char *token)
++set_auth_token(struct user_pass *tk, const char *token)
+ {
+-
+     if (strlen(token))
+     {
+         strncpynt(tk->password, token, USER_PASS_LEN);
+         tk->token_defined = true;
+ 
+         /*
+-         * --auth-token has no username, so it needs the username
+-         * either already set or copied from up, or later set by
+-         * --auth-token-user
+-         * If already set, tk is fully defined.
++         * If username already set, tk is fully defined.
+          */
+         if (strlen(tk->username))
+         {
+diff --git a/src/openvpn/misc.h b/src/openvpn/misc.h
+index 24a1ca56a48..0dc08834e41 100644
+--- a/src/openvpn/misc.h
++++ b/src/openvpn/misc.h
+@@ -135,26 +135,18 @@ get_user_pass(struct user_pass *up,
+     return get_user_pass_cr(up, auth_file, prefix, flags, NULL);
+ }
+ 
+-void fail_user_pass(const char *prefix,
+-                    const unsigned int flags,
+-                    const char *reason);
+-
+ void purge_user_pass(struct user_pass *up, const bool force);
+ 
+ /**
+- * Sets the auth-token to token. If a username is available from
+- * either up or already present in tk that will be used as default
+- * username for the token. The method will also purge up if
++ * Sets the auth-token to token. The method will also purge up if
+  * the auth-nocache option is active.
+  *
+- * @param up        (non Auth-token) Username/password
+  * @param tk        auth-token userpass to set
+  * @param token     token to use as password for the auth-token
+  *
+  * @note    all parameters to this function must not be null.
+  */
+-void set_auth_token(struct user_pass *up, struct user_pass *tk,
+-                    const char *token);
++void set_auth_token(struct user_pass *tk, const char *token);
+ 
+ /**
+  * Sets the auth-token username by base64 decoding the passed
+diff --git a/src/openvpn/ssl.c b/src/openvpn/ssl.c
+index 6aa1051521c..162a8622de7 100644
+--- a/src/openvpn/ssl.c
++++ b/src/openvpn/ssl.c
+@@ -504,7 +504,7 @@ ssl_set_auth_nocache(void)
+ void
+ ssl_set_auth_token(const char *token)
+ {
+-    set_auth_token(&auth_user_pass, &auth_token, token);
++    set_auth_token(&auth_token, token);
+ }
+ 
+ void
diff --git a/feeds/packages/net/openvpn/patches/204.patch b/feeds/packages/net/openvpn/patches/204.patch
new file mode 100644
index 0000000..440a601
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/204.patch
@@ -0,0 +1,137 @@
+From 65fb67cd6c320a426567b2922c4282fb8738ba3f Mon Sep 17 00:00:00 2001
+From: =?UTF-8?q?Reynir=20Bj=C3=B6rnsson?= <reynir@reynir.dk>
+Date: Thu, 16 May 2024 13:58:08 +0200
+Subject: [PATCH] Only schedule_exit() once
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+If an exit has already been scheduled we should not schedule it again.
+Otherwise, the exit signal is never emitted if the peer reschedules the
+exit before the timeout occurs.
+
+schedule_exit() now only takes the context as argument. The signal is
+hard coded to SIGTERM, and the interval is read directly from the
+context options.
+
+Furthermore, schedule_exit() now returns a bool signifying whether an
+exit was scheduled; false if exit is already scheduled. The call sites
+are updated accordingly. A notable difference is that management is only
+notified *once* when an exit is scheduled - we no longer notify
+management on redundant exit.
+
+This patch was assigned a CVE number after already reviewed and ACKed,
+because it was discovered that a misbehaving client can use the (now
+fixed) server behaviour to avoid being disconnected by means of a
+managment interface "client-kill" command - the security issue here is
+"client can circumvent security policy set by management interface".
+
+This only affects previously authenticated clients, and only management
+client-kill, so normal renegotion / AUTH_FAIL ("your session ends") is not
+affected.
+
+CVE: 2024-28882
+
+Change-Id: I9457f005f4ba970502e6b667d9dc4299a588d661
+Signed-off-by: Reynir Björnsson <reynir@reynir.dk>
+Acked-by: Arne Schwabe <arne-openvpn@rfc2549.org>
+Message-Id: <20240516120434.23499-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg28679.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit 55bb3260c12bae33b6a8eac73cbb6972f8517411)
+---
+ src/openvpn/forward.c | 15 +++++++++++----
+ src/openvpn/forward.h |  2 +-
+ src/openvpn/push.c    | 12 +++++++-----
+ 3 files changed, 19 insertions(+), 10 deletions(-)
+
+diff --git a/src/openvpn/forward.c b/src/openvpn/forward.c
+index e9811b9c81d..29e812ffd17 100644
+--- a/src/openvpn/forward.c
++++ b/src/openvpn/forward.c
+@@ -514,17 +514,24 @@ check_server_poll_timeout(struct context *c)
+ }
+ 
+ /*
+- * Schedule a signal n_seconds from now.
++ * Schedule a SIGTERM signal c->options.scheduled_exit_interval seconds from now.
+  */
+-void
+-schedule_exit(struct context *c, const int n_seconds, const int signal)
++bool
++schedule_exit(struct context *c)
+ {
++    const int n_seconds = c->options.scheduled_exit_interval;
++    /* don't reschedule if already scheduled. */
++    if (event_timeout_defined(&c->c2.scheduled_exit))
++    {
++        return false;
++    }
+     tls_set_single_session(c->c2.tls_multi);
+     update_time();
+     reset_coarse_timers(c);
+     event_timeout_init(&c->c2.scheduled_exit, n_seconds, now);
+-    c->c2.scheduled_exit_signal = signal;
++    c->c2.scheduled_exit_signal = SIGTERM;
+     msg(D_SCHED_EXIT, "Delayed exit in %d seconds", n_seconds);
++    return true;
+ }
+ 
+ /*
+diff --git a/src/openvpn/forward.h b/src/openvpn/forward.h
+index 060fc374ca6..245a8029211 100644
+--- a/src/openvpn/forward.h
++++ b/src/openvpn/forward.h
+@@ -302,7 +302,7 @@ void reschedule_multi_process(struct context *c);
+ 
+ void process_ip_header(struct context *c, unsigned int flags, struct buffer *buf);
+ 
+-void schedule_exit(struct context *c, const int n_seconds, const int signal);
++bool schedule_exit(struct context *c);
+ 
+ static inline struct link_socket_info *
+ get_link_socket_info(struct context *c)
+diff --git a/src/openvpn/push.c b/src/openvpn/push.c
+index 1b406b9c531..d220eeb9744 100644
+--- a/src/openvpn/push.c
++++ b/src/openvpn/push.c
+@@ -204,7 +204,11 @@ receive_exit_message(struct context *c)
+      * */
+     if (c->options.mode == MODE_SERVER)
+     {
+-        schedule_exit(c, c->options.scheduled_exit_interval, SIGTERM);
++        if (!schedule_exit(c))
++        {
++            /* Return early when we don't need to notify management */
++            return;
++        }
+     }
+     else
+     {
+@@ -391,7 +395,7 @@ __attribute__ ((format(__printf__, 4, 5)))
+ void
+ send_auth_failed(struct context *c, const char *client_reason)
+ {
+-    if (event_timeout_defined(&c->c2.scheduled_exit))
++    if (!schedule_exit(c))
+     {
+         msg(D_TLS_DEBUG, "exit already scheduled for context");
+         return;
+@@ -401,8 +405,6 @@ send_auth_failed(struct context *c, const char *client_reason)
+     static const char auth_failed[] = "AUTH_FAILED";
+     size_t len;
+ 
+-    schedule_exit(c, c->options.scheduled_exit_interval, SIGTERM);
+-
+     len = (client_reason ? strlen(client_reason)+1 : 0) + sizeof(auth_failed);
+     if (len > PUSH_BUNDLE_SIZE)
+     {
+@@ -492,7 +494,7 @@ send_auth_pending_messages(struct tls_multi *tls_multi,
+ void
+ send_restart(struct context *c, const char *kill_msg)
+ {
+-    schedule_exit(c, c->options.scheduled_exit_interval, SIGTERM);
++    schedule_exit(c);
+     send_control_channel_string(c, kill_msg ? kill_msg : "RESTART", D_PUSH);
+ }
+ 
-- 
2.38.1.windows.1

