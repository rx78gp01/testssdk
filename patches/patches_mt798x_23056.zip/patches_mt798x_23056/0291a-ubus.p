From a7901969932a175cded3c93bdeb65f32ed3705e6 Mon Sep 17 00:00:00 2001
From: Felix Fietkau <nbd@nbd.name>
Date: Fri, 17 Oct 2025 13:28:52 +0200
Subject: [PATCH] ubus: update to Git HEAD (2025-10-17)

b462895d3157 lua: CMakeLists: drop redundant cmake_minimum_required
f247c18f8a55 examples: CMakeLists: drop redundant cmake_minimum_required
83a70399030d github: add CI build
d31effb4277b ubusd: Fix out of bounds access in event register message
d95837b1b143 ubusd: acl: compare uid/gid instead of user/group strings
b81257bb20dd ubusd: load extra group IDs for a client process
7d7b45fea05b add debian/ directory
aa4a7ee1d341 ubusd: fix more instances of missing length checks for patterns
60e04048a0e2 ubusd: fix ACL check for receiving events

Signed-off-by: Felix Fietkau <nbd@nbd.name>
(cherry picked from commit 4b907e69ea58fc0ba35fd1755dc4ba22262af3a4)
---
 package/system/ubus/Makefile | 6 +++---
 1 file changed, 3 insertions(+), 3 deletions(-)

diff --git a/package/system/ubus/Makefile b/package/system/ubus/Makefile
index 469b0e45f85742..8e0a3a9e305613 100644
--- a/package/system/ubus/Makefile
+++ b/package/system/ubus/Makefile
@@ -5,9 +5,9 @@ PKG_RELEASE:=1
 
 PKG_SOURCE_PROTO:=git
 PKG_SOURCE_URL=$(PROJECT_GIT)/project/ubus.git
-PKG_SOURCE_DATE:=2023-06-05
+PKG_SOURCE_DATE:=2025-10-17
-PKG_SOURCE_VERSION:=f787c97b34894a38b15599886cacbca01271684f
-PKG_MIRROR_HASH:=f4e898eb9207f069652f1767835f6aa9f015df2282d51e50ab57a0c3736f36e3
+PKG_SOURCE_VERSION:=60e04048a0e2f3e33651c19e62861b41be4c290f
+PKG_MIRROR_HASH:=skip
 PKG_ABI_VERSION:=$(call abi_version_str,$(PKG_SOURCE_DATE))
 CMAKE_INSTALL:=1
 
