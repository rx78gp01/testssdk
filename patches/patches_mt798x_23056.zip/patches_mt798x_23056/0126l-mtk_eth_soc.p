From 4a2f712f85b5e29c5763e92a0cc47265580157a3 Mon Sep 17 00:00:00 2001
From: Daniel Golle <daniel@makrotopia.org>
Date: Thu, 4 Jul 2024 02:19:01 +0100
Subject: [PATCH] generic: 6.6: mtk_eth_soc: add support for flow-control
 settings

Add patch implementing operations to get and set flow-control link
parameters of mtk_eth_soc via ethtool.

Signed-off-by: Daniel Golle <daniel@makrotopia.org>
---

diff --git a/target/linux/mediatek/patches-5.15/973-30-v6.10-net-ethernet-mtk_eth_soc-implement-.-get-set-_pausep.patch b/target/linux/mediatek/patches-5.15/973-30-v6.10-net-ethernet-mtk_eth_soc-implement-.-get-set-_pausep.patch
new file mode 100644
index 00000000000000..09d7054965b224
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/973-30-v6.10-net-ethernet-mtk_eth_soc-implement-.-get-set-_pausep.patch
@@ -0,0 +1,55 @@
+From 064fbc4e9b5a6dbda7fe7b67dc7e9e95d31f8d75 Mon Sep 17 00:00:00 2001
+From: Daniel Golle <daniel@makrotopia.org>
+Date: Thu, 4 Jul 2024 11:14:55 +0100
+Subject: [PATCH] net: ethernet: mtk_eth_soc: implement .{get,set}_pauseparam
+ ethtool ops
+
+Implement operations to get and set flow-control link parameters.
+Both is done by simply calling phylink_ethtool_{get,set}_pauseparam().
+Fix whitespace in mtk_ethtool_ops while at it.
+
+Signed-off-by: Daniel Golle <daniel@makrotopia.org>
+Reviewed-by: Michal Kubiak <michal.kubiak@intel.com>
+Reviewed-by: Russell King (Oracle) <rmk+kernel@armlinux.org.uk>
+Tested-by: Rui Salvaterra <rsalvaterra@gmail.com>
+Link: https://patch.msgid.link/e3ece47323444631d6cb479f32af0dfd6d145be0.1720088047.git.daniel@makrotopia.org
+Signed-off-by: Jakub Kicinski <kuba@kernel.org>
+---
+ drivers/net/ethernet/mediatek/mtk_eth_soc.c | 18 +++++++++++++++++-
+ 1 file changed, 17 insertions(+), 1 deletion(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -4595,6 +4595,20 @@ static int mtk_set_rxnfc(struct net_devi
+ 	return ret;
+ }
+ 
++static void mtk_get_pauseparam(struct net_device *dev, struct ethtool_pauseparam *pause)
++{
++	struct mtk_mac *mac = netdev_priv(dev);
++
++	phylink_ethtool_get_pauseparam(mac->phylink, pause);
++}
++
++static int mtk_set_pauseparam(struct net_device *dev, struct ethtool_pauseparam *pause)
++{
++	struct mtk_mac *mac = netdev_priv(dev);
++
++	return phylink_ethtool_set_pauseparam(mac->phylink, pause);
++}
++
+ static u16 mtk_select_queue(struct net_device *dev, struct sk_buff *skb,
+ 			    struct net_device *sb_dev)
+ {
+@@ -4623,8 +4623,10 @@ static const struct ethtool_ops mtk_etht
+ 	.get_strings		= mtk_get_strings,
+ 	.get_sset_count		= mtk_get_sset_count,
+ 	.get_ethtool_stats	= mtk_get_ethtool_stats,
++	.get_pauseparam		= mtk_get_pauseparam,
++	.set_pauseparam		= mtk_set_pauseparam,
+ 	.get_rxnfc		= mtk_get_rxnfc,
+-	.set_rxnfc              = mtk_set_rxnfc,
++	.set_rxnfc		= mtk_set_rxnfc,
+ };
+ 
+ static const struct net_device_ops mtk_netdev_ops = {
