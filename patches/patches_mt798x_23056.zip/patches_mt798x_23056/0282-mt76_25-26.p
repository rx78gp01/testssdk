diff --git a/package/kernel/mt76/patches/9999-mt76_25.patch b/package/kernel/mt76/patches/9999-mt76_25.patch
new file mode 100644
index 0000000..682d5a5
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_25.patch
@@ -0,0 +1,33 @@
+From 2fe5bdbe7e137645004c8d91e1b9d96b86105b26 Mon Sep 17 00:00:00 2001
+From: Peter Chiu <chui-hao.chiu@mediatek.com>
+Date: Wed, 8 Oct 2025 12:41:49 +0200
+Subject: [PATCH] wifi: mt76: use GFP_DMA32 for page_pool buffer allocation
+
+Set GFP_DMA32 flag for page_pool buffers allocation since the hw relies
+on 32-bit DMA addresses for WED offloading.
+
+Tested-by: Daniel Pawlik <pawlik.dan@gmail.com>
+Tested-by: Matteo Croce <teknoraver@meta.com>
+Signed-off-by: Peter Chiu <chui-hao.chiu@mediatek.com>
+Co-developed-by: Lorenzo Bianconi <lorenzo@kernel.org>
+Signed-off-by: Lorenzo Bianconi <lorenzo@kernel.org>
+Link: https://patch.msgid.link/20251008-wed-fixes-v1-2-8f7678583385@kernel.org
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt76.h | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/mt76.h b/mt76.h
+index ca2781a27..89f251155 100644
+--- a/mt76.h
++++ b/mt76.h
+@@ -1881,7 +1881,8 @@ mt76_get_page_pool_buf(struct mt76_queue *q, u32 *offset, u32 size)
+ {
+ 	struct page *page;
+ 
+-	page = page_pool_dev_alloc_frag(q->page_pool, offset, size);
++	page = page_pool_alloc_frag(q->page_pool, offset, size,
++				    GFP_ATOMIC | __GFP_NOWARN | GFP_DMA32);
+ 	if (!page)
+ 		return NULL;
+ 
diff --git a/package/kernel/mt76/patches/9999-mt76_26.patch b/package/kernel/mt76/patches/9999-mt76_26.patch
new file mode 100644
index 0000000..44a8d5c
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_26.patch
@@ -0,0 +1,31 @@
+From 2e63c495f59bb479f35a64d61fbb71d06c0dc9c1 Mon Sep 17 00:00:00 2001
+From: Thorsten Blum <thorsten.blum@linux.dev>
+Date: Tue, 23 Sep 2025 23:38:31 +0200
+Subject: [PATCH] wifi: mt76: connac: Replace memcpy + hard-coded size with
+ strscpy
+
+Replace memcpy() and the hard-coded string length with strscpy() to
+safely copy the string and improve mt76_connac_mcu_chip_config().
+
+No functional changes.
+
+Signed-off-by: Thorsten Blum <thorsten.blum@linux.dev>
+Link: https://patch.msgid.link/20250923213831.1896823-2-thorsten.blum@linux.dev
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt76_connac_mcu.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/mt76_connac_mcu.c b/mt76_connac_mcu.c
+index 9d5fcb33e..fba7025ff 100644
+--- a/mt76_connac_mcu.c
++++ b/mt76_connac_mcu.c
+@@ -1974,7 +1974,7 @@ int mt76_connac_mcu_chip_config(struct mt76_dev *dev)
+ 		.resp_type = 0,
+ 	};
+ 
+-	memcpy(req.data, "assert", 7);
++	strscpy(req.data, "assert");
+ 
+ 	return mt76_mcu_send_msg(dev, MCU_CE_CMD(CHIP_CONFIG),
+ 				 &req, sizeof(req), false);
-- 
2.46.2.windows.1

