diff --git a/package/libs/openssl/patches/0069-Fix-array-formatting-in-evp_extra_test.c.patch b/package/libs/openssl/patches/0069-Fix-array-formatting-in-evp_extra_test.c.patch
new file mode 100644
index 0000000..c1403ca
--- /dev/null
+++ b/package/libs/openssl/patches/0069-Fix-array-formatting-in-evp_extra_test.c.patch
@@ -0,0 +1,3156 @@
+From 6b10af6a6e1f38fc37bb195f902e9a2135ef51eb Mon Sep 17 00:00:00 2001
+From: Matt Caswell <matt@openssl.org>
+Date: Tue, 9 Dec 2025 12:22:02 +0000
+Subject: [PATCH 069/100] Fix array formatting in evp_extra_test.c
+
+The reformat did something silly with some of the arrays in evp_extra_test.c
+Fix the arrays such that clang-format is still happy.
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29349)
+
+(cherry picked from commit d54932c9fa4b59e0db8296b91a9392efb9cd897e)
+---
+ test/evp_extra_test.c | 3059 ++++-------------------------------------
+ 1 file changed, 241 insertions(+), 2818 deletions(-)
+
+diff --git a/test/evp_extra_test.c b/test/evp_extra_test.c
+index e8e7a43c2e..10ad58d975 100644
+--- a/test/evp_extra_test.c
++++ b/test/evp_extra_test.c
+@@ -53,614 +53,57 @@ static OSSL_PROVIDER *lgcyprov = NULL;
+  * should never use this key anywhere but in an example.
+  */
+ static const unsigned char kExampleRSAKeyDER[] = {
+-    0x30,
+-    0x82,
+-    0x02,
+-    0x5c,
+-    0x02,
+-    0x01,
+-    0x00,
+-    0x02,
+-    0x81,
+-    0x81,
+-    0x00,
+-    0xf8,
+-    0xb8,
+-    0x6c,
+-    0x83,
+-    0xb4,
+-    0xbc,
+-    0xd9,
+-    0xa8,
+-    0x57,
+-    0xc0,
+-    0xa5,
+-    0xb4,
+-    0x59,
+-    0x76,
+-    0x8c,
+-    0x54,
+-    0x1d,
+-    0x79,
+-    0xeb,
+-    0x22,
+-    0x52,
+-    0x04,
+-    0x7e,
+-    0xd3,
+-    0x37,
+-    0xeb,
+-    0x41,
+-    0xfd,
+-    0x83,
+-    0xf9,
+-    0xf0,
+-    0xa6,
+-    0x85,
+-    0x15,
+-    0x34,
+-    0x75,
+-    0x71,
+-    0x5a,
+-    0x84,
+-    0xa8,
+-    0x3c,
+-    0xd2,
+-    0xef,
+-    0x5a,
+-    0x4e,
+-    0xd3,
+-    0xde,
+-    0x97,
+-    0x8a,
+-    0xdd,
+-    0xff,
+-    0xbb,
+-    0xcf,
+-    0x0a,
+-    0xaa,
+-    0x86,
+-    0x92,
+-    0xbe,
+-    0xb8,
+-    0x50,
+-    0xe4,
+-    0xcd,
+-    0x6f,
+-    0x80,
+-    0x33,
+-    0x30,
+-    0x76,
+-    0x13,
+-    0x8f,
+-    0xca,
+-    0x7b,
+-    0xdc,
+-    0xec,
+-    0x5a,
+-    0xca,
+-    0x63,
+-    0xc7,
+-    0x03,
+-    0x25,
+-    0xef,
+-    0xa8,
+-    0x8a,
+-    0x83,
+-    0x58,
+-    0x76,
+-    0x20,
+-    0xfa,
+-    0x16,
+-    0x77,
+-    0xd7,
+-    0x79,
+-    0x92,
+-    0x63,
+-    0x01,
+-    0x48,
+-    0x1a,
+-    0xd8,
+-    0x7b,
+-    0x67,
+-    0xf1,
+-    0x52,
+-    0x55,
+-    0x49,
+-    0x4e,
+-    0xd6,
+-    0x6e,
+-    0x4a,
+-    0x5c,
+-    0xd7,
+-    0x7a,
+-    0x37,
+-    0x36,
+-    0x0c,
+-    0xde,
+-    0xdd,
+-    0x8f,
+-    0x44,
+-    0xe8,
+-    0xc2,
+-    0xa7,
+-    0x2c,
+-    0x2b,
+-    0xb5,
+-    0xaf,
+-    0x64,
+-    0x4b,
+-    0x61,
+-    0x07,
+-    0x02,
+-    0x03,
+-    0x01,
+-    0x00,
+-    0x01,
+-    0x02,
+-    0x81,
+-    0x80,
+-    0x74,
+-    0x88,
+-    0x64,
+-    0x3f,
+-    0x69,
+-    0x45,
+-    0x3a,
+-    0x6d,
+-    0xc7,
+-    0x7f,
+-    0xb9,
+-    0xa3,
+-    0xc0,
+-    0x6e,
+-    0xec,
+-    0xdc,
+-    0xd4,
+-    0x5a,
+-    0xb5,
+-    0x32,
+-    0x85,
+-    0x5f,
+-    0x19,
+-    0xd4,
+-    0xf8,
+-    0xd4,
+-    0x3f,
+-    0x3c,
+-    0xfa,
+-    0xc2,
+-    0xf6,
+-    0x5f,
+-    0xee,
+-    0xe6,
+-    0xba,
+-    0x87,
+-    0x74,
+-    0x2e,
+-    0xc7,
+-    0x0c,
+-    0xd4,
+-    0x42,
+-    0xb8,
+-    0x66,
+-    0x85,
+-    0x9c,
+-    0x7b,
+-    0x24,
+-    0x61,
+-    0xaa,
+-    0x16,
+-    0x11,
+-    0xf6,
+-    0xb5,
+-    0xb6,
+-    0xa4,
+-    0x0a,
+-    0xc9,
+-    0x55,
+-    0x2e,
+-    0x81,
+-    0xa5,
+-    0x47,
+-    0x61,
+-    0xcb,
+-    0x25,
+-    0x8f,
+-    0xc2,
+-    0x15,
+-    0x7b,
+-    0x0e,
+-    0x7c,
+-    0x36,
+-    0x9f,
+-    0x3a,
+-    0xda,
+-    0x58,
+-    0x86,
+-    0x1c,
+-    0x5b,
+-    0x83,
+-    0x79,
+-    0xe6,
+-    0x2b,
+-    0xcc,
+-    0xe6,
+-    0xfa,
+-    0x2c,
+-    0x61,
+-    0xf2,
+-    0x78,
+-    0x80,
+-    0x1b,
+-    0xe2,
+-    0xf3,
+-    0x9d,
+-    0x39,
+-    0x2b,
+-    0x65,
+-    0x57,
+-    0x91,
+-    0x3d,
+-    0x71,
+-    0x99,
+-    0x73,
+-    0xa5,
+-    0xc2,
+-    0x79,
+-    0x20,
+-    0x8c,
+-    0x07,
+-    0x4f,
+-    0xe5,
+-    0xb4,
+-    0x60,
+-    0x1f,
+-    0x99,
+-    0xa2,
+-    0xb1,
+-    0x4f,
+-    0x0c,
+-    0xef,
+-    0xbc,
+-    0x59,
+-    0x53,
+-    0x00,
+-    0x7d,
+-    0xb1,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xfc,
+-    0x7e,
+-    0x23,
+-    0x65,
+-    0x70,
+-    0xf8,
+-    0xce,
+-    0xd3,
+-    0x40,
+-    0x41,
+-    0x80,
+-    0x6a,
+-    0x1d,
+-    0x01,
+-    0xd6,
+-    0x01,
+-    0xff,
+-    0xb6,
+-    0x1b,
+-    0x3d,
+-    0x3d,
+-    0x59,
+-    0x09,
+-    0x33,
+-    0x79,
+-    0xc0,
+-    0x4f,
+-    0xde,
+-    0x96,
+-    0x27,
+-    0x4b,
+-    0x18,
+-    0xc6,
+-    0xd9,
+-    0x78,
+-    0xf1,
+-    0xf4,
+-    0x35,
+-    0x46,
+-    0xe9,
+-    0x7c,
+-    0x42,
+-    0x7a,
+-    0x5d,
+-    0x9f,
+-    0xef,
+-    0x54,
+-    0xb8,
+-    0xf7,
+-    0x9f,
+-    0xc4,
+-    0x33,
+-    0x6c,
+-    0xf3,
+-    0x8c,
+-    0x32,
+-    0x46,
+-    0x87,
+-    0x67,
+-    0x30,
+-    0x7b,
+-    0xa7,
+-    0xac,
+-    0xe3,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xfc,
+-    0x2c,
+-    0xdf,
+-    0x0c,
+-    0x0d,
+-    0x88,
+-    0xf5,
+-    0xb1,
+-    0x92,
+-    0xa8,
+-    0x93,
+-    0x47,
+-    0x63,
+-    0x55,
+-    0xf5,
+-    0xca,
+-    0x58,
+-    0x43,
+-    0xba,
+-    0x1c,
+-    0xe5,
+-    0x9e,
+-    0xb6,
+-    0x95,
+-    0x05,
+-    0xcd,
+-    0xb5,
+-    0x82,
+-    0xdf,
+-    0xeb,
+-    0x04,
+-    0x53,
+-    0x9d,
+-    0xbd,
+-    0xc2,
+-    0x38,
+-    0x16,
+-    0xb3,
+-    0x62,
+-    0xdd,
+-    0xa1,
+-    0x46,
+-    0xdb,
+-    0x6d,
+-    0x97,
+-    0x93,
+-    0x9f,
+-    0x8a,
+-    0xc3,
+-    0x9b,
+-    0x64,
+-    0x7e,
+-    0x42,
+-    0xe3,
+-    0x32,
+-    0x57,
+-    0x19,
+-    0x1b,
+-    0xd5,
+-    0x6e,
+-    0x85,
+-    0xfa,
+-    0xb8,
+-    0x8d,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xbc,
+-    0x3d,
+-    0xde,
+-    0x6d,
+-    0xd6,
+-    0x97,
+-    0xe8,
+-    0xba,
+-    0x9e,
+-    0x81,
+-    0x37,
+-    0x17,
+-    0xe5,
+-    0xa0,
+-    0x64,
+-    0xc9,
+-    0x00,
+-    0xb7,
+-    0xe7,
+-    0xfe,
+-    0xf4,
+-    0x29,
+-    0xd9,
+-    0x2e,
+-    0x43,
+-    0x6b,
+-    0x19,
+-    0x20,
+-    0xbd,
+-    0x99,
+-    0x75,
+-    0xe7,
+-    0x76,
+-    0xf8,
+-    0xd3,
+-    0xae,
+-    0xaf,
+-    0x7e,
+-    0xb8,
+-    0xeb,
+-    0x81,
+-    0xf4,
+-    0x9d,
+-    0xfe,
+-    0x07,
+-    0x2b,
+-    0x0b,
+-    0x63,
+-    0x0b,
+-    0x5a,
+-    0x55,
+-    0x90,
+-    0x71,
+-    0x7d,
+-    0xf1,
+-    0xdb,
+-    0xd9,
+-    0xb1,
+-    0x41,
+-    0x41,
+-    0x68,
+-    0x2f,
+-    0x4e,
+-    0x39,
+-    0x02,
+-    0x40,
+-    0x5a,
+-    0x34,
+-    0x66,
+-    0xd8,
+-    0xf5,
+-    0xe2,
+-    0x7f,
+-    0x18,
+-    0xb5,
+-    0x00,
+-    0x6e,
+-    0x26,
+-    0x84,
+-    0x27,
+-    0x14,
+-    0x93,
+-    0xfb,
+-    0xfc,
+-    0xc6,
+-    0x0f,
+-    0x5e,
+-    0x27,
+-    0xe6,
+-    0xe1,
+-    0xe9,
+-    0xc0,
+-    0x8a,
+-    0xe4,
+-    0x34,
+-    0xda,
+-    0xe9,
+-    0xa2,
+-    0x4b,
+-    0x73,
+-    0xbc,
+-    0x8c,
+-    0xb9,
+-    0xba,
+-    0x13,
+-    0x6c,
+-    0x7a,
+-    0x2b,
+-    0x51,
+-    0x84,
+-    0xa3,
+-    0x4a,
+-    0xe0,
+-    0x30,
+-    0x10,
+-    0x06,
+-    0x7e,
+-    0xed,
+-    0x17,
+-    0x5a,
+-    0x14,
+-    0x00,
+-    0xc9,
+-    0xef,
+-    0x85,
+-    0xea,
+-    0x52,
+-    0x2c,
+-    0xbc,
+-    0x65,
+-    0x02,
+-    0x40,
+-    0x51,
+-    0xe3,
+-    0xf2,
+-    0x83,
+-    0x19,
+-    0x9b,
+-    0xc4,
+-    0x1e,
+-    0x2f,
+-    0x50,
+-    0x3d,
+-    0xdf,
+-    0x5a,
+-    0xa2,
+-    0x18,
+-    0xca,
+-    0x5f,
+-    0x2e,
+-    0x49,
+-    0xaf,
+-    0x6f,
+-    0xcc,
+-    0xfa,
+-    0x65,
+-    0x77,
+-    0x94,
+-    0xb5,
+-    0xa1,
+-    0x0a,
+-    0xa9,
+-    0xd1,
+-    0x8a,
+-    0x39,
+-    0x37,
+-    0xf4,
+-    0x0b,
+-    0xa0,
+-    0xd7,
+-    0x82,
+-    0x27,
+-    0x5e,
+-    0xae,
+-    0x17,
+-    0x17,
+-    0xa1,
+-    0x1e,
+-    0x54,
+-    0x34,
+-    0xbf,
+-    0x6e,
+-    0xc4,
+-    0x8e,
+-    0x99,
+-    0x5d,
+-    0x08,
+-    0xf1,
+-    0x2d,
+-    0x86,
+-    0x9d,
+-    0xa5,
+-    0x20,
+-    0x1b,
+-    0xe5,
+-    0xdf,
++    0x30, 0x82, 0x02, 0x5c, 0x02, 0x01, 0x00, 0x02, 0x81, 0x81, 0x00, 0xf8,
++    0xb8, 0x6c, 0x83, 0xb4, 0xbc, 0xd9, 0xa8, 0x57, 0xc0, 0xa5, 0xb4, 0x59,
++    0x76, 0x8c, 0x54, 0x1d, 0x79, 0xeb, 0x22, 0x52, 0x04, 0x7e, 0xd3, 0x37,
++    0xeb, 0x41, 0xfd, 0x83, 0xf9, 0xf0, 0xa6, 0x85, 0x15, 0x34, 0x75, 0x71,
++    0x5a, 0x84, 0xa8, 0x3c, 0xd2, 0xef, 0x5a, 0x4e, 0xd3, 0xde, 0x97, 0x8a,
++    0xdd, 0xff, 0xbb, 0xcf, 0x0a, 0xaa, 0x86, 0x92, 0xbe, 0xb8, 0x50, 0xe4,
++    0xcd, 0x6f, 0x80, 0x33, 0x30, 0x76, 0x13, 0x8f, 0xca, 0x7b, 0xdc, 0xec,
++    0x5a, 0xca, 0x63, 0xc7, 0x03, 0x25, 0xef, 0xa8, 0x8a, 0x83, 0x58, 0x76,
++    0x20, 0xfa, 0x16, 0x77, 0xd7, 0x79, 0x92, 0x63, 0x01, 0x48, 0x1a, 0xd8,
++    0x7b, 0x67, 0xf1, 0x52, 0x55, 0x49, 0x4e, 0xd6, 0x6e, 0x4a, 0x5c, 0xd7,
++    0x7a, 0x37, 0x36, 0x0c, 0xde, 0xdd, 0x8f, 0x44, 0xe8, 0xc2, 0xa7, 0x2c,
++    0x2b, 0xb5, 0xaf, 0x64, 0x4b, 0x61, 0x07, 0x02, 0x03, 0x01, 0x00, 0x01,
++    0x02, 0x81, 0x80, 0x74, 0x88, 0x64, 0x3f, 0x69, 0x45, 0x3a, 0x6d, 0xc7,
++    0x7f, 0xb9, 0xa3, 0xc0, 0x6e, 0xec, 0xdc, 0xd4, 0x5a, 0xb5, 0x32, 0x85,
++    0x5f, 0x19, 0xd4, 0xf8, 0xd4, 0x3f, 0x3c, 0xfa, 0xc2, 0xf6, 0x5f, 0xee,
++    0xe6, 0xba, 0x87, 0x74, 0x2e, 0xc7, 0x0c, 0xd4, 0x42, 0xb8, 0x66, 0x85,
++    0x9c, 0x7b, 0x24, 0x61, 0xaa, 0x16, 0x11, 0xf6, 0xb5, 0xb6, 0xa4, 0x0a,
++    0xc9, 0x55, 0x2e, 0x81, 0xa5, 0x47, 0x61, 0xcb, 0x25, 0x8f, 0xc2, 0x15,
++    0x7b, 0x0e, 0x7c, 0x36, 0x9f, 0x3a, 0xda, 0x58, 0x86, 0x1c, 0x5b, 0x83,
++    0x79, 0xe6, 0x2b, 0xcc, 0xe6, 0xfa, 0x2c, 0x61, 0xf2, 0x78, 0x80, 0x1b,
++    0xe2, 0xf3, 0x9d, 0x39, 0x2b, 0x65, 0x57, 0x91, 0x3d, 0x71, 0x99, 0x73,
++    0xa5, 0xc2, 0x79, 0x20, 0x8c, 0x07, 0x4f, 0xe5, 0xb4, 0x60, 0x1f, 0x99,
++    0xa2, 0xb1, 0x4f, 0x0c, 0xef, 0xbc, 0x59, 0x53, 0x00, 0x7d, 0xb1, 0x02,
++    0x41, 0x00, 0xfc, 0x7e, 0x23, 0x65, 0x70, 0xf8, 0xce, 0xd3, 0x40, 0x41,
++    0x80, 0x6a, 0x1d, 0x01, 0xd6, 0x01, 0xff, 0xb6, 0x1b, 0x3d, 0x3d, 0x59,
++    0x09, 0x33, 0x79, 0xc0, 0x4f, 0xde, 0x96, 0x27, 0x4b, 0x18, 0xc6, 0xd9,
++    0x78, 0xf1, 0xf4, 0x35, 0x46, 0xe9, 0x7c, 0x42, 0x7a, 0x5d, 0x9f, 0xef,
++    0x54, 0xb8, 0xf7, 0x9f, 0xc4, 0x33, 0x6c, 0xf3, 0x8c, 0x32, 0x46, 0x87,
++    0x67, 0x30, 0x7b, 0xa7, 0xac, 0xe3, 0x02, 0x41, 0x00, 0xfc, 0x2c, 0xdf,
++    0x0c, 0x0d, 0x88, 0xf5, 0xb1, 0x92, 0xa8, 0x93, 0x47, 0x63, 0x55, 0xf5,
++    0xca, 0x58, 0x43, 0xba, 0x1c, 0xe5, 0x9e, 0xb6, 0x95, 0x05, 0xcd, 0xb5,
++    0x82, 0xdf, 0xeb, 0x04, 0x53, 0x9d, 0xbd, 0xc2, 0x38, 0x16, 0xb3, 0x62,
++    0xdd, 0xa1, 0x46, 0xdb, 0x6d, 0x97, 0x93, 0x9f, 0x8a, 0xc3, 0x9b, 0x64,
++    0x7e, 0x42, 0xe3, 0x32, 0x57, 0x19, 0x1b, 0xd5, 0x6e, 0x85, 0xfa, 0xb8,
++    0x8d, 0x02, 0x41, 0x00, 0xbc, 0x3d, 0xde, 0x6d, 0xd6, 0x97, 0xe8, 0xba,
++    0x9e, 0x81, 0x37, 0x17, 0xe5, 0xa0, 0x64, 0xc9, 0x00, 0xb7, 0xe7, 0xfe,
++    0xf4, 0x29, 0xd9, 0x2e, 0x43, 0x6b, 0x19, 0x20, 0xbd, 0x99, 0x75, 0xe7,
++    0x76, 0xf8, 0xd3, 0xae, 0xaf, 0x7e, 0xb8, 0xeb, 0x81, 0xf4, 0x9d, 0xfe,
++    0x07, 0x2b, 0x0b, 0x63, 0x0b, 0x5a, 0x55, 0x90, 0x71, 0x7d, 0xf1, 0xdb,
++    0xd9, 0xb1, 0x41, 0x41, 0x68, 0x2f, 0x4e, 0x39, 0x02, 0x40, 0x5a, 0x34,
++    0x66, 0xd8, 0xf5, 0xe2, 0x7f, 0x18, 0xb5, 0x00, 0x6e, 0x26, 0x84, 0x27,
++    0x14, 0x93, 0xfb, 0xfc, 0xc6, 0x0f, 0x5e, 0x27, 0xe6, 0xe1, 0xe9, 0xc0,
++    0x8a, 0xe4, 0x34, 0xda, 0xe9, 0xa2, 0x4b, 0x73, 0xbc, 0x8c, 0xb9, 0xba,
++    0x13, 0x6c, 0x7a, 0x2b, 0x51, 0x84, 0xa3, 0x4a, 0xe0, 0x30, 0x10, 0x06,
++    0x7e, 0xed, 0x17, 0x5a, 0x14, 0x00, 0xc9, 0xef, 0x85, 0xea, 0x52, 0x2c,
++    0xbc, 0x65, 0x02, 0x40, 0x51, 0xe3, 0xf2, 0x83, 0x19, 0x9b, 0xc4, 0x1e,
++    0x2f, 0x50, 0x3d, 0xdf, 0x5a, 0xa2, 0x18, 0xca, 0x5f, 0x2e, 0x49, 0xaf,
++    0x6f, 0xcc, 0xfa, 0x65, 0x77, 0x94, 0xb5, 0xa1, 0x0a, 0xa9, 0xd1, 0x8a,
++    0x39, 0x37, 0xf4, 0x0b, 0xa0, 0xd7, 0x82, 0x27, 0x5e, 0xae, 0x17, 0x17,
++    0xa1, 0x1e, 0x54, 0x34, 0xbf, 0x6e, 0xc4, 0x8e, 0x99, 0x5d, 0x08, 0xf1,
++    0x2d, 0x86, 0x9d, 0xa5, 0x20, 0x1b, 0xe5, 0xdf
+ };
+ 
+ /*
+@@ -715,1073 +158,95 @@ static const unsigned char kExampleDSAKeyDER[] = {
+  * components are not correct.
+  */
+ static const unsigned char kExampleBadRSAKeyDER[] = {
+-    0x30,
+-    0x82,
+-    0x04,
+-    0x27,
+-    0x02,
+-    0x01,
+-    0x00,
+-    0x02,
+-    0x82,
+-    0x01,
+-    0x01,
+-    0x00,
+-    0xa6,
+-    0x1a,
+-    0x1e,
+-    0x6e,
+-    0x7b,
+-    0xee,
+-    0xc6,
+-    0x89,
+-    0x66,
+-    0xe7,
+-    0x93,
+-    0xef,
+-    0x54,
+-    0x12,
+-    0x68,
+-    0xea,
+-    0xbf,
+-    0x86,
+-    0x2f,
+-    0xdd,
+-    0xd2,
+-    0x79,
+-    0xb8,
+-    0xa9,
+-    0x6e,
+-    0x03,
+-    0xc2,
+-    0xa3,
+-    0xb9,
+-    0xa3,
+-    0xe1,
+-    0x4b,
+-    0x2a,
+-    0xb3,
+-    0xf8,
+-    0xb4,
+-    0xcd,
+-    0xea,
+-    0xbe,
+-    0x24,
+-    0xa6,
+-    0x57,
+-    0x5b,
+-    0x83,
+-    0x1f,
+-    0x0f,
+-    0xf2,
+-    0xd3,
+-    0xb7,
+-    0xac,
+-    0x7e,
+-    0xd6,
+-    0x8e,
+-    0x6e,
+-    0x1e,
+-    0xbf,
+-    0xb8,
+-    0x73,
+-    0x8c,
+-    0x05,
+-    0x56,
+-    0xe6,
+-    0x35,
+-    0x1f,
+-    0xe9,
+-    0x04,
+-    0x0b,
+-    0x09,
+-    0x86,
+-    0x7d,
+-    0xf1,
+-    0x26,
+-    0x08,
+-    0x99,
+-    0xad,
+-    0x7b,
+-    0xc8,
+-    0x4d,
+-    0x94,
+-    0xb0,
+-    0x0b,
+-    0x8b,
+-    0x38,
+-    0xa0,
+-    0x5c,
+-    0x62,
+-    0xa0,
+-    0xab,
+-    0xd3,
+-    0x8f,
+-    0xd4,
+-    0x09,
+-    0x60,
+-    0x72,
+-    0x1e,
+-    0x33,
+-    0x50,
+-    0x80,
+-    0x6e,
+-    0x22,
+-    0xa6,
+-    0x77,
+-    0x57,
+-    0x6b,
+-    0x9a,
+-    0x33,
+-    0x21,
+-    0x66,
+-    0x87,
+-    0x6e,
+-    0x21,
+-    0x7b,
+-    0xc7,
+-    0x24,
+-    0x0e,
+-    0xd8,
+-    0x13,
+-    0xdf,
+-    0x83,
+-    0xde,
+-    0xcd,
+-    0x40,
+-    0x58,
+-    0x1d,
+-    0x84,
+-    0x86,
+-    0xeb,
+-    0xb8,
+-    0x12,
+-    0x4e,
+-    0xd2,
+-    0xfa,
+-    0x80,
+-    0x1f,
+-    0xe4,
+-    0xe7,
+-    0x96,
+-    0x29,
+-    0xb8,
+-    0xcc,
+-    0xce,
+-    0x66,
+-    0x6d,
+-    0x53,
+-    0xca,
+-    0xb9,
+-    0x5a,
+-    0xd7,
+-    0xf6,
+-    0x84,
+-    0x6c,
+-    0x2d,
+-    0x9a,
+-    0x1a,
+-    0x14,
+-    0x1c,
+-    0x4e,
+-    0x93,
+-    0x39,
+-    0xba,
+-    0x74,
+-    0xed,
+-    0xed,
+-    0x87,
+-    0x87,
+-    0x5e,
+-    0x48,
+-    0x75,
+-    0x36,
+-    0xf0,
+-    0xbc,
+-    0x34,
+-    0xfb,
+-    0x29,
+-    0xf9,
+-    0x9f,
+-    0x96,
+-    0x5b,
+-    0x0b,
+-    0xa7,
+-    0x54,
+-    0x30,
+-    0x51,
+-    0x29,
+-    0x18,
+-    0x5b,
+-    0x7d,
+-    0xac,
+-    0x0f,
+-    0xd6,
+-    0x5f,
+-    0x7c,
+-    0xf8,
+-    0x98,
+-    0x8c,
+-    0xd8,
+-    0x86,
+-    0x62,
+-    0xb3,
+-    0xdc,
+-    0xff,
+-    0x0f,
+-    0xff,
+-    0x7a,
+-    0xaf,
+-    0x5c,
+-    0x4c,
+-    0x61,
+-    0x49,
+-    0x2e,
+-    0xc8,
+-    0x95,
+-    0x86,
+-    0xc4,
+-    0x0e,
+-    0x87,
+-    0xfc,
+-    0x1d,
+-    0xcf,
+-    0x8b,
+-    0x7c,
+-    0x61,
+-    0xf6,
+-    0xd8,
+-    0xd0,
+-    0x69,
+-    0xf6,
+-    0xcd,
+-    0x8a,
+-    0x8c,
+-    0xf6,
+-    0x62,
+-    0xa2,
+-    0x56,
+-    0xa9,
+-    0xe3,
+-    0xd1,
+-    0xcf,
+-    0x4d,
+-    0xa0,
+-    0xf6,
+-    0x2d,
+-    0x20,
+-    0x0a,
+-    0x04,
+-    0xb7,
+-    0xa2,
+-    0xf7,
+-    0xb5,
+-    0x99,
+-    0x47,
+-    0x18,
+-    0x56,
+-    0x85,
+-    0x87,
+-    0xc7,
+-    0x02,
+-    0x03,
+-    0x01,
+-    0x00,
+-    0x01,
+-    0x02,
+-    0x82,
+-    0x01,
+-    0x01,
+-    0x00,
+-    0x99,
+-    0x41,
+-    0x38,
+-    0x1a,
+-    0xd0,
+-    0x96,
+-    0x7a,
+-    0xf0,
+-    0x83,
+-    0xd5,
+-    0xdf,
+-    0x94,
+-    0xce,
+-    0x89,
+-    0x3d,
+-    0xec,
+-    0x7a,
+-    0x52,
+-    0x21,
+-    0x10,
+-    0x16,
+-    0x06,
+-    0xe0,
+-    0xee,
+-    0xd2,
+-    0xe6,
+-    0xfd,
+-    0x4b,
+-    0x7b,
+-    0x19,
+-    0x4d,
+-    0xe1,
+-    0xc0,
+-    0xc0,
+-    0xd5,
+-    0x14,
+-    0x5d,
+-    0x79,
+-    0xdd,
+-    0x7e,
+-    0x8b,
+-    0x4b,
+-    0xc6,
+-    0xcf,
+-    0xb0,
+-    0x75,
+-    0x52,
+-    0xa3,
+-    0x2d,
+-    0xb1,
+-    0x26,
+-    0x46,
+-    0x68,
+-    0x9c,
+-    0x0a,
+-    0x1a,
+-    0xf2,
+-    0xe1,
+-    0x09,
+-    0xac,
+-    0x53,
+-    0x85,
+-    0x8c,
+-    0x36,
+-    0xa9,
+-    0x14,
+-    0x65,
+-    0xea,
+-    0xa0,
+-    0x00,
+-    0xcb,
+-    0xe3,
+-    0x3f,
+-    0xc4,
+-    0x2b,
+-    0x61,
+-    0x2e,
+-    0x6b,
+-    0x06,
+-    0x69,
+-    0x77,
+-    0xfd,
+-    0x38,
+-    0x7e,
+-    0x1d,
+-    0x3f,
+-    0x92,
+-    0xe7,
+-    0x77,
+-    0x08,
+-    0x19,
+-    0xa7,
+-    0x9d,
+-    0x29,
+-    0x2d,
+-    0xdc,
+-    0x42,
+-    0xc6,
+-    0x7c,
+-    0xd7,
+-    0xd3,
+-    0xa8,
+-    0x01,
+-    0x2c,
+-    0xf2,
+-    0xd5,
+-    0x82,
+-    0x57,
+-    0xcb,
+-    0x55,
+-    0x3d,
+-    0xe7,
+-    0xaa,
+-    0xd2,
+-    0x06,
+-    0x30,
+-    0x30,
+-    0x05,
+-    0xe6,
+-    0xf2,
+-    0x47,
+-    0x86,
+-    0xba,
+-    0xc6,
+-    0x61,
+-    0x64,
+-    0xeb,
+-    0x4f,
+-    0x2a,
+-    0x5e,
+-    0x07,
+-    0x29,
+-    0xe0,
+-    0x96,
+-    0xb2,
+-    0x43,
+-    0xff,
+-    0x5f,
+-    0x1a,
+-    0x54,
+-    0x16,
+-    0xcf,
+-    0xb5,
+-    0x56,
+-    0x5c,
+-    0xa0,
+-    0x9b,
+-    0x0c,
+-    0xfd,
+-    0xb3,
+-    0xd2,
+-    0xe3,
+-    0x79,
+-    0x1d,
+-    0x21,
+-    0xe2,
+-    0xd6,
+-    0x13,
+-    0xc4,
+-    0x74,
+-    0xa6,
+-    0xf5,
+-    0x8e,
+-    0x8e,
+-    0x81,
+-    0xbb,
+-    0xb4,
+-    0xad,
+-    0x8a,
+-    0xf0,
+-    0x93,
+-    0x0a,
+-    0xd8,
+-    0x0a,
+-    0x42,
+-    0x36,
+-    0xbc,
+-    0xe5,
+-    0x26,
+-    0x2a,
+-    0x0d,
+-    0x5d,
+-    0x57,
+-    0x13,
+-    0xc5,
+-    0x4e,
+-    0x2f,
+-    0x12,
+-    0x0e,
+-    0xef,
+-    0xa7,
+-    0x81,
+-    0x1e,
+-    0xc3,
+-    0xa5,
+-    0xdb,
+-    0xc9,
+-    0x24,
+-    0xeb,
+-    0x1a,
+-    0xa1,
+-    0xf9,
+-    0xf6,
+-    0xa1,
+-    0x78,
+-    0x98,
+-    0x93,
+-    0x77,
+-    0x42,
+-    0x45,
+-    0x03,
+-    0xe2,
+-    0xc9,
+-    0xa2,
+-    0xfe,
+-    0x2d,
+-    0x77,
+-    0xc8,
+-    0xc6,
+-    0xac,
+-    0x9b,
+-    0x98,
+-    0x89,
+-    0x6d,
+-    0x9a,
+-    0xe7,
+-    0x61,
+-    0x63,
+-    0xb7,
+-    0xf2,
+-    0xec,
+-    0xd6,
+-    0xb1,
+-    0xa1,
+-    0x6e,
+-    0x0a,
+-    0x1a,
+-    0xff,
+-    0xfd,
+-    0x43,
+-    0x28,
+-    0xc3,
+-    0x0c,
+-    0xdc,
+-    0xf2,
+-    0x47,
+-    0x4f,
+-    0x27,
+-    0xaa,
+-    0x99,
+-    0x04,
+-    0x8e,
+-    0xac,
+-    0xe8,
+-    0x7c,
+-    0x01,
+-    0x02,
+-    0x04,
+-    0x12,
+-    0x34,
+-    0x56,
+-    0x78,
+-    0x02,
+-    0x81,
+-    0x81,
+-    0x00,
+-    0xca,
+-    0x69,
+-    0xe5,
+-    0xbb,
+-    0x3a,
+-    0x90,
+-    0x82,
+-    0xcb,
+-    0x82,
+-    0x50,
+-    0x2f,
+-    0x29,
+-    0xe2,
+-    0x76,
+-    0x6a,
+-    0x57,
+-    0x55,
+-    0x45,
+-    0x4e,
+-    0x35,
+-    0x18,
+-    0x61,
+-    0xe0,
+-    0x12,
+-    0x70,
+-    0xc0,
+-    0xab,
+-    0xc7,
+-    0x80,
+-    0xa2,
+-    0xd4,
+-    0x46,
+-    0x34,
+-    0x03,
+-    0xa0,
+-    0x19,
+-    0x26,
+-    0x23,
+-    0x9e,
+-    0xef,
+-    0x1a,
+-    0xcb,
+-    0x75,
+-    0xd6,
+-    0xba,
+-    0x81,
+-    0xf4,
+-    0x7e,
+-    0x52,
+-    0xe5,
+-    0x2a,
+-    0xe8,
+-    0xf1,
+-    0x49,
+-    0x6c,
+-    0x0f,
+-    0x1a,
+-    0xa0,
+-    0xf9,
+-    0xc6,
+-    0xe7,
+-    0xec,
+-    0x60,
+-    0xe4,
+-    0xcb,
+-    0x2a,
+-    0xb5,
+-    0x56,
+-    0xe9,
+-    0x9c,
+-    0xcd,
+-    0x19,
+-    0x75,
+-    0x92,
+-    0xb1,
+-    0x66,
+-    0xce,
+-    0xc3,
+-    0xd9,
+-    0x3d,
+-    0x11,
+-    0xcb,
+-    0xc4,
+-    0x09,
+-    0xce,
+-    0x1e,
+-    0x30,
+-    0xba,
+-    0x2f,
+-    0x60,
+-    0x60,
+-    0x55,
+-    0x8d,
+-    0x02,
+-    0xdc,
+-    0x5d,
+-    0xaf,
+-    0xf7,
+-    0x52,
+-    0x31,
+-    0x17,
+-    0x07,
+-    0x53,
+-    0x20,
+-    0x33,
+-    0xad,
+-    0x8c,
+-    0xd5,
+-    0x2f,
+-    0x5a,
+-    0xd0,
+-    0x57,
+-    0xd7,
+-    0xd1,
+-    0x80,
+-    0xd6,
+-    0x3a,
+-    0x9b,
+-    0x04,
+-    0x4f,
+-    0x35,
+-    0xbf,
+-    0xe7,
+-    0xd5,
+-    0xbc,
+-    0x8f,
+-    0xd4,
+-    0x81,
+-    0x02,
+-    0x81,
+-    0x81,
+-    0x00,
+-    0xc0,
+-    0x9f,
+-    0xf8,
+-    0xcd,
+-    0xf7,
+-    0x3f,
+-    0x26,
+-    0x8a,
+-    0x3d,
+-    0x4d,
+-    0x2b,
+-    0x0c,
+-    0x01,
+-    0xd0,
+-    0xa2,
+-    0xb4,
+-    0x18,
+-    0xfe,
+-    0xf7,
+-    0x5e,
+-    0x2f,
+-    0x06,
+-    0x13,
+-    0xcd,
+-    0x63,
+-    0xaa,
+-    0x12,
+-    0xa9,
+-    0x24,
+-    0x86,
+-    0xe3,
+-    0xf3,
+-    0x7b,
+-    0xda,
+-    0x1a,
+-    0x3c,
+-    0xb1,
+-    0x38,
+-    0x80,
+-    0x80,
+-    0xef,
+-    0x64,
+-    0x64,
+-    0xa1,
+-    0x9b,
+-    0xfe,
+-    0x76,
+-    0x63,
+-    0x8e,
+-    0x83,
+-    0xd2,
+-    0xd9,
+-    0xb9,
+-    0x86,
+-    0xb0,
+-    0xe6,
+-    0xa6,
+-    0x0c,
+-    0x7e,
+-    0xa8,
+-    0x84,
+-    0x90,
+-    0x98,
+-    0x0c,
+-    0x1e,
+-    0xf3,
+-    0x14,
+-    0x77,
+-    0xe0,
+-    0x5f,
+-    0x81,
+-    0x08,
+-    0x11,
+-    0x8f,
+-    0xa6,
+-    0x23,
+-    0xc4,
+-    0xba,
+-    0xc0,
+-    0x8a,
+-    0xe4,
+-    0xc6,
+-    0xe3,
+-    0x5c,
+-    0xbe,
+-    0xc5,
+-    0xec,
+-    0x2c,
+-    0xb9,
+-    0xd8,
+-    0x8c,
+-    0x4d,
+-    0x1a,
+-    0x9d,
+-    0xe7,
+-    0x7c,
+-    0x85,
+-    0x4c,
+-    0x0d,
+-    0x71,
+-    0x4e,
+-    0x72,
+-    0x33,
+-    0x1b,
+-    0xfe,
+-    0xa9,
+-    0x17,
+-    0x72,
+-    0x76,
+-    0x56,
+-    0x9d,
+-    0x74,
+-    0x7e,
+-    0x52,
+-    0x67,
+-    0x9a,
+-    0x87,
+-    0x9a,
+-    0xdb,
+-    0x30,
+-    0xde,
+-    0xe4,
+-    0x49,
+-    0x28,
+-    0x3b,
+-    0xd2,
+-    0x67,
+-    0xaf,
+-    0x02,
+-    0x81,
+-    0x81,
+-    0x00,
+-    0x89,
+-    0x74,
+-    0x9a,
+-    0x8e,
+-    0xa7,
+-    0xb9,
+-    0xa5,
+-    0x28,
+-    0xc0,
+-    0x68,
+-    0xe5,
+-    0x6e,
+-    0x63,
+-    0x1c,
+-    0x99,
+-    0x20,
+-    0x8f,
+-    0x86,
+-    0x8e,
+-    0x12,
+-    0x9e,
+-    0x69,
+-    0x30,
+-    0xfa,
+-    0x34,
+-    0xd9,
+-    0x92,
+-    0x8d,
+-    0xdb,
+-    0x7c,
+-    0x37,
+-    0xfd,
+-    0x28,
+-    0xab,
+-    0x61,
+-    0x98,
+-    0x52,
+-    0x7f,
+-    0x14,
+-    0x1a,
+-    0x39,
+-    0xae,
+-    0xfb,
+-    0x6a,
+-    0x03,
+-    0xa3,
+-    0xe6,
+-    0xbd,
+-    0xb6,
+-    0x5b,
+-    0x6b,
+-    0xe5,
+-    0x5e,
+-    0x9d,
+-    0xc6,
+-    0xa5,
+-    0x07,
+-    0x27,
+-    0x54,
+-    0x17,
+-    0xd0,
+-    0x3d,
+-    0x84,
+-    0x9b,
+-    0x3a,
+-    0xa0,
+-    0xd9,
+-    0x1e,
+-    0x99,
+-    0x6c,
+-    0x63,
+-    0x17,
+-    0xab,
+-    0xf1,
+-    0x1f,
+-    0x49,
+-    0xba,
+-    0x95,
+-    0xe3,
+-    0x3b,
+-    0x86,
+-    0x8f,
+-    0x42,
+-    0xa4,
+-    0x89,
+-    0xf5,
+-    0x94,
+-    0x8f,
+-    0x8b,
+-    0x46,
+-    0xbe,
+-    0x84,
+-    0xba,
+-    0x4a,
+-    0xbc,
+-    0x0d,
+-    0x5f,
+-    0x46,
+-    0xeb,
+-    0xe8,
+-    0xec,
+-    0x43,
+-    0x8c,
+-    0x1e,
+-    0xad,
+-    0x19,
+-    0x69,
+-    0x2f,
+-    0x08,
+-    0x86,
+-    0x7a,
+-    0x3f,
+-    0x7d,
+-    0x0f,
+-    0x07,
+-    0x97,
+-    0xf3,
+-    0x9a,
+-    0x7b,
+-    0xb5,
+-    0xb2,
+-    0xc1,
+-    0x8c,
+-    0x95,
+-    0x68,
+-    0x04,
+-    0xa0,
+-    0x81,
+-    0x02,
+-    0x81,
+-    0x80,
+-    0x4e,
+-    0xbf,
+-    0x7e,
+-    0x1b,
+-    0xcb,
+-    0x13,
+-    0x61,
+-    0x75,
+-    0x3b,
+-    0xdb,
+-    0x59,
+-    0x5f,
+-    0xb1,
+-    0xd4,
+-    0xb8,
+-    0xeb,
+-    0x9e,
+-    0x73,
+-    0xb5,
+-    0xe7,
+-    0xf6,
+-    0x89,
+-    0x3d,
+-    0x1c,
+-    0xda,
+-    0xf0,
+-    0x36,
+-    0xff,
+-    0x35,
+-    0xbd,
+-    0x1e,
+-    0x0b,
+-    0x74,
+-    0xe3,
+-    0x9e,
+-    0xf0,
+-    0xf2,
+-    0xf7,
+-    0xd7,
+-    0x82,
+-    0xb7,
+-    0x7b,
+-    0x6a,
+-    0x1b,
+-    0x0e,
+-    0x30,
+-    0x4a,
+-    0x98,
+-    0x0e,
+-    0xb4,
+-    0xf9,
+-    0x81,
+-    0x07,
+-    0xe4,
+-    0x75,
+-    0x39,
+-    0xe9,
+-    0x53,
+-    0xca,
+-    0xbb,
+-    0x5c,
+-    0xaa,
+-    0x93,
+-    0x07,
+-    0x0e,
+-    0xa8,
+-    0x2f,
+-    0xba,
+-    0x98,
+-    0x49,
+-    0x30,
+-    0xa7,
+-    0xcc,
+-    0x1a,
+-    0x3c,
+-    0x68,
+-    0x0c,
+-    0xe1,
+-    0xa4,
+-    0xb1,
+-    0x05,
+-    0xe6,
+-    0xe0,
+-    0x25,
+-    0x78,
+-    0x58,
+-    0x14,
+-    0x37,
+-    0xf5,
+-    0x1f,
+-    0xe3,
+-    0x22,
+-    0xef,
+-    0xa8,
+-    0x0e,
+-    0x22,
+-    0xa0,
+-    0x94,
+-    0x3a,
+-    0xf6,
+-    0xc9,
+-    0x13,
+-    0xe6,
+-    0x06,
+-    0xbf,
+-    0x7f,
+-    0x99,
+-    0xc6,
+-    0xcc,
+-    0xd8,
+-    0xc6,
+-    0xbe,
+-    0xd9,
+-    0x2e,
+-    0x24,
+-    0xc7,
+-    0x69,
+-    0x8c,
+-    0x95,
+-    0xba,
+-    0xf6,
+-    0x04,
+-    0xb3,
+-    0x0a,
+-    0xf4,
+-    0xcb,
+-    0xf0,
+-    0xce,
++    0x30, 0x82, 0x04, 0x27, 0x02, 0x01, 0x00, 0x02, 0x82, 0x01, 0x01, 0x00,
++    0xa6, 0x1a, 0x1e, 0x6e, 0x7b, 0xee, 0xc6, 0x89, 0x66, 0xe7, 0x93, 0xef,
++    0x54, 0x12, 0x68, 0xea, 0xbf, 0x86, 0x2f, 0xdd, 0xd2, 0x79, 0xb8, 0xa9,
++    0x6e, 0x03, 0xc2, 0xa3, 0xb9, 0xa3, 0xe1, 0x4b, 0x2a, 0xb3, 0xf8, 0xb4,
++    0xcd, 0xea, 0xbe, 0x24, 0xa6, 0x57, 0x5b, 0x83, 0x1f, 0x0f, 0xf2, 0xd3,
++    0xb7, 0xac, 0x7e, 0xd6, 0x8e, 0x6e, 0x1e, 0xbf, 0xb8, 0x73, 0x8c, 0x05,
++    0x56, 0xe6, 0x35, 0x1f, 0xe9, 0x04, 0x0b, 0x09, 0x86, 0x7d, 0xf1, 0x26,
++    0x08, 0x99, 0xad, 0x7b, 0xc8, 0x4d, 0x94, 0xb0, 0x0b, 0x8b, 0x38, 0xa0,
++    0x5c, 0x62, 0xa0, 0xab, 0xd3, 0x8f, 0xd4, 0x09, 0x60, 0x72, 0x1e, 0x33,
++    0x50, 0x80, 0x6e, 0x22, 0xa6, 0x77, 0x57, 0x6b, 0x9a, 0x33, 0x21, 0x66,
++    0x87, 0x6e, 0x21, 0x7b, 0xc7, 0x24, 0x0e, 0xd8, 0x13, 0xdf, 0x83, 0xde,
++    0xcd, 0x40, 0x58, 0x1d, 0x84, 0x86, 0xeb, 0xb8, 0x12, 0x4e, 0xd2, 0xfa,
++    0x80, 0x1f, 0xe4, 0xe7, 0x96, 0x29, 0xb8, 0xcc, 0xce, 0x66, 0x6d, 0x53,
++    0xca, 0xb9, 0x5a, 0xd7, 0xf6, 0x84, 0x6c, 0x2d, 0x9a, 0x1a, 0x14, 0x1c,
++    0x4e, 0x93, 0x39, 0xba, 0x74, 0xed, 0xed, 0x87, 0x87, 0x5e, 0x48, 0x75,
++    0x36, 0xf0, 0xbc, 0x34, 0xfb, 0x29, 0xf9, 0x9f, 0x96, 0x5b, 0x0b, 0xa7,
++    0x54, 0x30, 0x51, 0x29, 0x18, 0x5b, 0x7d, 0xac, 0x0f, 0xd6, 0x5f, 0x7c,
++    0xf8, 0x98, 0x8c, 0xd8, 0x86, 0x62, 0xb3, 0xdc, 0xff, 0x0f, 0xff, 0x7a,
++    0xaf, 0x5c, 0x4c, 0x61, 0x49, 0x2e, 0xc8, 0x95, 0x86, 0xc4, 0x0e, 0x87,
++    0xfc, 0x1d, 0xcf, 0x8b, 0x7c, 0x61, 0xf6, 0xd8, 0xd0, 0x69, 0xf6, 0xcd,
++    0x8a, 0x8c, 0xf6, 0x62, 0xa2, 0x56, 0xa9, 0xe3, 0xd1, 0xcf, 0x4d, 0xa0,
++    0xf6, 0x2d, 0x20, 0x0a, 0x04, 0xb7, 0xa2, 0xf7, 0xb5, 0x99, 0x47, 0x18,
++    0x56, 0x85, 0x87, 0xc7, 0x02, 0x03, 0x01, 0x00, 0x01, 0x02, 0x82, 0x01,
++    0x01, 0x00, 0x99, 0x41, 0x38, 0x1a, 0xd0, 0x96, 0x7a, 0xf0, 0x83, 0xd5,
++    0xdf, 0x94, 0xce, 0x89, 0x3d, 0xec, 0x7a, 0x52, 0x21, 0x10, 0x16, 0x06,
++    0xe0, 0xee, 0xd2, 0xe6, 0xfd, 0x4b, 0x7b, 0x19, 0x4d, 0xe1, 0xc0, 0xc0,
++    0xd5, 0x14, 0x5d, 0x79, 0xdd, 0x7e, 0x8b, 0x4b, 0xc6, 0xcf, 0xb0, 0x75,
++    0x52, 0xa3, 0x2d, 0xb1, 0x26, 0x46, 0x68, 0x9c, 0x0a, 0x1a, 0xf2, 0xe1,
++    0x09, 0xac, 0x53, 0x85, 0x8c, 0x36, 0xa9, 0x14, 0x65, 0xea, 0xa0, 0x00,
++    0xcb, 0xe3, 0x3f, 0xc4, 0x2b, 0x61, 0x2e, 0x6b, 0x06, 0x69, 0x77, 0xfd,
++    0x38, 0x7e, 0x1d, 0x3f, 0x92, 0xe7, 0x77, 0x08, 0x19, 0xa7, 0x9d, 0x29,
++    0x2d, 0xdc, 0x42, 0xc6, 0x7c, 0xd7, 0xd3, 0xa8, 0x01, 0x2c, 0xf2, 0xd5,
++    0x82, 0x57, 0xcb, 0x55, 0x3d, 0xe7, 0xaa, 0xd2, 0x06, 0x30, 0x30, 0x05,
++    0xe6, 0xf2, 0x47, 0x86, 0xba, 0xc6, 0x61, 0x64, 0xeb, 0x4f, 0x2a, 0x5e,
++    0x07, 0x29, 0xe0, 0x96, 0xb2, 0x43, 0xff, 0x5f, 0x1a, 0x54, 0x16, 0xcf,
++    0xb5, 0x56, 0x5c, 0xa0, 0x9b, 0x0c, 0xfd, 0xb3, 0xd2, 0xe3, 0x79, 0x1d,
++    0x21, 0xe2, 0xd6, 0x13, 0xc4, 0x74, 0xa6, 0xf5, 0x8e, 0x8e, 0x81, 0xbb,
++    0xb4, 0xad, 0x8a, 0xf0, 0x93, 0x0a, 0xd8, 0x0a, 0x42, 0x36, 0xbc, 0xe5,
++    0x26, 0x2a, 0x0d, 0x5d, 0x57, 0x13, 0xc5, 0x4e, 0x2f, 0x12, 0x0e, 0xef,
++    0xa7, 0x81, 0x1e, 0xc3, 0xa5, 0xdb, 0xc9, 0x24, 0xeb, 0x1a, 0xa1, 0xf9,
++    0xf6, 0xa1, 0x78, 0x98, 0x93, 0x77, 0x42, 0x45, 0x03, 0xe2, 0xc9, 0xa2,
++    0xfe, 0x2d, 0x77, 0xc8, 0xc6, 0xac, 0x9b, 0x98, 0x89, 0x6d, 0x9a, 0xe7,
++    0x61, 0x63, 0xb7, 0xf2, 0xec, 0xd6, 0xb1, 0xa1, 0x6e, 0x0a, 0x1a, 0xff,
++    0xfd, 0x43, 0x28, 0xc3, 0x0c, 0xdc, 0xf2, 0x47, 0x4f, 0x27, 0xaa, 0x99,
++    0x04, 0x8e, 0xac, 0xe8, 0x7c, 0x01, 0x02, 0x04, 0x12, 0x34, 0x56, 0x78,
++    0x02, 0x81, 0x81, 0x00, 0xca, 0x69, 0xe5, 0xbb, 0x3a, 0x90, 0x82, 0xcb,
++    0x82, 0x50, 0x2f, 0x29, 0xe2, 0x76, 0x6a, 0x57, 0x55, 0x45, 0x4e, 0x35,
++    0x18, 0x61, 0xe0, 0x12, 0x70, 0xc0, 0xab, 0xc7, 0x80, 0xa2, 0xd4, 0x46,
++    0x34, 0x03, 0xa0, 0x19, 0x26, 0x23, 0x9e, 0xef, 0x1a, 0xcb, 0x75, 0xd6,
++    0xba, 0x81, 0xf4, 0x7e, 0x52, 0xe5, 0x2a, 0xe8, 0xf1, 0x49, 0x6c, 0x0f,
++    0x1a, 0xa0, 0xf9, 0xc6, 0xe7, 0xec, 0x60, 0xe4, 0xcb, 0x2a, 0xb5, 0x56,
++    0xe9, 0x9c, 0xcd, 0x19, 0x75, 0x92, 0xb1, 0x66, 0xce, 0xc3, 0xd9, 0x3d,
++    0x11, 0xcb, 0xc4, 0x09, 0xce, 0x1e, 0x30, 0xba, 0x2f, 0x60, 0x60, 0x55,
++    0x8d, 0x02, 0xdc, 0x5d, 0xaf, 0xf7, 0x52, 0x31, 0x17, 0x07, 0x53, 0x20,
++    0x33, 0xad, 0x8c, 0xd5, 0x2f, 0x5a, 0xd0, 0x57, 0xd7, 0xd1, 0x80, 0xd6,
++    0x3a, 0x9b, 0x04, 0x4f, 0x35, 0xbf, 0xe7, 0xd5, 0xbc, 0x8f, 0xd4, 0x81,
++    0x02, 0x81, 0x81, 0x00, 0xc0, 0x9f, 0xf8, 0xcd, 0xf7, 0x3f, 0x26, 0x8a,
++    0x3d, 0x4d, 0x2b, 0x0c, 0x01, 0xd0, 0xa2, 0xb4, 0x18, 0xfe, 0xf7, 0x5e,
++    0x2f, 0x06, 0x13, 0xcd, 0x63, 0xaa, 0x12, 0xa9, 0x24, 0x86, 0xe3, 0xf3,
++    0x7b, 0xda, 0x1a, 0x3c, 0xb1, 0x38, 0x80, 0x80, 0xef, 0x64, 0x64, 0xa1,
++    0x9b, 0xfe, 0x76, 0x63, 0x8e, 0x83, 0xd2, 0xd9, 0xb9, 0x86, 0xb0, 0xe6,
++    0xa6, 0x0c, 0x7e, 0xa8, 0x84, 0x90, 0x98, 0x0c, 0x1e, 0xf3, 0x14, 0x77,
++    0xe0, 0x5f, 0x81, 0x08, 0x11, 0x8f, 0xa6, 0x23, 0xc4, 0xba, 0xc0, 0x8a,
++    0xe4, 0xc6, 0xe3, 0x5c, 0xbe, 0xc5, 0xec, 0x2c, 0xb9, 0xd8, 0x8c, 0x4d,
++    0x1a, 0x9d, 0xe7, 0x7c, 0x85, 0x4c, 0x0d, 0x71, 0x4e, 0x72, 0x33, 0x1b,
++    0xfe, 0xa9, 0x17, 0x72, 0x76, 0x56, 0x9d, 0x74, 0x7e, 0x52, 0x67, 0x9a,
++    0x87, 0x9a, 0xdb, 0x30, 0xde, 0xe4, 0x49, 0x28, 0x3b, 0xd2, 0x67, 0xaf,
++    0x02, 0x81, 0x81, 0x00, 0x89, 0x74, 0x9a, 0x8e, 0xa7, 0xb9, 0xa5, 0x28,
++    0xc0, 0x68, 0xe5, 0x6e, 0x63, 0x1c, 0x99, 0x20, 0x8f, 0x86, 0x8e, 0x12,
++    0x9e, 0x69, 0x30, 0xfa, 0x34, 0xd9, 0x92, 0x8d, 0xdb, 0x7c, 0x37, 0xfd,
++    0x28, 0xab, 0x61, 0x98, 0x52, 0x7f, 0x14, 0x1a, 0x39, 0xae, 0xfb, 0x6a,
++    0x03, 0xa3, 0xe6, 0xbd, 0xb6, 0x5b, 0x6b, 0xe5, 0x5e, 0x9d, 0xc6, 0xa5,
++    0x07, 0x27, 0x54, 0x17, 0xd0, 0x3d, 0x84, 0x9b, 0x3a, 0xa0, 0xd9, 0x1e,
++    0x99, 0x6c, 0x63, 0x17, 0xab, 0xf1, 0x1f, 0x49, 0xba, 0x95, 0xe3, 0x3b,
++    0x86, 0x8f, 0x42, 0xa4, 0x89, 0xf5, 0x94, 0x8f, 0x8b, 0x46, 0xbe, 0x84,
++    0xba, 0x4a, 0xbc, 0x0d, 0x5f, 0x46, 0xeb, 0xe8, 0xec, 0x43, 0x8c, 0x1e,
++    0xad, 0x19, 0x69, 0x2f, 0x08, 0x86, 0x7a, 0x3f, 0x7d, 0x0f, 0x07, 0x97,
++    0xf3, 0x9a, 0x7b, 0xb5, 0xb2, 0xc1, 0x8c, 0x95, 0x68, 0x04, 0xa0, 0x81,
++    0x02, 0x81, 0x80, 0x4e, 0xbf, 0x7e, 0x1b, 0xcb, 0x13, 0x61, 0x75, 0x3b,
++    0xdb, 0x59, 0x5f, 0xb1, 0xd4, 0xb8, 0xeb, 0x9e, 0x73, 0xb5, 0xe7, 0xf6,
++    0x89, 0x3d, 0x1c, 0xda, 0xf0, 0x36, 0xff, 0x35, 0xbd, 0x1e, 0x0b, 0x74,
++    0xe3, 0x9e, 0xf0, 0xf2, 0xf7, 0xd7, 0x82, 0xb7, 0x7b, 0x6a, 0x1b, 0x0e,
++    0x30, 0x4a, 0x98, 0x0e, 0xb4, 0xf9, 0x81, 0x07, 0xe4, 0x75, 0x39, 0xe9,
++    0x53, 0xca, 0xbb, 0x5c, 0xaa, 0x93, 0x07, 0x0e, 0xa8, 0x2f, 0xba, 0x98,
++    0x49, 0x30, 0xa7, 0xcc, 0x1a, 0x3c, 0x68, 0x0c, 0xe1, 0xa4, 0xb1, 0x05,
++    0xe6, 0xe0, 0x25, 0x78, 0x58, 0x14, 0x37, 0xf5, 0x1f, 0xe3, 0x22, 0xef,
++    0xa8, 0x0e, 0x22, 0xa0, 0x94, 0x3a, 0xf6, 0xc9, 0x13, 0xe6, 0x06, 0xbf,
++    0x7f, 0x99, 0xc6, 0xcc, 0xd8, 0xc6, 0xbe, 0xd9, 0x2e, 0x24, 0xc7, 0x69,
++    0x8c, 0x95, 0xba, 0xf6, 0x04, 0xb3, 0x0a, 0xf4, 0xcb, 0xf0, 0xce
+ };
+ 
+ /*
+@@ -1797,134 +262,17 @@ static const unsigned char kExampleBad2RSAKeyDER[] = {
+ static const unsigned char kMsg[] = { 1, 2, 3, 4 };
+ 
+ static const unsigned char kSignature[] = {
+-    0xa5,
+-    0xf0,
+-    0x8a,
+-    0x47,
+-    0x5d,
+-    0x3c,
+-    0xb3,
+-    0xcc,
+-    0xa9,
+-    0x79,
+-    0xaf,
+-    0x4d,
+-    0x8c,
+-    0xae,
+-    0x4c,
+-    0x14,
+-    0xef,
+-    0xc2,
+-    0x0b,
+-    0x34,
+-    0x36,
+-    0xde,
+-    0xf4,
+-    0x3e,
+-    0x3d,
+-    0xbb,
+-    0x4a,
+-    0x60,
+-    0x5c,
+-    0xc8,
+-    0x91,
+-    0x28,
+-    0xda,
+-    0xfb,
+-    0x7e,
+-    0x04,
+-    0x96,
+-    0x7e,
+-    0x63,
+-    0x13,
+-    0x90,
+-    0xce,
+-    0xb9,
+-    0xb4,
+-    0x62,
+-    0x7a,
+-    0xfd,
+-    0x09,
+-    0x3d,
+-    0xc7,
+-    0x67,
+-    0x78,
+-    0x54,
+-    0x04,
+-    0xeb,
+-    0x52,
+-    0x62,
+-    0x6e,
+-    0x24,
+-    0x67,
+-    0xb4,
+-    0x40,
+-    0xfc,
+-    0x57,
+-    0x62,
+-    0xc6,
+-    0xf1,
+-    0x67,
+-    0xc1,
+-    0x97,
+-    0x8f,
+-    0x6a,
+-    0xa8,
+-    0xae,
+-    0x44,
+-    0x46,
+-    0x5e,
+-    0xab,
+-    0x67,
+-    0x17,
+-    0x53,
+-    0x19,
+-    0x3a,
+-    0xda,
+-    0x5a,
+-    0xc8,
+-    0x16,
+-    0x3e,
+-    0x86,
+-    0xd5,
+-    0xc5,
+-    0x71,
+-    0x2f,
+-    0xfc,
+-    0x23,
+-    0x48,
+-    0xd9,
+-    0x0b,
+-    0x13,
+-    0xdd,
+-    0x7b,
+-    0x5a,
+-    0x25,
+-    0x79,
+-    0xef,
+-    0xa5,
+-    0x7b,
+-    0x04,
+-    0xed,
+-    0x44,
+-    0xf6,
+-    0x18,
+-    0x55,
+-    0xe4,
+-    0x0a,
+-    0xe9,
+-    0x57,
+-    0x79,
+-    0x5d,
+-    0xd7,
+-    0x55,
+-    0xa7,
+-    0xab,
+-    0x45,
+-    0x02,
+-    0x97,
+-    0x60,
+-    0x42,
++    0xa5, 0xf0, 0x8a, 0x47, 0x5d, 0x3c, 0xb3, 0xcc, 0xa9, 0x79, 0xaf, 0x4d,
++    0x8c, 0xae, 0x4c, 0x14, 0xef, 0xc2, 0x0b, 0x34, 0x36, 0xde, 0xf4, 0x3e,
++    0x3d, 0xbb, 0x4a, 0x60, 0x5c, 0xc8, 0x91, 0x28, 0xda, 0xfb, 0x7e, 0x04,
++    0x96, 0x7e, 0x63, 0x13, 0x90, 0xce, 0xb9, 0xb4, 0x62, 0x7a, 0xfd, 0x09,
++    0x3d, 0xc7, 0x67, 0x78, 0x54, 0x04, 0xeb, 0x52, 0x62, 0x6e, 0x24, 0x67,
++    0xb4, 0x40, 0xfc, 0x57, 0x62, 0xc6, 0xf1, 0x67, 0xc1, 0x97, 0x8f, 0x6a,
++    0xa8, 0xae, 0x44, 0x46, 0x5e, 0xab, 0x67, 0x17, 0x53, 0x19, 0x3a, 0xda,
++    0x5a, 0xc8, 0x16, 0x3e, 0x86, 0xd5, 0xc5, 0x71, 0x2f, 0xfc, 0x23, 0x48,
++    0xd9, 0x0b, 0x13, 0xdd, 0x7b, 0x5a, 0x25, 0x79, 0xef, 0xa5, 0x7b, 0x04,
++    0xed, 0x44, 0xf6, 0x18, 0x55, 0xe4, 0x0a, 0xe9, 0x57, 0x79, 0x5d, 0xd7,
++    0x55, 0xa7, 0xab, 0x45, 0x02, 0x97, 0x60, 0x42
+ };
+ 
+ /*
+@@ -1932,640 +280,59 @@ static const unsigned char kSignature[] = {
+  * PrivateKeyInfo.
+  */
+ static const unsigned char kExampleRSAKeyPKCS8[] = {
+-    0x30,
+-    0x82,
+-    0x02,
+-    0x76,
+-    0x02,
+-    0x01,
+-    0x00,
+-    0x30,
+-    0x0d,
+-    0x06,
+-    0x09,
+-    0x2a,
+-    0x86,
+-    0x48,
+-    0x86,
+-    0xf7,
+-    0x0d,
+-    0x01,
+-    0x01,
+-    0x01,
+-    0x05,
+-    0x00,
+-    0x04,
+-    0x82,
+-    0x02,
+-    0x60,
+-    0x30,
+-    0x82,
+-    0x02,
+-    0x5c,
+-    0x02,
+-    0x01,
+-    0x00,
+-    0x02,
+-    0x81,
+-    0x81,
+-    0x00,
+-    0xf8,
+-    0xb8,
+-    0x6c,
+-    0x83,
+-    0xb4,
+-    0xbc,
+-    0xd9,
+-    0xa8,
+-    0x57,
+-    0xc0,
+-    0xa5,
+-    0xb4,
+-    0x59,
+-    0x76,
+-    0x8c,
+-    0x54,
+-    0x1d,
+-    0x79,
+-    0xeb,
+-    0x22,
+-    0x52,
+-    0x04,
+-    0x7e,
+-    0xd3,
+-    0x37,
+-    0xeb,
+-    0x41,
+-    0xfd,
+-    0x83,
+-    0xf9,
+-    0xf0,
+-    0xa6,
+-    0x85,
+-    0x15,
+-    0x34,
+-    0x75,
+-    0x71,
+-    0x5a,
+-    0x84,
+-    0xa8,
+-    0x3c,
+-    0xd2,
+-    0xef,
+-    0x5a,
+-    0x4e,
+-    0xd3,
+-    0xde,
+-    0x97,
+-    0x8a,
+-    0xdd,
+-    0xff,
+-    0xbb,
+-    0xcf,
+-    0x0a,
+-    0xaa,
+-    0x86,
+-    0x92,
+-    0xbe,
+-    0xb8,
+-    0x50,
+-    0xe4,
+-    0xcd,
+-    0x6f,
+-    0x80,
+-    0x33,
+-    0x30,
+-    0x76,
+-    0x13,
+-    0x8f,
+-    0xca,
+-    0x7b,
+-    0xdc,
+-    0xec,
+-    0x5a,
+-    0xca,
+-    0x63,
+-    0xc7,
+-    0x03,
+-    0x25,
+-    0xef,
+-    0xa8,
+-    0x8a,
+-    0x83,
+-    0x58,
+-    0x76,
+-    0x20,
+-    0xfa,
+-    0x16,
+-    0x77,
+-    0xd7,
+-    0x79,
+-    0x92,
+-    0x63,
+-    0x01,
+-    0x48,
+-    0x1a,
+-    0xd8,
+-    0x7b,
+-    0x67,
+-    0xf1,
+-    0x52,
+-    0x55,
+-    0x49,
+-    0x4e,
+-    0xd6,
+-    0x6e,
+-    0x4a,
+-    0x5c,
+-    0xd7,
+-    0x7a,
+-    0x37,
+-    0x36,
+-    0x0c,
+-    0xde,
+-    0xdd,
+-    0x8f,
+-    0x44,
+-    0xe8,
+-    0xc2,
+-    0xa7,
+-    0x2c,
+-    0x2b,
+-    0xb5,
+-    0xaf,
+-    0x64,
+-    0x4b,
+-    0x61,
+-    0x07,
+-    0x02,
+-    0x03,
+-    0x01,
+-    0x00,
+-    0x01,
+-    0x02,
+-    0x81,
+-    0x80,
+-    0x74,
+-    0x88,
+-    0x64,
+-    0x3f,
+-    0x69,
+-    0x45,
+-    0x3a,
+-    0x6d,
+-    0xc7,
+-    0x7f,
+-    0xb9,
+-    0xa3,
+-    0xc0,
+-    0x6e,
+-    0xec,
+-    0xdc,
+-    0xd4,
+-    0x5a,
+-    0xb5,
+-    0x32,
+-    0x85,
+-    0x5f,
+-    0x19,
+-    0xd4,
+-    0xf8,
+-    0xd4,
+-    0x3f,
+-    0x3c,
+-    0xfa,
+-    0xc2,
+-    0xf6,
+-    0x5f,
+-    0xee,
+-    0xe6,
+-    0xba,
+-    0x87,
+-    0x74,
+-    0x2e,
+-    0xc7,
+-    0x0c,
+-    0xd4,
+-    0x42,
+-    0xb8,
+-    0x66,
+-    0x85,
+-    0x9c,
+-    0x7b,
+-    0x24,
+-    0x61,
+-    0xaa,
+-    0x16,
+-    0x11,
+-    0xf6,
+-    0xb5,
+-    0xb6,
+-    0xa4,
+-    0x0a,
+-    0xc9,
+-    0x55,
+-    0x2e,
+-    0x81,
+-    0xa5,
+-    0x47,
+-    0x61,
+-    0xcb,
+-    0x25,
+-    0x8f,
+-    0xc2,
+-    0x15,
+-    0x7b,
+-    0x0e,
+-    0x7c,
+-    0x36,
+-    0x9f,
+-    0x3a,
+-    0xda,
+-    0x58,
+-    0x86,
+-    0x1c,
+-    0x5b,
+-    0x83,
+-    0x79,
+-    0xe6,
+-    0x2b,
+-    0xcc,
+-    0xe6,
+-    0xfa,
+-    0x2c,
+-    0x61,
+-    0xf2,
+-    0x78,
+-    0x80,
+-    0x1b,
+-    0xe2,
+-    0xf3,
+-    0x9d,
+-    0x39,
+-    0x2b,
+-    0x65,
+-    0x57,
+-    0x91,
+-    0x3d,
+-    0x71,
+-    0x99,
+-    0x73,
+-    0xa5,
+-    0xc2,
+-    0x79,
+-    0x20,
+-    0x8c,
+-    0x07,
+-    0x4f,
+-    0xe5,
+-    0xb4,
+-    0x60,
+-    0x1f,
+-    0x99,
+-    0xa2,
+-    0xb1,
+-    0x4f,
+-    0x0c,
+-    0xef,
+-    0xbc,
+-    0x59,
+-    0x53,
+-    0x00,
+-    0x7d,
+-    0xb1,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xfc,
+-    0x7e,
+-    0x23,
+-    0x65,
+-    0x70,
+-    0xf8,
+-    0xce,
+-    0xd3,
+-    0x40,
+-    0x41,
+-    0x80,
+-    0x6a,
+-    0x1d,
+-    0x01,
+-    0xd6,
+-    0x01,
+-    0xff,
+-    0xb6,
+-    0x1b,
+-    0x3d,
+-    0x3d,
+-    0x59,
+-    0x09,
+-    0x33,
+-    0x79,
+-    0xc0,
+-    0x4f,
+-    0xde,
+-    0x96,
+-    0x27,
+-    0x4b,
+-    0x18,
+-    0xc6,
+-    0xd9,
+-    0x78,
+-    0xf1,
+-    0xf4,
+-    0x35,
+-    0x46,
+-    0xe9,
+-    0x7c,
+-    0x42,
+-    0x7a,
+-    0x5d,
+-    0x9f,
+-    0xef,
+-    0x54,
+-    0xb8,
+-    0xf7,
+-    0x9f,
+-    0xc4,
+-    0x33,
+-    0x6c,
+-    0xf3,
+-    0x8c,
+-    0x32,
+-    0x46,
+-    0x87,
+-    0x67,
+-    0x30,
+-    0x7b,
+-    0xa7,
+-    0xac,
+-    0xe3,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xfc,
+-    0x2c,
+-    0xdf,
+-    0x0c,
+-    0x0d,
+-    0x88,
+-    0xf5,
+-    0xb1,
+-    0x92,
+-    0xa8,
+-    0x93,
+-    0x47,
+-    0x63,
+-    0x55,
+-    0xf5,
+-    0xca,
+-    0x58,
+-    0x43,
+-    0xba,
+-    0x1c,
+-    0xe5,
+-    0x9e,
+-    0xb6,
+-    0x95,
+-    0x05,
+-    0xcd,
+-    0xb5,
+-    0x82,
+-    0xdf,
+-    0xeb,
+-    0x04,
+-    0x53,
+-    0x9d,
+-    0xbd,
+-    0xc2,
+-    0x38,
+-    0x16,
+-    0xb3,
+-    0x62,
+-    0xdd,
+-    0xa1,
+-    0x46,
+-    0xdb,
+-    0x6d,
+-    0x97,
+-    0x93,
+-    0x9f,
+-    0x8a,
+-    0xc3,
+-    0x9b,
+-    0x64,
+-    0x7e,
+-    0x42,
+-    0xe3,
+-    0x32,
+-    0x57,
+-    0x19,
+-    0x1b,
+-    0xd5,
+-    0x6e,
+-    0x85,
+-    0xfa,
+-    0xb8,
+-    0x8d,
+-    0x02,
+-    0x41,
+-    0x00,
+-    0xbc,
+-    0x3d,
+-    0xde,
+-    0x6d,
+-    0xd6,
+-    0x97,
+-    0xe8,
+-    0xba,
+-    0x9e,
+-    0x81,
+-    0x37,
+-    0x17,
+-    0xe5,
+-    0xa0,
+-    0x64,
+-    0xc9,
+-    0x00,
+-    0xb7,
+-    0xe7,
+-    0xfe,
+-    0xf4,
+-    0x29,
+-    0xd9,
+-    0x2e,
+-    0x43,
+-    0x6b,
+-    0x19,
+-    0x20,
+-    0xbd,
+-    0x99,
+-    0x75,
+-    0xe7,
+-    0x76,
+-    0xf8,
+-    0xd3,
+-    0xae,
+-    0xaf,
+-    0x7e,
+-    0xb8,
+-    0xeb,
+-    0x81,
+-    0xf4,
+-    0x9d,
+-    0xfe,
+-    0x07,
+-    0x2b,
+-    0x0b,
+-    0x63,
+-    0x0b,
+-    0x5a,
+-    0x55,
+-    0x90,
+-    0x71,
+-    0x7d,
+-    0xf1,
+-    0xdb,
+-    0xd9,
+-    0xb1,
+-    0x41,
+-    0x41,
+-    0x68,
+-    0x2f,
+-    0x4e,
+-    0x39,
+-    0x02,
+-    0x40,
+-    0x5a,
+-    0x34,
+-    0x66,
+-    0xd8,
+-    0xf5,
+-    0xe2,
+-    0x7f,
+-    0x18,
+-    0xb5,
+-    0x00,
+-    0x6e,
+-    0x26,
+-    0x84,
+-    0x27,
+-    0x14,
+-    0x93,
+-    0xfb,
+-    0xfc,
+-    0xc6,
+-    0x0f,
+-    0x5e,
+-    0x27,
+-    0xe6,
+-    0xe1,
+-    0xe9,
+-    0xc0,
+-    0x8a,
+-    0xe4,
+-    0x34,
+-    0xda,
+-    0xe9,
+-    0xa2,
+-    0x4b,
+-    0x73,
+-    0xbc,
+-    0x8c,
+-    0xb9,
+-    0xba,
+-    0x13,
+-    0x6c,
+-    0x7a,
+-    0x2b,
+-    0x51,
+-    0x84,
+-    0xa3,
+-    0x4a,
+-    0xe0,
+-    0x30,
+-    0x10,
+-    0x06,
+-    0x7e,
+-    0xed,
+-    0x17,
+-    0x5a,
+-    0x14,
+-    0x00,
+-    0xc9,
+-    0xef,
+-    0x85,
+-    0xea,
+-    0x52,
+-    0x2c,
+-    0xbc,
+-    0x65,
+-    0x02,
+-    0x40,
+-    0x51,
+-    0xe3,
+-    0xf2,
+-    0x83,
+-    0x19,
+-    0x9b,
+-    0xc4,
+-    0x1e,
+-    0x2f,
+-    0x50,
+-    0x3d,
+-    0xdf,
+-    0x5a,
+-    0xa2,
+-    0x18,
+-    0xca,
+-    0x5f,
+-    0x2e,
+-    0x49,
+-    0xaf,
+-    0x6f,
+-    0xcc,
+-    0xfa,
+-    0x65,
+-    0x77,
+-    0x94,
+-    0xb5,
+-    0xa1,
+-    0x0a,
+-    0xa9,
+-    0xd1,
+-    0x8a,
+-    0x39,
+-    0x37,
+-    0xf4,
+-    0x0b,
+-    0xa0,
+-    0xd7,
+-    0x82,
+-    0x27,
+-    0x5e,
+-    0xae,
+-    0x17,
+-    0x17,
+-    0xa1,
+-    0x1e,
+-    0x54,
+-    0x34,
+-    0xbf,
+-    0x6e,
+-    0xc4,
+-    0x8e,
+-    0x99,
+-    0x5d,
+-    0x08,
+-    0xf1,
+-    0x2d,
+-    0x86,
+-    0x9d,
+-    0xa5,
+-    0x20,
+-    0x1b,
+-    0xe5,
+-    0xdf,
++    0x30, 0x82, 0x02, 0x76, 0x02, 0x01, 0x00, 0x30, 0x0d, 0x06, 0x09, 0x2a,
++    0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00, 0x04, 0x82,
++    0x02, 0x60, 0x30, 0x82, 0x02, 0x5c, 0x02, 0x01, 0x00, 0x02, 0x81, 0x81,
++    0x00, 0xf8, 0xb8, 0x6c, 0x83, 0xb4, 0xbc, 0xd9, 0xa8, 0x57, 0xc0, 0xa5,
++    0xb4, 0x59, 0x76, 0x8c, 0x54, 0x1d, 0x79, 0xeb, 0x22, 0x52, 0x04, 0x7e,
++    0xd3, 0x37, 0xeb, 0x41, 0xfd, 0x83, 0xf9, 0xf0, 0xa6, 0x85, 0x15, 0x34,
++    0x75, 0x71, 0x5a, 0x84, 0xa8, 0x3c, 0xd2, 0xef, 0x5a, 0x4e, 0xd3, 0xde,
++    0x97, 0x8a, 0xdd, 0xff, 0xbb, 0xcf, 0x0a, 0xaa, 0x86, 0x92, 0xbe, 0xb8,
++    0x50, 0xe4, 0xcd, 0x6f, 0x80, 0x33, 0x30, 0x76, 0x13, 0x8f, 0xca, 0x7b,
++    0xdc, 0xec, 0x5a, 0xca, 0x63, 0xc7, 0x03, 0x25, 0xef, 0xa8, 0x8a, 0x83,
++    0x58, 0x76, 0x20, 0xfa, 0x16, 0x77, 0xd7, 0x79, 0x92, 0x63, 0x01, 0x48,
++    0x1a, 0xd8, 0x7b, 0x67, 0xf1, 0x52, 0x55, 0x49, 0x4e, 0xd6, 0x6e, 0x4a,
++    0x5c, 0xd7, 0x7a, 0x37, 0x36, 0x0c, 0xde, 0xdd, 0x8f, 0x44, 0xe8, 0xc2,
++    0xa7, 0x2c, 0x2b, 0xb5, 0xaf, 0x64, 0x4b, 0x61, 0x07, 0x02, 0x03, 0x01,
++    0x00, 0x01, 0x02, 0x81, 0x80, 0x74, 0x88, 0x64, 0x3f, 0x69, 0x45, 0x3a,
++    0x6d, 0xc7, 0x7f, 0xb9, 0xa3, 0xc0, 0x6e, 0xec, 0xdc, 0xd4, 0x5a, 0xb5,
++    0x32, 0x85, 0x5f, 0x19, 0xd4, 0xf8, 0xd4, 0x3f, 0x3c, 0xfa, 0xc2, 0xf6,
++    0x5f, 0xee, 0xe6, 0xba, 0x87, 0x74, 0x2e, 0xc7, 0x0c, 0xd4, 0x42, 0xb8,
++    0x66, 0x85, 0x9c, 0x7b, 0x24, 0x61, 0xaa, 0x16, 0x11, 0xf6, 0xb5, 0xb6,
++    0xa4, 0x0a, 0xc9, 0x55, 0x2e, 0x81, 0xa5, 0x47, 0x61, 0xcb, 0x25, 0x8f,
++    0xc2, 0x15, 0x7b, 0x0e, 0x7c, 0x36, 0x9f, 0x3a, 0xda, 0x58, 0x86, 0x1c,
++    0x5b, 0x83, 0x79, 0xe6, 0x2b, 0xcc, 0xe6, 0xfa, 0x2c, 0x61, 0xf2, 0x78,
++    0x80, 0x1b, 0xe2, 0xf3, 0x9d, 0x39, 0x2b, 0x65, 0x57, 0x91, 0x3d, 0x71,
++    0x99, 0x73, 0xa5, 0xc2, 0x79, 0x20, 0x8c, 0x07, 0x4f, 0xe5, 0xb4, 0x60,
++    0x1f, 0x99, 0xa2, 0xb1, 0x4f, 0x0c, 0xef, 0xbc, 0x59, 0x53, 0x00, 0x7d,
++    0xb1, 0x02, 0x41, 0x00, 0xfc, 0x7e, 0x23, 0x65, 0x70, 0xf8, 0xce, 0xd3,
++    0x40, 0x41, 0x80, 0x6a, 0x1d, 0x01, 0xd6, 0x01, 0xff, 0xb6, 0x1b, 0x3d,
++    0x3d, 0x59, 0x09, 0x33, 0x79, 0xc0, 0x4f, 0xde, 0x96, 0x27, 0x4b, 0x18,
++    0xc6, 0xd9, 0x78, 0xf1, 0xf4, 0x35, 0x46, 0xe9, 0x7c, 0x42, 0x7a, 0x5d,
++    0x9f, 0xef, 0x54, 0xb8, 0xf7, 0x9f, 0xc4, 0x33, 0x6c, 0xf3, 0x8c, 0x32,
++    0x46, 0x87, 0x67, 0x30, 0x7b, 0xa7, 0xac, 0xe3, 0x02, 0x41, 0x00, 0xfc,
++    0x2c, 0xdf, 0x0c, 0x0d, 0x88, 0xf5, 0xb1, 0x92, 0xa8, 0x93, 0x47, 0x63,
++    0x55, 0xf5, 0xca, 0x58, 0x43, 0xba, 0x1c, 0xe5, 0x9e, 0xb6, 0x95, 0x05,
++    0xcd, 0xb5, 0x82, 0xdf, 0xeb, 0x04, 0x53, 0x9d, 0xbd, 0xc2, 0x38, 0x16,
++    0xb3, 0x62, 0xdd, 0xa1, 0x46, 0xdb, 0x6d, 0x97, 0x93, 0x9f, 0x8a, 0xc3,
++    0x9b, 0x64, 0x7e, 0x42, 0xe3, 0x32, 0x57, 0x19, 0x1b, 0xd5, 0x6e, 0x85,
++    0xfa, 0xb8, 0x8d, 0x02, 0x41, 0x00, 0xbc, 0x3d, 0xde, 0x6d, 0xd6, 0x97,
++    0xe8, 0xba, 0x9e, 0x81, 0x37, 0x17, 0xe5, 0xa0, 0x64, 0xc9, 0x00, 0xb7,
++    0xe7, 0xfe, 0xf4, 0x29, 0xd9, 0x2e, 0x43, 0x6b, 0x19, 0x20, 0xbd, 0x99,
++    0x75, 0xe7, 0x76, 0xf8, 0xd3, 0xae, 0xaf, 0x7e, 0xb8, 0xeb, 0x81, 0xf4,
++    0x9d, 0xfe, 0x07, 0x2b, 0x0b, 0x63, 0x0b, 0x5a, 0x55, 0x90, 0x71, 0x7d,
++    0xf1, 0xdb, 0xd9, 0xb1, 0x41, 0x41, 0x68, 0x2f, 0x4e, 0x39, 0x02, 0x40,
++    0x5a, 0x34, 0x66, 0xd8, 0xf5, 0xe2, 0x7f, 0x18, 0xb5, 0x00, 0x6e, 0x26,
++    0x84, 0x27, 0x14, 0x93, 0xfb, 0xfc, 0xc6, 0x0f, 0x5e, 0x27, 0xe6, 0xe1,
++    0xe9, 0xc0, 0x8a, 0xe4, 0x34, 0xda, 0xe9, 0xa2, 0x4b, 0x73, 0xbc, 0x8c,
++    0xb9, 0xba, 0x13, 0x6c, 0x7a, 0x2b, 0x51, 0x84, 0xa3, 0x4a, 0xe0, 0x30,
++    0x10, 0x06, 0x7e, 0xed, 0x17, 0x5a, 0x14, 0x00, 0xc9, 0xef, 0x85, 0xea,
++    0x52, 0x2c, 0xbc, 0x65, 0x02, 0x40, 0x51, 0xe3, 0xf2, 0x83, 0x19, 0x9b,
++    0xc4, 0x1e, 0x2f, 0x50, 0x3d, 0xdf, 0x5a, 0xa2, 0x18, 0xca, 0x5f, 0x2e,
++    0x49, 0xaf, 0x6f, 0xcc, 0xfa, 0x65, 0x77, 0x94, 0xb5, 0xa1, 0x0a, 0xa9,
++    0xd1, 0x8a, 0x39, 0x37, 0xf4, 0x0b, 0xa0, 0xd7, 0x82, 0x27, 0x5e, 0xae,
++    0x17, 0x17, 0xa1, 0x1e, 0x54, 0x34, 0xbf, 0x6e, 0xc4, 0x8e, 0x99, 0x5d,
++    0x08, 0xf1, 0x2d, 0x86, 0x9d, 0xa5, 0x20, 0x1b, 0xe5, 0xdf
+ };
+ 
+ #ifndef OPENSSL_NO_EC
+@@ -2574,127 +341,17 @@ static const unsigned char kExampleRSAKeyPKCS8[] = {
+  * structure.
+  */
+ static const unsigned char kExampleECKeyDER[] = {
+-    0x30,
+-    0x77,
+-    0x02,
+-    0x01,
+-    0x01,
+-    0x04,
+-    0x20,
+-    0x07,
+-    0x0f,
+-    0x08,
+-    0x72,
+-    0x7a,
+-    0xd4,
+-    0xa0,
+-    0x4a,
+-    0x9c,
+-    0xdd,
+-    0x59,
+-    0xc9,
+-    0x4d,
+-    0x89,
+-    0x68,
+-    0x77,
+-    0x08,
+-    0xb5,
+-    0x6f,
+-    0xc9,
+-    0x5d,
+-    0x30,
+-    0x77,
+-    0x0e,
+-    0xe8,
+-    0xd1,
+-    0xc9,
+-    0xce,
+-    0x0a,
+-    0x8b,
+-    0xb4,
+-    0x6a,
+-    0xa0,
+-    0x0a,
+-    0x06,
+-    0x08,
+-    0x2a,
+-    0x86,
+-    0x48,
+-    0xce,
+-    0x3d,
+-    0x03,
+-    0x01,
+-    0x07,
+-    0xa1,
+-    0x44,
+-    0x03,
+-    0x42,
+-    0x00,
+-    0x04,
+-    0xe6,
+-    0x2b,
+-    0x69,
+-    0xe2,
+-    0xbf,
+-    0x65,
+-    0x9f,
+-    0x97,
+-    0xbe,
+-    0x2f,
+-    0x1e,
+-    0x0d,
+-    0x94,
+-    0x8a,
+-    0x4c,
+-    0xd5,
+-    0x97,
+-    0x6b,
+-    0xb7,
+-    0xa9,
+-    0x1e,
+-    0x0d,
+-    0x46,
+-    0xfb,
+-    0xdd,
+-    0xa9,
+-    0xa9,
+-    0x1e,
+-    0x9d,
+-    0xdc,
+-    0xba,
+-    0x5a,
+-    0x01,
+-    0xe7,
+-    0xd6,
+-    0x97,
+-    0xa8,
+-    0x0a,
+-    0x18,
+-    0xf9,
+-    0xc3,
+-    0xc4,
+-    0xa3,
+-    0x1e,
+-    0x56,
+-    0xe2,
+-    0x7c,
+-    0x83,
+-    0x48,
+-    0xdb,
+-    0x16,
+-    0x1a,
+-    0x1c,
+-    0xf5,
+-    0x1d,
+-    0x7e,
+-    0xf1,
+-    0x94,
+-    0x2d,
+-    0x4b,
+-    0xcf,
+-    0x72,
+-    0x22,
+-    0xc1,
++    0x30, 0x77, 0x02, 0x01, 0x01, 0x04, 0x20, 0x07, 0x0f, 0x08, 0x72, 0x7a,
++    0xd4, 0xa0, 0x4a, 0x9c, 0xdd, 0x59, 0xc9, 0x4d, 0x89, 0x68, 0x77, 0x08,
++    0xb5, 0x6f, 0xc9, 0x5d, 0x30, 0x77, 0x0e, 0xe8, 0xd1, 0xc9, 0xce, 0x0a,
++    0x8b, 0xb4, 0x6a, 0xa0, 0x0a, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d,
++    0x03, 0x01, 0x07, 0xa1, 0x44, 0x03, 0x42, 0x00, 0x04, 0xe6, 0x2b, 0x69,
++    0xe2, 0xbf, 0x65, 0x9f, 0x97, 0xbe, 0x2f, 0x1e, 0x0d, 0x94, 0x8a, 0x4c,
++    0xd5, 0x97, 0x6b, 0xb7, 0xa9, 0x1e, 0x0d, 0x46, 0xfb, 0xdd, 0xa9, 0xa9,
++    0x1e, 0x9d, 0xdc, 0xba, 0x5a, 0x01, 0xe7, 0xd6, 0x97, 0xa8, 0x0a, 0x18,
++    0xf9, 0xc3, 0xc4, 0xa3, 0x1e, 0x56, 0xe2, 0x7c, 0x83, 0x48, 0xdb, 0x16,
++    0x1a, 0x1c, 0xf5, 0x1d, 0x7e, 0xf1, 0x94, 0x2d, 0x4b, 0xcf, 0x72, 0x22,
++    0xc1
+ };
+ 
+ /*
+@@ -2834,30 +491,8 @@ static const unsigned char cfbPlaintext[] = {
+     0x73, 0x93, 0x17, 0x2A
+ };
+ static const unsigned char cfbPlaintext_partial[] = {
+-    0x6B,
+-    0xC1,
+-    0xBE,
+-    0xE2,
+-    0x2E,
+-    0x40,
+-    0x9F,
+-    0x96,
+-    0xE9,
+-    0x3D,
+-    0x7E,
+-    0x11,
+-    0x73,
+-    0x93,
+-    0x17,
+-    0x2A,
+-    0x6B,
+-    0xC1,
+-    0xBE,
+-    0xE2,
+-    0x2E,
+-    0x40,
+-    0x9F,
+-    0x96,
++    0x6B, 0xC1, 0xBE, 0xE2, 0x2E, 0x40, 0x9F, 0x96, 0xE9, 0x3D, 0x7E, 0x11,
++    0x73, 0x93, 0x17, 0x2A, 0x6B, 0xC1, 0xBE, 0xE2, 0x2E, 0x40, 0x9F, 0x96
+ };
+ 
+ static const unsigned char gcmDefaultPlaintext[16] = { 0 };
+@@ -4973,26 +2608,8 @@ static int test_empty_salt_info_HKDF(void)
+     unsigned char key[] = "012345678901234567890123456789";
+     unsigned char info[] = "";
+     const unsigned char expected[] = {
+-        0x67,
+-        0x12,
+-        0xf9,
+-        0x27,
+-        0x8a,
+-        0x8a,
+-        0x3a,
+-        0x8f,
+-        0x7d,
+-        0x2c,
+-        0xa3,
+-        0x6a,
+-        0xaa,
+-        0xe9,
+-        0xb3,
+-        0xb9,
+-        0x52,
+-        0x5f,
+-        0xe0,
+-        0x06,
++        0x67, 0x12, 0xf9, 0x27, 0x8a, 0x8a, 0x3a, 0x8f, 0x7d, 0x2c, 0xa3, 0x6a,
++        0xaa, 0xe9, 0xb3, 0xb9, 0x52, 0x5f, 0xe0, 0x06
+     };
+     size_t expectedlen = sizeof(expected);
+ 
+@@ -7588,222 +5205,34 @@ static int test_aes_gcm_ivlen_change_cve_2023_5363(void)
+ {
+     /* AES-GCM test data obtained from NIST public test vectors */
+     static const unsigned char gcm_key[] = {
+-        0xd0,
+-        0xc2,
+-        0x67,
+-        0xc1,
+-        0x9f,
+-        0x30,
+-        0xd8,
+-        0x0b,
+-        0x89,
+-        0x14,
+-        0xbb,
+-        0xbf,
+-        0xb7,
+-        0x2f,
+-        0x73,
+-        0xb8,
+-        0xd3,
+-        0xcd,
+-        0x5f,
+-        0x6a,
+-        0x78,
+-        0x70,
+-        0x15,
+-        0x84,
+-        0x8a,
+-        0x7b,
+-        0x30,
+-        0xe3,
+-        0x8f,
+-        0x16,
+-        0xf1,
+-        0x8b,
++        0xd0, 0xc2, 0x67, 0xc1, 0x9f, 0x30, 0xd8, 0x0b, 0x89, 0x14, 0xbb, 0xbf,
++        0xb7, 0x2f, 0x73, 0xb8, 0xd3, 0xcd, 0x5f, 0x6a, 0x78, 0x70, 0x15, 0x84,
++        0x8a, 0x7b, 0x30, 0xe3, 0x8f, 0x16, 0xf1, 0x8b
+     };
+     static const unsigned char gcm_iv[] = {
+-        0xb6,
+-        0xdc,
+-        0xda,
+-        0x95,
+-        0xac,
+-        0x99,
+-        0x77,
+-        0x76,
+-        0x25,
+-        0xae,
+-        0x87,
+-        0xf8,
+-        0xa3,
+-        0xa9,
+-        0xdd,
+-        0x64,
+-        0xd7,
+-        0x9b,
+-        0xbd,
+-        0x5f,
+-        0x4a,
+-        0x0e,
+-        0x54,
+-        0xca,
+-        0x1a,
+-        0x9f,
+-        0xa2,
+-        0xe3,
+-        0xf4,
+-        0x5f,
+-        0x5f,
+-        0xc2,
+-        0xce,
+-        0xa7,
+-        0xb6,
+-        0x14,
+-        0x12,
+-        0x6f,
+-        0xf0,
+-        0xaf,
+-        0xfd,
+-        0x3e,
+-        0x17,
+-        0x35,
+-        0x6e,
+-        0xa0,
+-        0x16,
+-        0x09,
+-        0xdd,
+-        0xa1,
+-        0x3f,
+-        0xd8,
+-        0xdd,
+-        0xf3,
+-        0xdf,
+-        0x4f,
+-        0xcb,
+-        0x18,
+-        0x49,
+-        0xb8,
+-        0xb3,
+-        0x69,
+-        0x2c,
+-        0x5d,
+-        0x4f,
+-        0xad,
+-        0x30,
+-        0x91,
+-        0x08,
+-        0xbc,
+-        0xbe,
+-        0x24,
+-        0x01,
+-        0x0f,
+-        0xbe,
+-        0x9c,
+-        0xfb,
+-        0x4f,
+-        0x5d,
+-        0x19,
+-        0x7f,
+-        0x4c,
+-        0x53,
+-        0xb0,
+-        0x95,
+-        0x90,
+-        0xac,
+-        0x7b,
+-        0x1f,
+-        0x7b,
+-        0xa0,
+-        0x99,
+-        0xe1,
+-        0xf3,
+-        0x48,
+-        0x54,
+-        0xd0,
+-        0xfc,
+-        0xa9,
+-        0xcc,
+-        0x91,
+-        0xf8,
+-        0x1f,
+-        0x9b,
+-        0x6c,
+-        0x9a,
+-        0xe0,
+-        0xdc,
+-        0x63,
+-        0xea,
+-        0x7d,
+-        0x2a,
+-        0x4a,
+-        0x7d,
+-        0xa5,
+-        0xed,
+-        0x68,
+-        0x57,
+-        0x27,
+-        0x6b,
+-        0x68,
+-        0xe0,
+-        0xf2,
+-        0xb8,
+-        0x51,
+-        0x50,
+-        0x8d,
+-        0x3d,
++        0xb6, 0xdc, 0xda, 0x95, 0xac, 0x99, 0x77, 0x76, 0x25, 0xae, 0x87, 0xf8,
++        0xa3, 0xa9, 0xdd, 0x64, 0xd7, 0x9b, 0xbd, 0x5f, 0x4a, 0x0e, 0x54, 0xca,
++        0x1a, 0x9f, 0xa2, 0xe3, 0xf4, 0x5f, 0x5f, 0xc2, 0xce, 0xa7, 0xb6, 0x14,
++        0x12, 0x6f, 0xf0, 0xaf, 0xfd, 0x3e, 0x17, 0x35, 0x6e, 0xa0, 0x16, 0x09,
++        0xdd, 0xa1, 0x3f, 0xd8, 0xdd, 0xf3, 0xdf, 0x4f, 0xcb, 0x18, 0x49, 0xb8,
++        0xb3, 0x69, 0x2c, 0x5d, 0x4f, 0xad, 0x30, 0x91, 0x08, 0xbc, 0xbe, 0x24,
++        0x01, 0x0f, 0xbe, 0x9c, 0xfb, 0x4f, 0x5d, 0x19, 0x7f, 0x4c, 0x53, 0xb0,
++        0x95, 0x90, 0xac, 0x7b, 0x1f, 0x7b, 0xa0, 0x99, 0xe1, 0xf3, 0x48, 0x54,
++        0xd0, 0xfc, 0xa9, 0xcc, 0x91, 0xf8, 0x1f, 0x9b, 0x6c, 0x9a, 0xe0, 0xdc,
++        0x63, 0xea, 0x7d, 0x2a, 0x4a, 0x7d, 0xa5, 0xed, 0x68, 0x57, 0x27, 0x6b,
++        0x68, 0xe0, 0xf2, 0xb8, 0x51, 0x50, 0x8d, 0x3d
+     };
+     static const unsigned char gcm_pt[] = {
+-        0xb8,
+-        0xb6,
+-        0x88,
+-        0x36,
+-        0x44,
+-        0xe2,
+-        0x34,
+-        0xdf,
+-        0x24,
+-        0x32,
+-        0x91,
+-        0x07,
+-        0x4f,
+-        0xe3,
+-        0x6f,
+-        0x81,
++        0xb8, 0xb6, 0x88, 0x36, 0x44, 0xe2, 0x34, 0xdf, 0x24, 0x32, 0x91, 0x07,
++        0x4f, 0xe3, 0x6f, 0x81
+     };
+     static const unsigned char gcm_ct[] = {
+-        0xff,
+-        0x4f,
+-        0xb3,
+-        0xf3,
+-        0xf9,
+-        0xa2,
+-        0x51,
+-        0xd4,
+-        0x82,
+-        0xc2,
+-        0xbe,
+-        0xf3,
+-        0xe2,
+-        0xd0,
+-        0xec,
+-        0xed,
++        0xff, 0x4f, 0xb3, 0xf3, 0xf9, 0xa2, 0x51, 0xd4, 0x82, 0xc2, 0xbe, 0xf3,
++        0xe2, 0xd0, 0xec, 0xed
+     };
+     static const unsigned char gcm_tag[] = {
+-        0xbd,
+-        0x06,
+-        0x38,
+-        0x09,
+-        0xf7,
+-        0xe1,
+-        0xc4,
+-        0x72,
+-        0x0e,
+-        0xf2,
+-        0xea,
+-        0x63,
+-        0xdb,
+-        0x99,
+-        0x6c,
+-        0x21,
++        0xbd, 0x06, 0x38, 0x09, 0xf7, 0xe1, 0xc4, 0x72, 0x0e, 0xf2, 0xea, 0x63,
++        0xdb, 0x99, 0x6c, 0x21
+     };
+ 
+     return aes_gcm_encrypt(gcm_key, sizeof(gcm_key), gcm_iv, sizeof(gcm_iv),
+@@ -7895,14 +5324,8 @@ static int test_aes_rc4_keylen_change_cve_2023_5363(void)
+         unsigned char key[5];
+         unsigned char padding[11];
+     } rc4_key = {
+-        {
+-            /* Five bytes of key material */
+-            0x83,
+-            0x32,
+-            0x22,
+-            0x77,
+-            0x2a,
+-        },
++        { /* Five bytes of key material */
++            0x83, 0x32, 0x22, 0x77, 0x2a },
+         { /* Random padding to 16 bytes */
+             0x80, 0xad, 0x97, 0xbd, 0xc9, 0x73, 0xdf, 0x8a, 0xaa, 0x32, 0x91 }
+     };
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0072-Documentation-for-BIO-flags-and-related-functions.patch b/package/libs/openssl/patches/0072-Documentation-for-BIO-flags-and-related-functions.patch
new file mode 100644
index 0000000..b890aec
--- /dev/null
+++ b/package/libs/openssl/patches/0072-Documentation-for-BIO-flags-and-related-functions.patch
@@ -0,0 +1,306 @@
+From affb1088acff0a7820269e131b21a0be7d0285b6 Mon Sep 17 00:00:00 2001
+From: Igor Ustinov <igus68@gmail.com>
+Date: Thu, 4 Dec 2025 17:05:59 +0100
+Subject: [PATCH 072/100] Documentation for BIO flags and related functions.
+
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29311)
+
+(cherry picked from commit e12870deb022555dd15678ff745c33ff19b65dfe)
+---
+ doc/build.info             |   6 ++
+ doc/man3/BIO_set_flags.pod | 194 +++++++++++++++++++++++++++++++++++++
+ util/missingcrypto.txt     |   3 -
+ util/other.syms            |   8 ++
+ 4 files changed, 208 insertions(+), 3 deletions(-)
+ create mode 100644 doc/man3/BIO_set_flags.pod
+
+diff --git a/doc/build.info b/doc/build.info
+index 0dbde5f312..c14dbd2cf4 100644
+--- a/doc/build.info
++++ b/doc/build.info
+@@ -679,6 +679,10 @@ DEPEND[html/man3/BIO_set_callback.html]=man3/BIO_set_callback.pod
+ GENERATE[html/man3/BIO_set_callback.html]=man3/BIO_set_callback.pod
+ DEPEND[man/man3/BIO_set_callback.3]=man3/BIO_set_callback.pod
+ GENERATE[man/man3/BIO_set_callback.3]=man3/BIO_set_callback.pod
++DEPEND[html/man3/BIO_set_flags.html]=man3/BIO_set_flags.pod
++GENERATE[html/man3/BIO_set_flags.html]=man3/BIO_set_flags.pod
++DEPEND[man/man3/BIO_set_flags.3]=man3/BIO_set_flags.pod
++GENERATE[man/man3/BIO_set_flags.3]=man3/BIO_set_flags.pod
+ DEPEND[html/man3/BIO_should_retry.html]=man3/BIO_should_retry.pod
+ GENERATE[html/man3/BIO_should_retry.html]=man3/BIO_should_retry.pod
+ DEPEND[man/man3/BIO_should_retry.3]=man3/BIO_should_retry.pod
+@@ -2957,6 +2961,7 @@ html/man3/BIO_s_mem.html \
+ html/man3/BIO_s_null.html \
+ html/man3/BIO_s_socket.html \
+ html/man3/BIO_set_callback.html \
++html/man3/BIO_set_flags.html \
+ html/man3/BIO_should_retry.html \
+ html/man3/BIO_socket_wait.html \
+ html/man3/BN_BLINDING_new.html \
+@@ -3566,6 +3571,7 @@ man/man3/BIO_s_mem.3 \
+ man/man3/BIO_s_null.3 \
+ man/man3/BIO_s_socket.3 \
+ man/man3/BIO_set_callback.3 \
++man/man3/BIO_set_flags.3 \
+ man/man3/BIO_should_retry.3 \
+ man/man3/BIO_socket_wait.3 \
+ man/man3/BN_BLINDING_new.3 \
+diff --git a/doc/man3/BIO_set_flags.pod b/doc/man3/BIO_set_flags.pod
+new file mode 100644
+index 0000000000..7899cc3e57
+--- /dev/null
++++ b/doc/man3/BIO_set_flags.pod
+@@ -0,0 +1,194 @@
++=pod
++
++=head1 NAME
++
++BIO_set_flags, BIO_clear_flags, BIO_test_flags, BIO_get_flags,
++BIO_set_retry_read, BIO_set_retry_write, BIO_set_retry_special,
++BIO_clear_retry_flags, BIO_get_retry_flags
++- manipulate and interpret BIO flags
++
++=head1 SYNOPSIS
++
++ #include <openssl/bio.h>
++
++ void BIO_set_flags(BIO *b, int flags);
++ void BIO_clear_flags(BIO *b, int flags);
++ int  BIO_test_flags(const BIO *b, int flags);
++ int  BIO_get_flags(const BIO *b);
++
++ void BIO_set_retry_read(BIO *b);
++ void BIO_set_retry_write(BIO *b);
++ void BIO_set_retry_special(BIO *b);
++ void BIO_clear_retry_flags(BIO *b);
++ int  BIO_get_retry_flags(BIO *b);
++
++=head1 DESCRIPTION
++
++A B<BIO> has an internal set of bit flags that describe its state.  These
++functions and macros are used primarily by B<BIO> implementations and by code
++that builds B<BIO> chains to manipulate those flags.
++
++BIO_set_flags() sets the bits given in I<flags> in the B<BIO> I<b>.  Any bits
++already set in the B<BIO>'s flag word remain set.
++
++BIO_clear_flags() clears the bits given in I<flags> from the B<BIO> I<b>.  Any
++other bits in the flag word are left unchanged.
++
++BIO_test_flags() tests the bits given in I<flags> in the B<BIO> I<b> and
++returns a nonzero value if any of them are currently set and zero
++otherwise.
++
++BIO_get_flags() returns the current flag word from the B<BIO> I<b>.  This is
++equivalent to testing for all bits and returning the result.
++
++The following convenience macros are built on top of these primitives and are
++used to maintain the retry state of a BIO:
++
++BIO_set_retry_read() marks the B<BIO> I<b> as being in a retryable state
++by setting the B<BIO_FLAGS_SHOULD_RETRY> flag. In addition, it sets the
++B<BIO_FLAGS_READ> flag to indicate that the retry condition is
++associated with a read operation.
++
++BIO_set_retry_write() marks the B<BIO> I<b> as being in a retryable state
++by setting the B<BIO_FLAGS_SHOULD_RETRY> flag. In addition, it sets the
++B<BIO_FLAGS_WRITE> flag to indicate that the retry condition is
++associated with a write operation.
++
++BIO_set_retry_special() marks the B<BIO> I<b> as being in a retryable state
++by setting the B<BIO_FLAGS_SHOULD_RETRY> flag. In addition, it sets the
++B<BIO_FLAGS_IO_SPECIAL> flag to indicate that the retry condition is
++associated with a read operation some "special" condition.
++The precise meaning of this condition depends on the B<BIO> type.
++
++BIO_clear_retry_flags() clears all retry-related bits from I<b>, i.e.
++B<BIO_FLAGS_READ>, B<BIO_FLAGS_WRITE>, B<BIO_FLAGS_IO_SPECIAL>, and
++B<BIO_FLAGS_SHOULD_RETRY>.
++
++BIO_get_retry_flags() returns retry-related bits that are
++currently set in I<b>.  The result is a subset of
++B<BIO_FLAGS_RWS|BIO_FLAGS_SHOULD_RETRY>.
++
++The retry bits are interpreted by the higher level macros
++BIO_should_read(), BIO_should_write(), BIO_should_io_special(),
++BIO_retry_type() and BIO_should_retry(), as documented in
++L<BIO_should_retry(3)>.  Application code will typically use those macros
++rather than manipulate the underlying flags directly.
++
++The following flag bits are currently defined for use with BIO_set_flags(),
++BIO_clear_flags() and BIO_test_flags():
++
++=over 4
++
++=item B<BIO_FLAGS_READ>
++
++The last I/O operation should be retried when the B<BIO> becomes readable.
++This flag is normally set by the B<BIO> implementation via BIO_set_retry_read()
++after a failed read operation.
++
++=item B<BIO_FLAGS_WRITE>
++
++The last I/O operation should be retried when the B<BIO> becomes writable.
++This flag is normally set by the B<BIO> implementation via BIO_set_retry_write()
++after a failed write operation.
++
++=item B<BIO_FLAGS_IO_SPECIAL>
++
++The last I/O operation should be retried when some "special" condition
++becomes true.  The precise meaning of this condition depends on the B<BIO>
++type and is usually obtained via BIO_get_retry_BIO() and
++BIO_get_retry_reason() as described in L<BIO_should_retry(3)>.
++This flag is normally set by the B<BIO> implementation via
++BIO_set_retry_special().
++
++=item B<BIO_FLAGS_RWS>
++
++The bitwise OR of B<BIO_FLAGS_READ>, B<BIO_FLAGS_WRITE> and
++B<BIO_FLAGS_IO_SPECIAL>.  This mask is used when clearing or extracting
++the retry-direction bits.
++
++=item B<BIO_FLAGS_SHOULD_RETRY>
++
++Set if the last I/O operation on the B<BIO> should be retried at a later time.
++If this bit is not set then the condition is treated as an error.
++This flag is normally set by the B<BIO> implementation.
++
++=item B<BIO_FLAGS_BASE64_NO_NL>
++
++When set on a base64 filter B<BIO> this flag disables the generation of
++newline characters in the encoded output and causes newlines to be ignored
++in the input.  See also L<BIO_f_base64(3)>.
++The flag has no effect on any other built-in B<BIO> types.
++
++=item B<BIO_FLAGS_MEM_RDONLY>
++
++When set on a memory B<BIO> this flag indicates that the underlying buffer is
++read only.  Attempts to write to such a B<BIO> will fail.
++The flag has no effect on any other built-in B<BIO> types.
++
++=item B<BIO_FLAGS_NONCLEAR_RST>
++
++On a memory B<BIO> this flag modifies the behaviour of BIO_reset().  When it
++is set, resetting the B<BIO> does not clear the underlying buffer but only
++resets the current read position.
++The flag has no effect on any other built-in B<BIO> types.
++
++=item B<BIO_FLAGS_IN_EOF>
++
++This flag may be used by a B<BIO> implementation to indicate that the end
++of the input stream has been reached.  However, B<BIO> types are not
++required to use this flag to signal end-of-file conditions; they may rely
++on other mechanisms such as system calls or by querying the next B<BIO> in a
++chain.  Applications must therefore not test this flag directly to
++determine whether EOF has been reached, and must use BIO_eof() instead.
++
++=back
++
++A range of additional flag values is reserved for internal use by OpenSSL
++to track kernel TLS (KTLS) state.  This range and the corresponding flag
++macros are not part of the public API and must not be used by applications.
++
++=head1 RETURN VALUES
++
++BIO_get_flags() returns a bit mask of the flags currently set on the B<BIO>.
++
++BIO_test_flags() returns a bit mask consisting of those flags from the
++argument that are currently set in the B<BIO>. Consequently, it returns a
++nonzero value if and only if at least one of the requested flags is set.
++
++BIO_get_retry_flags() returns a bit mask consisting of those flags from
++B<BIO_FLAGS_READ>, B<BIO_FLAGS_WRITE>, B<BIO_FLAGS_IO_SPECIAL>, and
++B<BIO_FLAGS_SHOULD_RETRY> that are currently set in the I<BIO>.
++
++=head1 NOTES
++
++Ordinary application code will rarely need to call BIO_set_flags(),
++BIO_clear_flags() or BIO_test_flags() directly.  They are intended for B<BIO>
++implementations and for code that forwards retry state from one B<BIO> in a
++chain to another.
++After a failed I/O operation, applications should normally use
++BIO_should_retry() and related macros as described in
++L<BIO_should_retry(3)> instead of inspecting the flags directly.
++
++These functions and macros are not thread-safe. If a single B<BIO>
++is accessed from multiple threads, the caller must provide appropriate
++external synchronisation.
++
++=head1 SEE ALSO
++
++L<BIO_should_retry(3)>, L<BIO_f_base64(3)>, L<bio(7)>
++
++=head1 HISTORY
++
++The functions and macros described here have been available in OpenSSL since
++at least 1.1.0 (B<BIO_FLAGS_IN_EOF> since 1.1.1).
++
++=head1 COPYRIGHT
++
++Copyright 2025 The OpenSSL Project Authors. All Rights Reserved.
++
++Licensed under the Apache License 2.0 (the "License").  You may not use
++this file except in compliance with the License.  You can obtain a copy
++in the file LICENSE in the source distribution or at
++L<https://www.openssl.org/source/license.html>.
++
++=cut
+diff --git a/util/missingcrypto.txt b/util/missingcrypto.txt
+index f930197905..9da5083b6f 100644
+--- a/util/missingcrypto.txt
++++ b/util/missingcrypto.txt
+@@ -172,7 +172,6 @@ BIO_asn1_get_prefix(3)
+ BIO_asn1_get_suffix(3)
+ BIO_asn1_set_prefix(3)
+ BIO_asn1_set_suffix(3)
+-BIO_clear_flags(3)
+ BIO_copy_next_retry(3)
+ BIO_dgram_is_sctp(3)
+ BIO_dgram_non_fatal_error(3)
+@@ -211,7 +210,6 @@ BIO_nwrite(3)
+ BIO_nwrite0(3)
+ BIO_s_datagram_sctp(3)
+ BIO_s_log(3)
+-BIO_set_flags(3)
+ BIO_set_tcp_ndelay(3)
+ BIO_sock_error(3)
+ BIO_sock_info(3)
+@@ -220,7 +218,6 @@ BIO_sock_non_fatal_error(3)
+ BIO_sock_should_retry(3)
+ BIO_socket_ioctl(3)
+ BIO_socket_nbio(3)
+-BIO_test_flags(3)
+ BN_GF2m_add(3)
+ BN_GF2m_arr2poly(3)
+ BN_GF2m_mod(3)
+diff --git a/util/other.syms b/util/other.syms
+index ea0a8caac4..ad38a7c530 100644
+--- a/util/other.syms
++++ b/util/other.syms
+@@ -178,6 +178,8 @@ BIO_get_conn_hostname                   define
+ BIO_get_conn_port                       define
+ BIO_get_conn_ip_family                  define
+ BIO_get_fd                              define
++BIO_get_flags                           define
++BIO_get_retry_flags                     define
+ BIO_get_fp                              define
+ BIO_get_indent                          define
+ BIO_get_info_callback                   define
+@@ -211,6 +213,12 @@ BIO_set_conn_hostname                   define
+ BIO_set_conn_port                       define
+ BIO_set_conn_ip_family                  define
+ BIO_set_fd                              define
++BIO_set_flags                           define
++BIO_set_retry_read                      define
++BIO_set_retry_write                     define
++BIO_set_retry_special                   define
++BIO_clear_flags                         define
++BIO_clear_retry_flags                   define
+ BIO_set_fp                              define
+ BIO_set_indent                          define
+ BIO_set_info_callback                   define
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0073-apps-req.c-Always-set-permissions-for-private-key-ou.patch b/package/libs/openssl/patches/0073-apps-req.c-Always-set-permissions-for-private-key-ou.patch
new file mode 100644
index 0000000..2704fb4
--- /dev/null
+++ b/package/libs/openssl/patches/0073-apps-req.c-Always-set-permissions-for-private-key-ou.patch
@@ -0,0 +1,33 @@
+From 3411a116511efb956e86f3e493d44edc64171565 Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Mon, 15 Dec 2025 12:19:30 +0100
+Subject: [PATCH 073/100] apps/req.c: Always set permissions for private key
+ output
+
+The key output will be always private.
+
+Reported with a proposed fix by Stanislav Fort (Aisle Research).
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/29397)
+---
+ apps/req.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/apps/req.c b/apps/req.c
+index 5c94857606..d31bd8c753 100644
+--- a/apps/req.c
++++ b/apps/req.c
+@@ -738,7 +738,7 @@ int req_main(int argc, char **argv)
+             else
+                 BIO_printf(bio_err, "'%s'\n", keyout);
+         }
+-        out = bio_open_owner(keyout, outformat, newreq);
++        out = bio_open_owner(keyout, outformat, 1);
+         if (out == NULL)
+             goto end;
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0074-Harden-ASN1_mbstring_ncopy.patch b/package/libs/openssl/patches/0074-Harden-ASN1_mbstring_ncopy.patch
new file mode 100644
index 0000000..0052aa1
--- /dev/null
+++ b/package/libs/openssl/patches/0074-Harden-ASN1_mbstring_ncopy.patch
@@ -0,0 +1,122 @@
+From fc70e91ce5a252b05cf0a48ab8d20a2d6914aa94 Mon Sep 17 00:00:00 2001
+From: Norbert Pocs <norbertp@openssl.org>
+Date: Thu, 11 Dec 2025 12:38:16 +0100
+Subject: [PATCH 074/100] Harden ASN1_mbstring_ncopy
+
+Reported by Murali Aniruddhan
+
+Signed-off-by: Norbert Pocs <norbertp@openssl.org>
+
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29376)
+---
+ crypto/asn1/a_mbstr.c     | 35 ++++++++++++++++++++++++++++++++---
+ test/asn1_internal_test.c | 17 +++++++++++++++++
+ 2 files changed, 49 insertions(+), 3 deletions(-)
+
+diff --git a/crypto/asn1/a_mbstr.c b/crypto/asn1/a_mbstr.c
+index c290824d17..531e01d332 100644
+--- a/crypto/asn1/a_mbstr.c
++++ b/crypto/asn1/a_mbstr.c
+@@ -114,7 +114,10 @@ int ASN1_mbstring_ncopy(ASN1_STRING **out, const unsigned char *in, int len,
+         return -1;
+     }
+ 
+-    /* Now work out output format and string type */
++    /*
++     * Now work out output format and string type.
++     * These checks should be in sync with the checks in type_str.
++     */
+     outform = MBSTRING_ASC;
+     if (mask & B_ASN1_NUMERICSTRING)
+         str_type = V_ASN1_NUMERICSTRING;
+@@ -182,7 +185,11 @@ int ASN1_mbstring_ncopy(ASN1_STRING **out, const unsigned char *in, int len,
+ 
+     case MBSTRING_UTF8:
+         outlen = 0;
+-        traverse_string(in, len, inform, out_utf8, &outlen);
++        ret = traverse_string(in, len, inform, out_utf8, &outlen);
++        if (ret < 0) {
++            ERR_raise(ERR_LIB_ASN1, ASN1_R_INVALID_UTF8STRING);
++            return -1;
++        }
+         cpyfunc = cpy_utf8;
+         break;
+     }
+@@ -278,9 +285,29 @@ static int out_utf8(unsigned long value, void *arg)
+ 
+ static int type_str(unsigned long value, void *arg)
+ {
+-    unsigned long types = *((unsigned long *)arg);
++    unsigned long usable_types = *((unsigned long *)arg);
++    unsigned long types = usable_types;
+     const int native = value > INT_MAX ? INT_MAX : ossl_fromascii(value);
+ 
++    /*
++     * Clear out all the types which are not checked later. If any of those
++     * is present in the mask, then the UTF8 type will be added and checked
++     * below.
++     */
++    types &= B_ASN1_NUMERICSTRING | B_ASN1_PRINTABLESTRING
++        | B_ASN1_IA5STRING | B_ASN1_T61STRING | B_ASN1_BMPSTRING
++        | B_ASN1_UNIVERSALSTRING | B_ASN1_UTF8STRING;
++
++    /*
++     * If any other types were in the input mask, they're effectively treated
++     * as UTF8
++     */
++    if (types != usable_types)
++        types |= B_ASN1_UTF8STRING;
++
++    /*
++     * These checks should be in sync with ASN1_mbstring_ncopy.
++     */
+     if ((types & B_ASN1_NUMERICSTRING) && !(ossl_isdigit(native) || native == ' '))
+         types &= ~B_ASN1_NUMERICSTRING;
+     if ((types & B_ASN1_PRINTABLESTRING) && !ossl_isasn1print(native))
+@@ -348,6 +375,8 @@ static int cpy_utf8(unsigned long value, void *arg)
+     p = arg;
+     /* We already know there is enough room so pass 0xff as the length */
+     ret = UTF8_putc(*p, 0xff, value);
++    if (ret < 0)
++        return ret;
+     *p += ret;
+     return 1;
+ }
+diff --git a/test/asn1_internal_test.c b/test/asn1_internal_test.c
+index 97f4b69ac4..919c7aaf33 100644
+--- a/test/asn1_internal_test.c
++++ b/test/asn1_internal_test.c
+@@ -190,11 +190,28 @@ static int test_unicode_range(void)
+     return ok;
+ }
+ 
++static int test_mbstring_ncopy(void)
++{
++    ASN1_STRING *str = NULL;
++    const unsigned char in[] = { 0xFF, 0xFE, 0xFF, 0xFE };
++    int inlen = 4;
++    int inform = MBSTRING_UNIV;
++
++    if (!TEST_int_eq(ASN1_mbstring_ncopy(&str, in, inlen, inform, B_ASN1_GENERALSTRING, 0, 0), -1)
++        || !TEST_int_eq(ASN1_mbstring_ncopy(&str, in, inlen, inform, B_ASN1_VISIBLESTRING, 0, 0), -1)
++        || !TEST_int_eq(ASN1_mbstring_ncopy(&str, in, inlen, inform, B_ASN1_VIDEOTEXSTRING, 0, 0), -1)
++        || !TEST_int_eq(ASN1_mbstring_ncopy(&str, in, inlen, inform, B_ASN1_GENERALIZEDTIME, 0, 0), -1))
++        return 0;
++
++    return 1;
++}
++
+ int setup_tests(void)
+ {
+     ADD_TEST(test_tbl_standard);
+     ADD_TEST(test_standard_methods);
+     ADD_TEST(test_empty_nonoptional_content);
+     ADD_TEST(test_unicode_range);
++    ADD_TEST(test_mbstring_ncopy);
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0075-Check-return-code-of-UTF8_putc.patch b/package/libs/openssl/patches/0075-Check-return-code-of-UTF8_putc.patch
new file mode 100644
index 0000000..00918cd
--- /dev/null
+++ b/package/libs/openssl/patches/0075-Check-return-code-of-UTF8_putc.patch
@@ -0,0 +1,51 @@
+From 41be0f216404f14457bbf3b9cc488dba60b49296 Mon Sep 17 00:00:00 2001
+From: Norbert Pocs <norbertp@openssl.org>
+Date: Thu, 11 Dec 2025 12:49:00 +0100
+Subject: [PATCH 075/100] Check return code of UTF8_putc
+
+Signed-off-by: Norbert Pocs <norbertp@openssl.org>
+
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29376)
+---
+ crypto/asn1/a_strex.c   | 6 ++++--
+ crypto/pkcs12/p12_utl.c | 5 +++++
+ 2 files changed, 9 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/asn1/a_strex.c b/crypto/asn1/a_strex.c
+index 9a5a6de678..6d3c26bc42 100644
+--- a/crypto/asn1/a_strex.c
++++ b/crypto/asn1/a_strex.c
+@@ -198,8 +198,10 @@ static int do_buf(unsigned char *buf, int buflen,
+             orflags = CHARTYPE_LAST_ESC_2253;
+         if (type & BUF_TYPE_CONVUTF8) {
+             unsigned char utfbuf[6];
+-            int utflen;
+-            utflen = UTF8_putc(utfbuf, sizeof(utfbuf), c);
++            int utflen = UTF8_putc(utfbuf, sizeof(utfbuf), c);
++
++            if (utflen < 0)
++                return -1; /* error happened with UTF8 */
+             for (i = 0; i < utflen; i++) {
+                 /*
+                  * We don't need to worry about setting orflags correctly
+diff --git a/crypto/pkcs12/p12_utl.c b/crypto/pkcs12/p12_utl.c
+index 17bbc4b77f..0943f2efd1 100644
+--- a/crypto/pkcs12/p12_utl.c
++++ b/crypto/pkcs12/p12_utl.c
+@@ -219,6 +219,11 @@ char *OPENSSL_uni2utf8(const unsigned char *uni, int unilen)
+     /* re-run the loop emitting UTF-8 string */
+     for (asclen = 0, i = 0; i < unilen;) {
+         j = bmp_to_utf8(asctmp + asclen, uni + i, unilen - i);
++        /* when UTF8_putc fails */
++        if (j < 0) {
++            OPENSSL_free(asctmp);
++            return NULL;
++        }
+         if (j == 4)
+             i += 4;
+         else
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0076-Fix-silent-failure-in-ASYNC_start_job-when-size-is-0.patch b/package/libs/openssl/patches/0076-Fix-silent-failure-in-ASYNC_start_job-when-size-is-0.patch
new file mode 100644
index 0000000..26c96f9
--- /dev/null
+++ b/package/libs/openssl/patches/0076-Fix-silent-failure-in-ASYNC_start_job-when-size-is-0.patch
@@ -0,0 +1,43 @@
+From 9b653f8e13c4fe83c35ece21d8cc7850e4ee0c4e Mon Sep 17 00:00:00 2001
+From: Weizhi Ao <2362422778@qq.com>
+Date: Thu, 11 Dec 2025 21:06:23 +0800
+Subject: [PATCH 076/100] Fix silent failure in ASYNC_start_job when size is 0
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+When ASYNC_start_job is called with args != NULL but size == 0,
+OPENSSL_malloc(0) is called. Depending on the libc implementation,
+malloc(0) may return NULL, causing a silent failure.
+
+This patch modifies the logic to skip allocation if size is 0.
+
+CLA: trivial
+
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29377)
+
+(cherry picked from commit 5cbbced70dd7dd37b6b11dc6e5b7ca78d4d2e436)
+---
+ crypto/async/async.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/async/async.c b/crypto/async/async.c
+index d252cd5b0e..0e5dec3c4c 100644
+--- a/crypto/async/async.c
++++ b/crypto/async/async.c
+@@ -255,7 +255,8 @@ int ASYNC_start_job(ASYNC_JOB **job, ASYNC_WAIT_CTX *wctx, int *ret,
+         if ((ctx->currjob = async_get_pool_job()) == NULL)
+             return ASYNC_NO_JOBS;
+ 
+-        if (args != NULL) {
++        /* Check for size > 0 to avoid malloc(0) */
++        if (args != NULL && size > 0) {
+             ctx->currjob->funcargs = OPENSSL_malloc(size);
+             if (ctx->currjob->funcargs == NULL) {
+                 ERR_raise(ERR_LIB_ASYNC, ERR_R_MALLOC_FAILURE);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0078-bss_acpt.c-Free-strings-returned-from-previous-BIO_A.patch b/package/libs/openssl/patches/0078-bss_acpt.c-Free-strings-returned-from-previous-BIO_A.patch
new file mode 100644
index 0000000..cdb96bd
--- /dev/null
+++ b/package/libs/openssl/patches/0078-bss_acpt.c-Free-strings-returned-from-previous-BIO_A.patch
@@ -0,0 +1,35 @@
+From 3f83559f91a0408fcecce2b493043c07931c17b3 Mon Sep 17 00:00:00 2001
+From: 609bob <1850029304@qq.com>
+Date: Fri, 19 Dec 2025 10:27:06 +0800
+Subject: [PATCH 078/100] bss_acpt.c: Free strings returned from previous
+ BIO_ADDR_hostname_string() calls
+
+CLA: trivial
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29452)
+
+(cherry picked from commit 117dc48fd587099dfb2d0fc107c84f0e359284ad)
+---
+ crypto/bio/bss_acpt.c | 3 +++
+ 1 file changed, 3 insertions(+)
+
+diff --git a/crypto/bio/bss_acpt.c b/crypto/bio/bss_acpt.c
+index 8c41ae73f3..7c7a6a4645 100644
+--- a/crypto/bio/bss_acpt.c
++++ b/crypto/bio/bss_acpt.c
+@@ -268,6 +268,9 @@ static int acpt_state(BIO *b, BIO_ACCEPT *c)
+                 }
+             }
+ 
++            /* Free old values before assigning new ones to prevent memory leak */
++            OPENSSL_free(c->cache_accepting_name);
++            OPENSSL_free(c->cache_accepting_serv);
+             c->cache_accepting_name = BIO_ADDR_hostname_string(&c->cache_accepting_addr, 1);
+             c->cache_accepting_serv = BIO_ADDR_service_string(&c->cache_accepting_addr, 1);
+             c->state = ACPT_S_ACCEPT;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0079-Fix-a-memory-leak-in-sctp-code.patch b/package/libs/openssl/patches/0079-Fix-a-memory-leak-in-sctp-code.patch
new file mode 100644
index 0000000..15c2488
--- /dev/null
+++ b/package/libs/openssl/patches/0079-Fix-a-memory-leak-in-sctp-code.patch
@@ -0,0 +1,50 @@
+From 0a864e0a2baae68f8a547bf7c87a38adc4771565 Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Sun, 4 Jan 2026 19:52:15 +0100
+Subject: [PATCH 079/100] Fix a memory leak in sctp code
+
+There is a memory leak of the addrinfo struct when
+`./openssl s_server -dtls -sctp -accept 127.0.0.1:4433`
+is used, but `sysctl -w net.sctp.auth_enable=1`
+is not done before.
+Additionally this fixes an oversight, when
+`./openssl s_client -dtls -sctp -connect localhost:4433`
+is used to connect to above server.
+The first connect attempt is to IPv6 ::1, which might fail,
+but the second attempt might still succeed, so continue to
+try all addesses even when the SCTP socket fails for one of them.
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29541)
+
+(cherry picked from commit c0a7890b6244cc5620942c3beeb8683f2164560e)
+---
+ apps/lib/s_socket.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/apps/lib/s_socket.c b/apps/lib/s_socket.c
+index 768716cb86..80b8ac25e4 100644
+--- a/apps/lib/s_socket.c
++++ b/apps/lib/s_socket.c
+@@ -156,7 +156,7 @@ int init_client(int *sock, const char *host, const char *port,
+             if (tmpbio == NULL) {
+                 BIO_closesocket(*sock);
+                 *sock = INVALID_SOCKET;
+-                goto out;
++                continue;
+             }
+             BIO_free(tmpbio);
+         }
+@@ -341,6 +341,7 @@ int do_server(int *accept_sock, const char *host, const char *port,
+         BIO *tmpbio = BIO_new_dgram_sctp(asock, BIO_NOCLOSE);
+ 
+         if (tmpbio == NULL) {
++            BIO_ADDRINFO_free(res);
+             BIO_closesocket(asock);
+             ERR_print_errors(bio_err);
+             goto end;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0081-Fix-legitimate-spelling-errors.patch b/package/libs/openssl/patches/0081-Fix-legitimate-spelling-errors.patch
new file mode 100644
index 0000000..dee170c
--- /dev/null
+++ b/package/libs/openssl/patches/0081-Fix-legitimate-spelling-errors.patch
@@ -0,0 +1,1235 @@
+From 05b7b18b9efce99e8a4ad2fd3d6e1a396e786574 Mon Sep 17 00:00:00 2001
+From: Richard Levitte <levitte@openssl.org>
+Date: Thu, 18 Dec 2025 09:51:36 +0100
+Subject: [PATCH 081/100] Fix legitimate spelling errors
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29464)
+---
+ ACKNOWLEDGEMENTS.md                                |  4 ++--
+ Configure                                          |  4 ++--
+ INSTALL.md                                         |  4 ++--
+ NEWS.md                                            |  6 +++---
+ README-ENGINES.md                                  |  2 +-
+ apps/cmp.c                                         |  4 ++--
+ apps/include/http_server.h                         |  2 +-
+ apps/progs.pl                                      |  2 +-
+ apps/speed.c                                       |  2 +-
+ configdata.pm.in                                   |  4 ++--
+ crypto/aes/asm/aesv8-armx.pl                       |  6 +++---
+ crypto/bio/bio_print.c                             |  2 +-
+ crypto/bn/asm/rsaz-avx512.pl                       |  2 +-
+ crypto/bn/bn_nist.c                                |  2 +-
+ crypto/cmp/cmp_vfy.c                               |  6 +++---
+ crypto/context.c                                   |  2 +-
+ crypto/ctype.c                                     |  2 +-
+ crypto/ec/ec2_oct.c                                |  2 +-
+ crypto/encode_decode/encoder_lib.c                 |  2 +-
+ crypto/evp/ctrl_params_translate.c                 |  4 ++--
+ crypto/evp/evp_enc.c                               |  2 +-
+ crypto/evp/evp_fetch.c                             |  2 +-
+ crypto/evp/m_sigver.c                              |  2 +-
+ crypto/evp/pmeth_gn.c                              |  2 +-
+ crypto/ffc/ffc_params_generate.c                   |  2 +-
+ crypto/param_build.c                               |  2 +-
+ crypto/rsa/rsa_lib.c                               |  2 +-
+ crypto/x509/v3_ist.c                               |  2 +-
+ crypto/x509/v3_utf8.c                              |  2 +-
+ crypto/x509/v3_utl.c                               |  2 +-
+ crypto/x509/x_pubkey.c                             |  2 +-
+ demos/mac/gmac.c                                   |  2 +-
+ dev/release-aux/README.md                          |  4 ++--
+ dev/release.sh                                     |  4 ++--
+ doc/man1/openssl-verification-options.pod          | 14 +++++++-------
+ doc/man3/OSSL_PROVIDER.pod                         |  2 +-
+ doc/man3/X509_STORE_CTX_new.pod                    |  2 +-
+ doc/man7/openssl-env.pod                           |  2 +-
+ engines/e_dasync.c                                 |  2 +-
+ include/internal/endian.h                          |  2 +-
+ include/openssl/core_dispatch.h                    |  2 +-
+ include/openssl/ec.h                               |  2 +-
+ .../ciphers/cipher_aes_gcm_hw_armv8.inc            |  2 +-
+ .../implementations/encode_decode/encode_key2any.c |  2 +-
+ .../encode_decode/encode_key2text.c                |  2 +-
+ providers/implementations/kdfs/x942kdf.c           |  4 ++--
+ providers/implementations/kem/rsa_kem.c            |  5 ++---
+ .../implementations/keymgmt/kdf_legacy_kmgmt.c     |  2 +-
+ .../implementations/keymgmt/mac_legacy_kmgmt.c     |  2 +-
+ providers/implementations/rands/drbg_hash.c        |  2 +-
+ providers/implementations/signature/sm2_sig.c      |  6 +++---
+ ssl/ssl_lib.c                                      |  2 +-
+ ssl/statem/statem_srvr.c                           |  2 +-
+ ssl/t1_trce.c                                      |  4 ++--
+ test/cmp_vfy_test.c                                |  2 +-
+ test/evp_extra_test.c                              |  4 ++--
+ test/ffc_internal_test.c                           |  2 +-
+ test/helpers/handshake_srp.c                       |  2 +-
+ test/param_build_test.c                            |  4 ++--
+ test/params_api_test.c                             |  2 +-
+ test/params_test.c                                 |  2 +-
+ test/recipes/15-test_gensm2.t                      |  2 +-
+ test/recipes/70-test_sslrecords.t                  |  2 +-
+ test/recipes/70-test_tls13alerts.t                 |  2 +-
+ .../80-test_cmp_http_data/test_connection.csv      |  2 +-
+ test/recipes/90-test_threads.t                     |  2 +-
+ test/ssl-tests/28-seclevel.cnf.in                  |  2 +-
+ test/sslapitest.c                                  |  2 +-
+ test/threadstest.c                                 |  2 +-
+ test/tls-provider.c                                |  6 +++---
+ util/add-depends.pl                                |  2 +-
+ 71 files changed, 100 insertions(+), 101 deletions(-)
+
+diff --git a/ACKNOWLEDGEMENTS.md b/ACKNOWLEDGEMENTS.md
+index a4dab0c4ff..10178d7cae 100644
+--- a/ACKNOWLEDGEMENTS.md
++++ b/ACKNOWLEDGEMENTS.md
+@@ -1,5 +1,5 @@
+-Acknowlegements
+-===============
++Acknowledgements
++================
+ 
+ Please see our [Thanks!][] page for the current acknowledgements.
+ 
+diff --git a/Configure b/Configure
+index 77bf0cfb96..eb0caac2c5 100755
+--- a/Configure
++++ b/Configure
+@@ -603,7 +603,7 @@ my @disable_cascades = (
+     # Without shared libraries, dynamic engines aren't possible.
+     # This is due to them having to link with libcrypto and register features
+     # using the ENGINE functionality, and since that relies on global tables,
+-    # those *have* to be exacty the same as the ones accessed from the app,
++    # those *have* to be exactly the same as the ones accessed from the app,
+     # which cannot be guaranteed if shared libraries aren't present.
+     # (note that even with shared libraries, both the app and dynamic engines
+     # must be linked with the same library)
+@@ -1792,7 +1792,7 @@ my %skipdir = ();
+ my %disabled_info = ();         # For configdata.pm
+ foreach my $what (sort keys %disabled) {
+     # There are deprecated disablables that translate to themselves.
+-    # They cause disabling cascades, but should otherwise not regiter.
++    # They cause disabling cascades, but should otherwise not register.
+     next if $deprecated_disablables{$what};
+     # The generated $disabled{"deprecated-x.y"} entries are special
+     # and treated properly elsewhere
+diff --git a/INSTALL.md b/INSTALL.md
+index 47d64b1a39..5a90ff9475 100644
+--- a/INSTALL.md
++++ b/INSTALL.md
+@@ -1471,7 +1471,7 @@ over the build process.  Typically these should be defined prior to running
+ 
+     PERL
+                    The name of the Perl executable to use when building OpenSSL.
+-                   Only needed if builing should use a different Perl executable
++                   Only needed if building should use a different Perl executable
+                    than what is used to run the Configure script.
+ 
+     RANLIB
+@@ -1627,7 +1627,7 @@ working incorrectly. If you think you encountered a bug, please
+ Along with a short description of the bug, please provide the complete
+ configure command line and the relevant output including the error message.
+ 
+-Note: To make the output readable, pleace add a 'code fence' (three backquotes
++Note: To make the output readable, please add a 'code fence' (three backquotes
+ ` ``` ` on a separate line) before and after your output:
+ 
+      ```
+diff --git a/NEWS.md b/NEWS.md
+index 2cdbad6260..7b0d9782fa 100644
+--- a/NEWS.md
++++ b/NEWS.md
+@@ -167,7 +167,7 @@ This release incorporates the following bug fixes and mitigations:
+   * Fixed a bug where the RC4-MD5 ciphersuite incorrectly used the
+     AAD data as the MAC key ([CVE-2022-1434])
+   * Fix a bug in the OPENSSL_LH_flush() function that breaks reuse of the memory
+-    occuppied by the removed hash table entries ([CVE-2022-1473])
++    occupied by the removed hash table entries ([CVE-2022-1473])
+ 
+ ### Major changes between OpenSSL 3.0.1 and OpenSSL 3.0.2 [15 Mar 2022]
+ 
+@@ -188,7 +188,7 @@ This release incorporates the following bug fixes and mitigations:
+   * Enhanced 'openssl list' with many new options.
+   * Added migration guide to man7.
+   * Implemented support for fully "pluggable" TLSv1.3 groups.
+-  * Added suport for Kernel TLS (KTLS).
++  * Added support for Kernel TLS (KTLS).
+   * Changed the license to the Apache License v2.0.
+   * Moved all variations of the EVP ciphers CAST5, BF, IDEA, SEED, RC2,
+     RC4, RC5, and DES to the legacy provider.
+@@ -231,7 +231,7 @@ This release incorporates the following bug fixes and mitigations:
+   * Deprecated ERR_put_error(), ERR_get_error_line(), ERR_get_error_line_data(),
+     ERR_peek_error_line_data(), ERR_peek_last_error_line_data() and
+     ERR_func_error_string().
+-  * Added OSSL_PROVIDER_available(), to check provider availibility.
++  * Added OSSL_PROVIDER_available(), to check provider availability.
+   * Added 'openssl mac' that uses the EVP_MAC API.
+   * Added 'openssl kdf' that uses the EVP_KDF API.
+   * Add OPENSSL_info() and 'openssl info' to get built-in data.
+diff --git a/README-ENGINES.md b/README-ENGINES.md
+index 9874276f13..3a702db81e 100644
+--- a/README-ENGINES.md
++++ b/README-ENGINES.md
+@@ -8,7 +8,7 @@ The ENGINE API was introduced in OpenSSL version 0.9.6 as a low level
+ interface for adding alternative implementations of cryptographic
+ primitives, most notably for integrating hardware crypto devices.
+ 
+-The ENGINE interface has its limitations and it has been superseeded
++The ENGINE interface has its limitations and it has been superseded
+ by the [PROVIDER API](README-PROVIDERS.md), it is deprecated in OpenSSL
+ version 3.0. The following documentation is retained as an aid for
+ users who need to maintain or support existing ENGINE implementations.
+diff --git a/apps/cmp.c b/apps/cmp.c
+index 1559a11681..81a709bafd 100644
+--- a/apps/cmp.c
++++ b/apps/cmp.c
+@@ -1180,7 +1180,7 @@ static OSSL_CMP_SRV_CTX *setup_srv_ctx(ENGINE *engine)
+     if (opt_grant_implicitconf)
+         (void)OSSL_CMP_SRV_CTX_set_grant_implicit_confirm(srv_ctx, 1);
+ 
+-    if (opt_failure != INT_MIN) { /* option has been set explicity */
++    if (opt_failure != INT_MIN) { /* option has been set explicitly */
+         if (opt_failure < 0 || OSSL_CMP_PKIFAILUREINFO_MAX < opt_failure) {
+             CMP_err1("-failure out of range, should be >= 0 and <= %d",
+                 OSSL_CMP_PKIFAILUREINFO_MAX);
+@@ -2937,7 +2937,7 @@ int cmp_main(int argc, char **argv)
+             || opt_tls_keypass != NULL || opt_tls_extra != NULL
+             || opt_tls_trusted != NULL || opt_tls_host != NULL)
+         && !opt_tls_used)
+-        CMP_warn("Ingnoring TLS options(s) since -tls_used is not given");
++        CMP_warn("Ignoring TLS options(s) since -tls_used is not given");
+     if (opt_port != NULL) {
+         if (opt_tls_used) {
+             CMP_err("-tls_used option not supported with -port option");
+diff --git a/apps/include/http_server.h b/apps/include/http_server.h
+index 5b227a1378..58b727eb19 100644
+--- a/apps/include/http_server.h
++++ b/apps/include/http_server.h
+@@ -93,7 +93,7 @@ int http_server_get_asn1_req(const ASN1_ITEM *it, ASN1_VALUE **preq,
+  * Send an ASN.1-formatted HTTP response
+  * cbio: destination BIO (typically as returned by http_server_get_asn1_req())
+  *       note: cbio should not do an encoding that changes the output length
+- * keep_alive: grant persistent connnection
++ * keep_alive: grant persistent connection
+  * content_type: string identifying the type of the response
+  * it: the response ASN.1 type
+  * resp: the response to send
+diff --git a/apps/progs.pl b/apps/progs.pl
+index 3a058ef7ea..844a016b81 100644
+--- a/apps/progs.pl
++++ b/apps/progs.pl
+@@ -107,7 +107,7 @@ EOF
+ # The format of this table is:
+ #   [0] = alternative command to use instead
+ #   [1] = deprecented in this version
+-#   [2] = preprocessor conditional for exclusing irrespective of deprecation
++#   [2] = preprocessor conditional for excluding irrespective of deprecation
+ #        rsa      => [ "pkey",      "3_0", "rsa" ],
+ #        genrsa   => [ "genpkey",   "3_0", "rsa" ],
+         rsautl   => [ "pkeyutl",   "3_0", "rsa" ],
+diff --git a/apps/speed.c b/apps/speed.c
+index 4cdd8ece49..210520ba19 100644
+--- a/apps/speed.c
++++ b/apps/speed.c
+@@ -1648,7 +1648,7 @@ int speed_main(int argc, char **argv)
+     uint8_t ecdh_doit[EC_NUM] = { 0 };
+     uint8_t eddsa_doit[EdDSA_NUM] = { 0 };
+ 
+-    /* checks declarated curves against choices list. */
++    /* checks declared curves against choices list. */
+     OPENSSL_assert(ed_curves[EdDSA_NUM - 1].nid == NID_ED448);
+     OPENSSL_assert(strcmp(eddsa_choices[EdDSA_NUM - 1].name, "ed448") == 0);
+ 
+diff --git a/configdata.pm.in b/configdata.pm.in
+index a4ae907299..fea6004d6c 100644
+--- a/configdata.pm.in
++++ b/configdata.pm.in
+@@ -20,7 +20,7 @@
+          # Unix form /VOLUME/DIR1/DIR2/FILE, which is what VMS perl supports
+          # for 'use lib'.
+ 
+-         # Start with spliting the native path
++         # Start with splitting the native path
+          (my $vol, my $dirs, my $file) = File::Spec->splitpath($path);
+          my @dirs = File::Spec->splitdir($dirs);
+ 
+@@ -89,7 +89,7 @@ unless (caller) {
+     if (scalar @ARGV == 0) {
+         # With no arguments, re-create the build file
+         # We do that in two steps, where the first step emits perl
+-        # snipets.
++        # snippets.
+ 
+         my $buildfile = $config{build_file};
+         my $buildfile_template = "$buildfile.in";
+diff --git a/crypto/aes/asm/aesv8-armx.pl b/crypto/aes/asm/aesv8-armx.pl
+index d0e0be6187..94eb5609bf 100755
+--- a/crypto/aes/asm/aesv8-armx.pl
++++ b/crypto/aes/asm/aesv8-armx.pl
+@@ -410,7 +410,7 @@ ___
+ # If lsize < 3*16 bytes, treat them as the tail, interleave the
+ # two blocks AES instructions.
+ # There is one special case, if the original input data size dsize
+-# = 16 bytes, we will treat it seperately to improve the
++# = 16 bytes, we will treat it separately to improve the
+ # performance: one independent code block without LR, FP load and
+ # store, just looks like what the original ECB implementation does.
+ 
+@@ -2210,7 +2210,7 @@ ___
+ # will be processed specially, which be integrated into the 5*16 bytes
+ # loop to improve the efficiency.
+ # There is one special case, if the original input data size dsize
+-# = 16 bytes, we will treat it seperately to improve the
++# = 16 bytes, we will treat it separately to improve the
+ # performance: one independent code block without LR, FP load and
+ # store.
+ # Encryption will process the (length -tailcnt) bytes as mentioned
+@@ -3543,7 +3543,7 @@ $code.=<<___	if ($flavour =~ /64/);
+ 	cbnz	x2,.Lxts_dec_1st_done
+ 	vld1.8	{$dat0},[$inp],#16
+ 
+-	// Decrypt the last secod block to get the last plain text block
++	// Decrypt the last second block to get the last plain text block
+ .Lxts_dec_1st_done:
+ 	eor	$tmpin,$dat0,$iv1
+ 	ldr	$rounds,[$key1,#240]
+diff --git a/crypto/bio/bio_print.c b/crypto/bio/bio_print.c
+index 7538716217..b1e053fdfe 100644
+--- a/crypto/bio/bio_print.c
++++ b/crypto/bio/bio_print.c
+@@ -62,7 +62,7 @@ static int _dopr(char **sbuffer, char **buffer,
+ #define DP_F_NUM (1 << 3)
+ /* print leading zeroes */
+ #define DP_F_ZERO (1 << 4)
+-/* print HEX in UPPPERcase */
++/* print HEX in UPPERcase */
+ #define DP_F_UP (1 << 5)
+ /* treat value as unsigned */
+ #define DP_F_UNSIGNED (1 << 6)
+diff --git a/crypto/bn/asm/rsaz-avx512.pl b/crypto/bn/asm/rsaz-avx512.pl
+index 8d1d19f6c7..ea1dfe94cc 100644
+--- a/crypto/bn/asm/rsaz-avx512.pl
++++ b/crypto/bn/asm/rsaz-avx512.pl
+@@ -98,7 +98,7 @@ ___
+ # specified in the original algorithm as according to the paper "Enhanced Montgomery
+ # Multiplication" by Shay Gueron (see Lemma 1), the result will be always < 2*2^1024
+ # and can be used as a direct input to the next AMM iteration.
+-# This post-condition is true, provided the correct parameter |s| is choosen, i.e.
++# This post-condition is true, provided the correct parameter |s| is chosen, i.e.
+ # s >= n + 2 * k, which matches our case: 1040 > 1024 + 2 * 1.
+ #
+ # void ossl_rsaz_amm52x20_x1_256(BN_ULONG *res,
+diff --git a/crypto/bn/bn_nist.c b/crypto/bn/bn_nist.c
+index 5c813276bd..ac51ae2e2c 100644
+--- a/crypto/bn/bn_nist.c
++++ b/crypto/bn/bn_nist.c
+@@ -248,7 +248,7 @@ const BIGNUM *BN_get0_nist_prime_521(void)
+ 
+ /*
+  * To avoid more recent compilers (specifically clang-14) from treating this
+- * code as a violation of the strict aliasing conditions and omiting it, this
++ * code as a violation of the strict aliasing conditions and omitting it, this
+  * cannot be declared as a function.  Moreover, the dst parameter cannot be
+  * cached in a local since this no longer references the union and again falls
+  * foul of the strict aliasing criteria.  Refer to #18225 for the initial
+diff --git a/crypto/cmp/cmp_vfy.c b/crypto/cmp/cmp_vfy.c
+index 6c659cc1f9..716a326186 100644
+--- a/crypto/cmp/cmp_vfy.c
++++ b/crypto/cmp/cmp_vfy.c
+@@ -598,7 +598,7 @@ int OSSL_CMP_validate_msg(OSSL_CMP_CTX *ctx, const OSSL_CMP_MSG *msg)
+                 break;
+             }
+             ossl_cmp_debug(ctx,
+-                "sucessfully validated PBM-based CMP message protection");
++                "successfully validated PBM-based CMP message protection");
+             return 1;
+         }
+         ossl_cmp_warn(ctx, "verifying PBM-based CMP message protection failed");
+@@ -629,7 +629,7 @@ int OSSL_CMP_validate_msg(OSSL_CMP_CTX *ctx, const OSSL_CMP_MSG *msg)
+             /* use ctx->srvCert for signature check even if not acceptable */
+             if (verify_signature(ctx, msg, scrt)) {
+                 ossl_cmp_debug(ctx,
+-                    "sucessfully validated signature-based CMP message protection");
++                    "successfully validated signature-based CMP message protection");
+ 
+                 return 1;
+             }
+@@ -646,7 +646,7 @@ int OSSL_CMP_validate_msg(OSSL_CMP_CTX *ctx, const OSSL_CMP_MSG *msg)
+  * Any msg->extraCerts are prepended to ctx->untrusted.
+  *
+  * Ensures that:
+- * its sender is of appropriate type (curently only X509_NAME) and
++ * its sender is of appropriate type (currently only X509_NAME) and
+  *     matches any expected sender or srvCert subject given in the ctx
+  * it has a valid body type
+  * its protection is valid (or invalid/absent, but only if a callback function
+diff --git a/crypto/context.c b/crypto/context.c
+index a62a395d27..5fed1e26bb 100644
+--- a/crypto/context.c
++++ b/crypto/context.c
+@@ -419,7 +419,7 @@ void *ossl_lib_ctx_get_data(OSSL_LIB_CTX *ctx, int index,
+      * The alloc call ensures there's a value there. We release the ctx->lock
+      * for this, because the allocation itself may recursively call
+      * ossl_lib_ctx_get_data for other indexes (never this one). The allocation
+-     * will itself aquire the ctx->lock when it actually comes to store the
++     * will itself acquire the ctx->lock when it actually comes to store the
+      * allocated data (see ossl_lib_ctx_generic_new() above). We call
+      * ossl_crypto_alloc_ex_data_intern() here instead of CRYPTO_alloc_ex_data().
+      * They do the same thing except that the latter calls CRYPTO_get_ex_data()
+diff --git a/crypto/ctype.c b/crypto/ctype.c
+index 9a4256692a..7f84343f72 100644
+--- a/crypto/ctype.c
++++ b/crypto/ctype.c
+@@ -258,7 +258,7 @@ int ossl_ctype_check(int c, unsigned int mask)
+ }
+ 
+ /*
+- * Implement some of the simplier functions directly to avoid the overhead of
++ * Implement some of the simpler functions directly to avoid the overhead of
+  * accessing memory via ctype_char_map[].
+  */
+ 
+diff --git a/crypto/ec/ec2_oct.c b/crypto/ec/ec2_oct.c
+index d29050b0c8..f4b9bbb21e 100644
+--- a/crypto/ec/ec2_oct.c
++++ b/crypto/ec/ec2_oct.c
+@@ -270,7 +270,7 @@ int ossl_ec_GF2m_simple_oct2point(const EC_GROUP *group, EC_POINT *point,
+     }
+ 
+     /*
+-     * The first octet is the point converison octet PC, see X9.62, page 4
++     * The first octet is the point conversion octet PC, see X9.62, page 4
+      * and section 4.4.2.  It must be:
+      *     0x00          for the point at infinity
+      *     0x02 or 0x03  for compressed form
+diff --git a/crypto/encode_decode/encoder_lib.c b/crypto/encode_decode/encoder_lib.c
+index d1aa491546..a510b8f7ed 100644
+--- a/crypto/encode_decode/encoder_lib.c
++++ b/crypto/encode_decode/encoder_lib.c
+@@ -531,7 +531,7 @@ static int encoder_process(struct encoder_process_data_st *data)
+         OSSL_TRACE_BEGIN(ENCODER)
+         {
+             BIO_printf(trc_out,
+-                "[%d]    Skipping because recusion level %d failed\n",
++                "[%d]    Skipping because recursion level %d failed\n",
+                 data->level, new_data.level);
+         }
+         OSSL_TRACE_END(ENCODER);
+diff --git a/crypto/evp/ctrl_params_translate.c b/crypto/evp/ctrl_params_translate.c
+index db73ff9f0b..f661375973 100644
+--- a/crypto/evp/ctrl_params_translate.c
++++ b/crypto/evp/ctrl_params_translate.c
+@@ -2238,7 +2238,7 @@ static const struct translation_st evp_pkey_ctx_translations[] = {
+         OSSL_ASYM_CIPHER_PARAM_OAEP_DIGEST, OSSL_PARAM_UTF8_STRING, fix_md },
+     /*
+      * The "rsa_oaep_label" ctrl_str expects the value to always be hex.
+-     * This is accomodated by default_fixup_args() above, which mimics that
++     * This is accommodated by default_fixup_args() above, which mimics that
+      * expectation for any translation item where |ctrl_str| is NULL and
+      * |ctrl_hexstr| is non-NULL.
+      */
+@@ -2799,7 +2799,7 @@ static int evp_pkey_ctx_setget_params_to_ctrl(EVP_PKEY_CTX *pctx,
+          * function to put it to good use, or maybe affect it.
+          *
+          * NOTE: even though EVP_PKEY_CTX_ctrl return value is documented
+-         * as return positive on Success and 0 or negative on falure. There
++         * as return positive on Success and 0 or negative on failure. There
+          * maybe parameters (e.g. ecdh_cofactor), which actually return 0
+          * as success value. That is why we do POST_PARAMS_TO_CTRL for 0
+          * value as well
+diff --git a/crypto/evp/evp_enc.c b/crypto/evp/evp_enc.c
+index d16d31a031..a57980fbcd 100644
+--- a/crypto/evp/evp_enc.c
++++ b/crypto/evp/evp_enc.c
+@@ -242,7 +242,7 @@ static int evp_cipher_init_internal(EVP_CIPHER_CTX *ctx,
+             memcpy(q++, p, sizeof(*q));
+ 
+         /*
+-         * Note that OSSL_CIPHER_PARAM_AEAD_IVLEN is a synomym for
++         * Note that OSSL_CIPHER_PARAM_AEAD_IVLEN is a synonym for
+          * OSSL_CIPHER_PARAM_IVLEN so both are covered here.
+          */
+         p = OSSL_PARAM_locate_const(params, OSSL_CIPHER_PARAM_IVLEN);
+diff --git a/crypto/evp/evp_fetch.c b/crypto/evp/evp_fetch.c
+index 615e767db6..28fdfca35e 100644
+--- a/crypto/evp/evp_fetch.c
++++ b/crypto/evp/evp_fetch.c
+@@ -354,7 +354,7 @@ inner_evp_generic_fetch(struct evp_method_data_st *methdata,
+              * will create a method against all names, but the lookup will fail
+              * as ossl_namemap_name2num treats the name string as a single name
+              * rather than introducing new features where in the EVP_<obj>_fetch
+-             * parses the string and querys for each, return an error.
++             * parses the string and queries for each, return an error.
+              */
+             if (name_id == 0)
+                 name_id = ossl_namemap_name2num(namemap, name);
+diff --git a/crypto/evp/m_sigver.c b/crypto/evp/m_sigver.c
+index dd14c3a47e..03e7bf69af 100644
+--- a/crypto/evp/m_sigver.c
++++ b/crypto/evp/m_sigver.c
+@@ -237,7 +237,7 @@ reinitialize:
+              * This might be requested by a later call to EVP_MD_CTX_get0_md().
+              * In that case the "explicit fetch" rules apply for that
+              * function (as per man pages), i.e. the ref count is not updated
+-             * so the EVP_MD should not be used beyound the lifetime of the
++             * so the EVP_MD should not be used beyond the lifetime of the
+              * EVP_MD_CTX.
+              */
+             ctx->fetched_digest = EVP_MD_fetch(locpctx->libctx, mdname, props);
+diff --git a/crypto/evp/pmeth_gn.c b/crypto/evp/pmeth_gn.c
+index 8f1a62b771..53218e2589 100644
+--- a/crypto/evp/pmeth_gn.c
++++ b/crypto/evp/pmeth_gn.c
+@@ -151,7 +151,7 @@ int EVP_PKEY_generate(EVP_PKEY_CTX *ctx, EVP_PKEY **ppkey)
+         goto legacy;
+ 
+     /*
+-     * Asssigning gentmp to ctx->keygen_info is something our legacy
++     * Assigning gentmp to ctx->keygen_info is something our legacy
+      * implementations do.  Because the provider implementations aren't
+      * allowed to reach into our EVP_PKEY_CTX, we need to provide similar
+      * space for backward compatibility.  It's ok that we attach a local
+diff --git a/crypto/ffc/ffc_params_generate.c b/crypto/ffc/ffc_params_generate.c
+index 39fa92b0d5..dffd718501 100644
+--- a/crypto/ffc/ffc_params_generate.c
++++ b/crypto/ffc/ffc_params_generate.c
+@@ -435,7 +435,7 @@ static int generate_q_fips186_2(BN_CTX *ctx, BIGNUM *q, const EVP_MD *evpmd,
+         }
+         if (r != 0)
+             goto err; /* Exit if error */
+-        /* Try another iteration if it wasnt prime - was in old code.. */
++        /* Try another iteration if it wasn't prime - was in old code.. */
+         generate_seed = 1;
+     }
+ err:
+diff --git a/crypto/param_build.c b/crypto/param_build.c
+index 115d318763..859c70623b 100644
+--- a/crypto/param_build.c
++++ b/crypto/param_build.c
+@@ -32,7 +32,7 @@ typedef struct {
+     union {
+         /*
+          * These fields are never directly addressed, but their sizes are
+-         * imporant so that all native types can be copied here without overrun.
++         * important so that all native types can be copied here without overrun.
+          */
+         ossl_intmax_t i;
+         ossl_uintmax_t u;
+diff --git a/crypto/rsa/rsa_lib.c b/crypto/rsa/rsa_lib.c
+index 1365cbd916..ba35114266 100644
+--- a/crypto/rsa/rsa_lib.c
++++ b/crypto/rsa/rsa_lib.c
+@@ -1124,7 +1124,7 @@ int EVP_PKEY_CTX_set0_rsa_oaep_label(EVP_PKEY_CTX *ctx, void *label, int llen)
+     if (ret <= 0)
+         return ret;
+ 
+-    /* Ownership is supposed to be transfered to the callee. */
++    /* Ownership is supposed to be transferred to the callee. */
+     OPENSSL_free(label);
+     return 1;
+ }
+diff --git a/crypto/x509/v3_ist.c b/crypto/x509/v3_ist.c
+index 5e9cbb1cdd..707e9c66b9 100644
+--- a/crypto/x509/v3_ist.c
++++ b/crypto/x509/v3_ist.c
+@@ -17,7 +17,7 @@
+ 
+ /*
+  * Issuer Sign Tool (1.2.643.100.112) The name of the tool used to signs the subject (ASN1_SEQUENCE)
+- * This extention is required to obtain the status of a qualified certificate at Russian Federation.
++ * This extension is required to obtain the status of a qualified certificate at Russian Federation.
+  * RFC-style description is available here: https://tools.ietf.org/html/draft-deremin-rfc4491-bis-04#section-5
+  * Russian Federal Law 63 "Digital Sign" is available here:  http://www.consultant.ru/document/cons_doc_LAW_112701/
+  */
+diff --git a/crypto/x509/v3_utf8.c b/crypto/x509/v3_utf8.c
+index 0b0b6ecdac..68a5b17c72 100644
+--- a/crypto/x509/v3_utf8.c
++++ b/crypto/x509/v3_utf8.c
+@@ -16,7 +16,7 @@
+ 
+ /*
+  * Subject Sign Tool (1.2.643.100.111) The name of the tool used to signs the subject (UTF8String)
+- * This extention is required to obtain the status of a qualified certificate at Russian Federation.
++ * This extension is required to obtain the status of a qualified certificate at Russian Federation.
+  * RFC-style description is available here: https://tools.ietf.org/html/draft-deremin-rfc4491-bis-04#section-5
+  * Russian Federal Law 63 "Digital Sign" is available here:  http://www.consultant.ru/document/cons_doc_LAW_112701/
+  */
+diff --git a/crypto/x509/v3_utl.c b/crypto/x509/v3_utl.c
+index c28e546c0b..fd895fa67a 100644
+--- a/crypto/x509/v3_utl.c
++++ b/crypto/x509/v3_utl.c
+@@ -47,7 +47,7 @@ static int x509v3_add_len_value(const char *name, const char *value,
+     if (name != NULL && (tname = OPENSSL_strdup(name)) == NULL)
+         goto err;
+     if (value != NULL) {
+-        /* We don't allow embeded NUL characters */
++        /* We don't allow embedded NUL characters */
+         if (memchr(value, 0, vallen) != NULL)
+             goto err;
+         tvalue = OPENSSL_strndup(value, vallen);
+diff --git a/crypto/x509/x_pubkey.c b/crypto/x509/x_pubkey.c
+index 56fcf4430e..1724a5b5f7 100644
+--- a/crypto/x509/x_pubkey.c
++++ b/crypto/x509/x_pubkey.c
+@@ -173,7 +173,7 @@ static int x509_pubkey_ex_d2i_ex(ASN1_VALUE **pval,
+ 
+     /*
+      * Try to decode with legacy method first.  This ensures that engines
+-     * aren't overriden by providers.
++     * aren't overridden by providers.
+      */
+     if ((ret = x509_pubkey_decode(&pubkey->pkey, pubkey)) == -1) {
+         /* -1 indicates a fatal error, like malloc failure */
+diff --git a/demos/mac/gmac.c b/demos/mac/gmac.c
+index a5ead71309..80e3bd9e8f 100644
+--- a/demos/mac/gmac.c
++++ b/demos/mac/gmac.c
+@@ -85,7 +85,7 @@ int main(int argc, char **argv)
+         goto end;
+     }
+ 
+-    /* GMAC requries a GCM mode cipher to be specified */
++    /* GMAC requires a GCM mode cipher to be specified */
+     *p++ = OSSL_PARAM_construct_utf8_string(OSSL_MAC_PARAM_CIPHER,
+         "AES-128-GCM", 0);
+ 
+diff --git a/dev/release-aux/README.md b/dev/release-aux/README.md
+index 01c5a20773..7c31287930 100644
+--- a/dev/release-aux/README.md
++++ b/dev/release-aux/README.md
+@@ -1,5 +1,5 @@
+-Auxilliary files for dev/release.sh
+-===================================
++Auxiliary files for dev/release.sh
++==================================
+ 
+ - release-state-fn.sh
+ 
+diff --git a/dev/release.sh b/dev/release.sh
+index 6ea228649c..a239e94b33 100755
+--- a/dev/release.sh
++++ b/dev/release.sh
+@@ -228,7 +228,7 @@ elif $force; then
+     :
+ else
+     echo >&2 "Not in master or any recognised release branch"
+-    echo >&2 "Please 'git checkout' an approprite branch"
++    echo >&2 "Please 'git checkout' an appropriate branch"
+     exit 1
+ fi
+ orig_HEAD=$(git rev-parse HEAD)
+@@ -373,7 +373,7 @@ for fixup in "$HERE/dev/release-aux"/fixup-*-release.pl; do
+         perl -pi $fixup $file
+ done
+ 
+-$VERBOSE "== Comitting updates and tagging"
++$VERBOSE "== Committing updates and tagging"
+ git add -u
+ git commit $git_quiet -m "Prepare for release of $release_text"$'\n\nRelease: yes'
+ if [ -n "$reviewers" ]; then
+diff --git a/doc/man1/openssl-verification-options.pod b/doc/man1/openssl-verification-options.pod
+index 17fcd4eb79..c95be7df4e 100644
+--- a/doc/man1/openssl-verification-options.pod
++++ b/doc/man1/openssl-verification-options.pod
+@@ -581,7 +581,7 @@ keyCertSign bit set if the keyUsage extension is present.
+ 
+ The extKeyUsage (EKU) extension places additional restrictions on
+ certificate use. If this extension is present (whether critical or not)
+-in an end-entity certficiate, the key is allowed only for the uses specified,
++in an end-entity certificate, the key is allowed only for the uses specified,
+ while the special EKU B<anyExtendedKeyUsage> allows for all uses.
+ 
+ Note that according to RFC 5280 section 4.2.1.12,
+@@ -639,7 +639,7 @@ This is used as a workaround if the basicConstraints extension is absent.
+ =item B<Netscape SSL Server> (C<nssslserver>)
+ 
+ In addition to what has been described for B<sslserver>, for a Netscape
+-SSL client to connect to an SSL server, its EE certficate must have the
++SSL client to connect to an SSL server, its EE certificate must have the
+ B<keyEncipherment> bit set if the keyUsage extension is present. This isn't
+ always valid because some cipher suites use the key for digital signing.
+ Otherwise it is the same as a normal SSL server.
+@@ -660,19 +660,19 @@ This is used as a workaround if the basicConstraints extension is absent.
+ 
+ =item B<S/MIME Signing> (C<smimesign>)
+ 
+-In addition to the common S/MIME checks, for target certficiates
++In addition to the common S/MIME checks, for target certificates
+ the key usage must allow for C<digitalSignature> and/or B<nonRepudiation>.
+ 
+ =item B<S/MIME Encryption> (C<smimeencrypt>)
+ 
+-In addition to the common S/MIME checks, for target certficiates
++In addition to the common S/MIME checks, for target certificates
+ the key usage must allow for C<keyEncipherment>.
+ 
+ =item B<CRL Signing> (C<crlsign>)
+ 
+ For target certificates, the key usage must allow for C<cRLSign>.
+ 
+-For all other certifcates the normal CA checks apply.
++For all other certificates the normal CA checks apply.
+ Except in this case the basicConstraints extension must be present.
+ 
+ =item B<OCSP Helper> (C<ocsphelper>)
+@@ -680,7 +680,7 @@ Except in this case the basicConstraints extension must be present.
+ For target certificates, no checks are performed at this stage,
+ but special checks apply; see L<OCSP_basic_verify(3)>.
+ 
+-For all other certifcates the normal CA checks apply.
++For all other certificates the normal CA checks apply.
+ 
+ =item B<Timestamp Signing> (C<timestampsign>)
+ 
+@@ -689,7 +689,7 @@ C<digitalSignature> and/or C<nonRepudiation> and must not include other bits.
+ The EKU extension must be present and contain C<timeStamping> only.
+ Moreover, it must be marked as critical.
+ 
+-For all other certifcates the normal CA checks apply.
++For all other certificates the normal CA checks apply.
+ 
+ =back
+ 
+diff --git a/doc/man3/OSSL_PROVIDER.pod b/doc/man3/OSSL_PROVIDER.pod
+index 40a4ea1005..1940617eb0 100644
+--- a/doc/man3/OSSL_PROVIDER.pod
++++ b/doc/man3/OSSL_PROVIDER.pod
+@@ -152,7 +152,7 @@ I<capability>. For each capability of that name supported by the provider it
+ will call the callback I<cb> and supply a set of L<OSSL_PARAM(3)>s describing the
+ capability. It will also pass back the argument I<arg>. For more details about
+ capabilities and what they can be used for please see
+-L<provider-base(7)/CAPABILTIIES>.
++L<provider-base(7)/CAPABILITIES>.
+ 
+ =head1 RETURN VALUES
+ 
+diff --git a/doc/man3/X509_STORE_CTX_new.pod b/doc/man3/X509_STORE_CTX_new.pod
+index 9929a98e0c..af323d6d83 100644
+--- a/doc/man3/X509_STORE_CTX_new.pod
++++ b/doc/man3/X509_STORE_CTX_new.pod
+@@ -77,7 +77,7 @@ If I<ctx> is NULL nothing is done.
+ X509_STORE_CTX_init() sets up I<ctx> for a subsequent verification operation.
+ 
+ X509_STORE_CTX_init() initializes the internal state and resources of the
+-given I<ctx>. Among others, it sets the verification parameters associcated
++given I<ctx>. Among others, it sets the verification parameters associated
+ with the method name C<default>, which includes the C<any> purpose,
+ and takes over callback function pointers from I<trust_store> (unless NULL).
+ It must be called before each call to L<X509_verify_cert(3)> or
+diff --git a/doc/man7/openssl-env.pod b/doc/man7/openssl-env.pod
+index c7dbd2277d..4750094e00 100644
+--- a/doc/man7/openssl-env.pod
++++ b/doc/man7/openssl-env.pod
+@@ -61,7 +61,7 @@ Unless OpenSSL tracing support is generally disabled,
+ enable trace output of specific parts of OpenSSL libraries, by name.
+ This output usually makes sense only if you know OpenSSL internals well.
+ 
+-The value of this environment varialble is a comma-separated list of names,
++The value of this environment variable is a comma-separated list of names,
+ with the following available:
+ 
+ =over 4
+diff --git a/engines/e_dasync.c b/engines/e_dasync.c
+index 29267ded82..72a547d4ee 100644
+--- a/engines/e_dasync.c
++++ b/engines/e_dasync.c
+@@ -13,7 +13,7 @@
+ /*
+  * SHA-1 low level APIs are deprecated for public use, but still ok for
+  * internal use.  Note, that due to symbols not being exported, only the
+- * #defines and strucures can be accessed, in this case SHA_CBLOCK and
++ * #defines and structures can be accessed, in this case SHA_CBLOCK and
+  * sizeof(SHA_CTX).
+  */
+ #include "internal/deprecated.h"
+diff --git a/include/internal/endian.h b/include/internal/endian.h
+index 94018416a5..100502d9eb 100644
+--- a/include/internal/endian.h
++++ b/include/internal/endian.h
+@@ -12,7 +12,7 @@
+ #pragma once
+ 
+ /*
+- * IS_LITTLE_ENDIAN and IS_BIG_ENDIAN can be used to detect the endiannes
++ * IS_LITTLE_ENDIAN and IS_BIG_ENDIAN can be used to detect the endianness
+  * at compile time. To use it, DECLARE_IS_ENDIAN must be used to declare
+  * a variable.
+  *
+diff --git a/include/openssl/core_dispatch.h b/include/openssl/core_dispatch.h
+index e8bfab22cf..412ce553cd 100644
+--- a/include/openssl/core_dispatch.h
++++ b/include/openssl/core_dispatch.h
+@@ -476,7 +476,7 @@ OSSL_CORE_MAKE_FUNC(void, rand_clear_seed,
+  * and key material, etc, essentially everything that manipulates the keys
+  * themselves and their parameters.
+  *
+- * The key objects are commonly refered to as |keydata|, and it MUST be able
++ * The key objects are commonly referred to as |keydata|, and it MUST be able
+  * to contain parameters if the key has any, the public key and the private
+  * key.  All parts are optional, but their presence determines what can be
+  * done with the key object in terms of encryption, signature, and so on.
+diff --git a/include/openssl/ec.h b/include/openssl/ec.h
+index 684cb36fb2..6e4ca32f1b 100644
+--- a/include/openssl/ec.h
++++ b/include/openssl/ec.h
+@@ -1276,7 +1276,7 @@ OSSL_DEPRECATEDIN_3_0 int EC_KEY_set_method(EC_KEY *key, const EC_KEY_METHOD *me
+ OSSL_DEPRECATEDIN_3_0 EC_KEY *EC_KEY_new_method(ENGINE *engine);
+ 
+ /** The old name for ecdh_KDF_X9_63
+- *  The ECDH KDF specification has been mistakingly attributed to ANSI X9.62,
++ *  The ECDH KDF specification has been mistakenly attributed to ANSI X9.62,
+  *  it is actually specified in ANSI X9.63.
+  *  This identifier is retained for backwards compatibility
+  */
+diff --git a/providers/implementations/ciphers/cipher_aes_gcm_hw_armv8.inc b/providers/implementations/ciphers/cipher_aes_gcm_hw_armv8.inc
+index d633ebd544..8d20ebb478 100644
+--- a/providers/implementations/ciphers/cipher_aes_gcm_hw_armv8.inc
++++ b/providers/implementations/ciphers/cipher_aes_gcm_hw_armv8.inc
+@@ -8,7 +8,7 @@
+  */
+ 
+ /*
+- * Crypto extention support for AES GCM.
++ * Crypto extension support for AES GCM.
+  * This file is included by cipher_aes_gcm_hw.c
+  */
+ 
+diff --git a/providers/implementations/encode_decode/encode_key2any.c b/providers/implementations/encode_decode/encode_key2any.c
+index c9cda807bc..3a792473ed 100644
+--- a/providers/implementations/encode_decode/encode_key2any.c
++++ b/providers/implementations/encode_decode/encode_key2any.c
+@@ -165,7 +165,7 @@ static X509_PUBKEY *key_to_pubkey(const void *key, int key_nid,
+  * EncryptedPrivateKeyInfo structure (defined by PKCS#8).  They require
+  * that there's an intent to encrypt, anything else is an error.
+  *
+- * key_to_pki_* primarly produce encoded output with the private key data
++ * key_to_pki_* primarily produce encoded output with the private key data
+  * in a PrivateKeyInfo structure (also defined by PKCS#8).  However, if
+  * there is an intent to encrypt the data, the corresponding key_to_epki_*
+  * function is used instead.
+diff --git a/providers/implementations/encode_decode/encode_key2text.c b/providers/implementations/encode_decode/encode_key2text.c
+index 65bbfeed30..9219d1ce06 100644
+--- a/providers/implementations/encode_decode/encode_key2text.c
++++ b/providers/implementations/encode_decode/encode_key2text.c
+@@ -109,7 +109,7 @@ static int print_labeled_bignum(BIO *out, const char *label, const BIGNUM *bn)
+         if ((bytes % 15) == 0 && bytes > 0) {
+             if (BIO_printf(out, ":\n%s", spaces) <= 0)
+                 goto err;
+-            use_sep = 0; /* The first byte on the next line doesnt have a : */
++            use_sep = 0; /* The first byte on the next line doesn't have a : */
+         }
+         if (BIO_printf(out, "%s%c%c", use_sep ? ":" : "",
+                 tolower((unsigned char)p[0]),
+diff --git a/providers/implementations/kdfs/x942kdf.c b/providers/implementations/kdfs/x942kdf.c
+index b1113b0827..e47ad39454 100644
+--- a/providers/implementations/kdfs/x942kdf.c
++++ b/providers/implementations/kdfs/x942kdf.c
+@@ -168,7 +168,7 @@ static int der_encode_sharedinfo(WPACKET *pkt, unsigned char *buf, size_t buflen
+  * |cek_oidlen| The length (in bytes) of the key wrapping algorithm oid,
+  * |acvp| is the optional blob of DER data representing one or more of the
+  *   OtherInfo fields related to |partyu|, |partyv|, |supp_pub| and |supp_priv|.
+- *   This field should noramlly be NULL. If |acvp| is non NULL then |partyu|,
++ *   This field should normally be NULL. If |acvp| is non NULL then |partyu|,
+  *   |partyv|, |supp_pub| and |supp_priv| should all be NULL.
+  * |acvp_len| is the |acvp| length (in bytes).
+  * |partyu| is the optional public info contributed by the initiator.
+@@ -236,7 +236,7 @@ x942_encode_otherinfo(size_t keylen,
+         goto err;
+     /*
+      * Since we allocated the exact size required, the buffer should point to the
+-     * start of the alllocated buffer at this point.
++     * start of the allocated buffer at this point.
+      */
+     if (WPACKET_get_curr(&pkt) != der_buf)
+         goto err;
+diff --git a/providers/implementations/kem/rsa_kem.c b/providers/implementations/kem/rsa_kem.c
+index d7e4b402ca..88d46cd4a7 100644
+--- a/providers/implementations/kem/rsa_kem.c
++++ b/providers/implementations/kem/rsa_kem.c
+@@ -267,7 +267,7 @@ static int rsasve_generate(PROV_RSA_CTX *prsactx,
+     /*
+      * If outlen is specified, then it must report the length
+      * of the out buffer on input so that we can confirm
+-     * its size is sufficent for encapsulation
++     * its size is sufficient for encapsulation
+      */
+     if (outlen != NULL && *outlen < nlen) {
+         ERR_raise(ERR_LIB_PROV, PROV_R_INVALID_OUTPUT_LENGTH);
+@@ -298,8 +298,7 @@ static int rsasve_generate(PROV_RSA_CTX *prsactx,
+ /**
+  * rsasve_recover - Recovers a secret value from ciphertext using an RSA
+  * private key.  Once, recovered, the secret value is considered to be a
+- * shared secret.  Algorithm is preformed as per
+- * NIST SP 800-56B Rev 2
++ * shared secret.  Algorithm is performed as per NIST SP 800-56B Rev 2
+  * 7.2.1.3 RSASVE Recovery Operation (RSASVE.RECOVER).
+  *
+  * This function performs RSA decryption using the private key from the
+diff --git a/providers/implementations/keymgmt/kdf_legacy_kmgmt.c b/providers/implementations/keymgmt/kdf_legacy_kmgmt.c
+index 0b301c333b..73e6974208 100644
+--- a/providers/implementations/keymgmt/kdf_legacy_kmgmt.c
++++ b/providers/implementations/keymgmt/kdf_legacy_kmgmt.c
+@@ -69,7 +69,7 @@ int ossl_kdf_data_up_ref(KDF_DATA *kdfdata)
+ 
+     /* This is effectively doing a new operation on the KDF_DATA and should be
+      * adequately guarded again modules' error states.  However, both current
+-     * calls here are guarded propery in exchange/kdf_exch.c.  Thus, it
++     * calls here are guarded properly in exchange/kdf_exch.c.  Thus, it
+      * could be removed here.  The concern is that something in the future
+      * might call this function without adequate guards.  It's a cheap call,
+      * it seems best to leave it even though it is currently redundant.
+diff --git a/providers/implementations/keymgmt/mac_legacy_kmgmt.c b/providers/implementations/keymgmt/mac_legacy_kmgmt.c
+index 7d577e0c13..3f9f7b5b46 100644
+--- a/providers/implementations/keymgmt/mac_legacy_kmgmt.c
++++ b/providers/implementations/keymgmt/mac_legacy_kmgmt.c
+@@ -108,7 +108,7 @@ int ossl_mac_key_up_ref(MAC_KEY *mackey)
+ 
+     /* This is effectively doing a new operation on the MAC_KEY and should be
+      * adequately guarded again modules' error states.  However, both current
+-     * calls here are guarded propery in signature/mac_legacy.c.  Thus, it
++     * calls here are guarded properly in signature/mac_legacy.c.  Thus, it
+      * could be removed here.  The concern is that something in the future
+      * might call this function without adequate guards.  It's a cheap call,
+      * it seems best to leave it even though it is currently redundant.
+diff --git a/providers/implementations/rands/drbg_hash.c b/providers/implementations/rands/drbg_hash.c
+index d25bb194e9..78594db156 100644
+--- a/providers/implementations/rands/drbg_hash.c
++++ b/providers/implementations/rands/drbg_hash.c
+@@ -164,7 +164,7 @@ static int add_bytes(PROV_DRBG *drbg, unsigned char *dst,
+         /* Add the carry to the top of the dst if inlen is not the same size */
+         for (i = drbg->seedlen - inlen; i > 0; --i, d--) {
+             *d += 1; /* Carry can only be 1 */
+-            if (*d != 0) /* exit if carry doesnt propagate to the next byte */
++            if (*d != 0) /* exit if carry doesn't propagate to the next byte */
+                 break;
+         }
+     }
+diff --git a/providers/implementations/signature/sm2_sig.c b/providers/implementations/signature/sm2_sig.c
+index 227ad2b351..2540417dc7 100644
+--- a/providers/implementations/signature/sm2_sig.c
++++ b/providers/implementations/signature/sm2_sig.c
+@@ -9,7 +9,7 @@
+ 
+ /*
+  * ECDSA low level APIs are deprecated for public use, but still ok for
+- * internal use - SM2 implemetation uses ECDSA_size() function.
++ * internal use - SM2 implementation uses ECDSA_size() function.
+  */
+ #include "internal/deprecated.h"
+ 
+@@ -66,9 +66,9 @@ typedef struct {
+     EC_KEY *ec;
+ 
+     /*
+-     * Flag to termine if the 'z' digest needs to be computed and fed to the
++     * Flag to determine if the 'z' digest needs to be computed and fed to the
+      * hash function.
+-     * This flag should be set on initialization and the compuation should
++     * This flag should be set on initialization and the computation should
+      * be performed only once, on first update.
+      */
+     unsigned int flag_compute_z_digest : 1;
+diff --git a/ssl/ssl_lib.c b/ssl/ssl_lib.c
+index 5f5731261d..d8dee32939 100644
+--- a/ssl/ssl_lib.c
++++ b/ssl/ssl_lib.c
+@@ -352,7 +352,7 @@ static int dane_tlsa_add(SSL_DANE *dane,
+                 /*
+                  * The Full(0) certificate decodes to a seemingly valid X.509
+                  * object with a plausible key, so the TLSA record is well
+-                 * formed.  However, we don't actually need the certifiate for
++                 * formed.  However, we don't actually need the certificate for
+                  * usages PKIX-EE(1) or DANE-EE(3), because at least the EE
+                  * certificate is always presented by the peer.  We discard the
+                  * certificate, and just use the TLSA data as an opaque blob
+diff --git a/ssl/statem/statem_srvr.c b/ssl/statem/statem_srvr.c
+index aeb6b36e1a..93c02205ba 100644
+--- a/ssl/statem/statem_srvr.c
++++ b/ssl/statem/statem_srvr.c
+@@ -2906,7 +2906,7 @@ static int tls_process_cke_rsa(SSL *s, PACKET *pkt)
+      * We must not leak whether a decryption failure occurs because of
+      * Bleichenbacher's attack on PKCS #1 v1.5 RSA padding (see RFC 2246,
+      * section 7.4.7.1). We use the special padding type
+-     * RSA_PKCS1_WITH_TLS_PADDING to do that. It will automaticaly decrypt the
++     * RSA_PKCS1_WITH_TLS_PADDING to do that. It will automatically decrypt the
+      * RSA, check the padding and check that the client version is as expected
+      * in the premaster secret. If any of that fails then the function appears
+      * to return successfully but with a random result. The call below could
+diff --git a/ssl/t1_trce.c b/ssl/t1_trce.c
+index a4b0cbf6e4..a40657355a 100644
+--- a/ssl/t1_trce.c
++++ b/ssl/t1_trce.c
+@@ -1234,7 +1234,7 @@ static int ssl_print_certificate(BIO *bio, int indent,
+     BIO_printf(bio, "ASN.1Cert, length=%d", (int)clen);
+     x = d2i_X509(NULL, &q, clen);
+     if (!x)
+-        BIO_puts(bio, "<UNPARSEABLE CERTIFICATE>\n");
++        BIO_puts(bio, "<UNPARSABLE CERTIFICATE>\n");
+     else {
+         BIO_puts(bio, "\n------details-----\n");
+         X509_print_ex(bio, x, XN_FLAG_ONELINE, 0);
+@@ -1352,7 +1352,7 @@ static int ssl_print_cert_request(BIO *bio, int indent, const SSL *ssl,
+         p = msg;
+         nm = d2i_X509_NAME(NULL, &p, dlen);
+         if (!nm) {
+-            BIO_puts(bio, "<UNPARSEABLE DN>\n");
++            BIO_puts(bio, "<UNPARSABLE DN>\n");
+         } else {
+             X509_NAME_print_ex(bio, nm, 0, XN_FLAG_ONELINE);
+             BIO_puts(bio, "\n");
+diff --git a/test/cmp_vfy_test.c b/test/cmp_vfy_test.c
+index 551d4ef63a..34946bb236 100644
+--- a/test/cmp_vfy_test.c
++++ b/test/cmp_vfy_test.c
+@@ -433,7 +433,7 @@ static int execute_msg_check_test(CMP_VFY_TEST_FIXTURE *fixture)
+                 fixture->additional_arg)))
+         return 0;
+ 
+-    if (fixture->expected == 0) /* error expected aready during above check */
++    if (fixture->expected == 0) /* error expected already during above check */
+         return 1;
+     return TEST_int_eq(0,
+                ASN1_OCTET_STRING_cmp(ossl_cmp_hdr_get0_senderNonce(hdr),
+diff --git a/test/evp_extra_test.c b/test/evp_extra_test.c
+index 10ad58d975..6cca75ccd5 100644
+--- a/test/evp_extra_test.c
++++ b/test/evp_extra_test.c
+@@ -3284,9 +3284,9 @@ static int test_pkey_ctx_fail_without_provider(int tst)
+ 
+     /*
+      * We check for certain algos in the null provider.
+-     * If an algo is expected to have a provider keymgmt, contructing an
++     * If an algo is expected to have a provider keymgmt, constructing an
+      * EVP_PKEY_CTX is expected to fail (return NULL).
+-     * Otherwise, if it's expected to have legacy support, contructing an
++     * Otherwise, if it's expected to have legacy support, constructing an
+      * EVP_PKEY_CTX is expected to succeed (return non-NULL).
+      */
+     switch (tst) {
+diff --git a/test/ffc_internal_test.c b/test/ffc_internal_test.c
+index 915532751f..4743279e4c 100644
+--- a/test/ffc_internal_test.c
++++ b/test/ffc_internal_test.c
+@@ -297,7 +297,7 @@ static int ffc_params_validate_pq_test(void)
+             &res, NULL)))
+         goto err;
+ 
+-    /* Provided seed doesnt produce a valid prime q */
++    /* Provided seed doesn't produce a valid prime q */
+     ossl_ffc_params_set_validate_params(&params, dsa_2048_224_sha224_bad_seed,
+         sizeof(dsa_2048_224_sha224_bad_seed),
+         dsa_2048_224_sha224_counter);
+diff --git a/test/helpers/handshake_srp.c b/test/helpers/handshake_srp.c
+index b2762dfbae..8898dcbd44 100644
+--- a/test/helpers/handshake_srp.c
++++ b/test/helpers/handshake_srp.c
+@@ -8,7 +8,7 @@
+  */
+ 
+ /*
+- * SRP is deprecated and there is no replacent. When SRP is removed, the code in
++ * SRP is deprecated and there is no replacement. When SRP is removed, the code in
+  * this file can be removed too. Until then we have to use the deprecated APIs.
+  */
+ #define OPENSSL_SUPPRESS_DEPRECATED
+diff --git a/test/param_build_test.c b/test/param_build_test.c
+index d8b6bfab65..d3bb9b6159 100644
+--- a/test/param_build_test.c
++++ b/test/param_build_test.c
+@@ -384,7 +384,7 @@ static int builder_limit_test(void)
+     }
+     if (!TEST_ptr(params = OSSL_PARAM_BLD_to_param(bld)))
+         goto err;
+-    /* Count the elements in the params arrary, expecting n */
++    /* Count the elements in the params array, expecting n */
+     for (i = 0; params[i].key != NULL; i++)
+         ;
+     if (!TEST_int_eq(i, n))
+@@ -397,7 +397,7 @@ static int builder_limit_test(void)
+     if (!TEST_true(OSSL_PARAM_BLD_push_int(bld, "g", 2))
+         || !TEST_ptr(params = OSSL_PARAM_BLD_to_param(bld)))
+         goto err;
+-    /* Count the elements in the params arrary, expecting 1 */
++    /* Count the elements in the params array, expecting 1 */
+     for (i = 0; params[i].key != NULL; i++)
+         ;
+     if (!TEST_int_eq(i, 1))
+diff --git a/test/params_api_test.c b/test/params_api_test.c
+index 57a6f8c647..70670a059e 100644
+--- a/test/params_api_test.c
++++ b/test/params_api_test.c
+@@ -76,7 +76,7 @@ static int test_param_type_extra(OSSL_PARAM *param, const unsigned char *cmp,
+     const int signd = param->data_type == OSSL_PARAM_INTEGER;
+ 
+     /*
+-     * Set the unmodified sentinal directly because there is no param array
++     * Set the unmodified sentinel directly because there is no param array
+      * for these tests.
+      */
+     param->return_size = OSSL_PARAM_UNMODIFIED;
+diff --git a/test/params_test.c b/test/params_test.c
+index cbafa1be14..32992d11cb 100644
+--- a/test/params_test.c
++++ b/test/params_test.c
+@@ -47,7 +47,7 @@ struct object_st {
+      */
+     double p2;
+     /*
+-     * Documented as an arbitrarly large unsigned integer.
++     * Documented as an arbitrarily large unsigned integer.
+      * The data size must be large enough to accommodate.
+      * Assumed data type OSSL_PARAM_UNSIGNED_INTEGER
+      */
+diff --git a/test/recipes/15-test_gensm2.t b/test/recipes/15-test_gensm2.t
+index 5c655b3d13..c62434cb15 100644
+--- a/test/recipes/15-test_gensm2.t
++++ b/test/recipes/15-test_gensm2.t
+@@ -16,7 +16,7 @@ use OpenSSL::Test::Utils;
+ 
+ # These are special key generation tests for SM2 keys specifically,
+ # as they could be said to be a bit special in their encoding.
+-# This is an auxilliary test to 15-test_genec.t
++# This is an auxiliary test to 15-test_genec.t
+ 
+ setup("test_gensm2");
+ 
+diff --git a/test/recipes/70-test_sslrecords.t b/test/recipes/70-test_sslrecords.t
+index 318c9235b0..9084ed1a21 100644
+--- a/test/recipes/70-test_sslrecords.t
++++ b/test/recipes/70-test_sslrecords.t
+@@ -88,7 +88,7 @@ use constant {
+ };
+ 
+ # The TLSv1.2 in SSLv2 ClientHello need to run at security level 0
+-# because in a SSLv2 ClientHello we can't send extentions to indicate
++# because in a SSLv2 ClientHello we can't send extensions to indicate
+ # which signature algorithm we want to use, and the default is SHA1.
+ 
+ #Test 5: Inject an SSLv2 style record format for a TLSv1.2 ClientHello
+diff --git a/test/recipes/70-test_tls13alerts.t b/test/recipes/70-test_tls13alerts.t
+index 44d026c202..5139753529 100644
+--- a/test/recipes/70-test_tls13alerts.t
++++ b/test/recipes/70-test_tls13alerts.t
+@@ -41,7 +41,7 @@ $proxy->filter(\&alert_filter);
+ $proxy->start() or plan skip_all => "Unable to start up Proxy for tests";
+ plan tests => 1;
+ my $alert = TLSProxy::Message->alert();
+-ok(TLSProxy::Message->fail() && !$alert->server() && !$alert->encrypted(), "Client sends an unecrypted alert");
++ok(TLSProxy::Message->fail() && !$alert->server() && !$alert->encrypted(), "Client sends an unencrypted alert");
+ 
+ sub alert_filter
+ {
+diff --git a/test/recipes/80-test_cmp_http_data/test_connection.csv b/test/recipes/80-test_cmp_http_data/test_connection.csv
+index cc012411ea..84804b8656 100644
+--- a/test/recipes/80-test_cmp_http_data/test_connection.csv
++++ b/test/recipes/80-test_cmp_http_data/test_connection.csv
+@@ -13,7 +13,7 @@ expected,description, -section,val, -server,val, -proxy,val, -no_proxy,val, -tls
+ 0,server missing argument, -section,, -server,,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
+ 0,server with default port, -section,, -server,_SERVER_HOST,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
+ 0,server port bad syntax: leading garbage, -section,, -server,_SERVER_HOST:x/+80,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
+-0,server port bad synatx: trailing garbage, -section,, -server,_SERVER_HOST:_SERVER_PORT+/x.,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
++0,server port bad syntax: trailing garbage, -section,, -server,_SERVER_HOST:_SERVER_PORT+/x.,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
+ 0,server with wrong port, -section,, -server,_SERVER_HOST:999,,,,,BLANK,,,,-msg_timeout,1,BLANK,,BLANK,
+ TBD,server IP address with TLS port, -section,, -server,_SERVER_IP:_SERVER_TLS,,,,,BLANK,,,,BLANK,,BLANK,,BLANK,
+ ,,,,,,,,,,,,,,,,,,,
+diff --git a/test/recipes/90-test_threads.t b/test/recipes/90-test_threads.t
+index d373fcbd16..4e892351ab 100644
+--- a/test/recipes/90-test_threads.t
++++ b/test/recipes/90-test_threads.t
+@@ -34,7 +34,7 @@ if ($no_fips) {
+ }
+ 
+ # Merge the configuration files into one filtering the contents so the failure
+-# condition is reproducable.  A working FIPS configuration without the install
++# condition is reproducible.  A working FIPS configuration without the install
+ # status is required.
+ 
+ open CFGBASE, '<', $config_path;
+diff --git a/test/ssl-tests/28-seclevel.cnf.in b/test/ssl-tests/28-seclevel.cnf.in
+index 3b97ac68eb..e727a46392 100644
+--- a/test/ssl-tests/28-seclevel.cnf.in
++++ b/test/ssl-tests/28-seclevel.cnf.in
+@@ -36,7 +36,7 @@ our @tests_ec = (
+     {
+         # The Ed448 signature algorithm will not be enabled.
+         # Because of the config order, the certificate is first loaded, and
+-        # then the security level is chaged. If you try this with s_server
++        # then the security level is changed. If you try this with s_server
+         # the order will be reversed and it will instead fail to load the key.
+         name => "SECLEVEL 5 server with ED448 key",
+         server => { "CipherString" => "DEFAULT:\@SECLEVEL=5",
+diff --git a/test/sslapitest.c b/test/sslapitest.c
+index 429c05a6d3..31231efe24 100644
+--- a/test/sslapitest.c
++++ b/test/sslapitest.c
+@@ -850,7 +850,7 @@ static int test_ccs_change_cipher(void)
+     size_t readbytes;
+ 
+     /*
+-     * Create a conection so we can resume and potentially (but not) use
++     * Create a connection so we can resume and potentially (but not) use
+      * a different cipher in the second connection.
+      */
+     if (!TEST_true(create_ssl_ctx_pair(libctx, TLS_server_method(),
+diff --git a/test/threadstest.c b/test/threadstest.c
+index 3a299afe18..43a37e5755 100644
+--- a/test/threadstest.c
++++ b/test/threadstest.c
+@@ -481,7 +481,7 @@ static int test_multi(int idx)
+ 
+ #ifdef OPENSSL_NO_DEPRECATED_3_0
+     if (idx == 3)
+-        return TEST_skip("Skipping tests for deprected functions");
++        return TEST_skip("Skipping tests for deprecated functions");
+ #endif
+ 
+     multi_success = 1;
+diff --git a/test/tls-provider.c b/test/tls-provider.c
+index 56044152ef..2d2a25673d 100644
+--- a/test/tls-provider.c
++++ b/test/tls-provider.c
+@@ -317,7 +317,7 @@ static const OSSL_DISPATCH xor_keyexch_functions[] = {
+ 
+ static const OSSL_ALGORITHM tls_prov_keyexch[] = {
+     /*
+-     * Obviously this is not FIPS approved, but in order to test in conjuction
++     * Obviously this is not FIPS approved, but in order to test in conjunction
+      * with the FIPS provider we pretend that it is.
+      */
+     { "XOR", "provider=tls-provider,fips=yes", xor_keyexch_functions },
+@@ -446,7 +446,7 @@ static const OSSL_DISPATCH xor_kem_functions[] = {
+ 
+ static const OSSL_ALGORITHM tls_prov_kem[] = {
+     /*
+-     * Obviously this is not FIPS approved, but in order to test in conjuction
++     * Obviously this is not FIPS approved, but in order to test in conjunction
+      * with the FIPS provider we pretend that it is.
+      */
+     { "XOR", "provider=tls-provider,fips=yes", xor_kem_functions },
+@@ -763,7 +763,7 @@ static const OSSL_DISPATCH xor_keymgmt_functions[] = {
+ 
+ static const OSSL_ALGORITHM tls_prov_keymgmt[] = {
+     /*
+-     * Obviously this is not FIPS approved, but in order to test in conjuction
++     * Obviously this is not FIPS approved, but in order to test in conjunction
+      * with the FIPS provider we pretend that it is.
+      */
+     { "XOR", "provider=tls-provider,fips=yes", xor_keymgmt_functions },
+diff --git a/util/add-depends.pl b/util/add-depends.pl
+index 599a267f6d..d0f7c3473d 100644
+--- a/util/add-depends.pl
++++ b/util/add-depends.pl
+@@ -214,7 +214,7 @@ my %procedures = (
+             #
+             #   Hinweis: Einlesen der Datei:   {whatever header file}
+             #
+-            # To accomodate, we need to use a very general regular expression
++            # To accommodate, we need to use a very general regular expression
+             # to parse those lines.
+             #
+             # Since there's no object file name at all in that information,
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0082-Use-codespell-ignore-where-justifiable.patch b/package/libs/openssl/patches/0082-Use-codespell-ignore-where-justifiable.patch
new file mode 100644
index 0000000..61a1083
--- /dev/null
+++ b/package/libs/openssl/patches/0082-Use-codespell-ignore-where-justifiable.patch
@@ -0,0 +1,52 @@
+From d6f5f18bc810830eb9fbb7591eb5bf6f0aae4e32 Mon Sep 17 00:00:00 2001
+From: Richard Levitte <levitte@openssl.org>
+Date: Thu, 18 Dec 2025 09:52:11 +0100
+Subject: [PATCH 082/100] Use 'codespell:ignore' where justifiable
+
+There's this one random string where we have the word "Hellow".  It's a
+random string, "correct" spelling is really not important, so we tell
+codespell to just ignore that line.
+
+There were also two struct field names...
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29464)
+---
+ engines/e_padlock.c | 4 ++--
+ test/params_test.c  | 2 +-
+ 2 files changed, 3 insertions(+), 3 deletions(-)
+
+diff --git a/engines/e_padlock.c b/engines/e_padlock.c
+index 61da05f199..8eba5ecf08 100644
+--- a/engines/e_padlock.c
++++ b/engines/e_padlock.c
+@@ -201,9 +201,9 @@ struct padlock_cipher_data {
+             int rounds : 4;
+             int dgst : 1; /* n/a in C3 */
+             int align : 1; /* n/a in C3 */
+-            int ciphr : 1; /* n/a in C3 */
++            int ciphr : 1; /* n/a in C3 */ /* codespell:ignore */
+             unsigned int keygen : 1;
+-            int interm : 1;
++            int interm : 1; /* codespell:ignore */
+             unsigned int encdec : 1;
+             int ksize : 2;
+         } b;
+diff --git a/test/params_test.c b/test/params_test.c
+index 32992d11cb..dfb7f6f04d 100644
+--- a/test/params_test.c
++++ b/test/params_test.c
+@@ -82,7 +82,7 @@ struct object_st {
+     "6768696a6b6c6d6e6f70717273747576" \
+     "7778797a30313233343536373839"
+ #define p4_init "BLAKE2s256" /* Random string */
+-#define p5_init "Hellow World" /* Random string */
++#define p5_init "Hellow World" /* Random string */ /* codespell:ignore */
+ #define p6_init OPENSSL_FULL_VERSION_STR /* Static string */
+ 
+ static void cleanup_object(void *vobj)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0083-apps-ocsp.c-fix-null-dereference-in-ocsp_response.patch b/package/libs/openssl/patches/0083-apps-ocsp.c-fix-null-dereference-in-ocsp_response.patch
new file mode 100644
index 0000000..9957106
--- /dev/null
+++ b/package/libs/openssl/patches/0083-apps-ocsp.c-fix-null-dereference-in-ocsp_response.patch
@@ -0,0 +1,57 @@
+From 2a7399a78083942c49d6072b62b542f1fdcece89 Mon Sep 17 00:00:00 2001
+From: Anton Moryakov <ant.v.moryakov@gmail.com>
+Date: Wed, 29 Oct 2025 21:21:39 +0300
+Subject: [PATCH 083/100] apps: ocsp.c: fix null dereference in ocsp_response
+
+Report of the static analyzer:
+Function 'OCSP_cert_to_id' may return NULL on allocation failure,
+but its return value is dereferenced in 'OCSP_id_issuer_cmp'
+without prior NULL check at ocsp.c:1088. This can lead to a null
+pointer dereference and cause a segmentation fault, resulting
+in a denial-of-service (DoS) condition. Although such failures
+are rare, an attacker could potentially trigger them under memory
+pressure. All other calls to 'OCSP_cert_to_id' in the codebase
+(e.g., add_ocsp_cert, add_ocsp_serial) properly check for NULL,
+making this instance a clear omission.
+
+Correct explained:
+Added a NULL check after calling OCSP_cert_to_id() when creating
+'ca_id' inside the issuer lookup loop. If the allocation fails, the
+function now safely returns an internal error response instead of
+risking a crash. This change aligns the code with existing
+error-handling patterns in the same file and improves robustness
+against resource exhaustion attacks.
+
+Signed-off-by: Anton Moryakov <ant.v.moryakov@gmail.com>
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Thu Jan  8 09:01:09 2026
+(Merged from https://github.com/openssl/openssl/pull/29033)
+
+(cherry picked from commit 5e2e7c60d33727f7818c6c0e915b02fe11be1188)
+---
+ apps/ocsp.c | 6 ++++++
+ 1 file changed, 6 insertions(+)
+
+diff --git a/apps/ocsp.c b/apps/ocsp.c
+index 89578a13e4..0e970f782a 100644
+--- a/apps/ocsp.c
++++ b/apps/ocsp.c
+@@ -1128,6 +1128,12 @@ static void make_ocsp_response(BIO *err, OCSP_RESPONSE **resp, OCSP_REQUEST *req
+             X509 *ca_cert = sk_X509_value(ca, jj);
+             OCSP_CERTID *ca_id = OCSP_cert_to_id(cert_id_md, NULL, ca_cert);
+ 
++            if (ca_id == NULL) {
++                *resp = OCSP_response_create(OCSP_RESPONSE_STATUS_INTERNALERROR,
++                    NULL);
++                goto end;
++            }
++
+             if (OCSP_id_issuer_cmp(ca_id, cid) == 0) {
+                 found = 1;
+                 if (resp_md != NULL)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0084-Fix-a-possible-crash-in-ASN1_generate_nconf.patch b/package/libs/openssl/patches/0084-Fix-a-possible-crash-in-ASN1_generate_nconf.patch
new file mode 100644
index 0000000..1bf4a9d
--- /dev/null
+++ b/package/libs/openssl/patches/0084-Fix-a-possible-crash-in-ASN1_generate_nconf.patch
@@ -0,0 +1,72 @@
+From 6a057674bc7a809ea8e57f52a28c32f808dd832e Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Mon, 5 Jan 2026 14:27:15 +0100
+Subject: [PATCH 084/100] Fix a possible crash in ASN1_generate_nconf
+
+Due to an out of memory error, the i2d_ASN1_TYPE might fail
+and cause a segfault.
+This adds a missing check for NULL pointer and a test case
+that exercises IMPLICIT and EXPLICT tagging in generate_v3,
+since there was no test coverage at all for this code section.
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Thu Jan  8 10:13:43 2026
+(Merged from https://github.com/openssl/openssl/pull/29545)
+
+(cherry picked from commit 48b788cad3e66b51b48a88f44881bbd4b865bad8)
+---
+ crypto/asn1/asn1_gen.c            | 2 ++
+ test/recipes/04-test_asn1_parse.t | 5 ++++-
+ test/test_asn1_genconf.cnf        | 5 +++++
+ 3 files changed, 11 insertions(+), 1 deletion(-)
+ create mode 100644 test/test_asn1_genconf.cnf
+
+diff --git a/crypto/asn1/asn1_gen.c b/crypto/asn1/asn1_gen.c
+index 54dbb26571..3537d4da36 100644
+--- a/crypto/asn1/asn1_gen.c
++++ b/crypto/asn1/asn1_gen.c
+@@ -148,6 +148,8 @@ static ASN1_TYPE *generate_v3(const char *str, X509V3_CTX *cnf, int depth,
+     cpy_len = i2d_ASN1_TYPE(ret, &orig_der);
+     ASN1_TYPE_free(ret);
+     ret = NULL;
++    if (orig_der == NULL)
++        return NULL;
+     /* Set point to start copying for modified encoding */
+     cpy_start = orig_der;
+ 
+diff --git a/test/recipes/04-test_asn1_parse.t b/test/recipes/04-test_asn1_parse.t
+index f3af436592..d745f34d59 100644
+--- a/test/recipes/04-test_asn1_parse.t
++++ b/test/recipes/04-test_asn1_parse.t
+@@ -12,7 +12,7 @@ use OpenSSL::Test::Utils;
+ 
+ setup("test_asn1_parse");
+ 
+-plan tests => 3;
++plan tests => 4;
+ 
+ $ENV{OPENSSL_CONF} = srctop_file("test", "test_asn1_parse.cnf");
+ 
+@@ -24,3 +24,6 @@ ok(run(app(([ 'openssl', 'asn1parse',
+ 
+ ok(run(app(([ 'openssl', 'asn1parse',
+               '-genstr', 'OID:1.2.3.4.3']))));
++
++ok(run(app(([ 'openssl', 'asn1parse',
++              '-genconf', srctop_file("test", "test_asn1_genconf.cnf")]))));
+diff --git a/test/test_asn1_genconf.cnf b/test/test_asn1_genconf.cnf
+new file mode 100644
+index 0000000000..946bab7962
+--- /dev/null
++++ b/test/test_asn1_genconf.cnf
+@@ -0,0 +1,5 @@
++asn1=SEQUENCE:seq
++
++[seq]
++impl=IMPLICIT:1,BOOL:true
++expl=EXPLICIT:2,BITWRAP,OCT:X
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0086-Ensure-ASN1-types-are-checked-before-use.patch b/package/libs/openssl/patches/0086-Ensure-ASN1-types-are-checked-before-use.patch
new file mode 100644
index 0000000..7fb0e3e
--- /dev/null
+++ b/package/libs/openssl/patches/0086-Ensure-ASN1-types-are-checked-before-use.patch
@@ -0,0 +1,74 @@
+From 572844beca95068394c916626a6d3a490f831a49 Mon Sep 17 00:00:00 2001
+From: Bob Beck <beck@openssl.org>
+Date: Wed, 7 Jan 2026 11:29:48 -0700
+Subject: [PATCH 086/100] Ensure ASN1 types are checked before use.
+
+Some of these were fixed by LibreSSL in commit https://github.com/openbsd/src/commit/aa1f637d454961d22117b4353f98253e984b3ba8
+this fix includes the other fixes in that commit, as well as fixes for others found by a scan
+for a similar unvalidated access paradigm in the tree.
+
+Reviewed-by: Kurt Roeckx <kurt@roeckx.be>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29582)
+---
+ apps/s_client.c          |  3 ++-
+ crypto/pkcs12/p12_kiss.c | 10 ++++++++--
+ crypto/pkcs7/pk7_doit.c  |  2 ++
+ 3 files changed, 12 insertions(+), 3 deletions(-)
+
+diff --git a/apps/s_client.c b/apps/s_client.c
+index 1419aafc9c..64e8127f67 100644
+--- a/apps/s_client.c
++++ b/apps/s_client.c
+@@ -2708,8 +2708,9 @@ re_start:
+             goto end;
+         }
+         atyp = ASN1_generate_nconf(genstr, cnf);
+-        if (atyp == NULL) {
++        if (atyp == NULL || atyp->type != V_ASN1_SEQUENCE) {
+             NCONF_free(cnf);
++            ASN1_TYPE_free(atyp);
+             BIO_printf(bio_err, "ASN1_generate_nconf failed\n");
+             goto end;
+         }
+diff --git a/crypto/pkcs12/p12_kiss.c b/crypto/pkcs12/p12_kiss.c
+index 6b668d8350..69fea53033 100644
+--- a/crypto/pkcs12/p12_kiss.c
++++ b/crypto/pkcs12/p12_kiss.c
+@@ -189,11 +189,17 @@ static int parse_bag(PKCS12_SAFEBAG *bag, const char *pass, int passlen,
+     ASN1_BMPSTRING *fname = NULL;
+     ASN1_OCTET_STRING *lkid = NULL;
+ 
+-    if ((attrib = PKCS12_SAFEBAG_get0_attr(bag, NID_friendlyName)))
++    if ((attrib = PKCS12_SAFEBAG_get0_attr(bag, NID_friendlyName))) {
++        if (attrib->type != V_ASN1_BMPSTRING)
++            return 0;
+         fname = attrib->value.bmpstring;
++    }
+ 
+-    if ((attrib = PKCS12_SAFEBAG_get0_attr(bag, NID_localKeyID)))
++    if ((attrib = PKCS12_SAFEBAG_get0_attr(bag, NID_localKeyID))) {
++        if (attrib->type != V_ASN1_OCTET_STRING)
++            return 0;
+         lkid = attrib->value.octet_string;
++    }
+ 
+     switch (PKCS12_SAFEBAG_get_nid(bag)) {
+     case NID_keyBag:
+diff --git a/crypto/pkcs7/pk7_doit.c b/crypto/pkcs7/pk7_doit.c
+index 4b0414f8e0..69b3011225 100644
+--- a/crypto/pkcs7/pk7_doit.c
++++ b/crypto/pkcs7/pk7_doit.c
+@@ -1185,6 +1185,8 @@ ASN1_OCTET_STRING *PKCS7_digest_from_attributes(STACK_OF(X509_ATTRIBUTE) *sk)
+     ASN1_TYPE *astype;
+     if ((astype = get_attribute(sk, NID_pkcs9_messageDigest)) == NULL)
+         return NULL;
++    if (astype->type != V_ASN1_OCTET_STRING)
++        return NULL;
+     return astype->value.octet_string;
+ }
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0087-apps-check-OPENSSL_uni2utf8-return-value.patch b/package/libs/openssl/patches/0087-apps-check-OPENSSL_uni2utf8-return-value.patch
new file mode 100644
index 0000000..bcc0be6
--- /dev/null
+++ b/package/libs/openssl/patches/0087-apps-check-OPENSSL_uni2utf8-return-value.patch
@@ -0,0 +1,35 @@
+From fd8c3384831eeca92164dae93385c319925b5dcc Mon Sep 17 00:00:00 2001
+From: Nikola Pajkovsky <nikolap@openssl.org>
+Date: Fri, 9 Jan 2026 16:30:10 +0100
+Subject: [PATCH 087/100] apps: check OPENSSL_uni2utf8 return value
+
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/29590)
+---
+ apps/pkcs12.c | 6 ++++++
+ 1 file changed, 6 insertions(+)
+
+diff --git a/apps/pkcs12.c b/apps/pkcs12.c
+index 20d97ad5e0..d1b0355319 100644
+--- a/apps/pkcs12.c
++++ b/apps/pkcs12.c
+@@ -829,6 +829,12 @@ int pkcs12_main(int argc, char **argv)
+             if (utmp == NULL)
+                 goto end;
+             badpass = OPENSSL_uni2utf8(utmp, utmplen);
++            if (badpass == NULL) {
++                BIO_printf(bio_err, "Verbatim password did not match, and fallback conversion to UTF-8 failed\n"
++                                    "The password entered or the input encoding may be wrong\n");
++                OPENSSL_free(utmp);
++                goto end;
++            }
+             OPENSSL_free(utmp);
+             if (!PKCS12_verify_mac(p12, badpass, -1)) {
+                 BIO_printf(bio_err, "Mac verify error: invalid password?\n");
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0089-util-and-.ctags.d-remove-remaining-references-to-del.patch b/package/libs/openssl/patches/0089-util-and-.ctags.d-remove-remaining-references-to-del.patch
new file mode 100644
index 0000000..658860e
--- /dev/null
+++ b/package/libs/openssl/patches/0089-util-and-.ctags.d-remove-remaining-references-to-del.patch
@@ -0,0 +1,1293 @@
+From 81467a1a449fb27c2d92ec90e993900408c0f011 Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Fri, 16 Jan 2026 16:08:40 +0100
+Subject: [PATCH 089/100] util/ and .ctags.d/: remove remaining references to
+ deleted util/check-format.pl
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+(Merged from https://github.com/openssl/openssl/pull/29655)
+
+(cherry picked from commit 85bc702cad79a18b9e0fa8b7a9beef9d91ba4782)
+---
+ util/check-format-test-negatives.c | 893 -----------------------------
+ util/check-format-test-positives.c | 365 ------------
+ 2 files changed, 1258 deletions(-)
+ delete mode 100644 util/check-format-test-negatives.c
+ delete mode 100644 util/check-format-test-positives.c
+
+diff --git a/util/check-format-test-negatives.c b/util/check-format-test-negatives.c
+deleted file mode 100644
+index d2f10a68c1..0000000000
+--- a/util/check-format-test-negatives.c
++++ /dev/null
+@@ -1,893 +0,0 @@
+-/*
+- * Copyright 2007-2024 The OpenSSL Project Authors. All Rights Reserved.
+- * Copyright Siemens AG 2015-2022
+- *
+- * Licensed under the Apache License 2.0 (the "License").  You may not use
+- * this file except in compliance with the License.  You can obtain a copy
+- * in the file LICENSE in the source distribution or at
+- * https://www.openssl.org/source/license.html
+- */
+-
+-/*
+- * A collection of test cases where check-format.pl should not report issues.
+- * There are some known false positives, though, which are marked below.
+- */
+-
+-#include <errno.h> /* should not report whitespace nits within <...> */
+-#define F       \
+-    void f()    \
+-    {           \
+-        int i;  \
+-        int j;  \
+-                \
+-        return; \
+-    }
+-
+-/* allow extra  SPC in single-line comment */
+-/*
+- * allow extra  SPC in regular multi-line comment
+- */
+-/*-
+- * allow extra  SPC in format-tagged multi-line comment
+- */
+-/** allow extra '*' in comment opening */
+-/*! allow extra '!' in comment opening */
+-/*
+- ** allow "**" as first non-space chars of a line within multi-line comment
+- */
+-
+-int f(void) /*
+-             * trailing multi-line comment
+-             */
+-{
+-    typedef int INT;
+-    void v;
+-    short b;
+-    char c;
+-    signed s;
+-    unsigned u;
+-    int i;
+-    long l;
+-    float f;
+-    double d;
+-    enum { } enu;
+-    struct {
+-    } stru;
+-    union {
+-    } un;
+-    auto a;
+-    extern e;
+-    static int stat;
+-    const int con;
+-    volatile int vola;
+-    register int reg;
+-    OSSL_x y, *p = params;
+-    int params[];
+-    OSSL_PARAM *(*params[])[MAX + 1];
+-    XY *(*fn)(int a, char b);
+-    /*
+-     * multi-line comment should not disturb detection of local decls
+-     */
+-    BIO1 ***b;
+-    /* intra-line comment should not disturb detection of local decls */
+-    unsigned k;
+-
+-    /* intra-line comment should not disturb detection of end of local decls */
+-
+-    {
+-        int x; /* just decls in block */
+-    }
+-    if (p != (unsigned char *)&(ctx->tmp[0])) {
+-        i -= (p - (unsigned char *)/* do not confuse with var decl */
+-            &(ctx->tmp[0]));
+-    }
+-    {
+-        ctx->buf_off = 0; /* do not confuse with var decl */
+-        return 0;
+-    }
+-    {
+-        ctx->buf_len = EVP_EncodeBlock((unsigned char *)ctx->buf,
+-            (unsigned char *)ctx->tmp, /* no decl */
+-            ctx->tmp_len);
+-    }
+-    {
+-        EVP_EncodeFinal(ctx->base64,
+-            (unsigned char *)ctx->buf, &(ctx->len)); /* no decl */
+-        /* push out the bytes */
+-        goto again;
+-    }
+-    {
+-        f(1, (unsigned long)2); /* no decl */
+-        x;
+-    }
+-    {
+-        char *pass_str = get_passwd(opt_srv_secret, "x");
+-
+-        if (pass_str != NULL) {
+-            cleanse(opt_srv_secret);
+-            res = OSSL_CMP_CTX_set1_secretValue(ctx, (unsigned char *)pass_str,
+-                strlen(pass_str));
+-            clear_free(pass_str);
+-        }
+-    }
+-}
+-
+-int g(void)
+-{
+-    if (ctx == NULL) { /* non-leading end-of-line comment */
+-        if (/* comment after '(' */ pem_name != NULL /* comment before ')' */)
+-            /* entire-line comment indent usually like for the following line */
+-            return NULL; /* hanging indent also for this line after comment */
+-        /* leading comment has same indentation as normal code */ stmt;
+-        /* entire-line comment may have same indent as normal code */
+-    }
+-    for (i = 0; i < n; i++)
+-        for (; i < n; i++)
+-            for (i = 0;; i++)
+-                for (i = 0;; i++)
+-                    for (i = 0; i < n;)
+-                        for (i = 0; i < n;)
+-                            ;
+-    for (i = 0;;)
+-        for (i = 0;;)
+-            for (i = 0;;)
+-                for (i = 0;;)
+-                    for (; i < n;)
+-                        for (; j < n;)
+-                            for (;; i++)
+-                                for (;; i++)
+-                                    ;
+-    for (;;) /* the only variant allowed in case of "empty" for (...) */
+-        ;
+-    for (;;)
+-        ; /* should not trigger: space before ';' */
+-lab:; /* should not trigger: space before ';' */
+-
+-#if X
+-    if (1) /* bad style: just part of control structure depends on #if */
+-#else
+-    if (2) /*@ resulting false positive */
+-#endif
+-        c; /*@ resulting false positive */
+-
+-    if (1)
+-        if (2)
+-            c;
+-        else
+-            e;
+-    else
+-        f;
+-    do
+-        do
+-            2;
+-        while (1);
+-    while (2);
+-
+-    if (1)
+-        f(a, b);
+-    do
+-        1;
+-    while (2); /*@ more than one stmt just to construct case */
+-    if (1)
+-        f(a, b);
+-    else
+-        do
+-            1;
+-        while (2);
+-    if (1)
+-        f(a, b);
+-    else
+-        do /*@ (non-brace) code before 'do' just to construct case */
+-            1;
+-        while (2);
+-    f1234(a,
+-        b);
+-    do /*@ (non-brace) code before 'do' just to construct case */
+-        1;
+-    while (2);
+-    if (1)
+-        f(a,
+-            b);
+-    do /*@ (non-brace) code before 'do' just to construct case */
+-        1;
+-    while (2);
+-    if (1)
+-        f(a, b);
+-    else
+-        do
+-            f(c, c); /*@ (non-brace) code after 'do' just to construct case */
+-        while (2);
+-
+-    if (1)
+-        f(a, b);
+-    else
+-        return;
+-    if (1)
+-        f(a,
+-            b);
+-    else /*@ (non-brace) code before 'else' just to construct case */
+-        do
+-            1;
+-        while (2);
+-
+-    if (1) { /*@ brace after 'if' not on same line just to construct case */
+-        c;
+-        d;
+-    }
+-    /* this comment is correctly indented if it refers to the following line */
+-    d;
+-
+-    if (1) {
+-        2;
+-    } else /*@ no brace after 'else' just to construct case */
+-        3;
+-    do {
+-    } while (x);
+-    if (1) {
+-        2;
+-    } else {
+-        3;
+-    }
+-    if (4)
+-        5;
+-    else
+-        6;
+-
+-    if (1) {
+-        if (2) {
+-        case MAC_TYPE_MAC: {
+-            EVP_MAC_CTX *new_mac_ctx;
+-
+-            if (ctx->pkey == NULL)
+-                return 0;
+-        } break;
+-        default:
+-            /* This should be dead code */
+-            return 0;
+-        }
+-    }
+-    if (expr_line1
+-            == expr_line2
+-        && expr_line3) {
+-        c1;
+-    } else {
+-        c;
+-        d;
+-    }
+-    if (expr_line1
+-            == expr_line2
+-        && expr_line3)
+-        hanging_stmt;
+-}
+-#define m                                                                  \
+-    do { /* should not be confused with function header followed by '{' */ \
+-    } while (0)
+-
+-/* should not trigger: constant on LHS of comparison or assignment operator */
+-X509 *x509 = NULL;
+-int y = a + 1 < b;
+-int ret, was_NULL = *certs == NULL;
+-
+-/* should not trigger: missing space before ... */
+-float z = 1e-6 * (-1) * b[+6] * 1e+1 * (a)->f * (long)+1
+-    - (tmstart.tv_sec + tmstart.tv_nsec * 1e-9);
+-struct st = { -1, 0 };
+-int x = (y <<= 1) + (z <= 5.0);
+-
+-const OPTIONS passwd_options[] = {
+-    { "aixmd5", OPT_AIXMD5, '-', "AIX MD5-based password algorithm" },
+-#if !defined(OPENSSL_NO_DES) && !defined(OPENSSL_NO_DEPRECATED_3_0)
+-    { "crypt", OPT_CRYPT, '-', "Standard Unix password algorithm (default)" },
+-#endif
+-    OPT_R_OPTIONS,
+-
+-    { NULL }
+-};
+-
+-typedef *d(int)
+-    x;
+-typedef(int)
+-    x;
+-typedef(int) * () x;
+-typedef *int *
+-    x;
+-typedef OSSL_CMP_MSG *(*cmp_srv_process_cb_t)(OSSL_CMP_SRV_CTX *ctx, OSSL_CMP_MSG *msg)
+-    xx;
+-
+-#define IF(cond) if (cond)
+-
+-_Pragma("GCC diagnostic push")
+-    _Pragma("GCC diagnostic pop")
+-
+-#define CB_ERR_IF(cond, ctx, cert, depth, err)                                 \
+-    if ((cond) && ((depth) < 0 || verify_cb_cert(ctx, cert, depth, err) == 0)) \
+-    return err
+-        static int verify_cb_crl(X509_STORE_CTX *ctx, int err)
+-{
+-    ctx->error = err;
+-    return ctx->verify_cb(0, ctx);
+-}
+-
+-#ifdef CMP_FALLBACK_EST
+-#define CMP_FALLBACK_CERT_FILE "cert.pem"
+-#endif
+-
+-#define X509_OBJECT_get0_X509(obj) \
+-    ((obj) == NULL || (obj)->type != X509_LU_X509 ? NULL : (obj)->data.x509)
+-#define X509_STORE_CTX_set_current_cert(ctx, x) \
+-    {                                           \
+-        (ctx)->current_cert = (x);              \
+-    }
+-#define X509_STORE_set_ex_data(ctx, idx, data) \
+-    CRYPTO_set_ex_data(&(ctx)->ex_data, (idx), (data))
+-
+-typedef int (*X509_STORE_CTX_check_revocation_fn)(X509_STORE_CTX *ctx);
+-#define X509_STORE_CTX_set_error_depth(ctx, depth) \
+-    {                                              \
+-        (ctx)->error_depth = (depth);              \
+-    }
+-#define EVP_PKEY_up_ref(x) ((x)->references++)
+-/* should not report missing blank line: */
+-DECLARE_STACK_OF(OPENSSL_CSTRING)
+-bool UTIL_iterate_dir(int (*fn)(const char *file, void *arg), void *arg,
+-    const char *path, bool recursive);
+-size_t UTIL_url_encode(
+-    size_t *size_needed);
+-size_t UTIL_url_encode(const char *source,
+-    char *destination,
+-    size_t destination_len,
+-    size_t *size_needed);
+-#error well. oops.
+-
+-int f()
+-{
+-    c;
+-    if (1)
+-        c;
+-    c;
+-    if (1)
+-        if (2) { /*@ brace after 'if' not on same line just to construct case */
+-            c;
+-        }
+-    e;
+-    const usign = {
+-        0xDF,
+-        { dd },
+-        dd
+-    };
+-    const unsign = {
+-        0xDF, { dd },
+-        dd
+-    };
+-}
+-const unsigned char trans_id[OSSL_CMP_TRANSACTIONID_LENGTH] = {
+-    0xDF,
+-};
+-const unsigned char trans_id[OSSL_CMP_TRANSACTIONID_LENGTH] = {
+-    0xDF,
+-};
+-typedef int
+-    a;
+-
+-typedef struct
+-{
+-    int a;
+-} b;
+-typedef enum {
+-    w = 0
+-} e_type;
+-typedef struct {
+-    enum {
+-        w = 0
+-    } e_type;
+-    enum {
+-        w = 0
+-    } e_type;
+-} e;
+-struct s_type {
+-    enum e_type {
+-        w = 0
+-    };
+-};
+-struct s_type {
+-    enum e_type {
+-        w = 0
+-    };
+-    enum e2_type {
+-        w = 0
+-    };
+-};
+-
+-#define X 1 + 1
+-#define Y /* .. */ 2 + 2
+-#define Z 3 + 3 * (*a++)
+-
+-static varref cmp_vars[] = {
+-    /* comment.  comment?  comment!  */
+-    { &opt_config },
+-    { &opt_section },
+-
+-    { &opt_server },
+-    { &opt_proxy },
+-    { &opt_path },
+-};
+-
+-#define SWITCH(x) \
+-    switch (x) {  \
+-    case 0:       \
+-        break;    \
+-    default:      \
+-        break;    \
+-    }
+-
+-#define DEFINE_SET_GET_BASE_TEST(PREFIX, SETN, GETN, DUP, FIELD, TYPE, ERR,                    \
+-    DEFAULT, NEW, FREE)                                                                        \
+-    static int execute_CTX_##SETN##_##GETN##_##FIELD(                                          \
+-        TEST_FIXTURE *fixture)                                                                 \
+-    {                                                                                          \
+-        CTX *ctx = fixture->ctx;                                                               \
+-        int (*set_fn)(CTX * ctx, TYPE) = (int (*)(CTX * ctx, TYPE)) PREFIX##_##SETN##_##FIELD; \
+-        /* comment */                                                                          \
+-    }
+-
+-union un var; /* struct/union/enum in variable type */
+-struct provider_store_st *f() /* struct/union/enum in function return type */
+-{
+-}
+-static void f(struct pem_pass_data *data) /* struct/union/enum in arg list */
+-{
+-}
+-
+-static void *fun(void)
+-{
+-    if (pem_name != NULL)
+-        /* comment */
+-        return NULL;
+-
+-label0:
+-label1: /* allow special indent 1 for label at outermost level in body */
+-    do {
+-    label2:
+-        size_t available_len, data_len;
+-        const char *curr = txt, *next = txt;
+-        char *tmp;
+-
+-        {
+-        label3:
+-        }
+-    } while (1);
+-
+-    char *intraline_string_with_comment_delimiters_and_dbl_space = "1  /*1";
+-    char *multiline_string_with_comment_delimiters_and_dbl_space = "1  /*1\
+-2222222\'22222222222222222\"222222222"
+-                                                                   "33333  /*3333333333"
+-                                                                   "44  /*44444444444\
+-55555555555555\
+-6666";
+-}
+-
+-ASN1_CHOICE(OSSL_CRMF_POPO) = {
+-    ASN1_IMP(OSSL_CRMF_POPO, value.raVerified, ASN1_NULL, 0),
+-    ASN1_EXP(OSSL_CRMF_POPO, value.keyAgreement, OSSL_CRMF_POPOPRIVKEY, 3)
+-} ASN1_CHOICE_END(OSSL_CRMF_POPO)
+-IMPLEMENT_ASN1_FUNCTIONS(OSSL_CRMF_POPO)
+-
+-ASN1_ADB(OSSL_CRMF_ATTRIBUTETYPEANDVALUE) = {
+-    ADB_ENTRY(NID_id_regCtrl_regToken,
+-        ASN1_SIMPLE(OSSL_CRMF_ATTRIBUTETYPEANDVALUE,
+-            value.regToken, ASN1_UTF8STRING)),
+-} ASN1_ADB_END(OSSL_CRMF_ATTRIBUTETYPEANDVALUE, 0, type, 0, &attributetypeandvalue_default_tt, NULL);
+-
+-ASN1_ITEM_TEMPLATE(OSSL_CRMF_MSGS) = ASN1_EX_TEMPLATE_TYPE(ASN1_TFLG_SEQUENCE_OF, 0,
+-    OSSL_CRMF_MSGS, OSSL_CRMF_MSG)
+-ASN1_ITEM_TEMPLATE_END(OSSL_CRMF_MSGS)
+-
+-void f_looong_body_200()
+-{ /* function body length up to 200 lines accepted */
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-}
+-
+-void f_looong_body_201()
+-{ /* function body length > 200 lines, but LONG BODY marker present */
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-    ;
+-}
+diff --git a/util/check-format-test-positives.c b/util/check-format-test-positives.c
+deleted file mode 100644
+index 96cfa8a902..0000000000
+--- a/util/check-format-test-positives.c
++++ /dev/null
+@@ -1,365 +0,0 @@
+-/*
+- * Copyright 2007-2023 The OpenSSL Project Authors. All Rights Reserved.
+- * Copyright Siemens AG 2015-2022
+- *
+- * Licensed under the Apache License 2.0 (the "License").  You may not use
+- * this file except in compliance with the License.  You can obtain a copy
+- * in the file LICENSE in the source distribution or at
+- * https://www.openssl.org/source/license.html
+- */
+-
+-/*
+- * This demonstrates/tests cases where check-format.pl should report issues.
+- * Some of the reports are due to sanity checks for proper nesting of comment
+- * delimiters and parenthesis-like symbols, e.g., on unexpected/unclosed braces.
+- */
+-
+-/*
+- * The '@'s after '*' are used for self-tests: they mark lines containing
+- * a single flaw that should be reported. Normally it should be reported
+- * while handling the given line, but in case of delayed checks there is a
+- * following digit indicating the number of reports expected for this line.
+- */
+-
+-/* For each of the following set of lines the tool should complain once */
+-/*@ tab character: 	 */
+-/*@ intra-line carriage return character:  */
+-/*@ non-printable ASCII character:  */
+-/*@ non-ASCII character: ä */
+-/*@ whitespace at EOL: */
+-// /*@ end-of-line comment style not allowed (for C90 compatibility) */
+-/*@0 intra-line comment indent off by 1, reported unless sloppy-cmt */
+-/*X */ /*@2 missing spc or '*' after comment start reported unless sloppy-spc */
+-/* X*/ /*@ missing space before comment end , reported unless sloppy-spc */
+-/*@ comment starting delimiter: /* inside intra-line comment */
+-/*@0
+- *@ above multi-line comment start indent off by 1, reported unless sloppy-cmt; this comment line is too long
+- *@ multi-line comment indent further off by 1 relative to comment start
+- *@ multi-line comment ending with text on last line */
+-/*@2 multi-line comment starting with text on first line
+- *@ comment starting delimiter: /* inside multi-line comment
+- *@ multi-line comment indent off by -1
+- *X*@ no spc after leading '*' in multi-line comment, reported unless sloppy-spc
+- *@0 more than two spaces after .   in comment, no more reported
+- *@0 more than two spaces after ?   in comment, no more reported
+- *@0 more than two spaces after !   in comment, no more reported
+- */
+-/*@ multi-line comment end indent off by -1 (relative to comment start) */
+-*/ /*@ unexpected comment ending delimiter outside comment */
+-/*- '-' for formatted comment not allowed in intra-line comment */
+-/*@ comment line is 4 columns tooooooooooooooooo wide, reported unless sloppy-len */
+-/*@ comment line is 5 columns toooooooooooooooooooooooooooooooooooooooooooooo wide */
+-#if ~0 /*@ '#if' with constant condition */
+-#endif /*@ indent of preproc. directive off by 1 (must be 0) */
+-#define X (1 + 1) /*@0 extra space in body, reported unless sloppy-spc */
+-#define Y 1 /*@ extra space before body, reported unless sloppy-spc */ \
+-    #define Z /*@2 preprocessor directive within multi-line directive */
+-    typedef struct { /*@0 extra space in code, reported unless sloppy-spc */
+-    enum { /*@1 extra space  in intra-line comment, no more reported */
+-        w = 0 /*@ hanging expr indent off by 1, or 3 for lines after '{' */
+-            && 1, /*@ hanging expr indent off by 3, or -1 for leading '&&' */
+-        x = 1, /*@ hanging expr indent off by -1 */
+-        y,
+-        z /*@ no space after ',', reported unless sloppy-spc */
+-    } e_member; /*@ space before ';', reported unless sloppy-spc */
+-    int v[1;        /*@ unclosed bracket in type declaration */
+-   union {          /*@ statement/type declaration indent off by -1 */
+-        struct {
+-        } s; /*@ no space before '{', reported unless sloppy-spc */
+-    }u_member;      /*@ no space after '}', reported unless sloppy-spc */
+-} s_type; /*@ statement/type declaration indent off by 4 */
+-int *somefunc(); /*@ no space before '*' in type decl, r unless sloppy-spc */
+-void main(int n)
+-{ /*@ opening brace at end of function definition header */
+-    for (;;)
+-        ; /*@ space before ')', reported unless sloppy-spc */
+-    for (; x; y)
+-        ; /*@2 space after '(' and before ';', unless sloppy-spc */
+-    for (;; n++) { /*@ missing space after ';', reported unless sloppy-spc */
+-        return; /*@0 (1-line) single statement in braces */
+-    }
+-} /*@2 code after '}' outside expr */
+-} /*@ unexpected closing brace (too many '}') outside expr */
+-)                   /*@ unexpected closing paren outside expr */
+-#endif /*@ unexpected #endif */
+-int f (int a,       /*@ space after fn before '(', reported unless sloppy-spc */
+-      int b,        /*@ hanging expr indent off by -1 */
+-       long I)      /*@ single-letter name 'I' */
+-{
+-    int x; /*@ code after '{' opening a block */
+-    int xx = 1) +   /*@ unexpected closing parenthesis */
+-        0L <        /*@ constant on LHS of comparison operator */
+-        a] -        /*@ unexpected closing bracket */
+-        3: *        /*@ unexpected ':' (without preceding '?') within expr */
+-        4
+-}; /*@ unexpected closing brace within expression */
+-    char y[] = {    /*@0 unclosed brace within initializer/enum expression */
+-        1* 1,       /*@ no space etc. before '*', reported unless sloppy-spc */
+-         2,         /*@ hanging expr indent (for lines after '{') off by 1 */
+-        (xx         /*@0 unclosed parenthesis in expression */
+-         ? y        /*@0 unclosed '? (conditional expression) */
+-         [0;        /*@4 unclosed bracket in expression */
+-    /*@ blank line within local decls */
+-   s_type s;        /*@2 local variable declaration indent off by -1 */
+-   t_type t;        /*@ local variable declaration indent again off by -1 */
+-    /* */           /*@0 missing blank line after local decls */
+-   somefunc(a,      /*@2 statement indent off by -1 */
+-          "aligned" /*@ expr indent off by -2 accepted if sloppy-hang */ "right"
+-           , b,     /*@ expr indent off by -1 */
+-           b,       /*@ expr indent as on line above, accepted if sloppy-hang */
+-    b, /*@ expr indent off -8 but @ extra indent accepted if sloppy-hang */
+-   "again aligned" /*@ expr indent off by -9 (left of stmt indent, */ "right",
+-            abc == /*@ .. so reported also with sloppy-hang; this line is too long */ 456
+-#define MAC(A) (A) /*@ nesting indent of preprocessor directive off by 1 */
+-             ? 1    /*@ hanging expr indent off by 1 */
+-              : 2); /*@ hanging expr indent off by 2, or 1 for leading ':' */
+-    if(a            /*@ missing space after 'if', reported unless sloppy-spc */
+-          /*@0 intra-line comment indent off by -1 (not: by 3 due to '&&') */
+-           && ! 0   /*@2 space after '!', reported unless sloppy-spc */
+-         || b ==    /*@ hanging expr indent off by 2, or -2 for leading '||' */
+-       (x<<= 1) +   /*@ missing space before '<<=' reported unless sloppy-spc */
+-       (xx+= 2) +   /*@ missing space before '+=', reported unless sloppy-spc */
+-       (a^ 1) +     /*@ missing space before '^', reported unless sloppy-spc */
+-       (y *=z) +    /*@ missing space after '*=' reported unless sloppy-spc */
+-       a %2 /       /*@ missing space after '%', reported unless sloppy-spc */
+-       1 +/* */     /*@ no space before comment, reported unless sloppy-spc */
+-       /* */+       /*@ no space after comment, reported unless sloppy-spc */
+-       s. e_member) /*@ space after '.', reported unless sloppy-spc */
+-         xx = a + b /*@ extra single-statement indent off by 1 */
+-               + 0; /*@ two times extra single-statement indent off by 3 */
+-    if (a ++)       /*@ space before postfix '++', reported unless sloppy-spc */
+-    {               /*@ {' not on same line as preceding 'if' */
+-    c; /*@0 single stmt in braces, reported on 1-stmt */
+-    } else          /*@ missing '{' on same line after '} else' */
+-      {             /*@ statement indent off by 2 */
+-    d; /*@0 single stmt in braces, reported on 1-stmt */
+-          }         /*@ statement indent off by 6 */
+-    if (1) f(a,     /*@ (non-brace) code after end of 'if' condition */
+-             b); else /*@ (non-brace) code before 'else' */
+-        do f(c, c); /*@ (non-brace) code after 'do' */
+-        while ( 2); /*@ space after '(', reported unless sloppy-spc */
+-    b; c;           /*@ more than one statement per line */
+-  outer:            /*@ outer label special indent off by 1 */
+-    do{             /*@ missing space before '{', reported unless sloppy-spc */
+-inner: /*@ inner label normal indent off by 1 */
+-    f(3, /*@ space after fn before '(', reported unless sloppy-spc */
+-        4); /*@0 false negative: should report single stmt in braces */
+-    }               /*@0 'while' not on same line as preceding '}' */
+-    while (a+ 0);   /*@2 missing space before '+', reported unless sloppy-spc */
+-    switch (b ) {   /*@ space before ')', reported unless sloppy-spc */
+-case 1: /*@ 'case' special statement indent off by -1 */
+-case (2): /*@ missing space after 'case', reported unless sloppy-spc */
+-default:; /*@ code after 'default:' */
+-}                   /*@ statement indent off by -4 */
+-    return(      /*@ missing space after 'return', reported unless sloppy-spc */
+-           x); }    /*@ code before block-level '}' */
+-/* Here the tool should stop complaining apart from the below issues at EOF */
+-
+-void f_looong_body()
+-    {
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-        ;
+-
+-        ; /*@ 2 essentially blank lines before, if !sloppy-spc */
+-    } /*@ function body length > 200 lines */
+-#if X /*@0 unclosed #if */
+-    struct t { /*@0 unclosed brace at decl/block level */
+-    enum {          /*@0 unclosed brace at enum/expression level */
+-          v = (1    /*@0 unclosed parenthesis */
+-               etyp /*@0 blank line follows just before EOF, if !sloppy-spc: */
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0090-Clear-addr_iter-on-reset-in-bss_acpt.patch b/package/libs/openssl/patches/0090-Clear-addr_iter-on-reset-in-bss_acpt.patch
new file mode 100644
index 0000000..75943c2
--- /dev/null
+++ b/package/libs/openssl/patches/0090-Clear-addr_iter-on-reset-in-bss_acpt.patch
@@ -0,0 +1,31 @@
+From 4fd09f24b5914c5f5f5421e057f12ecfec979249 Mon Sep 17 00:00:00 2001
+From: Joshua Rogers <MegaManSec@users.noreply.github.com>
+Date: Sun, 12 Oct 2025 05:47:16 +0800
+Subject: [PATCH 090/100] Clear addr_iter on reset in bss_acpt
+
+Signed-off-by: Joshua Rogers <MegaManSec@users.noreply.github.com>
+
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28915)
+
+(cherry picked from commit eb84d81e93b53f60302261870008eeb3117d36e2)
+---
+ crypto/bio/bss_acpt.c | 1 +
+ 1 file changed, 1 insertion(+)
+
+diff --git a/crypto/bio/bss_acpt.c b/crypto/bio/bss_acpt.c
+index 7c7a6a4645..da5a8e2c71 100644
+--- a/crypto/bio/bss_acpt.c
++++ b/crypto/bio/bss_acpt.c
+@@ -418,6 +418,7 @@ static long acpt_ctrl(BIO *b, int cmd, long num, void *ptr)
+         acpt_close_socket(b);
+         BIO_ADDRINFO_free(data->addr_first);
+         data->addr_first = NULL;
++        data->addr_iter = NULL;
+         b->flags = 0;
+         break;
+     case BIO_C_DO_STATE_MACHINE:
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0091-Clear-addr_iter-on-reset-in-bss_conn.patch b/package/libs/openssl/patches/0091-Clear-addr_iter-on-reset-in-bss_conn.patch
new file mode 100644
index 0000000..324285d
--- /dev/null
+++ b/package/libs/openssl/patches/0091-Clear-addr_iter-on-reset-in-bss_conn.patch
@@ -0,0 +1,31 @@
+From 827f7fdd8aec17f61717ef065ad0c0705dde81e6 Mon Sep 17 00:00:00 2001
+From: Joshua Rogers <MegaManSec@users.noreply.github.com>
+Date: Sat, 10 Jan 2026 19:55:15 +1100
+Subject: [PATCH 091/100] Clear addr_iter on reset in bss_conn
+
+Signed-off-by: Joshua Rogers <MegaManSec@users.noreply.github.com>
+
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28915)
+
+(cherry picked from commit c64912cd5956e90746e668509278e0b8224f7a2a)
+---
+ crypto/bio/bss_conn.c | 1 +
+ 1 file changed, 1 insertion(+)
+
+diff --git a/crypto/bio/bss_conn.c b/crypto/bio/bss_conn.c
+index 0a8b03188d..1853b09e99 100644
+--- a/crypto/bio/bss_conn.c
++++ b/crypto/bio/bss_conn.c
+@@ -393,6 +393,7 @@ static long conn_ctrl(BIO *b, int cmd, long num, void *ptr)
+         conn_close_socket(b);
+         BIO_ADDRINFO_free(data->addr_first);
+         data->addr_first = NULL;
++        data->addr_iter = NULL;
+         b->flags = 0;
+         break;
+     case BIO_C_DO_STATE_MACHINE:
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0092-Fix-openssl-cms-man-page-references-to-EncryptedData.patch b/package/libs/openssl/patches/0092-Fix-openssl-cms-man-page-references-to-EncryptedData.patch
new file mode 100644
index 0000000..4efe919
--- /dev/null
+++ b/package/libs/openssl/patches/0092-Fix-openssl-cms-man-page-references-to-EncryptedData.patch
@@ -0,0 +1,44 @@
+From 0884c045e3dd77fc937a446a3957ae058639cae1 Mon Sep 17 00:00:00 2001
+From: Josh Holtrop <jholtrop@gmail.com>
+Date: Tue, 8 Jul 2025 23:03:18 -0400
+Subject: [PATCH 092/100] Fix openssl-cms man page references to
+ -EncryptedData_encrypt option
+
+CLA: trivial
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Tue Jan 20 18:06:27 2026
+(Merged from https://github.com/openssl/openssl/pull/27996)
+
+(cherry picked from commit 233e1810587f30ff2c0b55a9af475df894ac5ed7)
+---
+ doc/man1/openssl-cms.pod.in | 4 ++--
+ 1 file changed, 2 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man1/openssl-cms.pod.in b/doc/man1/openssl-cms.pod.in
+index 77de2fd82c..ed2b5cf8c8 100644
+--- a/doc/man1/openssl-cms.pod.in
++++ b/doc/man1/openssl-cms.pod.in
+@@ -410,7 +410,7 @@ Currently the AES variants with GCM mode are the only supported AEAD
+ algorithms.
+ 
+ If not specified triple DES is used. Only used with B<-encrypt> and
+-B<-EncryptedData_create> commands.
++B<-EncryptedData_encrypt> commands.
+ 
+ =item B<-wrap> I<cipher>
+ 
+@@ -764,7 +764,7 @@ The use of PSS with B<-sign>.
+ 
+ The use of OAEP or non-RSA keys with B<-encrypt>.
+ 
+-Additionally the B<-EncryptedData_create> and B<-data_create> type cannot
++Additionally the B<-EncryptedData_encrypt> and B<-data_create> type cannot
+ be processed by the older L<openssl-smime(1)> command.
+ 
+ =head1 EXAMPLES
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0093-Fix-double-free-in-TLS1-PRF-KDF-when-digest-change-f.patch b/package/libs/openssl/patches/0093-Fix-double-free-in-TLS1-PRF-KDF-when-digest-change-f.patch
new file mode 100644
index 0000000..92438d3
--- /dev/null
+++ b/package/libs/openssl/patches/0093-Fix-double-free-in-TLS1-PRF-KDF-when-digest-change-f.patch
@@ -0,0 +1,40 @@
+From 4d566e3be67f9f595452169d6bf09015a2f0e087 Mon Sep 17 00:00:00 2001
+From: Zijie Zhao <zijie4@illinois.edu>
+Date: Thu, 15 Jan 2026 11:55:53 -0600
+Subject: [PATCH 093/100] Fix double-free in TLS1-PRF KDF when digest change
+ fails
+
+When changing the digest from MD5-SHA1 to a non-MD5-SHA1 digest,
+`ctx->P_sha1` is freed but not set to NULL. If `ossl_prov_macctx_load()`
+subsequently fails, `ctx->P_sha1` remains as a dangling pointer.
+When the context is later freed via `kdf_tls1_prf_reset()`, this
+causes a double-free.
+
+Fix by setting `ctx->P_sha1` to NULL immediately after freeing it.
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Tue Jan 20 18:23:59 2026
+(Merged from https://github.com/openssl/openssl/pull/29657)
+
+(cherry picked from commit f9106877fb1521e2d9e0f4b64ea514554cc4cce8)
+---
+ providers/implementations/kdfs/tls1_prf.c | 1 +
+ 1 file changed, 1 insertion(+)
+
+diff --git a/providers/implementations/kdfs/tls1_prf.c b/providers/implementations/kdfs/tls1_prf.c
+index f7c6e467ae..f0c4e5172b 100644
+--- a/providers/implementations/kdfs/tls1_prf.c
++++ b/providers/implementations/kdfs/tls1_prf.c
+@@ -184,6 +184,7 @@ static int kdf_tls1_prf_set_ctx_params(void *vctx, const OSSL_PARAM params[])
+                 return 0;
+         } else {
+             EVP_MAC_CTX_free(ctx->P_sha1);
++            ctx->P_sha1 = NULL;
+             if (!ossl_prov_macctx_load_from_params(&ctx->P_hash, params,
+                     OSSL_MAC_NAME_HMAC,
+                     NULL, NULL, libctx))
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0094-Fix-NULL-pointer-dereference-when-zlib-DSO-fails-to-.patch b/package/libs/openssl/patches/0094-Fix-NULL-pointer-dereference-when-zlib-DSO-fails-to-.patch
new file mode 100644
index 0000000..4ac7a8b
--- /dev/null
+++ b/package/libs/openssl/patches/0094-Fix-NULL-pointer-dereference-when-zlib-DSO-fails-to-.patch
@@ -0,0 +1,74 @@
+From 347e3f79a094ccf7cb2456acad18fa1590d0af8b Mon Sep 17 00:00:00 2001
+From: SiteRelEnby <125829806+SiteRelEnby@users.noreply.github.com>
+Date: Wed, 21 Jan 2026 02:57:52 +0000
+Subject: [PATCH 094/100] Fix NULL pointer dereference when zlib DSO fails to
+ load
+
+When ZLIB_SHARED is defined and DSO_load() fails to load the zlib
+library, ossl_comp_zlib_init() incorrectly returns 1 (success) while
+leaving all function pointers (p_compress, p_uncompress, etc.) as NULL.
+
+This causes COMP_zlib() and COMP_zlib_oneshot() to return valid-looking
+COMP_METHOD pointers, but when these methods are used (e.g., during
+TLS 1.3 certificate decompression), the NULL function pointers are
+dereferenced, causing a SIGSEGV crash.
+
+The bug occurs because the NULL pointer check (lines 297-303) was inside
+the `if (zlib_dso != NULL)` block, so it was skipped entirely when
+DSO_load() returned NULL.
+
+The fix moves the NULL pointer check outside the conditional block,
+consistent with how c_brotli.c and c_zstd.c handle this case. Now if
+the DSO fails to load, all function pointers remain NULL, the check
+catches this, and the function correctly returns 0 (failure).
+
+This also fixes an incorrect cast of p_uncompress from compress_ft to
+the correct uncompress_ft type.
+
+PoC demonstrating the bug: https://github.com/SiteRelEnby/openssl-zlib-poc
+
+Fixes #23563
+
+CLA: trivial
+
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Thu Jan 22 17:00:50 2026
+(Merged from https://github.com/openssl/openssl/pull/29699)
+
+(cherry picked from commit 045ca33cef8d1585ecb9ee8a4ef04e6e790f6828)
+---
+ crypto/comp/c_zlib.c | 14 +++++++-------
+ 1 file changed, 7 insertions(+), 7 deletions(-)
+
+diff --git a/crypto/comp/c_zlib.c b/crypto/comp/c_zlib.c
+index 229a73227c..a17362242c 100644
+--- a/crypto/comp/c_zlib.c
++++ b/crypto/comp/c_zlib.c
+@@ -228,14 +228,14 @@ DEFINE_RUN_ONCE_STATIC(ossl_comp_zlib_init)
+         p_deflate = (deflate_ft)DSO_bind_func(zlib_dso, "deflate");
+         p_deflateInit_ = (deflateInit__ft)DSO_bind_func(zlib_dso, "deflateInit_");
+         p_zError = (zError__ft)DSO_bind_func(zlib_dso, "zError");
++    }
+ 
+-        if (p_compress == NULL || p_inflateEnd == NULL
+-            || p_inflate == NULL || p_inflateInit_ == NULL
+-            || p_deflateEnd == NULL || p_deflate == NULL
+-            || p_deflateInit_ == NULL || p_zError == NULL) {
+-            ossl_comp_zlib_cleanup();
+-            return 0;
+-        }
++    if (p_compress == NULL || p_inflateEnd == NULL
++        || p_inflate == NULL || p_inflateInit_ == NULL
++        || p_deflateEnd == NULL || p_deflate == NULL
++        || p_deflateInit_ == NULL || p_zError == NULL) {
++        ossl_comp_zlib_cleanup();
++        return 0;
+     }
+ #endif
+     return 1;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0095-DOC-Clarify-EVP_PKEY_CTX_-get-set-_app_data-document.patch b/package/libs/openssl/patches/0095-DOC-Clarify-EVP_PKEY_CTX_-get-set-_app_data-document.patch
new file mode 100644
index 0000000..04c1dfd
--- /dev/null
+++ b/package/libs/openssl/patches/0095-DOC-Clarify-EVP_PKEY_CTX_-get-set-_app_data-document.patch
@@ -0,0 +1,38 @@
+From 04e2a96d723056ae58ed71d8b6bebe5c1d83c67f Mon Sep 17 00:00:00 2001
+From: Daniel Kubec <kubec@openssl.org>
+Date: Wed, 21 Jan 2026 23:48:58 +0100
+Subject: [PATCH 095/100] DOC: Clarify EVP_PKEY_CTX_{get,set}_app_data
+ documentation
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+MergeDate: Fri Jan 23 10:17:12 2026
+(Merged from https://github.com/openssl/openssl/pull/29710)
+---
+ doc/man3/EVP_PKEY_keygen.pod | 10 ++++++----
+ 1 file changed, 6 insertions(+), 4 deletions(-)
+
+diff --git a/doc/man3/EVP_PKEY_keygen.pod b/doc/man3/EVP_PKEY_keygen.pod
+index 4331236186..4deba4e29f 100644
+--- a/doc/man3/EVP_PKEY_keygen.pod
++++ b/doc/man3/EVP_PKEY_keygen.pod
+@@ -86,10 +86,12 @@ If the callback returns 0 then the key generation operation is aborted and an
+ error occurs. This might occur during a time consuming operation where
+ a user clicks on a "cancel" button.
+ 
+-The functions EVP_PKEY_CTX_set_app_data() and EVP_PKEY_CTX_get_app_data() set
+-and retrieve an opaque pointer. This can be used to set some application
+-defined value which can be retrieved in the callback: for example a handle
+-which is used to update a "progress dialog".
++The functions EVP_PKEY_CTX_set_app_data() and EVP_PKEY_CTX_get_app_data()
++associate an opaque, application-defined pointer with an EVP_PKEY_CTX object.
++
++This pointer is not interpreted by the library and is reserved entirely for use
++by the application. It may be used to store arbitrary context or state that
++needs to be accessible wherever the corresponding EVP_PKEY_CTX is available.
+ 
+ EVP_PKEY_Q_keygen() abstracts from the explicit use of B<EVP_PKEY_CTX> while
+ providing a 'quick' but limited way of generating a new asymmetric key pair.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0096-DOC-Add-EVP_CIPHER_CTX_-get-set-_app_data-documentat.patch b/package/libs/openssl/patches/0096-DOC-Add-EVP_CIPHER_CTX_-get-set-_app_data-documentat.patch
new file mode 100644
index 0000000..acd78ab
--- /dev/null
+++ b/package/libs/openssl/patches/0096-DOC-Add-EVP_CIPHER_CTX_-get-set-_app_data-documentat.patch
@@ -0,0 +1,119 @@
+From 29d9ae2664bb479d2bd0a652377cbb1b8cc6cde7 Mon Sep 17 00:00:00 2001
+From: Daniel Kubec <kubec@openssl.org>
+Date: Wed, 21 Jan 2026 15:11:38 +0100
+Subject: [PATCH 096/100] DOC: Add EVP_CIPHER_CTX_{get,set}_app_data
+ documentation
+
+Fixes #9788
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+MergeDate: Fri Jan 23 10:30:45 2026
+(Merged from https://github.com/openssl/openssl/pull/29704)
+---
+ doc/build.info                           |  6 ++++
+ doc/man3/EVP_CIPHER_CTX_get_app_data.pod | 38 ++++++++++++++++++++++++
+ doc/man3/EVP_EncryptInit.pod             |  4 ---
+ 3 files changed, 44 insertions(+), 4 deletions(-)
+ create mode 100644 doc/man3/EVP_CIPHER_CTX_get_app_data.pod
+
+diff --git a/doc/build.info b/doc/build.info
+index c14dbd2cf4..30f519338a 100644
+--- a/doc/build.info
++++ b/doc/build.info
+@@ -1099,6 +1099,10 @@ DEPEND[html/man3/EVP_BytesToKey.html]=man3/EVP_BytesToKey.pod
+ GENERATE[html/man3/EVP_BytesToKey.html]=man3/EVP_BytesToKey.pod
+ DEPEND[man/man3/EVP_BytesToKey.3]=man3/EVP_BytesToKey.pod
+ GENERATE[man/man3/EVP_BytesToKey.3]=man3/EVP_BytesToKey.pod
++DEPEND[html/man3/EVP_CIPHER_CTX_get_app_data.html]=man3/EVP_CIPHER_CTX_get_app_data.pod
++GENERATE[html/man3/EVP_CIPHER_CTX_get_app_data.html]=man3/EVP_CIPHER_CTX_get_app_data.pod
++DEPEND[man/man3/EVP_CIPHER_CTX_get_app_data.3]=man3/EVP_CIPHER_CTX_get_app_data.pod
++GENERATE[man/man3/EVP_CIPHER_CTX_get_app_data.3]=man3/EVP_CIPHER_CTX_get_app_data.pod
+ DEPEND[html/man3/EVP_CIPHER_CTX_get_cipher_data.html]=man3/EVP_CIPHER_CTX_get_cipher_data.pod
+ GENERATE[html/man3/EVP_CIPHER_CTX_get_cipher_data.html]=man3/EVP_CIPHER_CTX_get_cipher_data.pod
+ DEPEND[man/man3/EVP_CIPHER_CTX_get_cipher_data.3]=man3/EVP_CIPHER_CTX_get_cipher_data.pod
+@@ -3066,6 +3070,7 @@ html/man3/ERR_remove_state.html \
+ html/man3/ERR_set_mark.html \
+ html/man3/EVP_ASYM_CIPHER_free.html \
+ html/man3/EVP_BytesToKey.html \
++html/man3/EVP_CIPHER_CTX_get_app_data.html \
+ html/man3/EVP_CIPHER_CTX_get_cipher_data.html \
+ html/man3/EVP_CIPHER_CTX_get_original_iv.html \
+ html/man3/EVP_CIPHER_meth_new.html \
+@@ -3676,6 +3681,7 @@ man/man3/ERR_remove_state.3 \
+ man/man3/ERR_set_mark.3 \
+ man/man3/EVP_ASYM_CIPHER_free.3 \
+ man/man3/EVP_BytesToKey.3 \
++man/man3/EVP_CIPHER_CTX_get_app_data.3 \
+ man/man3/EVP_CIPHER_CTX_get_cipher_data.3 \
+ man/man3/EVP_CIPHER_CTX_get_original_iv.3 \
+ man/man3/EVP_CIPHER_meth_new.3 \
+diff --git a/doc/man3/EVP_CIPHER_CTX_get_app_data.pod b/doc/man3/EVP_CIPHER_CTX_get_app_data.pod
+new file mode 100644
+index 0000000000..3865bb4390
+--- /dev/null
++++ b/doc/man3/EVP_CIPHER_CTX_get_app_data.pod
+@@ -0,0 +1,38 @@
++=pod
++
++=head1 NAME
++
++EVP_CIPHER_CTX_get_app_data, EVP_CIPHER_CTX_set_app_data - Routines to
++inspect and modify application data related to EVP_CIPHER_CTX
++
++=head1 SYNOPSIS
++
++ #include <openssl/evp.h>
++
++ void *EVP_CIPHER_CTX_get_app_data(const EVP_CIPHER_CTX *ctx);
++ void EVP_CIPHER_CTX_set_app_data(EVP_CIPHER_CTX *ctx, void *data);
++
++=head1 DESCRIPTION
++
++The functions EVP_CIPHER_CTX_set_app_data() and EVP_CIPHER_CTX_get_app_data()
++associate an opaque, application-defined pointer with an EVP_CIPHER_CTX object.
++
++This pointer is not interpreted by the library and is reserved entirely for use
++by the application. It may be used to store arbitrary context or state that
++needs to be accessible wherever the corresponding EVP_CIPHER_CTX is available.
++
++=head1 RETURN VALUES
++
++The EVP_CIPHER_CTX_get_app_data() function returns a opaque pointer to the
++current application data for the EVP_CIPHER_CTX.
++
++=head1 COPYRIGHT
++
++Copyright 2026 The OpenSSL Project Authors. All Rights Reserved.
++
++Licensed under the Apache License 2.0 (the "License").  You may not use
++this file except in compliance with the License.  You can obtain a copy
++in the file LICENSE in the source distribution or at
++L<https://www.openssl.org/source/license.html>.
++
++=cut
+diff --git a/doc/man3/EVP_EncryptInit.pod b/doc/man3/EVP_EncryptInit.pod
+index 497e6cfe26..33c6dcc278 100644
+--- a/doc/man3/EVP_EncryptInit.pod
++++ b/doc/man3/EVP_EncryptInit.pod
+@@ -61,8 +61,6 @@ EVP_CIPHER_CTX_get_block_size,
+ EVP_CIPHER_CTX_get_key_length,
+ EVP_CIPHER_CTX_get_iv_length,
+ EVP_CIPHER_CTX_get_tag_length,
+-EVP_CIPHER_CTX_get_app_data,
+-EVP_CIPHER_CTX_set_app_data,
+ EVP_CIPHER_CTX_flags,
+ EVP_CIPHER_CTX_set_flags,
+ EVP_CIPHER_CTX_clear_flags,
+@@ -196,8 +194,6 @@ EVP_CIPHER_CTX_mode
+  int EVP_CIPHER_CTX_get_key_length(const EVP_CIPHER_CTX *ctx);
+  int EVP_CIPHER_CTX_get_iv_length(const EVP_CIPHER_CTX *ctx);
+  int EVP_CIPHER_CTX_get_tag_length(const EVP_CIPHER_CTX *ctx);
+- void *EVP_CIPHER_CTX_get_app_data(const EVP_CIPHER_CTX *ctx);
+- void EVP_CIPHER_CTX_set_app_data(const EVP_CIPHER_CTX *ctx, void *data);
+  int EVP_CIPHER_CTX_get_type(const EVP_CIPHER_CTX *ctx);
+  int EVP_CIPHER_CTX_get_mode(const EVP_CIPHER_CTX *ctx);
+  int EVP_CIPHER_CTX_get_num(const EVP_CIPHER_CTX *ctx);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0097-Correct-alert-when-extended-master-secret-support-is.patch b/package/libs/openssl/patches/0097-Correct-alert-when-extended-master-secret-support-is.patch
new file mode 100644
index 0000000..e58fc9f
--- /dev/null
+++ b/package/libs/openssl/patches/0097-Correct-alert-when-extended-master-secret-support-is.patch
@@ -0,0 +1,37 @@
+From af551a874ec0856ef46034a56ca66ac4cdd5e72d Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Wed, 21 Jan 2026 18:50:07 +0100
+Subject: [PATCH 097/100] Correct alert when extended master secret support is
+ dropped
+
+When resuming session with the extended master secret support
+dropped we should use SSL_AD_HANDSHAKE_FAILURE instead of
+SSL_AD_ILLEGAL_PARAMETER according to the RFC7627 section 5.
+
+Fixes #9791
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+MergeDate: Fri Jan 23 10:35:11 2026
+(Merged from https://github.com/openssl/openssl/pull/29706)
+---
+ ssl/ssl_sess.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/ssl/ssl_sess.c b/ssl/ssl_sess.c
+index 7df67148a7..c9c447d19c 100644
+--- a/ssl/ssl_sess.c
++++ b/ssl/ssl_sess.c
+@@ -698,7 +698,7 @@ int ssl_get_prev_session(SSL *s, CLIENTHELLO_MSG *hello)
+     if (ret->flags & SSL_SESS_FLAG_EXTMS) {
+         /* If old session includes extms, but new does not: abort handshake */
+         if (!(s->s3.flags & TLS1_FLAGS_RECEIVED_EXTMS)) {
+-            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, SSL_R_INCONSISTENT_EXTMS);
++            SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_INCONSISTENT_EXTMS);
+             fatal = 1;
+             goto err;
+         }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0098-rsa_sig.c-Properly-duplicate-the-sig-member.patch b/package/libs/openssl/patches/0098-rsa_sig.c-Properly-duplicate-the-sig-member.patch
new file mode 100644
index 0000000..ba418dc
--- /dev/null
+++ b/package/libs/openssl/patches/0098-rsa_sig.c-Properly-duplicate-the-sig-member.patch
@@ -0,0 +1,45 @@
+From 9389cdd717569a13be65f5327089193c17aee15b Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Wed, 21 Jan 2026 19:10:28 +0100
+Subject: [PATCH 098/100] rsa_sig.c: Properly duplicate the sig member
+
+Otherwise UAF and doublefree appears when the duplicate
+is freed.
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+MergeDate: Fri Jan 23 10:40:29 2026
+(Merged from https://github.com/openssl/openssl/pull/29707)
+---
+ providers/implementations/signature/rsa_sig.c | 7 +++++++
+ 1 file changed, 7 insertions(+)
+
+diff --git a/providers/implementations/signature/rsa_sig.c b/providers/implementations/signature/rsa_sig.c
+index 825c61bf0d..b53d039489 100644
+--- a/providers/implementations/signature/rsa_sig.c
++++ b/providers/implementations/signature/rsa_sig.c
+@@ -996,6 +996,7 @@ static void *rsa_dupctx(void *vprsactx)
+     dstctx->mdctx = NULL;
+     dstctx->tbuf = NULL;
+     dstctx->propq = NULL;
++    dstctx->sig = NULL;
+ 
+     if (srcctx->rsa != NULL && !RSA_up_ref(srcctx->rsa))
+         goto err;
+@@ -1022,6 +1023,12 @@ static void *rsa_dupctx(void *vprsactx)
+             goto err;
+     }
+ 
++    if (srcctx->sig != NULL) {
++        dstctx->sig = OPENSSL_memdup(srcctx->sig, srcctx->siglen);
++        if (dstctx->sig == NULL)
++            goto err;
++    }
++
+     return dstctx;
+ err:
+     rsa_freectx(dstctx);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0099-rsa_enc.c-Properly-duplicate-the-oaep_label-member.patch b/package/libs/openssl/patches/0099-rsa_enc.c-Properly-duplicate-the-oaep_label-member.patch
new file mode 100644
index 0000000..9ed3178
--- /dev/null
+++ b/package/libs/openssl/patches/0099-rsa_enc.c-Properly-duplicate-the-oaep_label-member.patch
@@ -0,0 +1,38 @@
+From 923213c68032dce9f98e90758edb9c5f87cd2400 Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Wed, 21 Jan 2026 19:11:30 +0100
+Subject: [PATCH 099/100] rsa_enc.c: Properly duplicate the oaep_label member
+
+Otherwise UAF and doublefree appears when the duplicate
+is freed.
+Reported by Tomas Dulka and Stanislav Fort (Aisle Research)
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+MergeDate: Fri Jan 23 10:40:31 2026
+(Merged from https://github.com/openssl/openssl/pull/29707)
+---
+ providers/implementations/asymciphers/rsa_enc.c | 6 ++++++
+ 1 file changed, 6 insertions(+)
+
+diff --git a/providers/implementations/asymciphers/rsa_enc.c b/providers/implementations/asymciphers/rsa_enc.c
+index 6a82f88217..6cbd01cbc5 100644
+--- a/providers/implementations/asymciphers/rsa_enc.c
++++ b/providers/implementations/asymciphers/rsa_enc.c
+@@ -332,6 +332,12 @@ static void *rsa_dupctx(void *vprsactx)
+         return NULL;
+     }
+ 
++    if (dstctx->oaep_label != NULL
++        && (dstctx->oaep_label = OPENSSL_memdup(dstctx->oaep_label, dstctx->oaep_labellen)) == NULL) {
++        rsa_freectx(dstctx);
++        return NULL;
++    }
++
+     return dstctx;
+ }
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0100-Revert-rsa_sig.c-Properly-duplicate-the-sig-member.patch b/package/libs/openssl/patches/0100-Revert-rsa_sig.c-Properly-duplicate-the-sig-member.patch
new file mode 100644
index 0000000..5fd734b
--- /dev/null
+++ b/package/libs/openssl/patches/0100-Revert-rsa_sig.c-Properly-duplicate-the-sig-member.patch
@@ -0,0 +1,44 @@
+From 3250efdfe99d2d7fe4fb05231add7fba864b7653 Mon Sep 17 00:00:00 2001
+From: Norbert Pocs <norbertp@openssl.org>
+Date: Fri, 23 Jan 2026 11:59:55 +0100
+Subject: [PATCH 100/100] Revert "rsa_sig.c: Properly duplicate the sig member"
+
+This reverts commit 9389cdd717569a13be65f5327089193c17aee15b.
+
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+MergeDate: Fri Jan 23 13:58:21 2026
+(Merged from https://github.com/openssl/openssl/pull/29735)
+---
+ providers/implementations/signature/rsa_sig.c | 7 -------
+ 1 file changed, 7 deletions(-)
+
+diff --git a/providers/implementations/signature/rsa_sig.c b/providers/implementations/signature/rsa_sig.c
+index b53d039489..825c61bf0d 100644
+--- a/providers/implementations/signature/rsa_sig.c
++++ b/providers/implementations/signature/rsa_sig.c
+@@ -996,7 +996,6 @@ static void *rsa_dupctx(void *vprsactx)
+     dstctx->mdctx = NULL;
+     dstctx->tbuf = NULL;
+     dstctx->propq = NULL;
+-    dstctx->sig = NULL;
+ 
+     if (srcctx->rsa != NULL && !RSA_up_ref(srcctx->rsa))
+         goto err;
+@@ -1023,12 +1022,6 @@ static void *rsa_dupctx(void *vprsactx)
+             goto err;
+     }
+ 
+-    if (srcctx->sig != NULL) {
+-        dstctx->sig = OPENSSL_memdup(srcctx->sig, srcctx->siglen);
+-        if (dstctx->sig == NULL)
+-            goto err;
+-    }
+-
+     return dstctx;
+ err:
+     rsa_freectx(dstctx);
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

