From 852ed0379a170ca031bc238ec34a4a8768526a45 Mon Sep 17 00:00:00 2001
From: Daniel Golle <daniel@makrotopia.org>
Date: Thu, 19 Sep 2024 14:33:15 +0100
Subject: [PATCH] generic: 5.15: mtk_eth_soc: increase QDMA RESV_BUF size

Increase QDMA RESV_BUF from 2K to 3K for netsys v2 to match Mediatek SDK.
This helps reduce the possibility of Ethernet transmit timeouts.

Link: https://git01.mediatek.com/plugins/gitiles/openwrt/feeds/mtk-openwrt-feeds/+/19d8456c3051e5f6dabf42fa770916a2126ea4bf
Signed-off-by: Daniel Golle <daniel@makrotopia.org>
---
 ...-mediatek-enlarge-DMA-reserve-buffer.patch | 44 +++++++++++++++
 ..._eth_soc-add-paths-and-SerDes-modes-.patch | 54 +++++++++----------
 2 files changed, 71 insertions(+), 27 deletions(-)
 create mode 100644 target/linux/generic/pending-5.15/734-net-ethernet-mediatek-enlarge-DMA-reserve-buffer.patch

diff --git a/target/linux/generic/pending-5.15/734-net-ethernet-mediatek-enlarge-DMA-reserve-buffer.patch b/target/linux/generic/pending-5.15/734-net-ethernet-mediatek-enlarge-DMA-reserve-buffer.patch
new file mode 100644
index 00000000000000..d786b462c2579d
--- /dev/null
+++ b/target/linux/generic/pending-5.15/734-net-ethernet-mediatek-enlarge-DMA-reserve-buffer.patch
@@ -0,0 +1,44 @@
+From: Chad Monroe <chad@monroe.io>
+Date: Mon, 16 Sep 2024 19:29:03 -0700
+Subject: [PATCH] net: ethernet: mediatek: increase QDMA RESV_BUF size
+
+Increase QDMA RESV_BUF from 2K to 3K for netsys v2 to match Mediatek SDK[1].
+This helps reduce the possibility of Ethernet transmit timeouts.
+
+[1]: https://git01.mediatek.com/plugins/gitiles/openwrt/feeds/mtk-openwrt-feeds/+/19d8456c3051e5f6dabf42fa770916a2126ea4bf
+
+Signed-off-by: Chad Monroe <chad@monroe.io>
+---
+ drivers/net/ethernet/mediatek/mtk_eth_soc.c |    6 ++++--
+ drivers/net/ethernet/mediatek/mtk_eth_soc.h |    1 +
+ 2 files changed, 5 insertions(+), 2 deletions(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.h
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.h
+@@ -271,6 +271,7 @@
+ #define MTK_WCOMP_EN		BIT(24)
+ #define MTK_RESV_BUF		(0x80 << 16)
+ #define MTK_MUTLI_CNT		(0x4 << 12)
++#define MTK_RESV_BUF_MASK	(0xff << 16)
+ #define MTK_LEAKY_BUCKET_EN	BIT(11)
+ 
+ /* QDMA Flow Control Register */
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -3309,12 +3309,14 @@ static int mtk_start_dma(struct mtk_eth
+ 		       MTK_TX_BT_32DWORDS | MTK_NDP_CO_PRO |
+ 		       MTK_RX_2B_OFFSET | MTK_TX_WB_DDONE;
+ 
+-		if (mtk_is_netsys_v2_or_greater(eth))
++		if (mtk_is_netsys_v2_or_greater(eth)) {
++			val &= ~MTK_RESV_BUF_MASK;
+ 			val |= MTK_MUTLI_CNT | MTK_RESV_BUF |
+ 			       MTK_WCOMP_EN | MTK_DMAD_WR_WDONE |
+ 			       MTK_CHK_DDONE_EN | MTK_LEAKY_BUCKET_EN;
+-		else
++		} else {
+ 			val |= MTK_RX_BT_32DWORDS;
++		}
+ 		mtk_w32(eth, val, reg_map->qdma.glo_cfg);
+ 
+ 		mtk_w32(eth,
