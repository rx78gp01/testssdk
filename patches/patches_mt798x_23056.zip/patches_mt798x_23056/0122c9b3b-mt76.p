From 2cd8697efb5c1ef1e56e5530005c746bcab81913 Mon Sep 17 00:00:00 2001
From: xxxxxxx <xxxxxxx@users.noreply.github.com>
Date: Wed, 21 Aug 2024 23:28:46 +0800
Subject: [PATCH] mt76

---
 ...-channel-time-is-reset-by-ch_restore.patch |  58 +++++
 ...-Fixed-null-pointer-dereference-issu.patch |  38 ++++
 ...hannel-time-too-long-on-duty-channel.patch |  51 +++++
 ...-statistics-about-tx-retry-and-tx-fa.patch |  44 ++++
 ...sanity-check-to-prevent-kernel-crash.patch |  35 +++
 ...19-wifi-mt76-mt7915-adjust-rx-filter.patch |  58 +++++
 ...-add-PID-to-only-report-data-frame-T.patch | 116 ++++++++++
 ...i-mt76-mt7915-wed-add-wed-tx-support.patch | 139 ++++++++++++
 ...-wed-add-wds-support-when-wed-is-ena.patch | 210 ++++++++++++++++++
 ...-wed-find-rx-token-by-physical-addre.patch |  64 ++++++
 10 files changed, 813 insertions(+)
 create mode 100644 package/kernel/mac80211/patches/subsys/920-mac80211-mtk-ACS-channel-time-is-reset-by-ch_restore.patch
 create mode 100644 package/kernel/mt76/patches/0005-wifi-mt76-mt7915-Fixed-null-pointer-dereference-issu.patch
 create mode 100644 package/kernel/mt76/patches/0006-wifi-mt76-ACS-channel-time-too-long-on-duty-channel.patch
 create mode 100644 package/kernel/mt76/patches/0011-wifi-mt76-fix-tx-statistics-about-tx-retry-and-tx-fa.patch
 create mode 100644 package/kernel/mt76/patches/0012-wifi-mt76-add-sanity-check-to-prevent-kernel-crash.patch
 create mode 100644 package/kernel/mt76/patches/0019-wifi-mt76-mt7915-adjust-rx-filter.patch
 create mode 100644 package/kernel/mt76/patches/0022-wifi-mt76-mt7915-add-PID-to-only-report-data-frame-T.patch
 create mode 100644 package/kernel/mt76/patches/2000-wifi-mt76-mt7915-wed-add-wed-tx-support.patch
 create mode 100644 package/kernel/mt76/patches/2001-wifi-mt76-mt7915-wed-add-wds-support-when-wed-is-ena.patch
 create mode 100644 package/kernel/mt76/patches/2003-wifi-mt76-mt7915-wed-find-rx-token-by-physical-addre.patch

diff --git a/package/kernel/mac80211/patches/subsys/920-mac80211-mtk-ACS-channel-time-is-reset-by-ch_restore.patch b/package/kernel/mac80211/patches/subsys/920-mac80211-mtk-ACS-channel-time-is-reset-by-ch_restore.patch
new file mode 100644
index 0000000..71095ca
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/920-mac80211-mtk-ACS-channel-time-is-reset-by-ch_restore.patch
@@ -0,0 +1,58 @@
+From e86b89d026fa963ff6c789747b9b373884956157 Mon Sep 17 00:00:00 2001
+From: Evelyn Tsai <evelyn.tsai@mediatek.com>
+Date: Fri, 1 Dec 2023 08:48:35 +0800
+Subject: [PATCH] mac80211: mtk: ACS channel time is reset by ch_restore
+
+Issue:
+There's a chance that the channel time for duty channel is zero in ACS
+scan.
+
+Root cause:
+The chan_stat may be reset when restore to duty channel.
+Mac80211 will notify to hostapd when scan done and then restore to duty
+channel.
+And mt76 will clear scan flag after restore done.
+If hostapd get the chan_stat before channel_restore, will get the
+correct channel time;
+If hostapd get the chan_stat after channel_restore, will get zero
+channel time;
+
+Solution:
+When channel switch, will check the mac80211 scan state but not the mt76 scan flag.
+Mac80211 scan state will be set in scanning, and will be reset after
+scan done and before restore to duty channel.
+
+Signed-off-by: fancy.liu <fancy.liu@mediatek.com>
+---
+ include/net/mac80211.h | 6 ++++++
+ net/mac80211/util.c    | 8 ++++++++
+ 2 files changed, 14 insertions(+)
+
+--- a/include/net/mac80211.h
++++ b/include/net/mac80211.h
+@@ -7444,4 +7444,10 @@ int ieee80211_set_active_links(struct ie
+ void ieee80211_set_active_links_async(struct ieee80211_vif *vif,
+ 				      u16 active_links);
+ 
++/**
++ * ieee80211_get_scanning - get scanning bitmask
++ *
++ * @hw: pointer as obtained from ieee80211_alloc_hw()
++ */
++unsigned long ieee80211_get_scanning(struct ieee80211_hw *hw);
+ #endif /* MAC80211_H */
+--- a/net/mac80211/util.c
++++ b/net/mac80211/util.c
+@@ -5147,3 +5147,11 @@ void ieee80211_fragment_element(struct s
+ 
+ 	*len_pos = elem_len;
+ }
++
++unsigned long ieee80211_get_scanning(struct ieee80211_hw *hw)
++{
++	struct ieee80211_local *local = hw_to_local(hw);
++
++	return local->scanning;
++}
++EXPORT_SYMBOL(ieee80211_get_scanning);
+\ No newline at end of file
diff --git a/package/kernel/mt76/patches/0005-wifi-mt76-mt7915-Fixed-null-pointer-dereference-issu.patch b/package/kernel/mt76/patches/0005-wifi-mt76-mt7915-Fixed-null-pointer-dereference-issu.patch
new file mode 100644
index 0000000..07ae952
--- /dev/null
+++ b/package/kernel/mt76/patches/0005-wifi-mt76-mt7915-Fixed-null-pointer-dereference-issu.patch
@@ -0,0 +1,38 @@
+From dc0b3bc81859846e1f7bab33eca1212753b4ec1d Mon Sep 17 00:00:00 2001
+From: MeiChia Chiu <meichia.chiu@mediatek.com>
+Date: Thu, 26 Oct 2023 21:11:05 +0800
+Subject: [PATCH 05/21] wifi: mt76: mt7915: Fixed null pointer dereference
+ issue
+
+Without this patch, when the station is still in Authentication stage and
+sends a "Notify bandwidth change action frame" to AP at the same time,
+there will be a race condition that causes a crash to occur because the AP
+access "msta->vif" that has not been fully initialized.
+
+Signed-off-by: Bo Jiao <Bo.Jiao@mediatek.com>
+Signed-off-by: Money Wang <money.wang@mediatek.com>
+Signed-off-by: MeiChia Chiu <meichia.chiu@mediatek.com>
+---
+ mt7915/main.c | 6 ++++++
+ 1 file changed, 6 insertions(+)
+
+diff --git a/mt7915/main.c b/mt7915/main.c
+index 1903db4..61a1dbb 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -1170,6 +1170,12 @@ static void mt7915_sta_rc_update(struct ieee80211_hw *hw,
+ 	if (!msta->wcid.sta)
+ 		return;
+ 
++	if (!msta->vif) {
++		dev_warn(dev->mt76.dev, "Un-initialized STA %pM wcid %d in rc_work\n",
++			 sta->addr, msta->wcid.idx);
++		return;
++	}
++
+ 	mt7915_sta_rc_work(&changed, sta);
+ 	ieee80211_queue_work(hw, &dev->rc_work);
+ }
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/0006-wifi-mt76-ACS-channel-time-too-long-on-duty-channel.patch b/package/kernel/mt76/patches/0006-wifi-mt76-ACS-channel-time-too-long-on-duty-channel.patch
new file mode 100644
index 0000000..8fd5036
--- /dev/null
+++ b/package/kernel/mt76/patches/0006-wifi-mt76-ACS-channel-time-too-long-on-duty-channel.patch
@@ -0,0 +1,51 @@
+From e6a8b61c776db565c532515af002156da38f2f48 Mon Sep 17 00:00:00 2001
+From: Evelyn Tsai <evelyn.tsai@mediatek.com>
+Date: Sat, 18 Nov 2023 07:36:45 +0800
+Subject: [PATCH 06/21] wifi: mt76: ACS channel time too long on duty channel
+
+Issue:
+There's a chance that the channel time for duty channel is zero in ACS
+scan.
+
+Root cause:
+The chan_stat may be reset when restore to duty channel.
+Mac80211 will notify to hostapd when scan done and then restore to duty
+channel.
+And mt76 will clear scan flag after restore done.
+If hostapd get the chan_stat before channel_restore, will get the
+correct channel time;
+If hostapd get the chan_stat after channel_restore, will get zero
+channel time;
+
+Solution:
+When channel switch, will check the mac80211 scan state but not the mt76 scan flag.
+Mac80211 scan state will be set in scanning, and will be reset after
+scan done and before restore to duty channel.
+---
+ mac80211.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/mac80211.c b/mac80211.c
+index e7b763b..bc20f60 100644
+--- a/mac80211.c
++++ b/mac80211.c
+@@ -927,6 +927,7 @@ void mt76_set_channel(struct mt76_phy *phy)
+ 	struct mt76_dev *dev = phy->dev;
+ 	int timeout = HZ / 5;
+ 	int ret;
++	unsigned long was_scanning = ieee80211_get_scanning(phy->hw);
+ 
+ 	cancel_delayed_work_sync(&phy->mac_work);
+ 
+@@ -941,7 +942,7 @@ void mt76_set_channel(struct mt76_phy *phy)
+ 	if (!offchannel)
+ 		phy->main_chan = chandef->chan;
+ 
+-	if (chandef->chan != phy->main_chan)
++	if (chandef->chan != phy->main_chan || was_scanning)
+ 		memset(phy->chan_state, 0, sizeof(*phy->chan_state));
+ 	mt76_worker_enable(&dev->tx_worker);
+ 
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/0011-wifi-mt76-fix-tx-statistics-about-tx-retry-and-tx-fa.patch b/package/kernel/mt76/patches/0011-wifi-mt76-fix-tx-statistics-about-tx-retry-and-tx-fa.patch
new file mode 100644
index 0000000..9837869
--- /dev/null
+++ b/package/kernel/mt76/patches/0011-wifi-mt76-fix-tx-statistics-about-tx-retry-and-tx-fa.patch
@@ -0,0 +1,44 @@
+From 99458375f8a646403eed7c259d05ff3e47e892b6 Mon Sep 17 00:00:00 2001
+From: Peter Chiu <chui-hao.chiu@mediatek.com>
+Date: Mon, 29 Jan 2024 11:02:06 +0800
+Subject: [PATCH 11/21] wifi: mt76: fix tx statistics about tx retry and tx
+ fail
+
+The tx retry and tx failed are reported by PPDU TxS.
+
+Signed-off-by: Peter Chiu <chui-hao.chiu@mediatek.com>
+---
+ mt76_connac_mac.c | 3 ---
+ mt7915/mac.c      | 2 +-
+ 2 files changed, 1 insertion(+), 4 deletions(-)
+
+diff --git a/mt76_connac_mac.c b/mt76_connac_mac.c
+index b841bf6..630c640 100644
+--- a/mt76_connac_mac.c
++++ b/mt76_connac_mac.c
+@@ -716,9 +716,6 @@ bool mt76_connac2_mac_add_txs_skb(struct mt76_dev *dev, struct mt76_wcid *wcid,
+ 	struct sk_buff_head list;
+ 	struct sk_buff *skb;
+ 
+-	if (le32_get_bits(txs_data[0], MT_TXS0_TXS_FORMAT) == MT_TXS_PPDU_FMT)
+-		return false;
+-
+ 	mt76_tx_status_lock(dev, &list);
+ 	skb = mt76_tx_status_skb_get(dev, wcid, pid, &list);
+ 	if (skb) {
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index e167e7b..a5d0b09 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -1021,7 +1021,7 @@ static void mt7915_mac_add_txs(struct mt7915_dev *dev, void *data)
+ 
+ 	msta = container_of(wcid, struct mt7915_sta, wcid);
+ 
+-	if (pid == MT_PACKET_ID_WED)
++	if (le32_get_bits(txs_data[0], MT_TXS0_TXS_FORMAT) == MT_TXS_PPDU_FMT)
+ 		mt76_connac2_mac_fill_txs(&dev->mt76, wcid, txs_data);
+ 	else
+ 		mt76_connac2_mac_add_txs_skb(&dev->mt76, wcid, pid, txs_data);
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/0012-wifi-mt76-add-sanity-check-to-prevent-kernel-crash.patch b/package/kernel/mt76/patches/0012-wifi-mt76-add-sanity-check-to-prevent-kernel-crash.patch
new file mode 100644
index 0000000..ed4d714
--- /dev/null
+++ b/package/kernel/mt76/patches/0012-wifi-mt76-add-sanity-check-to-prevent-kernel-crash.patch
@@ -0,0 +1,35 @@
+From 8bcee1da876907d67de94317dcd343842a54921f Mon Sep 17 00:00:00 2001
+From: Peter Chiu <chui-hao.chiu@mediatek.com>
+Date: Mon, 29 Jan 2024 15:33:24 +0800
+Subject: [PATCH 12/21] wifi: mt76: add sanity check to prevent kernel crash
+
+wcid may not be initialized when mac80211 calls mt76.tx and it would lead to
+kernel crash.
+
+Signed-off-by: Peter Chiu <chui-hao.chiu@mediatek.com>
+---
+ tx.c | 8 ++++++++
+ 1 file changed, 8 insertions(+)
+
+diff --git a/tx.c b/tx.c
+index 5cf6ede..ab42f69 100644
+--- a/tx.c
++++ b/tx.c
+@@ -345,6 +345,14 @@ mt76_tx(struct mt76_phy *phy, struct ieee80211_sta *sta,
+ 
+ 	info->hw_queue |= FIELD_PREP(MT_TX_HW_QUEUE_PHY, phy->band_idx);
+ 
++	if (!wcid || !wcid->tx_pending.prev || !wcid->tx_pending.next) {
++		dev_warn(phy->dev->dev, "Un-initialized STA %pM wcid %d in mt76_tx\n",
++			 sta ? sta->addr : NULL, wcid ? wcid->idx : -1);
++
++		ieee80211_free_txskb(phy->hw, skb);
++		return;
++	}
++
+ 	if ((info->flags & IEEE80211_TX_CTL_TX_OFFCHAN) ||
+ 	    (info->control.flags & IEEE80211_TX_CTRL_DONT_USE_RATE_MASK))
+ 		head = &wcid->tx_offchannel;
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/0019-wifi-mt76-mt7915-adjust-rx-filter.patch b/package/kernel/mt76/patches/0019-wifi-mt76-mt7915-adjust-rx-filter.patch
new file mode 100644
index 0000000..beeeaf9
--- /dev/null
+++ b/package/kernel/mt76/patches/0019-wifi-mt76-mt7915-adjust-rx-filter.patch
@@ -0,0 +1,58 @@
+From 304c98810a9e68eccae433c570d1fc7c1063a641 Mon Sep 17 00:00:00 2001
+From: Howard Hsu <howard-yh.hsu@mediatek.com>
+Date: Fri, 19 Apr 2024 15:43:23 +0800
+Subject: [PATCH 19/21] wifi: mt76: mt7915: adjust rx filter
+
+Adjust rx filter setting to drop the packet that we do not need to
+receive.
+
+Fixes: e57b7901469f ("mt76: add mac80211 driver for MT7915 PCIe-based chipsets")
+Signed-off-by: Howard Hsu <howard-yh.hsu@mediatek.com>
+---
+ mt7915/main.c | 11 +++++++----
+ 1 file changed, 7 insertions(+), 4 deletions(-)
+
+diff --git a/mt7915/main.c b/mt7915/main.c
+index c6880ca..3783849 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -489,7 +489,8 @@ static int mt7915_config(struct ieee80211_hw *hw, u32 changed)
+ 			rxfilter |= MT_WF_RFCR_DROP_OTHER_UC;
+ 			dev->monitor_mask &= ~BIT(band);
+ 		} else {
+-			rxfilter &= ~MT_WF_RFCR_DROP_OTHER_UC;
++			rxfilter &= ~(MT_WF_RFCR_DROP_A2_BSSID |
++				      MT_WF_RFCR_DROP_OTHER_UC);
+ 			dev->monitor_mask |= BIT(band);
+ 		}
+ 
+@@ -552,13 +553,14 @@ static void mt7915_configure_filter(struct ieee80211_hw *hw,
+ 			   MT_WF_RFCR_DROP_MCAST |
+ 			   MT_WF_RFCR_DROP_BCAST |
+ 			   MT_WF_RFCR_DROP_DUPLICATE |
+-			   MT_WF_RFCR_DROP_A2_BSSID |
+ 			   MT_WF_RFCR_DROP_UNWANTED_CTL |
+ 			   MT_WF_RFCR_DROP_STBC_MULTI);
++	phy->rxfilter |= MT_WF_RFCR_DROP_VERSION;
+ 
+ 	MT76_FILTER(OTHER_BSS, MT_WF_RFCR_DROP_OTHER_TIM |
+ 			       MT_WF_RFCR_DROP_A3_MAC |
+-			       MT_WF_RFCR_DROP_A3_BSSID);
++			       MT_WF_RFCR_DROP_A3_BSSID |
++			       MT_WF_RFCR_DROP_A2_BSSID);
+ 
+ 	MT76_FILTER(FCSFAIL, MT_WF_RFCR_DROP_FCSFAIL);
+ 
+@@ -569,7 +571,8 @@ static void mt7915_configure_filter(struct ieee80211_hw *hw,
+ 	*total_flags = flags;
+ 	rxfilter = phy->rxfilter;
+ 	if (hw->conf.flags & IEEE80211_CONF_MONITOR)
+-		rxfilter &= ~MT_WF_RFCR_DROP_OTHER_UC;
++		rxfilter &= ~(MT_WF_RFCR_DROP_A2_BSSID |
++			      MT_WF_RFCR_DROP_OTHER_UC);
+ 	else
+ 		rxfilter |= MT_WF_RFCR_DROP_OTHER_UC;
+ 	mt76_wr(dev, MT_WF_RFCR(band), rxfilter);
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/2000-wifi-mt76-mt7915-wed-add-wed-tx-support.patch b/package/kernel/mt76/patches/2000-wifi-mt76-mt7915-wed-add-wed-tx-support.patch
new file mode 100644
index 0000000..b5030a5
--- /dev/null
+++ b/package/kernel/mt76/patches/2000-wifi-mt76-mt7915-wed-add-wed-tx-support.patch
@@ -0,0 +1,139 @@
+From 3af8d78c5f9622276367d9e71921fe25f9d211b5 Mon Sep 17 00:00:00 2001
+From: Sujuan Chen <sujuan.chen@mediatek.com>
+Date: Fri, 25 Nov 2022 10:38:53 +0800
+Subject: [PATCH 2000/2015] wifi: mt76: mt7915: wed: add wed tx support
+
+Signed-off-by: Sujuan Chen <sujuan.chen@mediatek.com>
+---
+ mt76_connac.h   |  1 +
+ mt7915/mac.c    | 10 +++++++---
+ mt7915/main.c   |  4 ++--
+ mt7915/mmio.c   |  3 ++-
+ mt7915/mt7915.h |  2 +-
+ wed.c           |  2 +-
+ 6 files changed, 14 insertions(+), 8 deletions(-)
+
+diff --git a/mt76_connac.h b/mt76_connac.h
+index 8e7068c..e1d6ca2 100644
+--- a/mt76_connac.h
++++ b/mt76_connac.h
+@@ -130,6 +130,7 @@ struct mt76_connac_sta_key_conf {
+ };
+ 
+ #define MT_TXP_MAX_BUF_NUM		6
++#define MT_TXD_TXP_BUF_SIZE		128
+ 
+ struct mt76_connac_fw_txp {
+ 	__le16 flags;
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index c84b957..1c8b873 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -878,9 +878,9 @@ u32 mt7915_wed_init_buf(void *ptr, dma_addr_t phys, int token_id)
+ 
+ 	txp->token = cpu_to_le16(token_id);
+ 	txp->nbuf = 1;
+-	txp->buf[0] = cpu_to_le32(phys + MT_TXD_SIZE + sizeof(*txp));
++	txp->buf[0] = cpu_to_le32(phys + MT_TXD_TXP_BUF_SIZE);
+ 
+-	return MT_TXD_SIZE + sizeof(*txp);
++	return MT_TXD_TXP_BUF_SIZE;
+ }
+ 
+ static void
+@@ -929,6 +929,7 @@ mt7915_mac_tx_free(struct mt7915_dev *dev, void *data, int len)
+ 	LIST_HEAD(free_list);
+ 	void *end = data + len;
+ 	bool v3, wake = false;
++	bool with_txwi = true;
+ 	u16 total, count = 0;
+ 	u32 txd = le32_to_cpu(free->txd);
+ 	__le32 *cur_info;
+@@ -1010,12 +1011,15 @@ mt7915_mac_tx_free(struct mt7915_dev *dev, void *data, int len)
+ 			txwi = mt76_token_release(mdev, msdu, &wake);
+ 			if (!txwi)
+ 				continue;
++			else
++				with_txwi = false;
+ 
+ 			mt76_connac2_txwi_free(mdev, txwi, sta, &free_list);
+ 		}
+ 	}
+ 
+-	mt7915_mac_tx_free_done(dev, &free_list, wake);
++	if (!with_txwi)
++		mt7915_mac_tx_free_done(dev, &free_list, wake);
+ }
+ 
+ static void
+diff --git a/mt7915/main.c b/mt7915/main.c
+index c97974a..ed7ade1 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -1761,14 +1761,14 @@ mt7915_net_fill_forward_path(struct ieee80211_hw *hw,
+ 	if (!mtk_wed_device_active(wed))
+ 		return -ENODEV;
+ 
+-	if (msta->wcid.idx > 0xff)
++	if (msta->wcid.idx > MT7915_WTBL_STA)
+ 		return -EIO;
+ 
+ 	path->type = DEV_PATH_MTK_WDMA;
+ 	path->dev = ctx->dev;
+ 	path->mtk_wdma.wdma_idx = wed->wdma_idx;
+ 	path->mtk_wdma.bss = mvif->mt76.idx;
+-	path->mtk_wdma.wcid = is_mt7915(&dev->mt76) ? msta->wcid.idx : 0x3ff;
++	path->mtk_wdma.wcid = is_mt7915(&dev->mt76) ? 0xff : 0x3ff;
+ 	path->mtk_wdma.queue = phy != &dev->phy;
+ 
+ 	ctx->dev = NULL;
+diff --git a/mt7915/mmio.c b/mt7915/mmio.c
+index 437a9b0..91100f1 100644
+--- a/mt7915/mmio.c
++++ b/mt7915/mmio.c
+@@ -13,7 +13,7 @@
+ #include "../trace.h"
+ #include "../dma.h"
+ 
+-static bool wed_enable;
++static bool wed_enable;
+ module_param(wed_enable, bool, 0644);
+ MODULE_PARM_DESC(wed_enable, "Enable Wireless Ethernet Dispatch support");
+ 
+@@ -732,6 +732,7 @@ int mt7915_mmio_wed_init(struct mt7915_dev *dev, void *pdev_ptr,
+ 
+ 	*irq = wed->irq;
+ 	dev->mt76.dma_dev = wed->dev;
++	dev->mt76.token_size = wed->wlan.token_start;
+ 
+ 	ret = dma_set_mask(wed->dev, DMA_BIT_MASK(32));
+ 	if (ret)
+diff --git a/mt7915/mt7915.h b/mt7915/mt7915.h
+index a6901dd..2dce288 100644
+--- a/mt7915/mt7915.h
++++ b/mt7915/mt7915.h
+@@ -62,7 +62,7 @@
+ #define MT7916_EEPROM_SIZE		4096
+ 
+ #define MT7915_EEPROM_BLOCK_SIZE	16
+-#define MT7915_HW_TOKEN_SIZE		4096
++#define MT7915_HW_TOKEN_SIZE		7168
+ #define MT7915_TOKEN_SIZE		8192
+ 
+ #define MT7915_CFEND_RATE_DEFAULT	0x49	/* OFDM 24M */
+diff --git a/wed.c b/wed.c
+index f7a3f1b..47c81a2 100644
+--- a/wed.c
++++ b/wed.c
+@@ -187,7 +187,7 @@ void mt76_wed_offload_disable(struct mtk_wed_device *wed)
+ 	struct mt76_dev *dev = container_of(wed, struct mt76_dev, mmio.wed);
+ 
+ 	spin_lock_bh(&dev->token_lock);
+-	dev->token_size = dev->drv->token_size;
++	dev->token_size = wed->wlan.token_start;
+ 	spin_unlock_bh(&dev->token_lock);
+ }
+ EXPORT_SYMBOL_GPL(mt76_wed_offload_disable);
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/2001-wifi-mt76-mt7915-wed-add-wds-support-when-wed-is-ena.patch b/package/kernel/mt76/patches/2001-wifi-mt76-mt7915-wed-add-wds-support-when-wed-is-ena.patch
new file mode 100644
index 0000000..48cd32a
--- /dev/null
+++ b/package/kernel/mt76/patches/2001-wifi-mt76-mt7915-wed-add-wds-support-when-wed-is-ena.patch
@@ -0,0 +1,210 @@
+From 0454c032c589da59ef4e44654d2f650e273e215a Mon Sep 17 00:00:00 2001
+From: Sujuan Chen <sujuan.chen@mediatek.com>
+Date: Tue, 13 Dec 2022 17:51:26 +0800
+Subject: [PATCH 2001/2015] wifi: mt76: mt7915: wed: add wds support when wed
+ is enabled
+
+Signed-off-by: Sujuan Chen <sujuan.chen@mediatek.com>
+---
+ mt76.h        |  6 ++++++
+ mt7915/main.c | 22 ++++++++++++++++++++--
+ mt7915/mcu.c  | 16 ++++++++++++----
+ mt7915/mcu.h  |  1 +
+ util.c        | 40 +++++++++++++++++++++++++++++++++++++---
+ util.h        |  7 ++++++-
+ 6 files changed, 82 insertions(+), 10 deletions(-)
+
+diff --git a/mt76.h b/mt76.h
+index e6482e5..6168758 100644
+--- a/mt76.h
++++ b/mt76.h
+@@ -78,6 +78,12 @@ enum mt76_wed_type {
+ 	MT76_WED_RRO_Q_IND,
+ };
+ 
++enum mt76_wed_state {
++	MT76_WED_DEFAULT,
++	MT76_WED_ACTIVE,
++	MT76_WED_WDS_ACTIVE,
++};
++
+ struct mt76_bus_ops {
+ 	u32 (*rr)(struct mt76_dev *dev, u32 offset);
+ 	void (*wr)(struct mt76_dev *dev, u32 offset, u32 val);
+diff --git a/mt7915/main.c b/mt7915/main.c
+index ed7ade1..6276230 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -831,8 +831,15 @@ int mt7915_mac_sta_add(struct mt76_dev *mdev, struct ieee80211_vif *vif,
+ 	struct mt7915_vif *mvif = (struct mt7915_vif *)vif->drv_priv;
+ 	bool ext_phy = mvif->phy != &dev->phy;
+ 	int idx;
++	u8 flags = MT76_WED_DEFAULT;
+ 
+-	idx = mt76_wcid_alloc(dev->mt76.wcid_mask, MT7915_WTBL_STA);
++	if (mtk_wed_device_active(&dev->mt76.mmio.wed) &&
++	    !is_mt7915(&dev->mt76)) {
++		flags = test_bit(MT_WCID_FLAG_4ADDR, &msta->wcid.flags) ?
++			MT76_WED_WDS_ACTIVE : MT76_WED_ACTIVE;
++	}
++
++	idx = __mt76_wcid_alloc(mdev->wcid_mask, MT7915_WTBL_STA, flags);
+ 	if (idx < 0)
+ 		return -ENOSPC;
+ 
+@@ -1323,6 +1330,13 @@ static void mt7915_sta_set_4addr(struct ieee80211_hw *hw,
+ 	if (!msta->wcid.sta)
+ 		return;
+ 
++	if (mtk_wed_device_active(&dev->mt76.mmio.wed) &&
++	    !is_mt7915(&dev->mt76)) {
++		mt76_sta_state(hw, vif, sta, IEEE80211_STA_NONE, IEEE80211_STA_NOTEXIST);
++		mt76_sta_pre_rcu_remove(hw, vif, sta);
++		mt76_sta_state(hw, vif, sta, IEEE80211_STA_NOTEXIST, IEEE80211_STA_NONE);
++	}
++
+ 	mt76_connac_mcu_wtbl_update_hdr_trans(&dev->mt76, vif, sta);
+ }
+ 
+@@ -1768,8 +1782,12 @@ mt7915_net_fill_forward_path(struct ieee80211_hw *hw,
+ 	path->dev = ctx->dev;
+ 	path->mtk_wdma.wdma_idx = wed->wdma_idx;
+ 	path->mtk_wdma.bss = mvif->mt76.idx;
+-	path->mtk_wdma.wcid = is_mt7915(&dev->mt76) ? 0xff : 0x3ff;
+ 	path->mtk_wdma.queue = phy != &dev->phy;
++	if (test_bit(MT_WCID_FLAG_4ADDR, &msta->wcid.flags) ||
++	    is_mt7915(&dev->mt76))
++		path->mtk_wdma.wcid = msta->wcid.idx;
++	else
++		path->mtk_wdma.wcid = 0x3ff;
+ 
+ 	ctx->dev = NULL;
+ 
+diff --git a/mt7915/mcu.c b/mt7915/mcu.c
+index 853a50e..4390f42 100644
+--- a/mt7915/mcu.c
++++ b/mt7915/mcu.c
+@@ -2588,10 +2588,18 @@ int mt7915_mcu_init_firmware(struct mt7915_dev *dev)
+ 
+ 	mt76_connac_mcu_del_wtbl_all(&dev->mt76);
+ 
+-	if ((mtk_wed_device_active(&dev->mt76.mmio.wed) &&
+-	     is_mt7915(&dev->mt76)) ||
+-	    !mtk_wed_get_rx_capa(&dev->mt76.mmio.wed))
+-		mt7915_mcu_wa_cmd(dev, MCU_WA_PARAM_CMD(CAPABILITY), 0, 0, 0);
++	if (mtk_wed_device_active(&dev->mt76.mmio.wed)) {
++		if (is_mt7915(&dev->mt76) ||
++		    !mtk_wed_get_rx_capa(&dev->mt76.mmio.wed))
++			ret = mt7915_mcu_wa_cmd(dev, MCU_WA_PARAM_CMD(CAPABILITY),
++						0, 0, 0);
++		else
++			ret = mt7915_mcu_wa_cmd(dev, MCU_WA_PARAM_CMD(SET),
++						MCU_WA_PARAM_WED_VERSION,
++						dev->mt76.mmio.wed.rev_id, 0);
++		if (ret)
++			return ret;
++	}
+ 
+ 	ret = mt7915_mcu_set_mwds(dev, 1);
+ 	if (ret)
+diff --git a/mt7915/mcu.h b/mt7915/mcu.h
+index f476767..52baaa7 100644
+--- a/mt7915/mcu.h
++++ b/mt7915/mcu.h
+@@ -392,6 +392,7 @@ enum {
+ 	MCU_WA_PARAM_PDMA_RX = 0x04,
+ 	MCU_WA_PARAM_CPU_UTIL = 0x0b,
+ 	MCU_WA_PARAM_RED = 0x0e,
++	MCU_WA_PARAM_WED_VERSION = 0x32,
+ 	MCU_WA_PARAM_RED_SETTING = 0x40,
+ };
+ 
+diff --git a/util.c b/util.c
+index fc76c66..61b2d30 100644
+--- a/util.c
++++ b/util.c
+@@ -42,9 +42,14 @@ bool ____mt76_poll_msec(struct mt76_dev *dev, u32 offset, u32 mask, u32 val,
+ }
+ EXPORT_SYMBOL_GPL(____mt76_poll_msec);
+ 
+-int mt76_wcid_alloc(u32 *mask, int size)
++int __mt76_wcid_alloc(u32 *mask, int size, u8 flag)
+ {
++#define MT76_WED_WDS_MIN    256
++#define MT76_WED_WDS_CNT    16
++
+ 	int i, idx = 0, cur;
++	int min = MT76_WED_WDS_MIN;
++	int max = min + MT76_WED_WDS_CNT;
+ 
+ 	for (i = 0; i < DIV_ROUND_UP(size, 32); i++) {
+ 		idx = ffs(~mask[i]);
+@@ -53,16 +58,45 @@ int mt76_wcid_alloc(u32 *mask, int size)
+ 
+ 		idx--;
+ 		cur = i * 32 + idx;
+-		if (cur >= size)
++
++		switch (flag) {
++		case MT76_WED_ACTIVE:
++			if (cur >= min && cur < max)
++				continue;
++
++			if (cur >= size) {
++				u32 end = MT76_WED_WDS_CNT - 1;
++
++				i = min / 32;
++				idx = ffs(~mask[i] & GENMASK(end, 0));
++				if (!idx)
++					goto error;
++				idx--;
++				cur = min + idx;
++			}
++
+ 			break;
++		case MT76_WED_WDS_ACTIVE:
++			if (cur < min)
++				continue;
++			if (cur >= max)
++				goto error;
++
++			break;
++		default:
++			if (cur >= size)
++				goto error;
++			break;
++		}
+ 
+ 		mask[i] |= BIT(idx);
+ 		return cur;
+ 	}
+ 
++error:
+ 	return -1;
+ }
+-EXPORT_SYMBOL_GPL(mt76_wcid_alloc);
++EXPORT_SYMBOL_GPL(__mt76_wcid_alloc);
+ 
+ int mt76_get_min_avg_rssi(struct mt76_dev *dev, bool ext_phy)
+ {
+diff --git a/util.h b/util.h
+index 260965d..99b7263 100644
+--- a/util.h
++++ b/util.h
+@@ -27,7 +27,12 @@ enum {
+ #define MT76_INCR(_var, _size) \
+ 	(_var = (((_var) + 1) % (_size)))
+ 
+-int mt76_wcid_alloc(u32 *mask, int size);
++int __mt76_wcid_alloc(u32 *mask, int size, u8 flags);
++
++static inline int mt76_wcid_alloc(u32 *mask, int size)
++{
++	return __mt76_wcid_alloc(mask, size, 0);
++}
+ 
+ static inline void
+ mt76_wcid_mask_set(u32 *mask, int idx)
+-- 
+2.18.0
+
diff --git a/package/kernel/mt76/patches/2003-wifi-mt76-mt7915-wed-find-rx-token-by-physical-addre.patch b/package/kernel/mt76/patches/2003-wifi-mt76-mt7915-wed-find-rx-token-by-physical-addre.patch
new file mode 100644
index 0000000..e603ade
--- /dev/null
+++ b/package/kernel/mt76/patches/2003-wifi-mt76-mt7915-wed-find-rx-token-by-physical-addre.patch
@@ -0,0 +1,64 @@
+From 5a0028b27ba80cb34d905a668e335fb2c55685d1 Mon Sep 17 00:00:00 2001
+From: Sujuan Chen <sujuan.chen@mediatek.com>
+Date: Fri, 25 Nov 2022 14:32:35 +0800
+Subject: [PATCH 2003/2015] wifi: mt76: mt7915: wed: find rx token by physical
+ address
+
+The token id in RxDMAD may be incorrect when it is not the last frame due to
+WED HW bug. Lookup correct token id by physical address in sdp0.
+
+Signed-off-by: Peter Chiu <chui-hao.chiu@mediatek.com>
+---
+ dma.c | 25 ++++++++++++++++++++++++-
+ 1 file changed, 24 insertions(+), 1 deletion(-)
+
+diff --git a/dma.c b/dma.c
+index 100d2af..185c6f1 100644
+--- a/dma.c
++++ b/dma.c
+@@ -444,9 +444,32 @@ mt76_dma_get_buf(struct mt76_dev *dev, struct mt76_queue *q, int idx,
+ 	mt76_dma_should_drop_buf(drop, ctrl, buf1, desc_info);
+ 
+ 	if (mt76_queue_is_wed_rx(q)) {
++		u32 id, find = 0;
+ 		u32 token = FIELD_GET(MT_DMA_CTL_TOKEN, buf1);
+-		struct mt76_txwi_cache *t = mt76_rx_token_release(dev, token);
++		struct mt76_txwi_cache *t;
++
++		if (*more) {
++			spin_lock_bh(&dev->rx_token_lock);
++
++			idr_for_each_entry(&dev->rx_token, t, id) {
++				if (t->dma_addr == le32_to_cpu(desc->buf0)) {
++					find = 1;
++					token = id;
++
++					/* Write correct id back to DMA*/
++					u32p_replace_bits(&buf1, id,
++							  MT_DMA_CTL_TOKEN);
++					WRITE_ONCE(desc->buf1, cpu_to_le32(buf1));
++					break;
++				}
++			}
++
++			spin_unlock_bh(&dev->rx_token_lock);
++			if (!find)
++				return NULL;
++		}
+ 
++		t = mt76_rx_token_release(dev, token);
+ 		if (!t)
+ 			return NULL;
+ 
+@@ -901,7 +901,7 @@ mt76_dma_rx_process(struct mt76_dev *dev
+ 		if (!data)
+ 			break;
+ 
+-		if (drop)
++		if (drop || (len == 0))
+ 			goto free_frag;
+ 
+ 		if (q->rx_head)
+-- 
+2.18.0
+
-- 
2.38.1.windows.1

