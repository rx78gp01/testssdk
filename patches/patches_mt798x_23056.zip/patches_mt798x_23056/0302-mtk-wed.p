diff --git a/target/linux/mediatek/patches-5.15/999-wed-01-fix-SER-case-call-trace-due-to-double-free-hwrro-buf.patch b/target/linux/mediatek/patches-5.15/999-wed-01-fix-SER-case-call-trace-due-to-double-free-hwrro-buf.patch
new file mode 100644
index 0000000..0bf189b
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-wed-01-fix-SER-case-call-trace-due-to-double-free-hwrro-buf.patch
@@ -0,0 +1,29 @@
+---
+[v2] net: ethernet: mtk_wed: fix SER case call trace due to double free
+
+Fix kernel call trace caused by double freeing HW RRO (Hardware Receive
+Reorder) buffer during System Error Recovery (SER) process.
+---
+v2: Refined fix with improved error handling.
+v1: Initial fix for double free issue.
+---
+
+From 068fbf5708b9a082fc1e2c7bed2f74af5ff27cc1 Mon Sep 17 00:00:00 2001
+From: Rex Lu <rex.lu@mediatek.com>
+Date: Fri, 27 Sep 2024 13:46:33 +0800
+Subject: [PATCH 01/15] fix SER case call trace due to double free hwrro buffer
+
+---
+ drivers/net/ethernet/mediatek/mtk_wed.c | 1 -
+ 1 file changed, 1 deletion(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_wed.c
++++ b/drivers/net/ethernet/mediatek/mtk_wed.c
+@@ -1746,7 +1746,6 @@ mtk_wed_rx_reset(struct mtk_wed_device *
+ 				   false);
+ 	}
+ 	mtk_wed_free_rx_buffer(dev);
+-	mtk_wed_hwrro_free_buffer(dev);
+ 
+ 	return 0;
+ }
diff --git a/target/linux/mediatek/patches-5.15/999-wed-03-fix-wdma-rx-hang-on-wed1-after-SER.patch b/target/linux/mediatek/patches-5.15/999-wed-03-fix-wdma-rx-hang-on-wed1-after-SER.patch
new file mode 100644
index 0000000..b957f36
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-wed-03-fix-wdma-rx-hang-on-wed1-after-SER.patch
@@ -0,0 +1,52 @@
+---
+[v2] net: ethernet: mtk_wed: fix WDMA RX hang on WED1 after SER
+
+Fix WDMA (WiFi DMA) RX hang issue on WED1 device that occurs after
+System Error Recovery process.
+---
+v2: Enhanced recovery mechanism.
+v1: Initial WDMA RX hang fix.
+---
+
+From 56cce216f7daed56f129c3a01a22e6b1c4edfb54 Mon Sep 17 00:00:00 2001
+From: Rex Lu <rex.lu@mediatek.com>
+Date: Fri, 27 Sep 2024 16:58:22 +0800
+Subject: [PATCH 03/15] fix wdma rx hang on wed1 after SER
+
+---
+ drivers/net/ethernet/mediatek/mtk_wed.c | 17 ++++++++++++++++-
+ 1 file changed, 16 insertions(+), 1 deletion(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_wed.c
++++ b/drivers/net/ethernet/mediatek/mtk_wed.c
+@@ -257,7 +257,7 @@ mtk_wdma_rx_reset(struct mtk_wed_device
+ 	wdma_w32(dev, MTK_WDMA_RESET_IDX, 0);
+ 
+ 	for (i = 0; i < ARRAY_SIZE(dev->rx_wdma); i++) {
+-		if (dev->rx_wdma[i].desc)
++		if (!dev->rx_wdma[i].desc)
+ 			continue;
+ 
+ 		wdma_w32(dev,
+@@ -1796,6 +1796,21 @@ mtk_wed_reset_dma(struct mtk_wed_device
+ 			wed_clr(dev, MTK_WED_WDMA_RX_PREF_CFG,
+ 				MTK_WED_WDMA_RX_PREF_DDONE2_EN);
+ 
++			/* Reset prefetch index */
++			wed_set(dev, MTK_WED_WDMA_RX_PREF_CFG,
++				MTK_WED_WDMA_RX_PREF_RX0_SIDX_CLR |
++				MTK_WED_WDMA_RX_PREF_RX1_SIDX_CLR);
++
++			wed_clr(dev, MTK_WED_WDMA_RX_PREF_CFG,
++				MTK_WED_WDMA_RX_PREF_RX0_SIDX_CLR |
++				MTK_WED_WDMA_RX_PREF_RX1_SIDX_CLR);
++
++			/* Reset prefetch FIFO */
++			wed_w32(dev, MTK_WED_WDMA_RX_PREF_FIFO_CFG,
++				MTK_WED_WDMA_RX_PREF_FIFO_RX0_CLR |
++				MTK_WED_WDMA_RX_PREF_FIFO_RX1_CLR);
++			wed_w32(dev, MTK_WED_WDMA_RX_PREF_FIFO_CFG, 0);
++
+ 			/* 2. Reset dma index */
+ 			wed_w32(dev, MTK_WED_WDMA_RESET_IDX,
+ 				MTK_WED_WDMA_RESET_IDX_RX_ALL);
diff --git a/target/linux/mediatek/patches-5.15/999-wed-04-Fix-reinsert-wifi-module-cause-memory-leak-issue.patch b/target/linux/mediatek/patches-5.15/999-wed-04-Fix-reinsert-wifi-module-cause-memory-leak-issue.patch
new file mode 100644
index 0000000..991d7c2
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-wed-04-Fix-reinsert-wifi-module-cause-memory-leak-issue.patch
@@ -0,0 +1,79 @@
+---
+[v2] net: ethernet: mtk_wed: fix memory leak on WiFi module reinsertion
+
+Fix memory leak that occurs when WiFi module is removed and reinserted.
+Properly cleanup resources on module removal.
+---
+v2: Complete resource cleanup.
+v1: Initial memory leak fix.
+---
+
+From dbfb21802c5516fb1c67d3218a90c116e717c51a Mon Sep 17 00:00:00 2001
+From: Rex Lu <rex.lu@mediatek.com>
+Date: Tue, 1 Oct 2024 14:07:22 +0800
+Subject: [PATCH 04/15] Fix reinsert wifi module cause memory leak issue
+
+---
+ drivers/net/ethernet/mediatek/mtk_wed.c | 22 ++++++++++++++++++++--
+ 1 file changed, 20 insertions(+), 2 deletions(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_wed.c
++++ b/drivers/net/ethernet/mediatek/mtk_wed.c
+@@ -936,6 +936,16 @@ mtk_wed_free_ring(struct mtk_wed_device
+ static void
+ mtk_wed_free_rx_rings(struct mtk_wed_device *dev)
+ {
++	int i;
++
++	for (i = 0; i < ARRAY_SIZE(dev->rx_ring); i++)
++		if ((dev->tx_ring[i].flags & MTK_WED_RING_CONFIGURED))
++			mtk_wed_free_ring(dev, &dev->rx_ring[i]);
++
++	for (i = 0; i < ARRAY_SIZE(dev->tx_wdma); i++)
++		if ((dev->tx_wdma[i].flags & MTK_WED_RING_CONFIGURED))
++			mtk_wed_free_ring(dev, &dev->tx_wdma[i]);
++
+ 	mtk_wed_free_rx_buffer(dev);
+ 	mtk_wed_free_ring(dev, &dev->rro.ring);
+ }
+@@ -946,9 +956,12 @@ mtk_wed_free_tx_rings(struct mtk_wed_dev
+ 	int i;
+ 
+ 	for (i = 0; i < ARRAY_SIZE(dev->tx_ring); i++)
+-		mtk_wed_free_ring(dev, &dev->tx_ring[i]);
++		if ((dev->tx_ring[i].flags & MTK_WED_RING_CONFIGURED))
++			mtk_wed_free_ring(dev, &dev->tx_ring[i]);
++
+ 	for (i = 0; i < ARRAY_SIZE(dev->rx_wdma); i++)
+-		mtk_wed_free_ring(dev, &dev->rx_wdma[i]);
++		if ((dev->rx_wdma[i].flags & MTK_WED_RING_CONFIGURED))
++			mtk_wed_free_ring(dev, &dev->rx_wdma[i]);
+ }
+ 
+ static void
+@@ -1917,6 +1930,8 @@ mtk_wed_wdma_rx_ring_setup(struct mtk_we
+ 					 dev->hw->soc->wdma_desc_size, true))
+ 		return -ENOMEM;
+ 
++	wdma->flags |= MTK_WED_RING_CONFIGURED;
++
+ 	wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_BASE,
+ 		 wdma->desc_phys);
+ 	wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_COUNT,
+@@ -1963,6 +1978,8 @@ mtk_wed_wdma_tx_ring_setup(struct mtk_we
+ 		}
+ 	}
+ 
++	wdma->flags |= MTK_WED_RING_CONFIGURED;
++
+ 	wdma_w32(dev, MTK_WDMA_RING_TX(idx) + MTK_WED_RING_OFS_BASE,
+ 		 wdma->desc_phys);
+ 	wdma_w32(dev, MTK_WDMA_RING_TX(idx) + MTK_WED_RING_OFS_COUNT,
+@@ -2529,6 +2546,7 @@ mtk_wed_tx_ring_setup(struct mtk_wed_dev
+ 
+ 	ring->reg_base = MTK_WED_RING_TX(idx);
+ 	ring->wpdma = regs;
++	ring->flags |= MTK_WED_RING_CONFIGURED;
+ 
+ 	if (mtk_wed_is_v3_or_greater(dev->hw) && idx == 1) {
+ 		/* reset prefetch index */
diff --git a/target/linux/mediatek/patches-5.15/999-wed-16-refactor-wdma-init-flow-to-avoid-double-init.patch b/target/linux/mediatek/patches-5.15/999-wed-16-refactor-wdma-init-flow-to-avoid-double-init.patch
new file mode 100644
index 0000000..8923c55
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-wed-16-refactor-wdma-init-flow-to-avoid-double-init.patch
@@ -0,0 +1,119 @@
+---
+[v2] net: ethernet: mtk_wed: refactor WDMA init to avoid double initialization
+
+Refactor WDMA initialization flow to prevent double initialization
+that can cause resource conflicts.
+---
+v2: Added initialization guard.
+v1: Initial WDMA init refactoring.
+---
+
+From 38b51269aabf06cdbe2883a2dbf38edc37c65a62 Mon Sep 17 00:00:00 2001
+From: Rex Lu <rex.lu@mediatek.com>
+Date: Fri, 12 Dec 2025 16:47:10 +0800
+Subject: [PATCH] refactor wdma init flow to avoid double init
+
+Signed-off-by: Rex Lu <rex.lu@mediatek.com>
+---
+ drivers/net/ethernet/mediatek/mtk_wed.c | 52 ++++++++++++-------------
+ 1 file changed, 24 insertions(+), 28 deletions(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_wed.c
++++ b/drivers/net/ethernet/mediatek/mtk_wed.c
+@@ -2197,31 +2197,32 @@ mtk_wed_ring_alloc(struct mtk_wed_device
+ }
+ 
+ static int
+-mtk_wed_wdma_rx_ring_setup(struct mtk_wed_device *dev, int idx, int size,
+-			   bool reset)
++mtk_wed_wdma_rx_ring_setup(struct mtk_wed_device *dev, int size, bool reset)
+ {
+ 	struct mtk_wed_ring *wdma;
++	int idx;
+ 
+-	if (idx >= ARRAY_SIZE(dev->rx_wdma))
+-		return -EINVAL;
++	for (idx = 0; idx < ARRAY_SIZE(dev->rx_wdma); idx++) {
++		wdma = &dev->rx_wdma[idx];
+ 
+-	wdma = &dev->rx_wdma[idx];
+-	if (!reset && mtk_wed_ring_alloc(dev, wdma, MTK_WED_WDMA_RING_SIZE,
+-					 dev->hw->soc->wdma_desc_size, true))
+-		return -ENOMEM;
++		if (!wdma->desc && mtk_wed_ring_alloc(dev, wdma, MTK_WED_WDMA_RING_SIZE,
++						      dev->hw->soc->wdma_desc_size, true))
++			return -ENOMEM;
+ 
+-	wdma->flags |= MTK_WED_RING_CONFIGURED;
++		wdma->flags |= MTK_WED_RING_CONFIGURED;
+ 
+-	wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_BASE,
+-		 wdma->desc_phys);
+-	wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_COUNT,
+-		 size);
+-	wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_CPU_IDX, 0);
++		wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_BASE,
++			wdma->desc_phys);
++		wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_COUNT,
++			size);
++		if (reset)
++			wdma_w32(dev, MTK_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_CPU_IDX, 0);
+ 
+-	wed_w32(dev, MTK_WED_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_BASE,
+-		wdma->desc_phys);
+-	wed_w32(dev, MTK_WED_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_COUNT,
+-		size);
++		wed_w32(dev, MTK_WED_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_BASE,
++			wdma->desc_phys);
++		wed_w32(dev, MTK_WED_WDMA_RING_RX(idx) + MTK_WED_RING_OFS_COUNT,
++			size);
++	}
+ 
+ 	return 0;
+ }
+@@ -2236,7 +2237,7 @@ mtk_wed_wdma_tx_ring_setup(struct mtk_we
+ 		return -EINVAL;
+ 
+ 	wdma = &dev->tx_wdma[idx];
+-	if (!reset && mtk_wed_ring_alloc(dev, wdma, MTK_WED_WDMA_RING_SIZE,
++	if (!wdma->desc && mtk_wed_ring_alloc(dev, wdma, MTK_WED_WDMA_RING_SIZE,
+ 					 dev->hw->soc->wdma_desc_size, true))
+ 		return -ENOMEM;
+ 
+@@ -2723,10 +2724,6 @@ mtk_wed_start(struct mtk_wed_device *dev
+ 	if (mtk_wed_get_rx_capa(dev) && mtk_wed_rx_buffer_alloc(dev))
+ 		return;
+ 
+-	for (i = 0; i < ARRAY_SIZE(dev->rx_wdma); i++)
+-		if (!dev->rx_wdma[i].desc)
+-			mtk_wed_wdma_rx_ring_setup(dev, i, 16, false);
+-
+ 	if (dev->wlan.hw_rro) {
+ 		for (i = 0; i < MTK_WED_RX_PAGE_QUEUES; i++) {
+ 			u32 addr = MTK_WED_RRO_MSDU_PG_CTRL0(i) +
+@@ -2884,12 +2881,11 @@ mtk_wed_tx_ring_setup(struct mtk_wed_dev
+ 	if (WARN_ON(idx >= ARRAY_SIZE(dev->tx_ring)))
+ 		return -EINVAL;
+ 
+-	if (!reset && mtk_wed_ring_alloc(dev, ring, MTK_WED_TX_RING_SIZE,
++	if (!ring->desc && mtk_wed_ring_alloc(dev, ring, MTK_WED_TX_RING_SIZE,
+ 					 sizeof(*ring->desc), true))
+ 		return -ENOMEM;
+ 
+-	if (mtk_wed_wdma_rx_ring_setup(dev, idx, MTK_WED_WDMA_RING_SIZE,
+-				       reset))
++	if (mtk_wed_wdma_rx_ring_setup(dev, MTK_WED_WDMA_RING_SIZE, reset))
+ 		return -ENOMEM;
+ 
+ 	ring->reg_base = MTK_WED_RING_TX(idx);
+@@ -2960,8 +2956,8 @@ mtk_wed_rx_ring_setup(struct mtk_wed_dev
+ 	if (WARN_ON(idx >= ARRAY_SIZE(dev->rx_ring)))
+ 		return -EINVAL;
+ 
+-	if (!reset && mtk_wed_ring_alloc(dev, ring, MTK_WED_RX_RING_SIZE,
+-					 sizeof(*ring->desc), false))
++	if (!ring->desc && mtk_wed_ring_alloc(dev, ring, MTK_WED_RX_RING_SIZE,
++					      sizeof(*ring->desc), false))
+ 		return -ENOMEM;
+ 
+ 	if (mtk_wed_wdma_tx_ring_setup(dev, idx, MTK_WED_WDMA_RING_SIZE,
-- 
2.46.2.windows.1

