diff --git a/target/linux/generic/pending-5.15/151-net-bridge-do-not-send-arp-replies-if-src-and-target.patch b/target/linux/generic/pending-5.15/151-net-bridge-do-not-send-arp-replies-if-src-and-target.patch
index f420d21..491f928 100644
--- a/target/linux/generic/pending-5.15/151-net-bridge-do-not-send-arp-replies-if-src-and-target.patch
+++ b/target/linux/generic/pending-5.15/151-net-bridge-do-not-send-arp-replies-if-src-and-target.patch
@@ -17,8 +17,8 @@ Signed-off-by: Felix Fietkau <nbd@nbd.name>
 +++ b/net/bridge/br_arp_nd_proxy.c
 @@ -204,7 +204,10 @@ void br_do_proxy_suppress_arp(struct sk_
  			if ((p && (p->flags & BR_PROXYARP)) ||
- 			    (f->dst && (f->dst->flags & (BR_PROXYARP_WIFI |
- 							 BR_NEIGH_SUPPRESS)))) {
+ 			    (dst && (dst->flags & (BR_PROXYARP_WIFI |
+ 						   BR_NEIGH_SUPPRESS)))) {
 -				if (!vid)
 +				replied = true;
 +				if (!memcmp(n->ha, sha, dev->addr_len))
-- 
2.46.2.windows.1

