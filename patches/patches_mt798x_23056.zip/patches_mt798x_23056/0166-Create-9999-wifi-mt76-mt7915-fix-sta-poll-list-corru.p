diff --git a/package/kernel/mt76/patches/9999-wifi-mt76-mt7915-fix-sta-poll-list-corruption-on-hw-.patch b/package/kernel/mt76/patches/9999-wifi-mt76-mt7915-fix-sta-poll-list-corruption-on-hw-.patch
new file mode 100644
index 0000000..3f72a97
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-wifi-mt76-mt7915-fix-sta-poll-list-corruption-on-hw-.patch
@@ -0,0 +1,208 @@
+From 24cc79fc32e873a5d2dab7be43a9b98ff2212bb4 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Thu, 22 Aug 2024 19:31:31 +0200
+Subject: [PATCH] wifi: mt76: mt7915: fix sta poll list corruption on hw
+ restart
+
+When ieee80211_restart_hw is called, all interfaces and stations are
+recreated. This can lead to corruption in the sta poll list, since
+existing entries were not removed before their private data is reset.
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+
+wifi: mt76: connac: move mt7615_mcu_del_wtbl_all to connac
+
+Preparation for reusing it in mt7915
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+
+wifi: mt76: mt7915: improve hardware restart reliability
+
+- use reconfig_complete to restart mac_work / queues
+- reset full wtbl after firmware init
+- clear wcid and vif mask to avoid leak
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+
+wifi: mt76: mt7915: fix unused variable error
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7615/init.c     |  2 +-
+ mt7615/mcu.c      | 10 ----------
+ mt7615/mt7615.h   |  1 -
+ mt76_connac_mcu.c | 11 +++++++++++
+ mt76_connac_mcu.h |  1 +
+ mt7915/mac.c      | 25 +++++++++++++------------
+ mt7915/main.c     | 12 ++++++++++++
+ mt7915/mcu.c      |  2 ++
+ 8 files changed, 40 insertions(+), 24 deletions(-)
+
+diff --git a/mt7615/init.c b/mt7615/init.c
+index f7722f67..f9274c13 100644
+--- a/mt7615/init.c
++++ b/mt7615/init.c
+@@ -319,7 +319,7 @@ void mt7615_init_work(struct mt7615_dev *dev)
+ 	mt7615_mcu_set_eeprom(dev);
+ 	mt7615_mac_init(dev);
+ 	mt7615_phy_init(dev);
+-	mt7615_mcu_del_wtbl_all(dev);
++	mt76_connac_mcu_del_wtbl_all(&dev->mt76);
+ 	mt7615_check_offload_capability(dev);
+ }
+ EXPORT_SYMBOL_GPL(mt7615_init_work);
+diff --git a/mt7615/mcu.c b/mt7615/mcu.c
+index 959f7337..7484e8e9 100644
+--- a/mt7615/mcu.c
++++ b/mt7615/mcu.c
+@@ -1880,16 +1880,6 @@ out:
+ 				 sizeof(req), true);
+ }
+ 
+-int mt7615_mcu_del_wtbl_all(struct mt7615_dev *dev)
+-{
+-	struct wtbl_req_hdr req = {
+-		.operation = WTBL_RESET_ALL,
+-	};
+-
+-	return mt76_mcu_send_msg(&dev->mt76, MCU_EXT_CMD(WTBL_UPDATE),
+-				 &req, sizeof(req), true);
+-}
+-
+ int mt7615_mcu_set_fcc5_lpn(struct mt7615_dev *dev, int val)
+ {
+ 	struct {
+diff --git a/mt7615/mt7615.h b/mt7615/mt7615.h
+index bff83241..98377b82 100644
+--- a/mt7615/mt7615.h
++++ b/mt7615/mt7615.h
+@@ -399,7 +399,6 @@ void mt7615_mac_set_rates(struct mt7615_phy *phy, struct mt7615_sta *sta,
+ 			  struct ieee80211_tx_rate *rates);
+ void mt7615_pm_wake_work(struct work_struct *work);
+ void mt7615_pm_power_save_work(struct work_struct *work);
+-int mt7615_mcu_del_wtbl_all(struct mt7615_dev *dev);
+ int mt7615_mcu_set_chan_info(struct mt7615_phy *phy, int cmd);
+ int mt7615_mcu_set_wmm(struct mt7615_dev *dev, u8 queue,
+ 		       const struct ieee80211_tx_queue_params *params);
+diff --git a/mt76_connac_mcu.c b/mt76_connac_mcu.c
+index f3abe1da..08c1aa53 100644
+--- a/mt76_connac_mcu.c
++++ b/mt76_connac_mcu.c
+@@ -2849,6 +2849,17 @@ int mt76_connac_mcu_restart(struct mt76_dev *dev)
+ }
+ EXPORT_SYMBOL_GPL(mt76_connac_mcu_restart);
+ 
++int mt76_connac_mcu_del_wtbl_all(struct mt76_dev *dev)
++{
++	struct wtbl_req_hdr req = {
++		.operation = WTBL_RESET_ALL,
++	};
++
++	return mt76_mcu_send_msg(dev, MCU_EXT_CMD(WTBL_UPDATE),
++				 &req, sizeof(req), true);
++}
++EXPORT_SYMBOL_GPL(mt76_connac_mcu_del_wtbl_all);
++
+ int mt76_connac_mcu_rdd_cmd(struct mt76_dev *dev, int cmd, u8 index,
+ 			    u8 rx_sel, u8 val)
+ {
+diff --git a/mt76_connac_mcu.h b/mt76_connac_mcu.h
+index aab81d75..0dfe893e 100644
+--- a/mt76_connac_mcu.h
++++ b/mt76_connac_mcu.h
+@@ -2032,6 +2032,7 @@ void mt76_connac_mcu_wtbl_smps_tlv(struct sk_buff *skb,
+ 				   void *sta_wtbl, void *wtbl_tlv);
+ int mt76_connac_mcu_set_pm(struct mt76_dev *dev, int band, int enter);
+ int mt76_connac_mcu_restart(struct mt76_dev *dev);
++int mt76_connac_mcu_del_wtbl_all(struct mt76_dev *dev);
+ int mt76_connac_mcu_rdd_cmd(struct mt76_dev *dev, int cmd, u8 index,
+ 			    u8 rx_sel, u8 val);
+ int mt76_connac_mcu_sta_wed_update(struct mt76_dev *dev, struct sk_buff *skb);
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index 7b6ed226..b3639097 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -1500,26 +1500,27 @@ mt7915_mac_full_reset(struct mt7915_dev *dev)
+ 		if (!mt7915_mac_restart(dev))
+ 			break;
+ 	}
+-	mutex_unlock(&dev->mt76.mutex);
+ 
+ 	if (i == 10)
+ 		dev_err(dev->mt76.dev, "chip full reset failed\n");
+ 
+-	ieee80211_restart_hw(mt76_hw(dev));
+-	if (ext_phy)
+-		ieee80211_restart_hw(ext_phy->hw);
++	spin_lock_bh(&dev->mt76.sta_poll_lock);
++	while (!list_empty(&dev->mt76.sta_poll_list))
++		list_del_init(dev->mt76.sta_poll_list.next);
++	spin_unlock_bh(&dev->mt76.sta_poll_lock);
+ 
+-	ieee80211_wake_queues(mt76_hw(dev));
+-	if (ext_phy)
+-		ieee80211_wake_queues(ext_phy->hw);
++	memset(dev->mt76.wcid_mask, 0, sizeof(dev->mt76.wcid_mask));
++	dev->mt76.vif_mask = 0;
+ 
++	i = mt76_wcid_alloc(dev->mt76.wcid_mask, MT7915_WTBL_STA);
++	dev->mt76.global_wcid.idx = i;
+ 	dev->recovery.hw_full_reset = false;
+-	ieee80211_queue_delayed_work(mt76_hw(dev), &dev->mphy.mac_work,
+-				     MT7915_WATCHDOG_TIME);
++
++	mutex_unlock(&dev->mt76.mutex);
++
++	ieee80211_restart_hw(mt76_hw(dev));
+ 	if (ext_phy)
+-		ieee80211_queue_delayed_work(ext_phy->hw,
+-					     &ext_phy->mac_work,
+-					     MT7915_WATCHDOG_TIME);
++		ieee80211_restart_hw(ext_phy->hw);
+ }
+ 
+ /* system error recovery */
+diff --git a/mt7915/main.c b/mt7915/main.c
+index d234cded..7a00febb 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -1707,6 +1707,17 @@ mt7915_net_fill_forward_path(struct ieee80211_hw *hw,
+ }
+ #endif
+ 
++static void
++mt7915_reconfig_complete(struct ieee80211_hw *hw,
++			 enum ieee80211_reconfig_type reconfig_type)
++{
++	struct mt7915_phy *phy = mt7915_hw_phy(hw);
++
++	ieee80211_wake_queues(hw);
++	ieee80211_queue_delayed_work(hw, &phy->mt76->mac_work,
++				     MT7915_WATCHDOG_TIME);
++}
++
+ const struct ieee80211_ops mt7915_ops = {
+ 	.tx = mt7915_tx,
+ 	.start = mt7915_start,
+@@ -1761,4 +1772,5 @@ const struct ieee80211_ops mt7915_ops = {
+ 	.net_fill_forward_path = mt7915_net_fill_forward_path,
+ 	.net_setup_tc = mt76_wed_net_setup_tc,
+ #endif
++	.reconfig_complete = mt7915_reconfig_complete,
+ };
+diff --git a/mt7915/mcu.c b/mt7915/mcu.c
+index 4b985e4c..de38cfbb 100644
+--- a/mt7915/mcu.c
++++ b/mt7915/mcu.c
+@@ -2360,6 +2360,8 @@ int mt7915_mcu_init_firmware(struct mt7915_dev *dev)
+ 	if (ret)
+ 		return ret;
+ 
++	mt76_connac_mcu_del_wtbl_all(&dev->mt76);
++
+ 	if (mtk_wed_device_active(&dev->mt76.mmio.wed)) {
+ 		if (is_mt7915(&dev->mt76) ||
+ 		    !mtk_wed_get_rx_capa(&dev->mt76.mmio.wed))
+-- 
+2.38.1.windows.1
+
-- 
2.38.1.windows.1

