diff --git a/target/linux/generic/config-5.15 b/target/linux/generic/config-5.15
index 25946519ad713c..e9e782af417652 100644
--- a/target/linux/generic/config-5.15
+++ b/target/linux/generic/config-5.15
@@ -337,6 +337,8 @@ CONFIG_ARM64_CNP=y
 # CONFIG_ARM64_ERRATUM_2441007 is not set
 # CONFIG_ARM64_ERRATUM_2441009 is not set
 # CONFIG_ARM64_ERRATUM_3194386 is not set
+# CONFIG_ARM64_ERRATUM_4118414 is not set
+# CONFIG_ARM64_ERRATUM_4193714 is not set
 # CONFIG_ARM64_ERRATUM_819472 is not set
 # CONFIG_ARM64_ERRATUM_824069 is not set
 # CONFIG_ARM64_ERRATUM_826319 is not set
