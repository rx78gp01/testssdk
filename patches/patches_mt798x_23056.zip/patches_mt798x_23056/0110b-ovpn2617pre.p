diff --git a/feeds/packages/net/openvpn/patches/204-a8fb9f6443cd4ce3b76b1a31738ede2db5bc45ea.patch.txt b/feeds/packages/net/openvpn/patches/204-a8fb9f6443cd4ce3b76b1a31738ede2db5bc45ea.patch.txt
new file mode 100644
index 0000000..36096f0
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/204-a8fb9f6443cd4ce3b76b1a31738ede2db5bc45ea.patch.txt
@@ -0,0 +1,61 @@
+From a8fb9f6443cd4ce3b76b1a31738ede2db5bc45ea Mon Sep 17 00:00:00 2001
+From: Selva Nair <selva.nair@gmail.com>
+Date: Mon, 24 Nov 2025 19:38:34 +0100
+Subject: [PATCH] Harden interactive service pipe
+
+- Append a version 4 uuid to ovpn_pipe_name to make it less
+  predictable
+- Do not allow remote access to the pipe
+
+This greatly reduces the possibility of a rogue process racing to
+open the pipe before CreateFile() is called in the worker thread.
+
+Reported-by: Marc Heuse <marc@srlabs.de>
+Change-Id: Ie66a142751354e421d48b273784fc79bcb9f7208
+Signed-off-by: Selva Nair <selva.nair@gmail.com>
+Acked-by: Gert Doering <gert@greenie.muc.de>
+Gerrit URL: https://gerrit.openvpn.net/c/openvpn/+/1401
+Message-Id: <20251124183839.24803-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg34654.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+---
+ src/openvpnserv/interactive.c | 23 +++++++++++++++++++++--
+ 1 file changed, 21 insertions(+), 2 deletions(-)
+
+diff --git a/src/openvpnserv/interactive.c b/src/openvpnserv/interactive.c
+index c717e99cc54..2dc865e7303 100644
+--- a/src/openvpnserv/interactive.c
++++ b/src/openvpnserv/interactive.c
+@@ -1955,11 +1955,30 @@ RunOpenvpn(LPVOID p)
+         goto out;
+     }
+ 
++    UUID pipe_uuid;
++    RPC_STATUS rpc_stat = UuidCreate(&pipe_uuid);
++    if (rpc_stat != RPC_S_OK)
++    {
++        ReturnError(pipe, rpc_stat, L"UuidCreate", 1, &exit_event);
++        goto out;
++    }
++
++    RPC_WSTR pipe_uuid_str = NULL;
++    rpc_stat = UuidToStringW(&pipe_uuid, &pipe_uuid_str);
++    if (rpc_stat != RPC_S_OK)
++    {
++        ReturnError(pipe, rpc_stat, L"UuidToString", 1, &exit_event);
++        goto out;
++    }
+     openvpn_swprintf(ovpn_pipe_name, _countof(ovpn_pipe_name),
+-                     TEXT("\\\\.\\pipe\\" PACKAGE "%ls\\service_%lu"), service_instance, GetCurrentThreadId());
++                     TEXT("\\\\.\\pipe\\" PACKAGE "%ls\\service_%lu_%ls"), service_instance,
++                     GetCurrentThreadId(), pipe_uuid_str);
++    RpcStringFree(&pipe_uuid_str);
++
+     ovpn_pipe = CreateNamedPipe(ovpn_pipe_name,
+                                 PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE | FILE_FLAG_OVERLAPPED,
+-                                PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT, 1, 128, 128, 0, NULL);
++                                PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS,
++                                1, 128, 128, 0, NULL);
+     if (ovpn_pipe == INVALID_HANDLE_VALUE)
+     {
+         ReturnLastError(pipe, L"CreateNamedPipe");
diff --git a/feeds/packages/net/openvpn/patches/205-f41058420555e19fffcff9fa1fdb810e5a2f1585.patch.txt b/feeds/packages/net/openvpn/patches/205-f41058420555e19fffcff9fa1fdb810e5a2f1585.patch.txt
new file mode 100644
index 0000000..c4dadc4
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/205-f41058420555e19fffcff9fa1fdb810e5a2f1585.patch.txt
@@ -0,0 +1,53 @@
+From f41058420555e19fffcff9fa1fdb810e5a2f1585 Mon Sep 17 00:00:00 2001
+From: Selva Nair <selva.nair@gmail.com>
+Date: Mon, 24 Nov 2025 19:39:06 +0100
+Subject: [PATCH] Restrict access to the service pipe to SYSTEM and owner
+
+Access is restricted to SYSTEM and pipe client user
+(the user starting openvpn.exe). The default is
+full access to Administrtors, owner, and read access
+to everyone. This hardens the pipe further.
+
+Change-Id: I8aa1cf1585e2320fca9329bdd0227976606fe71e
+Signed-off-by: Selva Nair <selva.nair@gmail.com>
+Acked-by: Gert Doering <gert@greenie.muc.de>
+Gerrit URL: https://gerrit.openvpn.net/c/openvpn/+/1402
+Message-Id: <20251124183911.24851-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg34656.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+---
+ src/openvpnserv/interactive.c | 18 +++++++++++++++++-
+ 1 file changed, 17 insertions(+), 1 deletion(-)
+
+diff --git a/src/openvpnserv/interactive.c b/src/openvpnserv/interactive.c
+index 2dc865e7303..275bf426521 100644
+--- a/src/openvpnserv/interactive.c
++++ b/src/openvpnserv/interactive.c
+@@ -1975,10 +1975,26 @@ RunOpenvpn(LPVOID p)
+                      GetCurrentThreadId(), pipe_uuid_str);
+     RpcStringFree(&pipe_uuid_str);
+ 
++    /* make a security descriptor for the named pipe with access
++     * restricted to the user and SYSTEM
++     */
++    SECURITY_ATTRIBUTES sa;
++    PSECURITY_DESCRIPTOR pSD = NULL;
++    LPCWSTR szSDDL = L"D:(A;;GA;;;SY)(A;;GA;;;OW)";
++    if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(
++            szSDDL, SDDL_REVISION_1, &pSD, NULL))
++    {
++        ReturnLastError(pipe, L"ConvertSDDL");
++        goto out;
++    }
++    sa.nLength = sizeof(sa);
++    sa.lpSecurityDescriptor = pSD;
++    sa.bInheritHandle = FALSE;
+     ovpn_pipe = CreateNamedPipe(ovpn_pipe_name,
+                                 PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE | FILE_FLAG_OVERLAPPED,
+                                 PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS,
+-                                1, 128, 128, 0, NULL);
++                                1, 128, 128, 0, &sa);
++
+     if (ovpn_pipe == INVALID_HANDLE_VALUE)
+     {
+         ReturnLastError(pipe, L"CreateNamedPipe");
-- 
2.46.2.windows.1

