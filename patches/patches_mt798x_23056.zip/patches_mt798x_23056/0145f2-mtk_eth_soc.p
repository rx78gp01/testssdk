diff --git a/target/linux/generic/backport-5.15/991-net-ethernet-mtk_eth_soc-use-prefetch-methods.patch b/target/linux/generic/backport-5.15/991-net-ethernet-mtk_eth_soc-use-prefetch-methods.patch
new file mode 100644
index 0000000..deeab5c
--- /dev/null
+++ b/target/linux/generic/backport-5.15/991-net-ethernet-mtk_eth_soc-use-prefetch-methods.patch
@@ -0,0 +1,53 @@
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.c b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+index 0cc2dd85652f..1a0704166103 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -1963,6 +1963,7 @@ static u32 mtk_xdp_run(struct mtk_eth *eth, struct mtk_rx_ring *ring,
+ 	if (!prog)
+ 		goto out;
+ 
++	prefetchw(xdp->data_hard_start);
+ 	act = bpf_prog_run_xdp(prog, xdp);
+ 	switch (act) {
+ 	case XDP_PASS:
+@@ -2039,7 +2040,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 		idx = NEXT_DESP_IDX(ring->calc_idx, ring->dma_size);
+ 		rxd = ring->dma + idx * eth->soc->rx.desc_size;
+ 		data = ring->data[idx];
+-
++		prefetch(rxd);
+ 		if (!mtk_rx_get_desc(eth, &trxd, rxd))
+ 			break;
+ 
+@@ -2105,6 +2106,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 			if (ret != XDP_PASS)
+ 				goto skip_rx;
+ 
++			net_prefetch(xdp.data_meta);
+ 			skb = napi_build_skb(data, PAGE_SIZE);
+ 			if (unlikely(!skb)) {
+ 				page_pool_put_full_page(ring->page_pool,
+@@ -2113,6 +2115,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 				goto skip_rx;
+ 			}
+ 
++			prefetchw(skb->data);
+ 			skb_reserve(skb, xdp.data - xdp.data_hard_start);
+ 			skb_put(skb, xdp.data_end - xdp.data);
+ 			skb_mark_for_recycle(skb);
+@@ -2143,6 +2146,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 			dma_unmap_single(eth->dma_dev, ((u64)trxd.rxd1 | addr64),
+ 					 ring->buf_size, DMA_FROM_DEVICE);
+ 
++			net_prefetch(data);
+ 			skb = napi_build_skb(data, ring->frag_size);
+ 			if (unlikely(!skb)) {
+ 				netdev->stats.rx_dropped++;
+@@ -2150,6 +2154,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 				goto skip_rx;
+ 			}
+ 
++			prefetchw(skb->data);
+ 			skb_reserve(skb, NET_SKB_PAD + NET_IP_ALIGN);
+ 			skb_put(skb, pktlen);
+ 		}
-- 
2.38.1.windows.1

