diff --git a/target/linux/mediatek/patches-5.15/752-29-v6.10-net-ethernet-mtk_ppe-Change-PPE-entries-number-to-16.patch b/target/linux/mediatek/patches-5.15/752-29-v6.10-net-ethernet-mtk_ppe-Change-PPE-entries-number-to-16.patch
new file mode 100644
index 0000000000000..c6b332f3706b1
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/752-29-v6.10-net-ethernet-mtk_ppe-Change-PPE-entries-number-to-16.patch
@@ -0,0 +1,29 @@
+From ca18300e00d584d5693127eb60c108b84883b8ac Mon Sep 17 00:00:00 2001
+From: Shengyu Qu <wiagn233@outlook.com>
+Date: Fri, 5 Jul 2024 01:26:26 +0800
+Subject: [PATCH] net: ethernet: mtk_ppe: Change PPE entries number to 16K
+
+MT7981,7986 and 7988 all supports 32768 PPE entries, and MT7621/MT7620
+supports 16384 PPE entries, but only set to 8192 entries in driver. So
+incrase max entries to 16384 instead.
+
+Signed-off-by: Elad Yifee <eladwf@gmail.com>
+Signed-off-by: Shengyu Qu <wiagn233@outlook.com>
+Reviewed-by: Simon Horman <horms@kernel.org>
+Link: https://patch.msgid.link/TY3P286MB261103F937DE4EEB0F88437D98DE2@TY3P286MB2611.JPNP286.PROD.OUTLOOK.COM
+Signed-off-by: Jakub Kicinski <kuba@kernel.org>
+---
+ drivers/net/ethernet/mediatek/mtk_ppe.h | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_ppe.h
++++ b/drivers/net/ethernet/mediatek/mtk_ppe.h
+@@ -8,7 +8,7 @@
+ #include <linux/bitfield.h>
+ #include <linux/rhashtable.h>
+ 
+-#define MTK_PPE_ENTRIES_SHIFT		3
++#define MTK_PPE_ENTRIES_SHIFT		4
+ #define MTK_PPE_ENTRIES			(1024 << MTK_PPE_ENTRIES_SHIFT)
+ #define MTK_PPE_HASH_MASK		(MTK_PPE_ENTRIES - 1)
+ #define MTK_PPE_WAIT_TIMEOUT_US		1000000
