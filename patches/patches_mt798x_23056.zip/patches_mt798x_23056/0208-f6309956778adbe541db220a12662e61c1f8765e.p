From f6309956778adbe541db220a12662e61c1f8765e Mon Sep 17 00:00:00 2001
From: Nick Hainke <vincent@systemli.org>
Date: Sat, 11 Nov 2023 04:23:58 +0100
Subject: [PATCH] strace: update to 6.6

Release Notes:
https://github.com/strace/strace/releases/tag/v6.6

Signed-off-by: Nick Hainke <vincent@systemli.org>
---
 package/devel/strace/Makefile | 4 ++--
 1 file changed, 2 insertions(+), 2 deletions(-)

diff --git a/package/devel/strace/Makefile b/package/devel/strace/Makefile
index 3343177c3e914f..8ff0ead807c78f 100644
--- a/package/devel/strace/Makefile
+++ b/package/devel/strace/Makefile
@@ -9,12 +9,12 @@ include $(TOPDIR)/rules.mk
 include $(INCLUDE_DIR)/kernel.mk
 
 PKG_NAME:=strace
-PKG_VERSION:=6.3
+PKG_VERSION:=6.6
 PKG_RELEASE:=1
 
 PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.xz
 PKG_SOURCE_URL:=https://strace.io/files/$(PKG_VERSION)
-PKG_HASH:=e17878e301506c1cc301611118ad14efee7f8bcef63b27ace5d290acce7bb731
+PKG_HASH:=421b4186c06b705163e64dc85f271ebdcf67660af8667283147d5e859fc8a96c
 
 PKG_MAINTAINER:=Felix Fietkau <nbd@nbd.name>
 PKG_LICENSE:=LGPL-2.1-or-later
