diff --git a/package/kernel/mac80211/patches/subsys/mtk-0027-mac80211-mtk-fix-AP-mgmt-not-encrypted-in-WDS-mode-w.patch b/package/kernel/mac80211/patches/subsys/mtk-0027-mac80211-mtk-fix-AP-mgmt-not-encrypted-in-WDS-mode-w.patch
new file mode 100644
index 0000000..ab4b5cb
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/mtk-0027-mac80211-mtk-fix-AP-mgmt-not-encrypted-in-WDS-mode-w.patch
@@ -0,0 +1,39 @@
+From 6729cb3a0f853e59cb67fcadad70c138967ba534 Mon Sep 17 00:00:00 2001
+From: Michael-CY Lee <michael-cy.lee@mediatek.com>
+Date: Thu, 25 Jan 2024 14:07:23 +0800
+Subject: [PATCH] mac80211: mtk: fix AP mgmt not encrypted in WDS mode with PMF on
+
+mtk: mac80211: fix AP mgmt not encrypted in WDS mode with PMF on
+
+In ieee80211_tx_prepare(), if tx->sta is still NULL after calling
+sta_info_get(), the skb might be mgmt for WDS peer, so sta_info_get_bss()
+if called to find sta from AP_VLAN, and then interface type & 4-addr
+using is checked.
+
+Signed-off-by: Michael-CY Lee <michael-cy.lee@mediatek.com>
+
+---
+ net/mac80211/tx.c | 7 +++++++
+ 1 file changed, 7 insertions(+)
+
+diff --git a/net/mac80211/tx.c b/net/mac80211/tx.c
+index e071130..6daa5a9 100644
+--- a/net/mac80211/tx.c
++++ b/net/mac80211/tx.c
+@@ -1214,6 +1214,13 @@ ieee80211_tx_prepare(struct ieee80211_sub_if_data *sdata,
+ 		if (!tx->sta && !is_multicast_ether_addr(hdr->addr1)) {
+ 			tx->sta = sta_info_get(sdata, hdr->addr1);
+ 			aggr_check = true;
++
++			if (!tx->sta) {
++				tx->sta = sta_info_get_bss(sdata, hdr->addr1);
++				if (!tx->sta || !tx->sta->sdata->wdev.use_4addr ||
++				    !(tx->sta->sdata->vif.type == NL80211_IFTYPE_AP_VLAN))
++					tx->sta = NULL;
++			}
+ 		}
+ 	}
+ 
+-- 
+2.25.1
+
diff --git a/package/kernel/mac80211/patches/subsys/mtk-0029-mac80211-mtk-send-4-addr-nullfunc-after-drv_event_ca.patch b/package/kernel/mac80211/patches/subsys/mtk-0029-mac80211-mtk-send-4-addr-nullfunc-after-drv_event_ca.patch
new file mode 100644
index 0000000..981a532
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/mtk-0029-mac80211-mtk-send-4-addr-nullfunc-after-drv_event_ca.patch
@@ -0,0 +1,46 @@
+From 8cb06d601dff5b2728684f230ffe46d42e98cab3 Mon Sep 17 00:00:00 2001
+From: Peter Chiu <chui-hao.chiu@mediatek.com>
+Date: Fri, 29 Mar 2024 14:55:41 +0800
+Subject: [PATCH] mac80211: mtk: send 4 addr nullfunc after drv_event_callback
+
+mt76 set channel in drv_event_callback and the 4 addr nullfunc may
+be dropped. Send 4 addr nullfunc after drv_event_callback to avoid
+this issue.
+
+Signed-off-by: Peter Chiu <chui-hao.chiu@mediatek.com>
+
+diff --git a/net/mac80211/mlme.c b/net/mac80211/mlme.c
+index ed81ebf..0f3d8cc 100644
+--- a/net/mac80211/mlme.c
++++ b/net/mac80211/mlme.c
+@@ -3671,13 +3671,6 @@ static bool ieee80211_assoc_success(struct ieee80211_sub_if_data *sdata,
+ 	bss_conf->assoc_capability = capab_info;
+ 	ieee80211_set_associated(sdata, cbss, changed);
+ 
+-	/*
+-	 * If we're using 4-addr mode, let the AP know that we're
+-	 * doing so, so that it can create the STA VLAN on its side
+-	 */
+-	if (ifmgd->use_4addr)
+-		ieee80211_send_4addr_nullfunc(local, sdata);
+-
+ 	/*
+ 	 * Start timer to probe the connection to the AP now.
+ 	 * Also start the timer that will detect beacon loss.
+@@ -3798,6 +3791,13 @@ static void ieee80211_rx_mgmt_assoc_resp(struct ieee80211_sub_if_data *sdata,
+ 		drv_event_callback(sdata->local, sdata, &event);
+ 		sdata_info(sdata, "associated\n");
+ 
++		/*
++		* If we're using 4-addr mode, let the AP know that we're
++		* doing so, so that it can create the STA VLAN on its side
++		*/
++		if (ifmgd->use_4addr)
++			ieee80211_send_4addr_nullfunc(sdata->local, sdata);
++
+ 		/*
+ 		 * destroy assoc_data afterwards, as otherwise an idle
+ 		 * recalc after assoc_data is NULL but before associated
+-- 
+2.18.0
+
diff --git a/package/kernel/mac80211/patches/subsys/mtk-0030-mac80211-mtk-fix-incorrect-VIF-assignment-for-IEEE-8.patch b/package/kernel/mac80211/patches/subsys/mtk-0030-mac80211-mtk-fix-incorrect-VIF-assignment-for-IEEE-8.patch
new file mode 100644
index 0000000..60fa62b
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/mtk-0030-mac80211-mtk-fix-incorrect-VIF-assignment-for-IEEE-8.patch
@@ -0,0 +1,33 @@
+From 6f8a21b15ee4078ecf14c11a5cca0d8dee0bc474 Mon Sep 17 00:00:00 2001
+From: Benjamin Lin <benjamin-jw.lin@mediatek.com>
+Date: Wed, 3 Apr 2024 14:23:51 +0800
+Subject: [PATCH] mac80211: mtk: fix incorrect VIF assignment for IEEE 802.11
+ fragments
+
+When in WDS mode (vif is AP_VLAN), only the first fragment would be dequeued from txq and go through some tx processing which includes the replacement of vif in CB(SKB) from the AP_VLAN one to the AP one. However, the rest of the fragments would be dequeued from txqi->frags and bypass this process which in turn results in different VIF assignment for softmac to fill in TXD. Therefore, we fix this by assigning the correct AP VIF to SKB_CB of the rest fragments.
+
+Signed-off-by: Benjamin Lin <benjamin-jw.lin@mediatek.com>
+---
+ net/mac80211/tx.c | 5 ++++-
+ 1 file changed, 4 insertions(+), 1 deletion(-)
+
+diff --git a/net/mac80211/tx.c b/net/mac80211/tx.c
+index 4085444..0577764 100644
+--- a/net/mac80211/tx.c
++++ b/net/mac80211/tx.c
+@@ -3736,8 +3736,11 @@ begin:
+ 	skb = __skb_dequeue(&txqi->frags);
+ 	if (unlikely(skb)) {
+ 		if (!(IEEE80211_SKB_CB(skb)->control.flags &
+-				IEEE80211_TX_INTCFL_NEED_TXPROCESSING))
++				IEEE80211_TX_INTCFL_NEED_TXPROCESSING)) {
++			// TODO: report airtime of non-first fragments.
++			IEEE80211_SKB_CB(skb)->control.vif = vif;
+ 			goto out;
++		}
+ 		IEEE80211_SKB_CB(skb)->control.flags &=
+ 			~IEEE80211_TX_INTCFL_NEED_TXPROCESSING;
+ 	} else {
+-- 
+2.18.0
+
-- 
2.38.1

