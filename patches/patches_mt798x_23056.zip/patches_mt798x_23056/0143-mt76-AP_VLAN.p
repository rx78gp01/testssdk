diff --git a/package/kernel/mt76/patches/9997-AP_VLAN.patch b/package/kernel/mt76/patches/9997-AP_VLAN.patch
new file mode 100644
index 0000000..a48df99
--- /dev/null
+++ b/package/kernel/mt76/patches/9997-AP_VLAN.patch
@@ -0,0 +1,16 @@
+diff --git a/mt7915/main.c b/mt7915/main.c
+index 420eacfd..030f5a9e 100644
+--- a/mt7915/main.c
++++ b/mt7915/main.c
+@@ -263,7 +263,7 @@ static int mt7915_add_interface(struct ieee80211_hw *hw,
+ 		mtxq->wcid = idx;
+ 	}
+ 
+-	if (vif->type != NL80211_IFTYPE_AP &&
++	if ((vif->type != (NL80211_IFTYPE_AP || NL80211_IFTYPE_AP_VLAN)) &&
+ 	    (!mvif->mt76.omac_idx || mvif->mt76.omac_idx > 3))
+ 		vif->offload_flags = 0;
+ 	vif->offload_flags |= IEEE80211_OFFLOAD_ENCAP_4ADDR;
+-- 
+2.38.1.windows.1
+
-- 
2.38.1.windows.1

