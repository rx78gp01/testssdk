diff --git a/target/linux/generic/backport-5.15/964-mtk-soc.patch b/target/linux/generic/backport-5.15/964-mtk-soc.patch
new file mode 100644
index 0000000..e3f45e5
--- /dev/null
+++ b/target/linux/generic/backport-5.15/964-mtk-soc.patch
@@ -0,0 +1,29 @@
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.c b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+index e7b9911..a8256c0 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -1102,7 +1102,7 @@ static int mtk_init_fq_dma(struct mtk_eth *eth)
+ 		if (unlikely(dma_mapping_error(eth->dma_dev, dma_addr)))
+ 			return -ENOMEM;
+ 
+-		for (i = 0; i < cnt; i++) {
++		for (i = 0; i < len; i++) {
+ 			struct mtk_tx_dma_v2 *txd;
+ 
+ 			txd = eth->scratch_ring + (j * MTK_FQ_DMA_LENGTH + i) * soc->tx.desc_size;
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.h b/drivers/net/ethernet/mediatek/mtk_eth_soc.h
+index 115c1d2..f988041 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.h
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.h
+@@ -34,7 +34,7 @@
+ #define MTK_QDMA_RING_SIZE	2048
+ #define MTK_DMA_SIZE(x)		(SZ_##x)
+ #define MTK_FQ_DMA_HEAD		32
+-#define MTK_FQ_DMA_LENGTH	2048
++#define MTK_FQ_DMA_LENGTH	512
+ #define MTK_RX_ETH_HLEN		(VLAN_ETH_HLEN + ETH_FCS_LEN)
+ #define MTK_RX_HLEN		(NET_SKB_PAD + MTK_RX_ETH_HLEN + NET_IP_ALIGN)
+ #define MTK_DMA_DUMMY_DESC	0xffffffff
+-- 
+2.38.1
+
-- 
