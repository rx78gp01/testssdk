From 791a65ce94151b0bd495106a221174252b4dc10f Mon Sep 17 00:00:00 2001
From: Andrea Pesaresi <andreapesaresi82@gmail.com>
Date: Thu, 13 Jun 2024 23:40:14 +0200
Subject: [PATCH] luci-app-firewall: add WED enable disable support

Signed-off-by: Andrea Pesaresi <andreapesaresi82@gmail.com>
---

diff --git a/feeds/luci/applications/luci-app-firewall/htdocs/luci-static/resources/view/firewall/zones.js b/feeds/luci/applications/luci-app-firewall/htdocs/luci-static/resources/view/firewall/zones.js
index a91d4cb9754d..2643682c3ea6 100644
--- a/feeds/luci/applications/luci-app-firewall/htdocs/luci-static/resources/view/firewall/zones.js
+++ b/feeds/luci/applications/luci-app-firewall/htdocs/luci-static/resources/view/firewall/zones.js
@@ -5,6 +5,7 @@
 'require form';
 'require network';
 'require firewall';
+'require fs';
 'require tools.firewall as fwtool';
 'require tools.widgets as widgets';
 
@@ -18,7 +19,8 @@ return view.extend({
 	load: function() {
 		return Promise.all([
 			this.callConntrackHelpers(),
-			firewall.getDefaults()
+			firewall.getDefaults(),
+			fs.trimmed('/etc/modules.d/mt7915e')
 		]);
 	},
 
@@ -30,6 +32,7 @@ return view.extend({
 	},
 
 	renderZones: function(data) {
+		var wed_state = data[2];
 		var ctHelpers = data[0],
 		    fwDefaults = data[1],
 		    m, s, o, inp, out;
@@ -78,6 +81,36 @@ return view.extend({
 			s.anonymous = true;
 			s.addremove = false;
 
+			var wedisenabled;
+
+			if ( wed_state == "mt7915e wed_enable=1"){
+				wedisenabled = true;
+			}
+			else {
+				wedisenabled = false;
+			}
+
+			o = s.option(form.TextValue, 'WED state', _('WED state: contents of the file (/etc/modules.d/mt7915e).'), _('If contents is (mt7915e wed_enable=1) WED is enabled otherwise is disabled.'));
+			o.readonly = true;
+			o.cfgvalue = function (section_id) {
+				return fs.trimmed('/etc/modules.d/mt7915e');
+				};
+		if (wedisenabled == false){
+		o.write = function(section_id) {
+				return fs.write('/etc/modules.d/mt7915e', 'mt7915e wed_enable=1');
+				};
+		}
+		else {
+			o.write = function(section_id) {
+				return fs.write('/etc/modules.d/mt7915e', 'mt7915e wed_enable=0');
+				};
+		}
+
+			o = s.option(form.Flag, 'wed_enable',
+				_('Enable WED'),
+				_('Wireless Ethernet Dispatch (WED) - disabled by default. It is an extension of hardware flow offloading which can reduce CPU loads/increase routing throughput of wireless devices. ***After saved and apply this change, a reboot of the device is necessary to take effect.***'));
+			o.default = wedisenabled;
+
 			o = s.option(form.Flag, 'flow_offloading',
 				_('Software flow offloading'),
 				_('Software based offloading for routing/NAT'));
diff --git a/feeds/luci/applications/luci-app-firewall/root/usr/share/rpcd/acl.d/luci-app-firewall.json b/feeds/luci/applications/luci-app-firewall/root/usr/share/rpcd/acl.d/luci-app-firewall.json
index 17d1fbab1288..c1fbff1d38c5 100644
--- a/feeds/luci/applications/luci-app-firewall/root/usr/share/rpcd/acl.d/luci-app-firewall.json
+++ b/feeds/luci/applications/luci-app-firewall/root/usr/share/rpcd/acl.d/luci-app-firewall.json
@@ -3,6 +3,7 @@
 		"description": "Grant access to firewall configuration",
 		"read": {
 			"file": {
+				"/etc/modules.d/mt7915e": ["read"],
 				"/etc/firewall.user": [ "read" ]
 			},
 			"ubus": {
@@ -13,6 +14,7 @@
 		},
 		"write": {
 			"file": {
+				"/etc/modules.d/mt7915e":  [ "write" ],
 				"/etc/firewall.user": [ "write" ]
 			},
 			"ubus": {
