From 8ef4d785829241e3a6f95c896de210fd5d3f073b Mon Sep 17 00:00:00 2001
From: Daniel Golle <daniel@makrotopia.org>
Date: Mon, 1 Jul 2024 20:37:58 +0100
Subject: [PATCH] generic: 6.6: net: ethernet: mediatek: Allow gaps in MAC
 allocation

Some devices with MediaTek SoCs don't use the first but only the second
MAC in the chip. Especially with MT7981 which got a built-in 1GE PHY
connected to the second MAC this is quite common.
Make sure to reset and enable PSE also in those cases by skipping gaps
using 'continue' instead of aborting the loop using 'break'.

Fixes: 75081235b8 ("generic: 6.6: (re-)add support multiple PPE to mtk_eth_soc")
Reported-by: Daniel Suchy <danny@danysek.cz>
Signed-off-by: Daniel Golle <daniel@makrotopia.org>
---
 ...ediatek-Allow-gaps-in-MAC-allocation.patch | 33 +++++++++++++++++++
 1 file changed, 33 insertions(+)
 create mode 100644 target/linux/mediatek/patches-5.15/971-net-ethernet-mediatek-Allow-gaps-in-MAC-allocation.patch

diff --git a/target/linux/mediatek/patches-5.15/971-net-ethernet-mediatek-Allow-gaps-in-MAC-allocation.patch b/target/linux/mediatek/patches-5.15/971-net-ethernet-mediatek-Allow-gaps-in-MAC-allocation.patch
new file mode 100644
index 0000000000000..8e1ad54a53e83
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/971-net-ethernet-mediatek-Allow-gaps-in-MAC-allocation.patch
@@ -0,0 +1,33 @@
+From 379ae584cea112db60f4ada79c7e5ba4f3364a64 Mon Sep 17 00:00:00 2001
+X-Patchwork-Submitter: Daniel Golle <daniel@makrotopia.org>
+X-Patchwork-Id: 13718593
+X-Patchwork-Delegate: kuba@kernel.org
+List-Id: <netdev.vger.kernel.org>
+From: Daniel Golle <daniel@makrotopia.org>
+Date: Mon, 1 Jul 2024 19:26:28 +0100
+Subject: [PATCH] net: ethernet: mediatek: Allow gaps in MAC allocation
+
+Some devices with MediaTek SoCs don't use the first but only the second
+MAC in the chip. Especially with MT7981 which got a built-in 1GE PHY
+connected to the second MAC this is quite common.
+Make sure to reset and enable PSE also in those cases by skipping gaps
+using 'continue' instead of aborting the loop using 'break'.
+
+Fixes: dee4dd10c79a ("net: ethernet: mtk_eth_soc: ppe: add support for multiple PPEs")
+Suggested-by: Elad Yifee <eladwf@gmail.com>
+Signed-off-by: Daniel Golle <daniel@makrotopia.org>
+---
+ drivers/net/ethernet/mediatek/mtk_eth_soc.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -3530,7 +3530,7 @@ static int mtk_open(struct net_device *d
+ 
+ 		for (i = 0; i < MTK_MAX_DEVS; i++) {
+ 			if (!eth->netdev[i])
+-				break;
++				continue;
+ 
+ 			target_mac = netdev_priv(eth->netdev[i]);
+ 			if (!soc->offload_version) {
