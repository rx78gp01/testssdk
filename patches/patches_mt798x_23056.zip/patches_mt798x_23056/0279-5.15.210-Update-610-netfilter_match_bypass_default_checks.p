diff --git a/target/linux/generic/pending-5.15/610-netfilter_match_bypass_default_checks.patch b/target/linux/generic/pending-5.15/610-netfilter_match_bypass_default_checks.patch
index 8b1e70b..98dfda3 100644
--- a/target/linux/generic/pending-5.15/610-netfilter_match_bypass_default_checks.patch
+++ b/target/linux/generic/pending-5.15/610-netfilter_match_bypass_default_checks.patch
@@ -83,7 +83,7 @@ Signed-off-by: Felix Fietkau <nbd@nbd.name>
 +		flags = e->ip.flags & IPT_F_MASK;
 +		if (copy_to_user(userptr + off
 +				 + offsetof(struct ipt_entry, ip.flags),
-+				 &flags, sizeof(flags)) != 0) {
++				 &flags, sizeof(flags))) {
 +			ret = -EFAULT;
 +			goto free_counters;
 +		}
@@ -91,7 +91,7 @@ Signed-off-by: Felix Fietkau <nbd@nbd.name>
  		for (i = sizeof(struct ipt_entry);
  		     i < e->target_offset;
  		     i += m->u.match_size) {
-@@ -1226,12 +1263,15 @@ compat_copy_entry_to_user(struct ipt_ent
+@@ -1226,11 +1263,14 @@ compat_copy_entry_to_user(struct ipt_ent
  	compat_uint_t origsize;
  	const struct xt_entry_match *ematch;
  	int ret = 0;
@@ -99,12 +99,11 @@ Signed-off-by: Felix Fietkau <nbd@nbd.name>
  
  	origsize = *size;
  	ce = *dstptr;
- 	if (copy_to_user(ce, e, sizeof(struct ipt_entry)) != 0 ||
- 	    copy_to_user(&ce->counters, &counters[i],
--	    sizeof(counters[i])) != 0)
-+	    sizeof(counters[i])) != 0 ||
+ 	if (copy_to_user(ce, e, offsetof(struct compat_ipt_entry, counters)) ||
+-	    copy_to_user(&ce->counters, &counters[i], sizeof(counters[i])))
++	    copy_to_user(&ce->counters, &counters[i], sizeof(counters[i])) ||
 +	    copy_to_user(&ce->ip.flags, &flags,
-+	    sizeof(flags)) != 0)
++	    sizeof(flags)))
  		return -EFAULT;
  
  	*dstptr += sizeof(struct compat_ipt_entry);
-- 
2.46.2.windows.1

