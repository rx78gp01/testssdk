diff --git a/package/kernel/mt76/patches/9999-mt76_18.patch b/package/kernel/mt76/patches/9999-mt76_18.patch
new file mode 100644
index 0000000..c3cdd7a
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_18.patch
@@ -0,0 +1,25 @@
+From fb22489fd7380d4c674a5795ec8e7b69906db828 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Sun, 17 Aug 2025 20:23:41 +0200
+Subject: [PATCH] wifi: mt76: do not add non-sta wcid entries to the poll list
+
+Polling and airtime reporting is valid for station entries only
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mac80211.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/mac80211.c b/mac80211.c
+index bd5f56250..65927f85f 100644
+--- a/mac80211.c
++++ b/mac80211.c
+@@ -1682,7 +1682,7 @@ EXPORT_SYMBOL_GPL(mt76_wcid_cleanup);
+ 
+ void mt76_wcid_add_poll(struct mt76_dev *dev, struct mt76_wcid *wcid)
+ {
+-	if (test_bit(MT76_MCU_RESET, &dev->phy.state))
++	if (test_bit(MT76_MCU_RESET, &dev->phy.state) || !wcid->sta)
+ 		return;
+ 
+ 	spin_lock_bh(&dev->sta_poll_lock);
diff --git a/package/kernel/mt76/patches/9999-mt76_19.patch b/package/kernel/mt76/patches/9999-mt76_19.patch
new file mode 100644
index 0000000..e658e57
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_19.patch
@@ -0,0 +1,105 @@
+From 4cd64ad1283baee52a794ff44865131af2c35fb4 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Tue, 19 Aug 2025 16:19:25 +0200
+Subject: [PATCH] wifi: mt76: mt7915: fix list corruption after hardware
+ restart
+
+Since stations are recreated from scratch, all lists that wcids are added
+to must be cleared before calling ieee80211_restart_hw.
+Set wcid->sta = 0 for each wcid entry in order to ensure that they are
+not added again before they are ready.
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mac80211.c   | 37 +++++++++++++++++++++++++++++++++++++
+ mt76.h       |  1 +
+ mt7915/mac.c | 12 +++++-------
+ 3 files changed, 43 insertions(+), 7 deletions(-)
+
+diff --git a/mac80211.c b/mac80211.c
+index 65927f85f..c9b7a0600 100644
+--- a/mac80211.c
++++ b/mac80211.c
+@@ -810,6 +810,43 @@ void mt76_free_device(struct mt76_dev *dev)
+ }
+ EXPORT_SYMBOL_GPL(mt76_free_device);
+ 
++static void mt76_reset_phy(struct mt76_phy *phy)
++{
++	if (!phy)
++		return;
++
++	INIT_LIST_HEAD(&phy->tx_list);
++}
++
++void mt76_reset_device(struct mt76_dev *dev)
++{
++	int i;
++
++	rcu_read_lock();
++	for (i = 0; i < ARRAY_SIZE(dev->wcid); i++) {
++		struct mt76_wcid *wcid;
++
++		wcid = rcu_dereference(dev->wcid[i]);
++		if (!wcid)
++			continue;
++
++		wcid->sta = 0;
++		mt76_wcid_cleanup(dev, wcid);
++		rcu_assign_pointer(dev->wcid[i], NULL);
++	}
++	rcu_read_unlock();
++
++	INIT_LIST_HEAD(&dev->wcid_list);
++	INIT_LIST_HEAD(&dev->sta_poll_list);
++	dev->vif_mask = 0;
++	memset(dev->wcid_mask, 0, sizeof(dev->wcid_mask));
++
++	mt76_reset_phy(&dev->phy);
++	for (i = 0; i < ARRAY_SIZE(dev->phys); i++)
++		mt76_reset_phy(dev->phys[i]);
++}
++EXPORT_SYMBOL_GPL(mt76_reset_device);
++
+ static void mt76_rx_release_amsdu(struct mt76_phy *phy, enum mt76_rxq_id q)
+ {
+ 	struct sk_buff *skb = phy->rx_amsdu[q].head;
+diff --git a/mt76.h b/mt76.h
+index 95f7567ad..f6cfdf0f6 100644
+--- a/mt76.h
++++ b/mt76.h
+@@ -1248,6 +1248,7 @@ int mt76_register_device(struct mt76_dev *dev, bool vht,
+ 			 struct ieee80211_rate *rates, int n_rates);
+ void mt76_unregister_device(struct mt76_dev *dev);
+ void mt76_free_device(struct mt76_dev *dev);
++void mt76_reset_device(struct mt76_dev *dev);
+ void mt76_unregister_phy(struct mt76_phy *phy);
+ 
+ struct mt76_phy *mt76_alloc_radio_phy(struct mt76_dev *dev, unsigned int size,
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index 6639976af..1c0d31014 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -1460,17 +1460,15 @@ mt7915_mac_full_reset(struct mt7915_dev *dev)
+ 	if (i == 10)
+ 		dev_err(dev->mt76.dev, "chip full reset failed\n");
+ 
+-	spin_lock_bh(&dev->mt76.sta_poll_lock);
+-	while (!list_empty(&dev->mt76.sta_poll_list))
+-		list_del_init(dev->mt76.sta_poll_list.next);
+-	spin_unlock_bh(&dev->mt76.sta_poll_lock);
+-
+-	memset(dev->mt76.wcid_mask, 0, sizeof(dev->mt76.wcid_mask));
+-	dev->mt76.vif_mask = 0;
+ 	dev->phy.omac_mask = 0;
+ 	if (phy2)
+ 		phy2->omac_mask = 0;
+ 
++	mt76_reset_device(&dev->mt76);
++
++	INIT_LIST_HEAD(&dev->sta_rc_list);
++	INIT_LIST_HEAD(&dev->twt_list);
++
+ 	i = mt76_wcid_alloc(dev->mt76.wcid_mask, MT7915_WTBL_STA);
+ 	dev->mt76.global_wcid.idx = i;
+ 	dev->recovery.hw_full_reset = false;
diff --git a/package/kernel/mt76/patches/9999-mt76_20.patch b/package/kernel/mt76/patches/9999-mt76_20.patch
new file mode 100644
index 0000000..a359ae2
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_20.patch
@@ -0,0 +1,28 @@
+From ee538efba542ec34371fd25167effdc8ccff0593 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Tue, 26 Aug 2025 10:47:55 +0200
+Subject: [PATCH] wifi: mt76: free pending offchannel tx frames on wcid cleanup
+
+Avoid leaking them or keeping the wcid on the tx list
+
+Fixes: 0b3be9d1d34e ("wifi: mt76: add separate tx scheduling queue for off-channel tx")
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mac80211.c | 4 ++++
+ 1 file changed, 4 insertions(+)
+
+diff --git a/mac80211.c b/mac80211.c
+index c9b7a0600..8f02a8063 100644
+--- a/mac80211.c
++++ b/mac80211.c
+@@ -1708,6 +1708,10 @@ void mt76_wcid_cleanup(struct mt76_dev *dev, struct mt76_wcid *wcid)
+ 	skb_queue_splice_tail_init(&wcid->tx_pending, &list);
+ 	spin_unlock(&wcid->tx_pending.lock);
+ 
++	spin_lock(&wcid->tx_offchannel.lock);
++	skb_queue_splice_tail_init(&wcid->tx_offchannel, &list);
++	spin_unlock(&wcid->tx_offchannel.lock);
++
+ 	spin_unlock_bh(&phy->tx_lock);
+ 
+ 	while ((skb = __skb_dequeue(&list)) != NULL) {
diff --git a/package/kernel/mt76/patches/9999-mt76_21.patch b/package/kernel/mt76/patches/9999-mt76_21.patch
new file mode 100644
index 0000000..54f8055
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_21.patch
@@ -0,0 +1,51 @@
+From 415b5a68878b808e366ef071919fe24806a04005 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Wed, 27 Aug 2025 07:33:03 +0200
+Subject: [PATCH] wifi: mt76: fix list corruption
+
+Never leave scheduled wcid entries on the temporary on-stack list
+
+Fixes: 0b3be9d1d34e ("wifi: mt76: add separate tx scheduling queue for off-channel tx")
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ tx.c | 8 +++-----
+ 1 file changed, 3 insertions(+), 5 deletions(-)
+
+diff --git a/tx.c b/tx.c
+index 03b042fdf..8ab5840fe 100644
+--- a/tx.c
++++ b/tx.c
+@@ -646,6 +646,7 @@ mt76_txq_schedule_pending_wcid(struct mt76_phy *phy, struct mt76_wcid *wcid,
+ static void mt76_txq_schedule_pending(struct mt76_phy *phy)
+ {
+ 	LIST_HEAD(tx_list);
++	int ret = 0;
+ 
+ 	if (list_empty(&phy->tx_list))
+ 		return;
+@@ -657,13 +658,13 @@ static void mt76_txq_schedule_pending(struct mt76_phy *phy)
+ 	list_splice_init(&phy->tx_list, &tx_list);
+ 	while (!list_empty(&tx_list)) {
+ 		struct mt76_wcid *wcid;
+-		int ret;
+ 
+ 		wcid = list_first_entry(&tx_list, struct mt76_wcid, tx_list);
+ 		list_del_init(&wcid->tx_list);
+ 
+ 		spin_unlock(&phy->tx_lock);
+-		ret = mt76_txq_schedule_pending_wcid(phy, wcid, &wcid->tx_offchannel);
++		if (ret >= 0)
++			ret = mt76_txq_schedule_pending_wcid(phy, wcid, &wcid->tx_offchannel);
+ 		if (ret >= 0 && !phy->offchannel)
+ 			ret = mt76_txq_schedule_pending_wcid(phy, wcid, &wcid->tx_pending);
+ 		spin_lock(&phy->tx_lock);
+@@ -672,9 +673,6 @@ static void mt76_txq_schedule_pending(struct mt76_phy *phy)
+ 		    !skb_queue_empty(&wcid->tx_offchannel) &&
+ 		    list_empty(&wcid->tx_list))
+ 			list_add_tail(&wcid->tx_list, &phy->tx_list);
+-
+-		if (ret < 0)
+-			break;
+ 	}
+ 	spin_unlock(&phy->tx_lock);
+ 
-- 
2.46.2.windows.1

