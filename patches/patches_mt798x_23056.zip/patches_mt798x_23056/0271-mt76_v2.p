From 4b07ffbe66797bbf49278a5e83dfc6c93f71df18 Mon Sep 17 00:00:00 2001
From: rx78gp01 <rx78gp01@users.noreply.github.com>
Date: Mon, 7 Jul 2025 23:18:07 +0800
Subject: [PATCH] mt76

---
 .../kernel/mt76/patches/9999-mt76_14.patch    |  31 ++
 .../kernel/mt76/patches/9999-mt76_15.patch    | 326 ++++++++++++++++++
 2 files changed, 357 insertions(+)
 create mode 100644 package/kernel/mt76/patches/9999-mt76_14.patch
 create mode 100644 package/kernel/mt76/patches/9999-mt76_15.patch

diff --git a/package/kernel/mt76/patches/9999-mt76_14.patch b/package/kernel/mt76/patches/9999-mt76_14.patch
new file mode 100644
index 0000000..5feb6e3
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_14.patch
@@ -0,0 +1,31 @@
+From c4a114e2b8c9ac3f2b941b81f0c6031c4177dca4 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Fri, 4 Jul 2025 20:43:50 +0200
+Subject: [PATCH] wifi: mt76: fix queue assignment for deauth packets
+
+When running in AP mode and deauthenticating a client that's in powersave
+mode, the disassoc/deauth packet can get stuck in a tx queue along with
+other buffered frames. This can fill up hardware queues with frames
+that are only released after the WTBL slot is reused for another client.
+
+Fix this by moving deauth packets to the ALTX queue.
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ tx.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/tx.c b/tx.c
+index 513916469..dc9bf2fff 100644
+--- a/tx.c
++++ b/tx.c
+@@ -617,7 +617,8 @@ mt76_txq_schedule_pending_wcid(struct mt76_phy *phy, struct mt76_wcid *wcid,
+ 		if ((dev->drv->drv_flags & MT_DRV_HW_MGMT_TXQ) &&
+ 		    !(info->flags & IEEE80211_TX_CTL_HW_80211_ENCAP) &&
+ 		    !ieee80211_is_data(hdr->frame_control) &&
+-		    !ieee80211_is_bufferable_mmpdu(skb))
++		    (!ieee80211_is_bufferable_mmpdu(skb) ||
++		     ieee80211_is_deauth(hdr->frame_control)))
+ 			qid = MT_TXQ_PSD;
+ 
+ 		q = phy->q_tx[qid];
diff --git a/package/kernel/mt76/patches/9999-mt76_15.patch b/package/kernel/mt76/patches/9999-mt76_15.patch
new file mode 100644
index 0000000..58b1e4e
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_15.patch
@@ -0,0 +1,326 @@
+From 243e572d89fc122c59295cd6e66ee5baa984e67b Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Fri, 4 Jul 2025 20:46:04 +0200
+Subject: [PATCH] wifi: mt76: add a wrapper for wcid access with validation
+
+Several places use rcu_dereference to get a wcid entry without validating
+if the index exceeds the array boundary. Fix this by using a helper function,
+which handles validation.
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt76.h            | 10 ++++++++++
+ mt7603/dma.c      |  2 +-
+ mt7603/mac.c      | 10 ++--------
+ mt7615/mac.c      |  7 ++-----
+ mt76_connac_mac.c |  2 +-
+ mt76x02.h         |  5 +----
+ mt76x02_mac.c     |  4 +---
+ mt7915/mac.c      | 12 +++---------
+ mt7915/mcu.c      |  2 +-
+ mt7915/mmio.c     |  5 +----
+ mt7921/mac.c      |  6 +++---
+ mt7925/mac.c      |  6 +++---
+ mt792x_mac.c      |  5 +----
+ mt7996/mac.c      | 12 +++---------
+ mt7996/mcu.c      | 11 ++++-------
+ tx.c              |  8 +++-----
+ util.c            |  2 +-
+ 17 files changed, 41 insertions(+), 68 deletions(-)
+
+diff --git a/mt76.h b/mt76.h
+index e2a89fd24..879fd6eb9 100644
+--- a/mt76.h
++++ b/mt76.h
+@@ -1229,6 +1229,16 @@ static inline int mt76_wed_dma_setup(struct mt76_dev *dev, struct mt76_queue *q,
+ #define mt76_dereference(p, dev) \
+ 	rcu_dereference_protected(p, lockdep_is_held(&(dev)->mutex))
+ 
++static inline struct mt76_wcid *
++__mt76_wcid_ptr(struct mt76_dev *dev, u16 idx)
++{
++	if (idx >= ARRAY_SIZE(dev->wcid))
++		return NULL;
++	return rcu_dereference(dev->wcid[idx]);
++}
++
++#define mt76_wcid_ptr(dev, idx) __mt76_wcid_ptr(&(dev)->mt76, idx)
++
+ struct mt76_dev *mt76_alloc_device(struct device *pdev, unsigned int size,
+ 				   const struct ieee80211_ops *ops,
+ 				   const struct mt76_driver_ops *drv_ops);
+diff --git a/mt7603/dma.c b/mt7603/dma.c
+index e238161df..f68600213 100644
+--- a/mt7603/dma.c
++++ b/mt7603/dma.c
+@@ -44,7 +44,7 @@ mt7603_rx_loopback_skb(struct mt7603_dev *dev, struct sk_buff *skb)
+ 	if (idx >= MT7603_WTBL_STA - 1)
+ 		goto free;
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (!wcid)
+ 		goto free;
+ 
+diff --git a/mt7603/mac.c b/mt7603/mac.c
+index 413973d05..6387f9e61 100644
+--- a/mt7603/mac.c
++++ b/mt7603/mac.c
+@@ -487,10 +487,7 @@ mt7603_rx_get_wcid(struct mt7603_dev *dev, u8 idx, bool unicast)
+ 	struct mt7603_sta *sta;
+ 	struct mt76_wcid *wcid;
+ 
+-	if (idx >= MT7603_WTBL_SIZE)
+-		return NULL;
+-
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (unicast || !wcid)
+ 		return wcid;
+ 
+@@ -1266,12 +1263,9 @@ void mt7603_mac_add_txs(struct mt7603_dev *dev, void *data)
+ 	if (pid == MT_PACKET_ID_NO_ACK)
+ 		return;
+ 
+-	if (wcidx >= MT7603_WTBL_SIZE)
+-		return;
+-
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[wcidx]);
++	wcid = mt76_wcid_ptr(dev, wcidx);
+ 	if (!wcid)
+ 		goto out;
+ 
+diff --git a/mt7615/mac.c b/mt7615/mac.c
+index 3ca4fae7c..f8d2cc94b 100644
+--- a/mt7615/mac.c
++++ b/mt7615/mac.c
+@@ -90,10 +90,7 @@ static struct mt76_wcid *mt7615_rx_get_wcid(struct mt7615_dev *dev,
+ 	struct mt7615_sta *sta;
+ 	struct mt76_wcid *wcid;
+ 
+-	if (idx >= MT7615_WTBL_SIZE)
+-		return NULL;
+-
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (unicast || !wcid)
+ 		return wcid;
+ 
+@@ -1504,7 +1501,7 @@ static void mt7615_mac_add_txs(struct mt7615_dev *dev, void *data)
+ 
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[wcidx]);
++	wcid = mt76_wcid_ptr(dev, wcidx);
+ 	if (!wcid)
+ 		goto out;
+ 
+diff --git a/mt76_connac_mac.c b/mt76_connac_mac.c
+index e9ac8a731..0db00efe8 100644
+--- a/mt76_connac_mac.c
++++ b/mt76_connac_mac.c
+@@ -1172,7 +1172,7 @@ void mt76_connac2_txwi_free(struct mt76_dev *dev, struct mt76_txwi_cache *t,
+ 		wcid_idx = wcid->idx;
+ 	} else {
+ 		wcid_idx = le32_get_bits(txwi[1], MT_TXD1_WLAN_IDX);
+-		wcid = rcu_dereference(dev->wcid[wcid_idx]);
++		wcid = __mt76_wcid_ptr(dev, wcid_idx);
+ 
+ 		if (wcid && wcid->sta) {
+ 			sta = container_of((void *)wcid, struct ieee80211_sta,
+diff --git a/mt76x02.h b/mt76x02.h
+index 4cd63bacd..9d7ee09b6 100644
+--- a/mt76x02.h
++++ b/mt76x02.h
+@@ -262,10 +262,7 @@ mt76x02_rx_get_sta(struct mt76_dev *dev, u8 idx)
+ {
+ 	struct mt76_wcid *wcid;
+ 
+-	if (idx >= MT76x02_N_WCIDS)
+-		return NULL;
+-
+-	wcid = rcu_dereference(dev->wcid[idx]);
++	wcid = __mt76_wcid_ptr(dev, idx);
+ 	if (!wcid)
+ 		return NULL;
+ 
+diff --git a/mt76x02_mac.c b/mt76x02_mac.c
+index d5db6ffd6..83488b2d6 100644
+--- a/mt76x02_mac.c
++++ b/mt76x02_mac.c
+@@ -564,9 +564,7 @@ void mt76x02_send_tx_status(struct mt76x02_dev *dev,
+ 
+ 	rcu_read_lock();
+ 
+-	if (stat->wcid < MT76x02_N_WCIDS)
+-		wcid = rcu_dereference(dev->mt76.wcid[stat->wcid]);
+-
++	wcid = mt76_wcid_ptr(dev, stat->wcid);
+ 	if (wcid && wcid->sta) {
+ 		void *priv;
+ 
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index 9400e4af2..6639976af 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -56,10 +56,7 @@ static struct mt76_wcid *mt7915_rx_get_wcid(struct mt7915_dev *dev,
+ 	struct mt7915_sta *sta;
+ 	struct mt76_wcid *wcid;
+ 
+-	if (idx >= ARRAY_SIZE(dev->mt76.wcid))
+-		return NULL;
+-
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (unicast || !wcid)
+ 		return wcid;
+ 
+@@ -917,7 +914,7 @@ mt7915_mac_tx_free(struct mt7915_dev *dev, void *data, int len)
+ 			u16 idx;
+ 
+ 			idx = FIELD_GET(MT_TX_FREE_WLAN_ID, info);
+-			wcid = rcu_dereference(dev->mt76.wcid[idx]);
++			wcid = mt76_wcid_ptr(dev, idx);
+ 			sta = wcid_to_sta(wcid);
+ 			if (!sta)
+ 				continue;
+@@ -1013,12 +1010,9 @@ static void mt7915_mac_add_txs(struct mt7915_dev *dev, void *data)
+ 	if (pid < MT_PACKET_ID_WED)
+ 		return;
+ 
+-	if (wcidx >= mt7915_wtbl_size(dev))
+-		return;
+-
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[wcidx]);
++	wcid = mt76_wcid_ptr(dev, wcidx);
+ 	if (!wcid)
+ 		goto out;
+ 
+diff --git a/mt7915/mcu.c b/mt7915/mcu.c
+index cf948628e..2928e75b2 100644
+--- a/mt7915/mcu.c
++++ b/mt7915/mcu.c
+@@ -3996,7 +3996,7 @@ int mt7915_mcu_wed_wa_tx_stats(struct mt7915_dev *dev, u16 wlan_idx)
+ 
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[wlan_idx]);
++	wcid = mt76_wcid_ptr(dev, wlan_idx);
+ 	if (wcid)
+ 		wcid->stats.tx_packets += le32_to_cpu(res->tx_packets);
+ 	else
+diff --git a/mt7915/mmio.c b/mt7915/mmio.c
+index 9c4d5cea0..4a82f8e4c 100644
+--- a/mt7915/mmio.c
++++ b/mt7915/mmio.c
+@@ -587,12 +587,9 @@ static void mt7915_mmio_wed_update_rx_stats(struct mtk_wed_device *wed,
+ 
+ 	dev = container_of(wed, struct mt7915_dev, mt76.mmio.wed);
+ 
+-	if (idx >= mt7915_wtbl_size(dev))
+-		return;
+-
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (wcid) {
+ 		wcid->stats.rx_bytes += le32_to_cpu(stats->rx_byte_cnt);
+ 		wcid->stats.rx_packets += le32_to_cpu(stats->rx_pkt_cnt);
+diff --git a/mt7921/mac.c b/mt7921/mac.c
+index 5dd57de59..f1f76506b 100644
+--- a/mt7921/mac.c
++++ b/mt7921/mac.c
+@@ -465,7 +465,7 @@ void mt7921_mac_add_txs(struct mt792x_dev *dev, void *data)
+ 
+ 	rcu_read_lock();
+ 
+-	wcid = rcu_dereference(dev->mt76.wcid[wcidx]);
++	wcid = mt76_wcid_ptr(dev, wcidx);
+ 	if (!wcid)
+ 		goto out;
+ 
+@@ -516,7 +516,7 @@ static void mt7921_mac_tx_free(struct mt792x_dev *dev, void *data, int len)
+ 
+ 			count++;
+ 			idx = FIELD_GET(MT_TX_FREE_WLAN_ID, info);
+-			wcid = rcu_dereference(dev->mt76.wcid[idx]);
++			wcid = mt76_wcid_ptr(dev, idx);
+ 			sta = wcid_to_sta(wcid);
+ 			if (!sta)
+ 				continue;
+@@ -816,7 +816,7 @@ void mt7921_usb_sdio_tx_complete_skb(struct mt76_dev *mdev,
+ 	u16 idx;
+ 
+ 	idx = le32_get_bits(txwi[1], MT_TXD1_WLAN_IDX);
+-	wcid = rcu_dereference(mdev->wcid[idx]);
++	wcid = __mt76_wcid_ptr(mdev, idx);
+ 	sta = wcid_to_sta(wcid);
+ 
+ 	if (sta && likely(e->skb->protocol != cpu_to_be16(ETH_P_PAE)))
+diff --git a/mt792x_mac.c b/mt792x_mac.c
+index 05978d9c7..3f1d9ba49 100644
+--- a/mt792x_mac.c
++++ b/mt792x_mac.c
+@@ -142,10 +142,7 @@ struct mt76_wcid *mt792x_rx_get_wcid(struct mt792x_dev *dev, u16 idx,
+ 	struct mt792x_sta *sta;
+ 	struct mt76_wcid *wcid;
+ 
+-	if (idx >= ARRAY_SIZE(dev->mt76.wcid))
+-		return NULL;
+-
+-	wcid = rcu_dereference(dev->mt76.wcid[idx]);
++	wcid = mt76_wcid_ptr(dev, idx);
+ 	if (unicast || !wcid)
+ 		return wcid;
+ 
+diff --git a/tx.c b/tx.c
+index dc9bf2fff..e6cf16706 100644
+--- a/tx.c
++++ b/tx.c
+@@ -64,7 +64,7 @@ mt76_tx_status_unlock(struct mt76_dev *dev, struct sk_buff_head *list)
+ 		struct mt76_tx_cb *cb = mt76_tx_skb_cb(skb);
+ 		struct mt76_wcid *wcid;
+ 
+-		wcid = rcu_dereference(dev->wcid[cb->wcid]);
++		wcid = __mt76_wcid_ptr(dev, cb->wcid);
+ 		if (wcid) {
+ 			status.sta = wcid_to_sta(wcid);
+ 			if (status.sta && (wcid->rate.flags || wcid->rate.legacy)) {
+@@ -251,9 +251,7 @@ void __mt76_tx_complete_skb(struct mt76_dev *dev, u16 wcid_idx, struct sk_buff *
+ 
+ 	rcu_read_lock();
+ 
+-	if (wcid_idx < ARRAY_SIZE(dev->wcid))
+-		wcid = rcu_dereference(dev->wcid[wcid_idx]);
+-
++	wcid = __mt76_wcid_ptr(dev, wcid_idx);
+ 	mt76_tx_check_non_aql(dev, wcid, skb);
+ 
+ #ifdef CONFIG_NL80211_TESTMODE
+@@ -538,7 +536,7 @@ mt76_txq_schedule_list(struct mt76_phy *phy, enum mt76_txq_id qid)
+ 			break;
+ 
+ 		mtxq = (struct mt76_txq *)txq->drv_priv;
+-		wcid = rcu_dereference(dev->wcid[mtxq->wcid]);
++		wcid = __mt76_wcid_ptr(dev, mtxq->wcid);
+ 		if (!wcid || test_bit(MT_WCID_FLAG_PS, &wcid->flags))
+ 			continue;
+ 
+diff --git a/util.c b/util.c
+index 95b3dc96e..97249ebb4 100644
+--- a/util.c
++++ b/util.c
+@@ -83,7 +83,7 @@ int mt76_get_min_avg_rssi(struct mt76_dev *dev, u8 phy_idx)
+ 			if (!!(phy_mask & 1) != ext_phy)
+ 				continue;
+ 
+-			wcid = rcu_dereference(dev->wcid[j]);
++			wcid = __mt76_wcid_ptr(dev, j);
+ 			if (!wcid)
+ 				continue;
+ 
-- 
2.46.2.windows.1

