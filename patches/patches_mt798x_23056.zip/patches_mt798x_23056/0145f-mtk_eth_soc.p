diff --git a/target/linux/generic/backport-5.15/999-mtk_eth_soc.patch b/target/linux/generic/backport-5.15/999-mtk_eth_soc.patch
new file mode 100644
index 0000000..70112d4
--- /dev/null
+++ b/target/linux/generic/backport-5.15/999-mtk_eth_soc.patch
@@ -0,0 +1,43 @@
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.c b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+index baf606b..29ce422 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -2038,7 +2038,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 			if (ret != XDP_PASS)
+ 				goto skip_rx;
+ 
+-			skb = build_skb(data, PAGE_SIZE);
++			skb = napi_build_skb(data, PAGE_SIZE);
+ 			if (unlikely(!skb)) {
+ 				page_pool_put_full_page(ring->page_pool,
+ 							page, true);
+@@ -2076,7 +2076,7 @@ static int mtk_poll_rx(struct napi_struct *napi, int budget,
+ 			dma_unmap_single(eth->dma_dev, ((u64)trxd.rxd1 | addr64),
+ 					 ring->buf_size, DMA_FROM_DEVICE);
+ 
+-			skb = build_skb(data, ring->frag_size);
++			skb = napi_build_skb(data, ring->frag_size);
+ 			if (unlikely(!skb)) {
+ 				netdev->stats.rx_dropped++;
+ 				skb_free_frag(data);
+@@ -2603,14 +2603,14 @@ static int mtk_rx_alloc(struct mtk_eth *eth, int ring_no, int rx_flag)
+ 		rxd = ring->dma + i * eth->soc->rx.desc_size;
+ 		if (ring->page_pool) {
+ 			data = mtk_page_pool_get_buff(ring->page_pool,
+-						      &dma_addr, GFP_KERNEL);
++						      &dma_addr, GFP_ATOMIC);
+ 			if (!data)
+ 				return -ENOMEM;
+ 		} else {
+ 			if (ring->frag_size <= PAGE_SIZE)
+-				data = netdev_alloc_frag(ring->frag_size);
++				data = napi_alloc_frag(ring->frag_size);
+ 			else
+-				data = mtk_max_lro_buf_alloc(GFP_KERNEL);
++				data = mtk_max_lro_buf_alloc(GFP_ATOMIC);
+ 
+ 			if (!data)
+ 				return -ENOMEM;
+-- 
+2.38.1
+
-- 
2.38.1

