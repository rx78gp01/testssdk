diff --git a/package/kernel/mt76/patches/9999-mt76_16.patch b/package/kernel/mt76/patches/9999-mt76_16.patch
new file mode 100644
index 0000000..5b17344
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_16.patch
@@ -0,0 +1,32 @@
+From e35e4f8fcf8a632abacc19269c5cbc66097e7391 Mon Sep 17 00:00:00 2001
+From: Abdun Nihaal <abdun.nihaal@gmail.com>
+Date: Wed, 9 Jul 2025 20:25:30 +0530
+Subject: [PATCH] wifi: mt76: fix potential memory leak in mt76_wmac_probe()
+
+In mt76_wmac_probe(), when the mt76_alloc_device() call succeeds, memory
+is allocated for both struct ieee80211_hw and a workqueue. However, on
+the error path, the workqueue is not freed. Fix that by calling
+mt76_free_device() on the error path.
+
+Fixes: c8846e101502 ("mt76: add driver for MT7603E and MT7628/7688")
+Signed-off-by: Abdun Nihaal <abdun.nihaal@gmail.com>
+Reviewed-by: Jiri Slaby <jirislaby@kernel.org>
+Link: https://patch.msgid.link/20250709145532.41246-1-abdun.nihaal@gmail.com
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7603/soc.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/mt7603/soc.c b/mt7603/soc.c
+index 0587fce65..a14eb90bd 100644
+--- a/mt7603/soc.c
++++ b/mt7603/soc.c
+@@ -48,7 +48,7 @@ mt76_wmac_probe(struct platform_device *pdev)
+ 
+ 	return 0;
+ error:
+-	ieee80211_free_hw(mt76_hw(dev));
++	mt76_free_device(mdev);
+ 	return ret;
+ }
+ 
diff --git a/package/kernel/mt76/patches/9999-mt76_17.patch b/package/kernel/mt76/patches/9999-mt76_17.patch
new file mode 100644
index 0000000..b39370a
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_17.patch
@@ -0,0 +1,38 @@
+From 630e166c958d25ba59fdc5f30e8859c6f16d0280 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Fri, 8 Aug 2025 16:01:36 +0200
+Subject: [PATCH] wifi: mt76: prevent non-offchannel mgmt tx during scan/roc
+
+Only put probe request packets in the offchannel queue if
+IEEE80211_TX_CTRL_DONT_USE_RATE_MASK is set and IEEE80211_TX_CTL_TX_OFFCHAN
+is unset.
+
+Fixes: 0b3be9d1d34e ("wifi: mt76: add separate tx scheduling queue for off-channel tx")
+Reported-by: Chad Monroe <chad.monroe@adtran.com>
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ tx.c | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/tx.c b/tx.c
+index e6cf16706..03b042fdf 100644
+--- a/tx.c
++++ b/tx.c
+@@ -332,6 +332,7 @@ mt76_tx(struct mt76_phy *phy, struct ieee80211_sta *sta,
+ 	struct mt76_wcid *wcid, struct sk_buff *skb)
+ {
+ 	struct ieee80211_tx_info *info = IEEE80211_SKB_CB(skb);
++	struct ieee80211_hdr *hdr = (void *)skb->data;
+ 	struct sk_buff_head *head;
+ 
+ 	if (mt76_testmode_enabled(phy)) {
+@@ -349,7 +350,8 @@ mt76_tx(struct mt76_phy *phy, struct ieee80211_sta *sta,
+ 	info->hw_queue |= FIELD_PREP(MT_TX_HW_QUEUE_PHY, phy->band_idx);
+ 
+ 	if ((info->flags & IEEE80211_TX_CTL_TX_OFFCHAN) ||
+-	    (info->control.flags & IEEE80211_TX_CTRL_DONT_USE_RATE_MASK))
++	    ((info->control.flags & IEEE80211_TX_CTRL_DONT_USE_RATE_MASK) &&
++	     ieee80211_is_probe_req(hdr->frame_control)))
+ 		head = &wcid->tx_offchannel;
+ 	else
+ 		head = &wcid->tx_pending;
-- 
2.46.2.windows.1

