diff --git a/target/linux/generic/backport-5.15/966-mtk_eth_soc.patch b/target/linux/generic/backport-5.15/966-mtk_eth_soc.patch
new file mode 100644
index 0000000..d065233
--- /dev/null
+++ b/target/linux/generic/backport-5.15/966-mtk_eth_soc.patch
@@ -0,0 +1,37 @@
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.c b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+index d4c0ea8..0d486e1 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -5016,8 +5016,8 @@ static const struct mtk_soc_data mt7621_data = {
+ 		.dma_l4_valid = RX_DMA_L4_VALID,
+-		.dma_size = MTK_DMA_SIZE(2K),
++		.dma_size = MTK_DMA_SIZE(512),
+ 		.dma_max_len = MTK_TX_DMA_BUF_LEN,
+ 		.dma_len_offset = 16,
+ 	},
+ };
+ 
+ static const struct mtk_soc_data mt7622_data = {
+@@ -5128,8 +5128,8 @@ static const struct mtk_soc_data mt7981_data = {
+ 		.dma_l4_valid = RX_DMA_L4_VALID_V2,
+ 		.dma_max_len = MTK_TX_DMA_BUF_LEN,
+ 		.dma_len_offset = 16,
+-		.dma_size = MTK_DMA_SIZE(2K),
++		.dma_size = MTK_DMA_SIZE(512),
+ 	},
+ };
+ 
+ static const struct mtk_soc_data mt7986_data = {
+@@ -5157,8 +5157,8 @@ static const struct mtk_soc_data mt7986_data = {
+ 		.dma_l4_valid = RX_DMA_L4_VALID_V2,
+ 		.dma_max_len = MTK_TX_DMA_BUF_LEN,
+ 		.dma_len_offset = 16,
+-		.dma_size = MTK_DMA_SIZE(2K),
++		.dma_size = MTK_DMA_SIZE(512),
+ 	},
+ };
+ 
+ static const struct mtk_soc_data mt7988_data = {
+-- 
+2.38.1
+
-- 
