diff --git a/feeds/packages/net/openvpn/patches/201-e83c63f58135913bb2ca2f4345da8cd77098474b.patch b/feeds/packages/net/openvpn/patches/201-e83c63f58135913bb2ca2f4345da8cd77098474b.patch
new file mode 100644
index 0000000..1c714ea
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/201-e83c63f58135913bb2ca2f4345da8cd77098474b.patch
@@ -0,0 +1,47 @@
+From e83c63f58135913bb2ca2f4345da8cd77098474b Mon Sep 17 00:00:00 2001
+From: Steffan Karger <steffan@karger.me>
+Date: Sun, 26 Oct 2025 15:35:14 +0100
+Subject: [PATCH] ssl_mbedtls: fix missing perf_pop() call
+
+This was triggered by a bug report submitted by Joshua Rogers, who
+used ZeroPath to discover we missed a perf_pop() call in one of the
+error paths of ssl_mbedtls.c.
+
+Move an existing perf_pop call a bit upwards to fix that.
+
+The perf code is always disabled by ENABLE_PERFORMANCE_METRICS being
+commented out in perf.h. There is no configure flag. None of the active
+developers remembers using it and the git log shows no actual code changes
+since at least the project structure overhaul of 2012. So this has no
+real-world impact.
+
+Change-Id: I5b6881dc73358c8d1249ee2ceb968ede295105b0
+Signed-off-by: Steffan Karger <steffan@karger.me>
+Acked-by: Gert Doering <gert@greenie.muc.de>
+Gerrit URL: https://gerrit.openvpn.net/c/openvpn/+/1305
+Message-Id: <20251026143521.13291-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg33870.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+---
+ src/openvpn/ssl_mbedtls.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/src/openvpn/ssl_mbedtls.c b/src/openvpn/ssl_mbedtls.c
+index 8fb69c305b5..2862989b780 100644
+--- a/src/openvpn/ssl_mbedtls.c
++++ b/src/openvpn/ssl_mbedtls.c
+@@ -1489,13 +1489,13 @@ key_state_read_plaintext(struct key_state_ssl *ks, struct buffer *buf)
+     /* Error during read, check for retry error */
+     if (retval < 0)
+     {
++        perf_pop();
+         if (MBEDTLS_ERR_SSL_WANT_WRITE == retval || MBEDTLS_ERR_SSL_WANT_READ == retval)
+         {
+             return 0;
+         }
+         mbed_log_err(D_TLS_ERRORS, retval, "TLS_ERROR: read tls_read_plaintext error");
+         buf->len = 0;
+-        perf_pop();
+         return -1;
+     }
+     /* Nothing read, try again */
diff --git a/feeds/packages/net/openvpn/patches/202-12a2e88b9e9fc7b0e6f8fce0125b5272980ec51b.patch b/feeds/packages/net/openvpn/patches/202-12a2e88b9e9fc7b0e6f8fce0125b5272980ec51b.patch
new file mode 100644
index 0000000..830bf7e
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/202-12a2e88b9e9fc7b0e6f8fce0125b5272980ec51b.patch
@@ -0,0 +1,77 @@
+From 12a2e88b9e9fc7b0e6f8fce0125b5272980ec51b Mon Sep 17 00:00:00 2001
+From: Antonio Quartulli <antonio@mandelbit.com>
+Date: Tue, 28 Oct 2025 17:28:38 +0100
+Subject: [PATCH] sitnl: set FD_CLOEXEC on socket to prevent abuse
+
+Since OpenVPN spawns various child processes, it is important
+that sockets are closed after calling exec.
+
+The sitnl socket didn't have the right flag set, resulting
+in it surviving in, for example, connect/disconnect scripts
+and giving the latter a chance to abuse the socket.
+
+Ensure this doesn't happen by setting FD_CLOEXEC on
+this socket right after creation.
+
+Reported-by: Joshua Rogers <contact@joshua.hu>
+Found-by: ZeroPath (https://zeropath.com/)
+Change-Id: I54845bf4dd17d06cfc3b402f188795f74f4b1d3e
+Signed-off-by: Antonio Quartulli <antonio@mandelbit.com>
+Acked-by: Gert Doering <gert@greenie.muc.de>
+Gerrit URL: https://gerrit.openvpn.net/c/openvpn/+/1314
+Message-Id: <20251028162843.18189-1-gert@greenie.muc.de>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg33952.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit b9b5470521294209146c7253a97012d399978d72)
+---
+ CMakeLists.txt                       | 1 +
+ src/openvpn/networking_sitnl.c       | 4 ++++
+ tests/unit_tests/openvpn/Makefile.am | 1 +
+ 3 files changed, 6 insertions(+)
+
+diff --git a/CMakeLists.txt b/CMakeLists.txt
+index a91cd32a2e5..f7cb5a7ccc8 100644
+--- a/CMakeLists.txt
++++ b/CMakeLists.txt
+@@ -711,6 +711,7 @@ if (BUILD_TESTING)
+             src/openvpn/crypto_mbedtls.c
+             src/openvpn/crypto_openssl.c
+             src/openvpn/crypto.c
++            src/openvpn/fdmisc.c
+             src/openvpn/otime.c
+             src/openvpn/packet_id.c
+             )
+diff --git a/src/openvpn/networking_sitnl.c b/src/openvpn/networking_sitnl.c
+index 10c38256293..c08f2e98ef0 100644
+--- a/src/openvpn/networking_sitnl.c
++++ b/src/openvpn/networking_sitnl.c
+@@ -28,6 +28,7 @@
+ 
+ #include "dco.h"
+ #include "errlevel.h"
++#include "fdmisc.h"
+ #include "buffer.h"
+ #include "misc.h"
+ #include "networking.h"
+@@ -166,6 +167,9 @@ sitnl_socket(void)
+         return fd;
+     }
+ 
++    /* set close on exec to avoid child processes access the socket */
++    set_cloexec(fd);
++
+     if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf)) < 0)
+     {
+         msg(M_WARN | M_ERRNO, "%s: SO_SNDBUF", __func__);
+diff --git a/tests/unit_tests/openvpn/Makefile.am b/tests/unit_tests/openvpn/Makefile.am
+index dd3985d613a..38a7ab482b9 100644
+--- a/tests/unit_tests/openvpn/Makefile.am
++++ b/tests/unit_tests/openvpn/Makefile.am
+@@ -130,6 +130,7 @@ networking_testdriver_SOURCES = test_networking.c mock_msg.c \
+ 	$(top_srcdir)/src/openvpn/crypto.c \
+ 	$(top_srcdir)/src/openvpn/crypto_mbedtls.c \
+ 	$(top_srcdir)/src/openvpn/crypto_openssl.c \
++	$(top_srcdir)/src/openvpn/fdmisc.c \
+ 	$(top_srcdir)/src/openvpn/otime.c \
+ 	$(top_srcdir)/src/openvpn/packet_id.c \
+ 	$(top_srcdir)/src/openvpn/platform.c
diff --git a/feeds/packages/net/openvpn/patches/203-2aa8550d44440a039da509a7afebfeacf0886a32.patch b/feeds/packages/net/openvpn/patches/203-2aa8550d44440a039da509a7afebfeacf0886a32.patch
new file mode 100644
index 0000000..73e995f
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/203-2aa8550d44440a039da509a7afebfeacf0886a32.patch
@@ -0,0 +1,37 @@
+From 2aa8550d44440a039da509a7afebfeacf0886a32 Mon Sep 17 00:00:00 2001
+From: Joshua Rogers <MegaManSec@users.noreply.github.com>
+Date: Wed, 22 Oct 2025 01:20:52 +0800
+Subject: [PATCH] tcp: apply CLOEXEC to accepted socket, not listener
+
+The accept path calls set_cloexec(sd) after accept(). That re-flags the
+listening socket, which is already CLOEXEC from create_socket_tcp(), and
+leaves new_sd inheritable. As a result, client-connect and auth scripts
+spawned after accept can inherit the connected socket and read or write
+the raw TCP stream. This defeats the stated intent to prevent scripts from
+accessing the client socket.
+
+This bug was found using ZeroPath.
+
+Signed-off-by: Joshua Rogers <MegaManSec@users.noreply.github.com>
+Acked-by: Gert Doering <gert@greenie.muc.de>
+Message-Id: <-MNw5Hu8h0rHV18x36ISt7V0UHchIO4i-JoAeV_wlxS1AmDIAe7YVYNput3_r2hiu3HhwxkhGyUhv4-iH_E7mf7nGjvocmGXlDq7Tjly5cE=@joshua.hu>
+URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg33823.html
+Signed-off-by: Gert Doering <gert@greenie.muc.de>
+(cherry picked from commit c0d96fd8732bd903ab390bb5047a13880cdcac9b)
+---
+ src/openvpn/socket.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/src/openvpn/socket.c b/src/openvpn/socket.c
+index 2eb2e747285..ea06bb18b47 100644
+--- a/src/openvpn/socket.c
++++ b/src/openvpn/socket.c
+@@ -1270,7 +1270,7 @@ socket_do_accept(socket_descriptor_t sd,
+     {
+         /* set socket file descriptor to not pass across execs, so that
+          * scripts don't have access to it */
+-        set_cloexec(sd);
++        set_cloexec(new_sd);
+     }
+     return new_sd;
+ }
-- 
2.46.2.windows.1

