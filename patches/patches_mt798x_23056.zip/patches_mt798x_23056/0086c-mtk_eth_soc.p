diff --git a/target/linux/mediatek/patches-5.15/999-mtk_eth_soc.patch b/target/linux/mediatek/patches-5.15/999-mtk_eth_soc.patch
new file mode 100644
index 0000000..696413b
--- /dev/null
+++ b/target/linux/mediatek/patches-5.15/999-mtk_eth_soc.patch
@@ -0,0 +1,21 @@
+diff --git a/drivers/net/ethernet/mediatek/mtk_eth_soc.c b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+index ea3ff92..6b55c3d 100644
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -2738,13 +2738,13 @@
+ 		if (ring->page_pool) {
+ 			data = mtk_page_pool_get_buff(ring->page_pool,
+-						      &dma_addr, GFP_KERNEL);
++						      &dma_addr, GFP_ATOMIC);
+ 			if (!data)
+ 				return -ENOMEM;
+ 		} else {
+ 			if (ring->frag_size <= PAGE_SIZE)
+-				data = netdev_alloc_frag(ring->frag_size);
++				data = napi_alloc_frag(ring->frag_size);
+ 			else
+-				data = mtk_max_lro_buf_alloc(GFP_KERNEL);
++				data = mtk_max_lro_buf_alloc(GFP_ATOMIC);
+ 
+ 			if (!data)
+ 				return -ENOMEM;
\ No newline at end of file
-- 
2.38.1.windows.1

