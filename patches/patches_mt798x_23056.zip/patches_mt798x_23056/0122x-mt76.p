diff --git a/package/kernel/mt76/patches/9999-mt76_01.patch b/package/kernel/mt76/patches/9999-mt76_01.patch
new file mode 100644
index 0000000..375f6c7
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_01.patch
@@ -0,0 +1,110 @@
+From dfdb8e9757188d9c973dbbbc0afe1fedec748f91 Mon Sep 17 00:00:00 2001
+From: Nikita Zhandarovich <n.zhandarovich@fintech.ru>
+Date: Tue, 14 Jan 2025 07:44:41 -0800
+Subject: [PATCH] wifi: mt76: mt7915: fix possible integer overflows in
+ mt7915_muru_stats_show()
+
+Assuming sums of values stored in variables such as sub_total_cnt
+and total_ppdu_cnt are big enough to warrant their u64 type, it
+makes sense to ensure that their calculation takes into account
+possible integer overflow issues.
+
+Play it safe and fix the problem by casting right hand expressions
+to u64 as well. Also, slightly adjust tabulation.
+
+Found by Linux Verification Center (linuxtesting.org) with static
+analysis tool SVACE.
+
+Fixes: 1966a5078f2d ("mt76: mt7915: add mu-mimo and ofdma debugfs knobs")
+Signed-off-by: Nikita Zhandarovich <n.zhandarovich@fintech.ru>
+Link: https://patch.msgid.link/20250114154441.16920-1-n.zhandarovich@fintech.ru
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7915/debugfs.c | 45 +++++++++++++++++++++++----------------------
+ 1 file changed, 23 insertions(+), 22 deletions(-)
+
+diff --git a/mt7915/debugfs.c b/mt7915/debugfs.c
+index 578013884..4fec7d000 100644
+--- a/mt7915/debugfs.c
++++ b/mt7915/debugfs.c
+@@ -303,9 +303,9 @@ static int mt7915_muru_stats_show(struct seq_file *file, void *data)
+ 		   phy->mib.dl_vht_3mu_cnt,
+ 		   phy->mib.dl_vht_4mu_cnt);
+ 
+-	sub_total_cnt = phy->mib.dl_vht_2mu_cnt +
+-			phy->mib.dl_vht_3mu_cnt +
+-			phy->mib.dl_vht_4mu_cnt;
++	sub_total_cnt = (u64)phy->mib.dl_vht_2mu_cnt +
++			     phy->mib.dl_vht_3mu_cnt +
++			     phy->mib.dl_vht_4mu_cnt;
+ 
+ 	seq_printf(file, "\nTotal non-HE MU-MIMO DL PPDU count: %lld",
+ 		   sub_total_cnt);
+@@ -353,26 +353,27 @@ static int mt7915_muru_stats_show(struct seq_file *file, void *data)
+ 		   phy->mib.dl_he_9to16ru_cnt,
+ 		   phy->mib.dl_he_gtr16ru_cnt);
+ 
+-	sub_total_cnt = phy->mib.dl_he_2mu_cnt +
+-			phy->mib.dl_he_3mu_cnt +
+-			phy->mib.dl_he_4mu_cnt;
++	sub_total_cnt = (u64)phy->mib.dl_he_2mu_cnt +
++			     phy->mib.dl_he_3mu_cnt +
++			     phy->mib.dl_he_4mu_cnt;
+ 	total_ppdu_cnt = sub_total_cnt;
+ 
+ 	seq_printf(file, "\nTotal HE MU-MIMO DL PPDU count: %lld",
+ 		   sub_total_cnt);
+ 
+-	sub_total_cnt = phy->mib.dl_he_2ru_cnt +
+-			phy->mib.dl_he_3ru_cnt +
+-			phy->mib.dl_he_4ru_cnt +
+-			phy->mib.dl_he_5to8ru_cnt +
+-			phy->mib.dl_he_9to16ru_cnt +
+-			phy->mib.dl_he_gtr16ru_cnt;
++	sub_total_cnt = (u64)phy->mib.dl_he_2ru_cnt +
++			     phy->mib.dl_he_3ru_cnt +
++			     phy->mib.dl_he_4ru_cnt +
++			     phy->mib.dl_he_5to8ru_cnt +
++			     phy->mib.dl_he_9to16ru_cnt +
++			     phy->mib.dl_he_gtr16ru_cnt;
+ 	total_ppdu_cnt += sub_total_cnt;
+ 
+ 	seq_printf(file, "\nTotal HE OFDMA DL PPDU count: %lld",
+ 		   sub_total_cnt);
+ 
+-	total_ppdu_cnt += phy->mib.dl_he_su_cnt + phy->mib.dl_he_ext_su_cnt;
++	total_ppdu_cnt += (u64)phy->mib.dl_he_su_cnt +
++			       phy->mib.dl_he_ext_su_cnt;
+ 
+ 	seq_printf(file, "\nAll HE DL PPDU count: %lld", total_ppdu_cnt);
+ 
+@@ -404,20 +405,20 @@ static int mt7915_muru_stats_show(struct seq_file *file, void *data)
+ 		   phy->mib.ul_hetrig_9to16ru_cnt,
+ 		   phy->mib.ul_hetrig_gtr16ru_cnt);
+ 
+-	sub_total_cnt = phy->mib.ul_hetrig_2mu_cnt +
+-			phy->mib.ul_hetrig_3mu_cnt +
+-			phy->mib.ul_hetrig_4mu_cnt;
++	sub_total_cnt = (u64)phy->mib.ul_hetrig_2mu_cnt +
++			     phy->mib.ul_hetrig_3mu_cnt +
++			     phy->mib.ul_hetrig_4mu_cnt;
+ 	total_ppdu_cnt = sub_total_cnt;
+ 
+ 	seq_printf(file, "\nTotal HE MU-MIMO UL TB PPDU count: %lld",
+ 		   sub_total_cnt);
+ 
+-	sub_total_cnt = phy->mib.ul_hetrig_2ru_cnt +
+-			phy->mib.ul_hetrig_3ru_cnt +
+-			phy->mib.ul_hetrig_4ru_cnt +
+-			phy->mib.ul_hetrig_5to8ru_cnt +
+-			phy->mib.ul_hetrig_9to16ru_cnt +
+-			phy->mib.ul_hetrig_gtr16ru_cnt;
++	sub_total_cnt = (u64)phy->mib.ul_hetrig_2ru_cnt +
++			     phy->mib.ul_hetrig_3ru_cnt +
++			     phy->mib.ul_hetrig_4ru_cnt +
++			     phy->mib.ul_hetrig_5to8ru_cnt +
++			     phy->mib.ul_hetrig_9to16ru_cnt +
++			     phy->mib.ul_hetrig_gtr16ru_cnt;
+ 	total_ppdu_cnt += sub_total_cnt;
+ 
+ 	seq_printf(file, "\nTotal HE OFDMA UL TB PPDU count: %lld",
diff --git a/package/kernel/mt76/patches/9999-mt76_02.patch b/package/kernel/mt76/patches/9999-mt76_02.patch
new file mode 100644
index 0000000..c6d14d5
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_02.patch
@@ -0,0 +1,32 @@
+From d6a197dbc9a20b9606a7ebc8d7effff35d2b6c25 Mon Sep 17 00:00:00 2001
+From: Haoxiang Li <haoxiang_li2024@163.com>
+Date: Wed, 19 Feb 2025 11:36:45 +0800
+Subject: [PATCH] wifi: mt76: Add check for devm_kstrdup()
+
+Add check for the return value of devm_kstrdup() in
+mt76_get_of_data_from_mtd() to catch potential exception.
+
+Fixes: e7a6a044f9b9 ("mt76: testmode: move mtd part to mt76_dev")
+Cc: stable@vger.kernel.org
+Signed-off-by: Haoxiang Li <haoxiang_li2024@163.com>
+Link: https://patch.msgid.link/20250219033645.2594753-1-haoxiang_li2024@163.com
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ eeprom.c | 4 ++++
+ 1 file changed, 4 insertions(+)
+
+diff --git a/eeprom.c b/eeprom.c
+index ab4fab110..30b744a1c 100644
+--- a/eeprom.c
++++ b/eeprom.c
+@@ -95,6 +95,10 @@ int mt76_get_of_data_from_mtd(struct mt76_dev *dev, void *eep, int offset, int l
+ 
+ #ifdef CONFIG_NL80211_TESTMODE
+ 	dev->test_mtd.name = devm_kstrdup(dev->dev, part, GFP_KERNEL);
++	if (!dev->test_mtd.name) {
++		ret = -ENOMEM;
++		goto out_put_node;
++	}
+ 	dev->test_mtd.offset = offset;
+ #endif
+ 
diff --git a/package/kernel/mt76/patches/9999-mt76_03.patch b/package/kernel/mt76/patches/9999-mt76_03.patch
new file mode 100644
index 0000000..fc2a8ae
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_03.patch
@@ -0,0 +1,51 @@
+From f1180736425854be73113a5c19ecc690b49f0008 Mon Sep 17 00:00:00 2001
+From: Razvan Grigore <razvan.grigore@vampirebyte.ro>
+Date: Tue, 11 Feb 2025 08:12:43 +0000
+Subject: [PATCH] wifi: mt76: add mt76_get_power_bound helper function
+
+This will replace mt7915_get_power_bound function from b/mt7915/mcu.h,
+since we will need it also for mt7921 and mt7925
+
+Signed-off-by: Razvan Grigore <razvan.grigore@vampirebyte.ro>
+Link: https://patch.msgid.link/20250211081247.5892-2-razvan.grigore@vampirebyte.ro
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mac80211.c | 11 +++++++++++
+ mt76.h     |  2 ++
+ 2 files changed, 13 insertions(+)
+
+diff --git a/mac80211.c b/mac80211.c
+index 983b41bc2..b96e219a2 100644
+--- a/mac80211.c
++++ b/mac80211.c
+@@ -1689,6 +1689,17 @@ void mt76_wcid_add_poll(struct mt76_dev *dev, struct mt76_wcid *wcid)
+ }
+ EXPORT_SYMBOL_GPL(mt76_wcid_add_poll);
+ 
++s8 mt76_get_power_bound(struct mt76_phy *phy, s8 txpower)
++{
++	int n_chains = hweight16(phy->chainmask);
++
++	txpower = mt76_get_sar_power(phy, phy->chandef.chan, txpower * 2);
++	txpower -= mt76_tx_power_nss_delta(n_chains);
++
++	return txpower;
++}
++EXPORT_SYMBOL_GPL(mt76_get_power_bound);
++
+ int mt76_get_txpower(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
+ 		     int *dbm)
+ {
+diff --git a/mt76.h b/mt76.h
+index 5c463debf..a485fe9e0 100644
+--- a/mt76.h
++++ b/mt76.h
+@@ -1491,6 +1491,8 @@ void mt76_sta_pre_rcu_remove(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
+ 
+ int mt76_get_min_avg_rssi(struct mt76_dev *dev, u8 phy_idx);
+ 
++s8 mt76_get_power_bound(struct mt76_phy *phy, s8 txpower);
++
+ int mt76_get_txpower(struct ieee80211_hw *hw, struct ieee80211_vif *vif,
+ 		     int *dbm);
+ int mt76_init_sar_power(struct ieee80211_hw *hw,
diff --git a/package/kernel/mt76/patches/9999-mt76_04.patch b/package/kernel/mt76/patches/9999-mt76_04.patch
new file mode 100644
index 0000000..e63a248
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_04.patch
@@ -0,0 +1,83 @@
+From 43aaa62fbc551a943efc9a2bea7096f68d92d26d Mon Sep 17 00:00:00 2001
+From: Razvan Grigore <razvan.grigore@vampirebyte.ro>
+Date: Tue, 11 Feb 2025 08:12:46 +0000
+Subject: [PATCH] wifi: mt76: mt7915: cleanup mt7915_get_power_bound
+
+Refactor for making use of mt76_get_power_bound instead of the specific
+mt7915_get_power_bound, since we need this for other chipsets as well
+when calculating txpower
+
+Signed-off-by: Razvan Grigore <razvan.grigore@vampirebyte.ro>
+Link: https://patch.msgid.link/20250211081247.5892-5-razvan.grigore@vampirebyte.ro
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7915/debugfs.c |  8 ++++----
+ mt7915/mcu.c     |  4 ++--
+ mt7915/mcu.h     | 12 ------------
+ 3 files changed, 6 insertions(+), 18 deletions(-)
+
+diff --git a/mt7915/debugfs.c b/mt7915/debugfs.c
+index 4fec7d000..192e8eff9 100644
+--- a/mt7915/debugfs.c
++++ b/mt7915/debugfs.c
+@@ -1085,13 +1085,13 @@ mt7915_rate_txpower_set(struct file *file, const char __user *user_buf,
+ 		return -EINVAL;
+ 
+ 	if (pwr160)
+-		pwr160 = mt7915_get_power_bound(phy, pwr160);
++		pwr160 = mt76_get_power_bound(mphy, pwr160);
+ 	if (pwr80)
+-		pwr80 = mt7915_get_power_bound(phy, pwr80);
++		pwr80 = mt76_get_power_bound(mphy, pwr80);
+ 	if (pwr40)
+-		pwr40 = mt7915_get_power_bound(phy, pwr40);
++		pwr40 = mt76_get_power_bound(mphy, pwr40);
+ 	if (pwr20)
+-		pwr20 = mt7915_get_power_bound(phy, pwr20);
++		pwr20 = mt76_get_power_bound(mphy, pwr20);
+ 
+ 	if (pwr160 < 0 || pwr80 < 0 || pwr40 < 0 || pwr20 < 0)
+ 		return -EINVAL;
+diff --git a/mt7915/mcu.c b/mt7915/mcu.c
+index 9d790f234..3643c72bb 100644
+--- a/mt7915/mcu.c
++++ b/mt7915/mcu.c
+@@ -3323,7 +3323,7 @@ int mt7915_mcu_set_txpower_frame(struct mt7915_phy *phy,
+ 	if (ret)
+ 		return ret;
+ 
+-	txpower = mt7915_get_power_bound(phy, txpower);
++	txpower = mt76_get_power_bound(mphy, txpower);
+ 	if (txpower > mphy->txpower_cur || txpower < 0)
+ 		return -EINVAL;
+ 
+@@ -3373,7 +3373,7 @@ int mt7915_mcu_set_txpower_sku(struct mt7915_phy *phy)
+ 	int i, idx;
+ 	int tx_power;
+ 
+-	tx_power = mt7915_get_power_bound(phy, hw->conf.power_level);
++	tx_power = mt76_get_power_bound(mphy, hw->conf.power_level);
+ 	tx_power = mt76_get_rate_power_limits(mphy, mphy->chandef.chan,
+ 					      &limits_array, tx_power);
+ 	mphy->txpower_cur = tx_power;
+diff --git a/mt7915/mcu.h b/mt7915/mcu.h
+index 49476a418..092ed504a 100644
+--- a/mt7915/mcu.h
++++ b/mt7915/mcu.h
+@@ -515,16 +515,4 @@ enum {
+ 					 sizeof(struct bss_info_bmc_rate) +\
+ 					 sizeof(struct bss_info_ext_bss))
+ 
+-static inline s8
+-mt7915_get_power_bound(struct mt7915_phy *phy, s8 txpower)
+-{
+-	struct mt76_phy *mphy = phy->mt76;
+-	int n_chains = hweight16(mphy->chainmask);
+-
+-	txpower = mt76_get_sar_power(mphy, mphy->chandef.chan, txpower * 2);
+-	txpower -= mt76_tx_power_nss_delta(n_chains);
+-
+-	return txpower;
+-}
+-
+ #endif
diff --git a/package/kernel/mt76/patches/9999-mt76_05.patch b/package/kernel/mt76/patches/9999-mt76_05.patch
new file mode 100644
index 0000000..a9684ff
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_05.patch
@@ -0,0 +1,280 @@
+From 0ba7a69f8927303496e5df97fe86fd27382db94f Mon Sep 17 00:00:00 2001
+From: Jakub Kicinski <kuba@kernel.org>
+Date: Thu, 23 Jan 2025 19:18:41 -0800
+Subject: [PATCH] wifi: mt76: move napi_enable() from under BH
+
+mt76 does a lot of:
+
+  local_bh_disable();
+  napi_enable(...napi);
+  napi_schedule(...napi);
+  local_bh_enable();
+
+local_bh_disable() is not a real lock, its most likely taken
+because napi_schedule() requires that we invoke softirqs at
+some point. napi_enable() needs to take a mutex, so move it
+from under the BH protection.
+
+Fixes: 413f0271f396 ("net: protect NAPI enablement with netdev_lock()")
+Reported-by: Dan Carpenter <dan.carpenter@linaro.org>
+Link: https://lore.kernel.org/dcfd56bc-de32-4b11-9e19-d8bd1543745d@stanley.mountain
+Reviewed-by: Eric Dumazet <edumazet@google.com>
+Link: https://patch.msgid.link/20250124031841.1179756-8-kuba@kernel.org
+Signed-off-by: Jakub Kicinski <kuba@kernel.org>
+---
+ mt7603/mac.c     |  9 ++++-----
+ mt7615/pci.c     |  8 ++++++--
+ mt7615/pci_mac.c |  8 +++++---
+ mt76x0/pci.c     |  8 +++++---
+ mt76x02_mmio.c   |  8 +++++---
+ mt76x2/pci.c     |  7 +++++--
+ mt7915/mac.c     | 17 +++++++++++++----
+ mt7921/pci.c     |  7 +++++--
+ mt7921/pci_mac.c |  7 +++++--
+ mt7925/pci.c     |  7 +++++--
+ mt7925/pci_mac.c |  7 +++++--
+ mt7996/mac.c     | 12 ++++++------
+ 12 files changed, 69 insertions(+), 36 deletions(-)
+
+diff --git a/mt7603/mac.c b/mt7603/mac.c
+index a259f4dd9..413973d05 100644
+--- a/mt7603/mac.c
++++ b/mt7603/mac.c
+@@ -1479,14 +1479,13 @@ static void mt7603_mac_watchdog_reset(struct mt7603_dev *dev)
+ 	tasklet_enable(&dev->mt76.pre_tbtt_tasklet);
+ 	mt7603_beacon_set_timer(dev, -1, beacon_int);
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
+-	napi_schedule(&dev->mt76.tx_napi);
+-
+ 	napi_enable(&dev->mt76.napi[0]);
+-	napi_schedule(&dev->mt76.napi[0]);
+-
+ 	napi_enable(&dev->mt76.napi[1]);
++
++	local_bh_disable();
++	napi_schedule(&dev->mt76.tx_napi);
++	napi_schedule(&dev->mt76.napi[0]);
+ 	napi_schedule(&dev->mt76.napi[1]);
+ 	local_bh_enable();
+ 
+diff --git a/mt7615/pci.c b/mt7615/pci.c
+index 9a278589d..68010e27f 100644
+--- a/mt7615/pci.c
++++ b/mt7615/pci.c
+@@ -164,12 +164,16 @@ static int mt7615_pci_resume(struct pci_dev *pdev)
+ 		dev_err(mdev->dev, "PDMA engine must be reinitialized\n");
+ 
+ 	mt76_worker_enable(&mdev->tx_worker);
+-	local_bh_disable();
++
+ 	mt76_for_each_q_rx(mdev, i) {
+ 		napi_enable(&mdev->napi[i]);
+-		napi_schedule(&mdev->napi[i]);
+ 	}
+ 	napi_enable(&mdev->tx_napi);
++
++	local_bh_disable();
++	mt76_for_each_q_rx(mdev, i) {
++		napi_schedule(&mdev->napi[i]);
++	}
+ 	napi_schedule(&mdev->tx_napi);
+ 	local_bh_enable();
+ 
+diff --git a/mt7615/pci_mac.c b/mt7615/pci_mac.c
+index a0ca3bbdf..c2e4e6aab 100644
+--- a/mt7615/pci_mac.c
++++ b/mt7615/pci_mac.c
+@@ -262,12 +262,14 @@ void mt7615_mac_reset_work(struct work_struct *work)
+ 
+ 	mt76_worker_enable(&dev->mt76.tx_worker);
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
+-	napi_schedule(&dev->mt76.tx_napi);
+-
+ 	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_enable(&dev->mt76.napi[i]);
++	}
++
++	local_bh_disable();
++	napi_schedule(&dev->mt76.tx_napi);
++	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_schedule(&dev->mt76.napi[i]);
+ 	}
+ 	local_bh_enable();
+diff --git a/mt76x0/pci.c b/mt76x0/pci.c
+index 911e162a4..11c16d1fc 100644
+--- a/mt76x0/pci.c
++++ b/mt76x0/pci.c
+@@ -283,14 +283,16 @@ static int mt76x0e_resume(struct pci_dev *pdev)
+ 
+ 	mt76_worker_enable(&mdev->tx_worker);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(mdev, i) {
+ 		mt76_queue_rx_reset(dev, i);
+ 		napi_enable(&mdev->napi[i]);
+-		napi_schedule(&mdev->napi[i]);
+ 	}
+-
+ 	napi_enable(&mdev->tx_napi);
++
++	local_bh_disable();
++	mt76_for_each_q_rx(mdev, i) {
++		napi_schedule(&mdev->napi[i]);
++	}
+ 	napi_schedule(&mdev->tx_napi);
+ 	local_bh_enable();
+ 
+diff --git a/mt76x02_mmio.c b/mt76x02_mmio.c
+index 99ec04d67..50badaade 100644
+--- a/mt76x02_mmio.c
++++ b/mt76x02_mmio.c
+@@ -504,12 +504,14 @@ static void mt76x02_watchdog_reset(struct mt76x02_dev *dev)
+ 	mt76_worker_enable(&dev->mt76.tx_worker);
+ 	tasklet_enable(&dev->mt76.pre_tbtt_tasklet);
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
+-	napi_schedule(&dev->mt76.tx_napi);
+-
+ 	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_enable(&dev->mt76.napi[i]);
++	}
++
++	local_bh_disable();
++	napi_schedule(&dev->mt76.tx_napi);
++	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_schedule(&dev->mt76.napi[i]);
+ 	}
+ 	local_bh_enable();
+diff --git a/mt76x2/pci.c b/mt76x2/pci.c
+index 55f076231..230301967 100644
+--- a/mt76x2/pci.c
++++ b/mt76x2/pci.c
+@@ -152,12 +152,15 @@ mt76x2e_resume(struct pci_dev *pdev)
+ 
+ 	mt76_worker_enable(&mdev->tx_worker);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(mdev, i) {
+ 		napi_enable(&mdev->napi[i]);
+-		napi_schedule(&mdev->napi[i]);
+ 	}
+ 	napi_enable(&mdev->tx_napi);
++
++	local_bh_disable();
++	mt76_for_each_q_rx(mdev, i) {
++		napi_schedule(&mdev->napi[i]);
++	}
+ 	napi_schedule(&mdev->tx_napi);
+ 	local_bh_enable();
+ 
+diff --git a/mt7915/mac.c b/mt7915/mac.c
+index 13bdc0a71..2ba6eb303 100644
+--- a/mt7915/mac.c
++++ b/mt7915/mac.c
+@@ -1356,10 +1356,15 @@ mt7915_mac_restart(struct mt7915_dev *dev)
+ 
+ 	mt7915_dma_reset(dev, true);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(mdev, i) {
+ 		if (mdev->q_rx[i].ndesc) {
+ 			napi_enable(&dev->mt76.napi[i]);
++		}
++	}
++
++	local_bh_disable();
++	mt76_for_each_q_rx(mdev, i) {
++		if (mdev->q_rx[i].ndesc) {
+ 			napi_schedule(&dev->mt76.napi[i]);
+ 		}
+ 	}
+@@ -1419,8 +1424,9 @@ mt7915_mac_restart(struct mt7915_dev *dev)
+ 	if (phy2)
+ 		clear_bit(MT76_RESET, &phy2->mt76->state);
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
++
++	local_bh_disable();
+ 	napi_schedule(&dev->mt76.tx_napi);
+ 	local_bh_enable();
+ 
+@@ -1570,9 +1576,12 @@ void mt7915_mac_reset_work(struct work_struct *work)
+ 	if (phy2)
+ 		clear_bit(MT76_RESET, &phy2->mt76->state);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_enable(&dev->mt76.napi[i]);
++	}
++
++	local_bh_disable();
++	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_schedule(&dev->mt76.napi[i]);
+ 	}
+ 	local_bh_enable();
+@@ -1581,8 +1590,8 @@ void mt7915_mac_reset_work(struct work_struct *work)
+ 
+ 	mt76_worker_enable(&dev->mt76.tx_worker);
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
++	local_bh_disable();
+ 	napi_schedule(&dev->mt76.tx_napi);
+ 	local_bh_enable();
+ 
+diff --git a/mt7921/pci.c b/mt7921/pci.c
+index b09374e2f..028d92c6a 100644
+--- a/mt7921/pci.c
++++ b/mt7921/pci.c
+@@ -523,12 +523,15 @@ static int mt7921_pci_resume(struct device *device)
+ 
+ 	mt76_worker_enable(&mdev->tx_worker);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(mdev, i) {
+ 		napi_enable(&mdev->napi[i]);
+-		napi_schedule(&mdev->napi[i]);
+ 	}
+ 	napi_enable(&mdev->tx_napi);
++
++	local_bh_disable();
++	mt76_for_each_q_rx(mdev, i) {
++		napi_schedule(&mdev->napi[i]);
++	}
+ 	napi_schedule(&mdev->tx_napi);
+ 	local_bh_enable();
+ 
+diff --git a/mt7921/pci_mac.c b/mt7921/pci_mac.c
+index 2452b1a2d..881812ba0 100644
+--- a/mt7921/pci_mac.c
++++ b/mt7921/pci_mac.c
+@@ -81,9 +81,12 @@ int mt7921e_mac_reset(struct mt792x_dev *dev)
+ 
+ 	mt792x_wpdma_reset(dev, true);
+ 
+-	local_bh_disable();
+ 	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_enable(&dev->mt76.napi[i]);
++	}
++
++	local_bh_disable();
++	mt76_for_each_q_rx(&dev->mt76, i) {
+ 		napi_schedule(&dev->mt76.napi[i]);
+ 	}
+ 	local_bh_enable();
+@@ -115,8 +118,8 @@ int mt7921e_mac_reset(struct mt792x_dev *dev)
+ 	err = __mt7921_start(&dev->phy);
+ out:
+ 
+-	local_bh_disable();
+ 	napi_enable(&dev->mt76.tx_napi);
++	local_bh_disable();
+ 	napi_schedule(&dev->mt76.tx_napi);
+ 	local_bh_enable();
+ 
diff --git a/package/kernel/mt76/patches/9999-mt76_06.patch b/package/kernel/mt76/patches/9999-mt76_06.patch
new file mode 100644
index 0000000..ac54d7e
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_06.patch
@@ -0,0 +1,74 @@
+From 56c0beddbed82bc91e147fbc64e83c9c07909675 Mon Sep 17 00:00:00 2001
+From: Ming Yen Hsieh <mingyen.hsieh@mediatek.com>
+Date: Tue, 18 Feb 2025 11:33:42 +0800
+Subject: [PATCH] wifi: mt76: mt7921: fix kernel panic due to null pointer
+ dereference
+
+Address a kernel panic caused by a null pointer dereference in the
+`mt792x_rx_get_wcid` function. The issue arises because the `deflink` structure
+is not properly initialized with the `sta` context. This patch ensures that the
+`deflink` structure is correctly linked to the `sta` context, preventing the
+null pointer dereference.
+
+ BUG: kernel NULL pointer dereference, address: 0000000000000400
+ #PF: supervisor read access in kernel mode
+ #PF: error_code(0x0000) - not-present page
+ PGD 0 P4D 0
+ Oops: Oops: 0000 [#1] PREEMPT SMP NOPTI
+ CPU: 0 UID: 0 PID: 470 Comm: mt76-usb-rx phy Not tainted 6.12.13-gentoo-dist #1
+ Hardware name:  /AMD HUDSON-M1, BIOS 4.6.4 11/15/2011
+ RIP: 0010:mt792x_rx_get_wcid+0x48/0x140 [mt792x_lib]
+ RSP: 0018:ffffa147c055fd98 EFLAGS: 00010202
+ RAX: 0000000000000000 RBX: ffff8e9ecb652000 RCX: 0000000000000000
+ RDX: 0000000000000000 RSI: 0000000000000001 RDI: ffff8e9ecb652000
+ RBP: 0000000000000685 R08: ffff8e9ec6570000 R09: 0000000000000000
+ R10: ffff8e9ecd2ca000 R11: ffff8e9f22a217c0 R12: 0000000038010119
+ R13: 0000000080843801 R14: ffff8e9ec6570000 R15: ffff8e9ecb652000
+ FS:  0000000000000000(0000) GS:ffff8e9f22a00000(0000) knlGS:0000000000000000
+ CS:  0010 DS: 0000 ES: 0000 CR0: 0000000080050033
+ CR2: 0000000000000400 CR3: 000000000d2ea000 CR4: 00000000000006f0
+ Call Trace:
+  <TASK>
+  ? __die_body.cold+0x19/0x27
+  ? page_fault_oops+0x15a/0x2f0
+  ? search_module_extables+0x19/0x60
+  ? search_bpf_extables+0x5f/0x80
+  ? exc_page_fault+0x7e/0x180
+  ? asm_exc_page_fault+0x26/0x30
+  ? mt792x_rx_get_wcid+0x48/0x140 [mt792x_lib]
+  mt7921_queue_rx_skb+0x1c6/0xaa0 [mt7921_common]
+  mt76u_alloc_queues+0x784/0x810 [mt76_usb]
+  ? __pfx___mt76_worker_fn+0x10/0x10 [mt76]
+  __mt76_worker_fn+0x4f/0x80 [mt76]
+  kthread+0xd2/0x100
+  ? __pfx_kthread+0x10/0x10
+  ret_from_fork+0x34/0x50
+  ? __pfx_kthread+0x10/0x10
+  ret_from_fork_asm+0x1a/0x30
+  </TASK>
+ ---[ end trace 0000000000000000 ]---
+
+Reported-by: Nick Morrow <usbwifi2024@gmail.com>
+Closes: https://github.com/morrownr/USB-WiFi/issues/577
+Cc: stable@vger.kernel.org
+Fixes: 90c10286b176 ("wifi: mt76: mt7925: Update mt792x_rx_get_wcid for per-link STA")
+Signed-off-by: Ming Yen Hsieh <mingyen.hsieh@mediatek.com>
+Tested-by: Salah Coronya <salah.coronya@gmail.com>
+Link: https://patch.msgid.link/20250218033343.1999648-1-mingyen.hsieh@mediatek.com
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7921/main.c | 1 +
+ 1 file changed, 1 insertion(+)
+
+diff --git a/mt7921/main.c b/mt7921/main.c
+index 8e80b4163..982064088 100644
+--- a/mt7921/main.c
++++ b/mt7921/main.c
+@@ -811,6 +811,7 @@ int mt7921_mac_sta_add(struct mt76_dev *mdev, struct ieee80211_vif *vif,
+ 	msta->deflink.wcid.phy_idx = mvif->bss_conf.mt76.band_idx;
+ 	msta->deflink.wcid.tx_info |= MT_WCID_TX_INFO_SET;
+ 	msta->deflink.last_txs = jiffies;
++	msta->deflink.sta = msta;
+ 
+ 	ret = mt76_connac_pm_wake(&dev->mphy, &dev->pm);
+ 	if (ret)
diff --git a/package/kernel/mt76/patches/9999-mt76_07.patch b/package/kernel/mt76/patches/9999-mt76_07.patch
new file mode 100644
index 0000000..1ea1cab
--- /dev/null
+++ b/package/kernel/mt76/patches/9999-mt76_07.patch
@@ -0,0 +1,38 @@
+From 1b370c689a2fab98d43b51a6222b8b9b88a22161 Mon Sep 17 00:00:00 2001
+From: Leon Yen <leon.yen@mediatek.com>
+Date: Fri, 12 Apr 2024 16:53:57 +0800
+Subject: [PATCH] wifi: mt76: mt7921: avoid undesired changes of the preset
+ regulatory domain
+
+Some countries have strict RF restrictions where changing the regulatory
+domain dynamically based on the connected AP is not acceptable.
+This patch disables Beacon country IE hinting when a valid country code
+is set from usersland (e.g., by system using iw or CRDA).
+
+Signed-off-by: Leon Yen <leon.yen@mediatek.com>
+Signed-off-by: Ming Yen Hsieh <mingyen.hsieh@mediatek.com>
+Tested-by: David Ruth <druth@chromium.org>
+Link: https://patch.msgid.link/20240412085357.13756-1-mingyen.hsieh@mediatek.com
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ mt7921/init.c | 7 +++++++
+ 1 file changed, 7 insertions(+)
+
+diff --git a/mt7921/init.c b/mt7921/init.c
+index cdcb002b3..14e17dc90 100644
+--- a/mt7921/init.c
++++ b/mt7921/init.c
+@@ -137,6 +137,13 @@ mt7921_regd_notifier(struct wiphy *wiphy,
+ 	dev->mt76.region = request->dfs_region;
+ 	dev->country_ie_env = request->country_ie_env;
+ 
++	if (request->initiator == NL80211_REGDOM_SET_BY_USER) {
++		if (dev->mt76.alpha2[0] == '0' && dev->mt76.alpha2[1] == '0')
++			wiphy->regulatory_flags &= ~REGULATORY_COUNTRY_IE_IGNORE;
++		else
++			wiphy->regulatory_flags |= REGULATORY_COUNTRY_IE_IGNORE;
++	}
++
+ 	if (pm->suspended)
+ 		return;
+ 
-- 
2.46.2.windows.1

