diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .188
-LINUX_KERNEL_HASH-5.15.188 = c4953a071802ac30bb29f9e1bb8f02255169d8437026c84e81f155a178cbccd9
+LINUX_VERSION-5.15 = .189
+LINUX_KERNEL_HASH-5.15.189 = e3d0025b87278e14733cb326700f17c7cceb54d920622b0d5fcd58a88c6850c3
