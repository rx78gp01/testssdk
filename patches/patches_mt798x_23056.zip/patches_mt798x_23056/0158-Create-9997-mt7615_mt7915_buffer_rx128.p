diff --git a/package/kernel/mt76/patches/9997-mt76.patch b/package/kernel/mt76/patches/9997-mt76.patch
new file mode 100644
index 0000000..a3052bf
--- /dev/null
+++ b/package/kernel/mt76/patches/9997-mt76.patch
@@ -0,0 +1,61 @@
+diff --git a/mt7615/mt7615.h b/mt7615/mt7615.h
+index 6d33b1d..f848a96 100644
+--- a/mt7615/mt7615.h
++++ b/mt7615/mt7615.h
+@@ -30,7 +30,7 @@
+ #define MT7615_TX_FWDL_RING_SIZE	128
+ 
+ #define MT7615_RX_RING_SIZE		128
+-#define MT7615_RX_MCU_RING_SIZE		512
++#define MT7615_RX_MCU_RING_SIZE		8
+ 
+ #define MT7615_DRV_OWN_RETRY_COUNT	10
+ 
+diff --git a/mt7915/dma.c b/mt7915/dma.c
+index 0baa82c..342570b 100644
+--- a/mt7915/dma.c
++++ b/mt7915/dma.c
+@@ -501,7 +501,7 @@ int mt7915_dma_init(struct mt7915_dev *dev, struct mt7915_phy *phy2)
+ 		wa_rx_idx = MT_RXQ_ID(MT_RXQ_MCU_WA);
+ 	}
+ 	ret = mt76_queue_alloc(dev, &dev->mt76.q_rx[MT_RXQ_MCU_WA],
+-			       wa_rx_idx, MT7915_RX_MCU_RING_SIZE,
++			       wa_rx_idx, MT7915_RX_MCU_WA_RING_SIZE,
+ 			       MT_RX_BUF_SIZE, wa_rx_base);
+ 	if (ret)
+ 		return ret;
+@@ -540,7 +540,7 @@ int mt7915_dma_init(struct mt7915_dev *dev, struct mt7915_phy *phy2)
+ 		}
+ 
+ 		ret = mt76_queue_alloc(dev, &dev->mt76.q_rx[MT_RXQ_MAIN_WA],
+-				       wa_rx_idx, MT7915_RX_MCU_RING_SIZE,
++				       wa_rx_idx, MT7915_RX_MCU_WA_RING_SIZE,
+ 				       MT_RX_BUF_SIZE, wa_rx_base);
+ 		if (ret)
+ 			return ret;
+@@ -567,7 +567,7 @@ int mt7915_dma_init(struct mt7915_dev *dev, struct mt7915_phy *phy2)
+ 		/* tx free notify event from WA for band1 */
+ 		ret = mt76_queue_alloc(dev, &dev->mt76.q_rx[MT_RXQ_BAND1_WA],
+ 				       MT_RXQ_ID(MT_RXQ_BAND1_WA),
+-				       MT7915_RX_MCU_RING_SIZE,
++				       MT7915_RX_MCU_WA_RING_SIZE,
+ 				       MT_RX_BUF_SIZE,
+ 				       MT_RXQ_RING_BASE(MT_RXQ_BAND1_WA) + hif1_ofs);
+ 		if (ret)
+diff --git a/mt7915/mt7915.h b/mt7915/mt7915.h
+index fc02919..e27e6ef 100644
+--- a/mt7915/mt7915.h
++++ b/mt7915/mt7915.h
+@@ -24,7 +24,8 @@
+ #define MT7915_TX_FWDL_RING_SIZE	128
+ 
+ #define MT7915_RX_RING_SIZE		128
+-#define MT7915_RX_MCU_RING_SIZE		512
++#define MT7915_RX_MCU_RING_SIZE		8
++#define MT7915_RX_MCU_WA_RING_SIZE		512
+ 
+ #define MT7915_FIRMWARE_WA		"mediatek/mt7915_wa.bin"
+ #define MT7915_FIRMWARE_WM		"mediatek/mt7915_wm.bin"
+-- 
+2.38.1
+
-- 
2.38.1.windows.1

