diff --git a/package/kernel/mt76/patches/9996-mt7615_mt7915_buffer.patch b/package/kernel/mt76/patches/9996-mt7615_mt7915_buffer.patch
new file mode 100644
index 0000000..c6d5d33
--- /dev/null
+++ b/package/kernel/mt76/patches/9996-mt7615_mt7915_buffer.patch
@@ -0,0 +1,40 @@
+diff --git a/mt7615/mt7615.h b/mt7615/mt7615.h
+index a20322a..6d33b1d 100644
+--- a/mt7615/mt7615.h
++++ b/mt7615/mt7615.h
+@@ -24,12 +24,12 @@
+ #define MT7615_RESET_TIMEOUT		(30 * HZ)
+ #define MT7615_RATE_RETRY		2
+ 
+-#define MT7615_TX_RING_SIZE		1024
++#define MT7615_TX_RING_SIZE		256
+ #define MT7615_TX_MGMT_RING_SIZE	128
+ #define MT7615_TX_MCU_RING_SIZE		128
+ #define MT7615_TX_FWDL_RING_SIZE	128
+ 
+-#define MT7615_RX_RING_SIZE		1024
++#define MT7615_RX_RING_SIZE		128
+ #define MT7615_RX_MCU_RING_SIZE		512
+ 
+ #define MT7615_DRV_OWN_RETRY_COUNT	10
+diff --git a/mt7915/mt7915.h b/mt7915/mt7915.h
+index 8f27692..fc02919 100644
+--- a/mt7915/mt7915.h
++++ b/mt7915/mt7915.h
+@@ -19,11 +19,11 @@
+ #define MT7915_WATCHDOG_TIME		(HZ / 10)
+ #define MT7915_RESET_TIMEOUT		(30 * HZ)
+ 
+-#define MT7915_TX_RING_SIZE		2048
++#define MT7915_TX_RING_SIZE		256
+ #define MT7915_TX_MCU_RING_SIZE		256
+ #define MT7915_TX_FWDL_RING_SIZE	128
+ 
+-#define MT7915_RX_RING_SIZE		1536
++#define MT7915_RX_RING_SIZE		128
+ #define MT7915_RX_MCU_RING_SIZE		512
+ 
+ #define MT7915_FIRMWARE_WA		"mediatek/mt7915_wa.bin"
+-- 
+2.38.1
+
-- 
2.38.1.windows.1

