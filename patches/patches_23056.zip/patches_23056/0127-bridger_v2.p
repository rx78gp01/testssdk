From 786e3dec012b0e61404db201918d2345ef977c44 Mon Sep 17 00:00:00 2001
From: Felix Fietkau <nbd@nbd.name>
Date: Mon, 22 Apr 2024 10:59:19 +0200
Subject: [PATCH] bridger: update to Git HEAD (2024-04-22)

ec8c620fd5f4 split bridge-local disable into rx and tx
40b1c5b6be4e flow: do not attempt to offload bridge-local flows

Signed-off-by: Felix Fietkau <nbd@nbd.name>
---

diff --git a/package/network/services/bridger/Makefile b/package/network/services/bridger/Makefile
index fa98220f68aa6..b38c2ddbc51d9 100644
--- a/package/network/services/bridger/Makefile
+++ b/package/network/services/bridger/Makefile
@@ -10,9 +10,9 @@ include $(TOPDIR)/rules.mk
 PKG_NAME:=bridger
 PKG_SOURCE_PROTO:=git
 PKG_SOURCE_URL=https://github.com/nbd168/bridger
-PKG_SOURCE_DATE:=2023-05-12
-PKG_SOURCE_VERSION:=d0f79a16c749ad310d79e1c31f593860619f99eb
-PKG_MIRROR_HASH:=bee35594767cbcd13764f5c95e4837a4fc73171a91fcdae73aaefe00f4e8f8fa
+PKG_SOURCE_DATE:=2024-04-22
+PKG_SOURCE_VERSION:=ccdc0394c833a1a1e79c76f1de5b5ffe011c7f7d
+PKG_MIRROR_HASH:=skip
 
 PKG_LICENSE:=GPL-2.0
 PKG_MAINTAINER:=Felix Fietkau <nbd@nbd.name>
diff --git a/package/network/services/bridger/files/bridger.conf b/package/network/services/bridger/files/bridger.conf
index cb43deff79529..2ff6b5b787aa0 100644
--- a/package/network/services/bridger/files/bridger.conf
+++ b/package/network/services/bridger/files/bridger.conf
@@ -1,3 +1,7 @@
 config defaults
+	# handle bridge local rx/tx
+	option bridge_local_tx 1
+	option bridge_local_rx 0
+
 	# example for blacklisting individual devices or bridges
 	# list blacklist eth0
diff --git a/package/network/services/bridger/files/bridger.init b/package/network/services/bridger/files/bridger.init
index 2ba9f06b65e1e..c9983ae9cc64a 100644
--- a/package/network/services/bridger/files/bridger.init
+++ b/package/network/services/bridger/files/bridger.init
@@ -6,25 +6,30 @@ START=19
 USE_PROCD=1
 PROG=/usr/sbin/bridger
 
-add_blacklist() {
+get_defaults() {
 	cfg="$1"
 
 	config_get blacklist "$cfg" blacklist
+	json_add_array blacklist
 	for i in $blacklist; do
 		json_add_string "" "$i"
 	done
+	json_close_array
+
+	config_get_bool bridge_local_tx "$cfg" bridge_local_tx 1
+	json_add_boolean bridge_local_tx "$bridge_local_tx"
+
+	config_get_bool bridge_local_rx "$cfg" bridge_local_rx 0
+	json_add_boolean bridge_local_rx "$bridge_local_rx"
 }
 
 reload_service() {
 	config_load bridger
 
 	json_init
-	json_add_string name "config"
-	json_add_array devices
-	config_foreach add_blacklist defaults
-	json_close_array
+	config_foreach get_defaults defaults
 
-	ubus call bridger set_blacklist "$(json_dump)"
+	ubus call bridger set_config "$(json_dump)"
 }
 
 service_triggers() {
