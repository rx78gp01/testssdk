From 8939e79178eac526bc2aca1d3d655bc7fa103c7c Mon Sep 17 00:00:00 2001
From: John Audia <therealgraysky@proton.me>
Date: Wed, 12 Feb 2025 08:56:47 -0500
Subject: [PATCH] openssl: update to 3.0.17

Changes between 3.0.15 and 3.0.16 [11 Feb 2025]

CVE-2024-13176[1] - Fixed timing side-channel in ECDSA signature
computation.

There is a timing signal of around 300 nanoseconds when the top word of
the inverted ECDSA nonce value is zero. This can happen with significant
probability only for some of the supported elliptic curves. In
particular the NIST P-521 curve is affected. To be able to measure this
leak, the attacker process must either be located in the same physical
computer or must have a very fast network connection with low latency.

CVE-2024-9143[2] - Fixed possible OOB memory access with invalid
low-level GF(2^m) elliptic curve parameters.

Use of the low-level GF(2^m) elliptic curve APIs with untrusted explicit
values for the field polynomial can lead to out-of-bounds memory reads
or writes. Applications working with "exotic" explicit binary (GF(2^m))
curve parameters, that make it possible to represent invalid field
polynomials with a zero constant term, via the above or similar APIs,
may terminate abruptly as a result of reading or writing outside of
array bounds. Remote code execution cannot easily be ruled out.

1. https://www.openssl.org/news/vulnerabilities.html#CVE-2024-13176
2. https://www.openssl.org/news/vulnerabilities.html#CVE-2024-9143

Build system: x86/64
Build-tested: bcm27xx/bcm2712
Run-tested: bcm27xx/bcm2712

Signed-off-by: John Audia <therealgraysky@proton.me>
---
 package/libs/openssl/Makefile | 4 ++--
 1 file changed, 2 insertions(+), 2 deletions(-)

diff --git a/package/libs/openssl/Makefile b/package/libs/openssl/Makefile
index 959424ce12c540..4829670f86fe70 100644
--- a/package/libs/openssl/Makefile
+++ b/package/libs/openssl/Makefile
@@ -8,7 +8,7 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=openssl
-PKG_VERSION:=3.0.16
+PKG_VERSION:=3.0.17
 PKG_RELEASE:=1
 PKG_BUILD_FLAGS:=no-mips16 gc-sections no-lto
 
@@ -21,7 +21,7 @@ PKG_SOURCE_URL:= \
 	https://www.openssl.org/source/old/$(PKG_BASE)/ \
 	https://github.com/openssl/openssl/releases/download/$(PKG_NAME)-$(PKG_VERSION)/
 
-PKG_HASH:=57e03c50feab5d31b152af2b764f10379aecd8ee92f16c985983ce4a99f7ef86
+PKG_HASH:=dfdd77e4ea1b57ff3a6dbde6b0bdc3f31db5ac99e7fdd4eaf9e1fbb6ec2db8ce
 
 PKG_LICENSE:=Apache-2.0
 PKG_LICENSE_FILES:=LICENSE
