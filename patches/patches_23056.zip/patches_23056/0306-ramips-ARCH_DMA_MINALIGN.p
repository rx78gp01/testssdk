From f648710dff71a288ca7d5733587a2196251785d3 Mon Sep 17 00:00:00 2001
From: Qingfang Deng <dqfext@gmail.com>
Date: Tue, 12 May 2026 11:50:36 +0800
Subject: [PATCH] ramips: reduce ARCH_DMA_MINALIGN

Currently, Ralink SoCs use the default ARCH_DMA_MINALIGN value of 128
bytes defined in mach-generic. This is excessive for these platforms
and leads to significant memory waste in kmalloc.

Override ARCH_DMA_MINALIGN to use L1_CACHE_BYTES, which is 16 bytes for
RT288X and 32 bytes for other Ralink SoCs.

Signed-off-by: Qingfang Deng <dqfext@gmail.com>
---
 .../files/arch/mips/include/asm/mach-ralink/kmalloc.h    | 9 +++++++++
 1 file changed, 9 insertions(+)
 create mode 100644 target/linux/ramips/files/arch/mips/include/asm/mach-ralink/kmalloc.h

diff --git a/target/linux/ramips/files/arch/mips/include/asm/mach-ralink/kmalloc.h b/target/linux/ramips/files/arch/mips/include/asm/mach-ralink/kmalloc.h
new file mode 100644
index 00000000000000..1693209d3f3739
--- /dev/null
+++ b/target/linux/ramips/files/arch/mips/include/asm/mach-ralink/kmalloc.h
@@ -0,0 +1,9 @@
+/* SPDX-License-Identifier: GPL-2.0 */
+#ifndef __ASM_MACH_RALINK_KMALLOC_H
+#define __ASM_MACH_RALINK_KMALLOC_H
+
+#ifdef CONFIG_DMA_NONCOHERENT
+#define ARCH_DMA_MINALIGN	L1_CACHE_BYTES
+#endif
+
+#endif /* __ASM_MACH_RALINK_KMALLOC_H */
