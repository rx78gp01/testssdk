diff --git a/package/kernel/mac80211/patches/subsys/803a.patch b/package/kernel/mac80211/patches/subsys/803a.patch
new file mode 100644
index 0000000..89921a5
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/803a.patch
@@ -0,0 +1,114 @@
+From e2c8a3c0388aef6bfc4aabfba07bc7dff16eea80 Mon Sep 17 00:00:00 2001
+From: Mathy Vanhoef <Mathy.Vanhoef@kuleuven.be>
+Date: Mon, 16 Jun 2025 02:46:35 +0200
+Subject: [PATCH] wifi: prevent A-MSDU attacks in mesh networks
+
+commit 737bb912ebbe4571195c56eba557c4d7315b26fb upstream.
+
+This patch is a mitigation to prevent the A-MSDU spoofing vulnerability
+for mesh networks. The initial update to the IEEE 802.11 standard, in
+response to the FragAttacks, missed this case (CVE-2025-27558). It can
+be considered a variant of CVE-2020-24588 but for mesh networks.
+
+This patch tries to detect if a standard MSDU was turned into an A-MSDU
+by an adversary. This is done by parsing a received A-MSDU as a standard
+MSDU, calculating the length of the Mesh Control header, and seeing if
+the 6 bytes after this header equal the start of an rfc1042 header. If
+equal, this is a strong indication of an ongoing attack attempt.
+
+This defense was tested with mac80211_hwsim against a mesh network that
+uses an empty Mesh Address Extension field, i.e., when four addresses
+are used, and when using a 12-byte Mesh Address Extension field, i.e.,
+when six addresses are used. Functionality of normal MSDUs and A-MSDUs
+was also tested, and confirmed working, when using both an empty and
+12-byte Mesh Address Extension field.
+
+It was also tested with mac80211_hwsim that A-MSDU attacks in non-mesh
+networks keep being detected and prevented.
+
+Note that the vulnerability being patched, and the defense being
+implemented, was also discussed in the following paper and in the
+following IEEE 802.11 presentation:
+
+https://papers.mathyvanhoef.com/wisec2025.pdf
+https://mentor.ieee.org/802.11/dcn/25/11-25-0949-00-000m-a-msdu-mesh-spoof-protection.docx
+
+Cc: stable@vger.kernel.org
+Signed-off-by: Mathy Vanhoef <Mathy.Vanhoef@kuleuven.be>
+Link: https://patch.msgid.link/20250616004635.224344-1-Mathy.Vanhoef@kuleuven.be
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Greg Kroah-Hartman <gregkh@linuxfoundation.org>
+---
+ net/wireless/util.c | 52 +++++++++++++++++++++++++++++++++++++++++++--
+ 1 file changed, 50 insertions(+), 2 deletions(-)
+
+diff --git a/net/wireless/util.c b/net/wireless/util.c
+index c71b85fd6052d..00c1530e19791 100644
+--- a/net/wireless/util.c
++++ b/net/wireless/util.c
+@@ -813,6 +813,52 @@ bool ieee80211_is_valid_amsdu(struct sk_buff *skb, bool mesh_hdr)
+ }
+ EXPORT_SYMBOL(ieee80211_is_valid_amsdu);
+ 
++
++/*
++ * Detects if an MSDU frame was maliciously converted into an A-MSDU
++ * frame by an adversary. This is done by parsing the received frame
++ * as if it were a regular MSDU, even though the A-MSDU flag is set.
++ *
++ * For non-mesh interfaces, detection involves checking whether the
++ * payload, when interpreted as an MSDU, begins with a valid RFC1042
++ * header. This is done by comparing the A-MSDU subheader's destination
++ * address to the start of the RFC1042 header.
++ *
++ * For mesh interfaces, the MSDU includes a 6-byte Mesh Control field
++ * and an optional variable-length Mesh Address Extension field before
++ * the RFC1042 header. The position of the RFC1042 header must therefore
++ * be calculated based on the mesh header length.
++ *
++ * Since this function intentionally parses an A-MSDU frame as an MSDU,
++ * it only assumes that the A-MSDU subframe header is present, and
++ * beyond this it performs its own bounds checks under the assumption
++ * that the frame is instead parsed as a non-aggregated MSDU.
++ */
++static bool
++is_amsdu_aggregation_attack(struct ethhdr *eth, struct sk_buff *skb,
++			    enum nl80211_iftype iftype)
++{
++	int offset;
++
++	/* Non-mesh case can be directly compared */
++	if (iftype != NL80211_IFTYPE_MESH_POINT)
++		return ether_addr_equal(eth->h_dest, rfc1042_header);
++
++	offset = __ieee80211_get_mesh_hdrlen(eth->h_dest[0]);
++	if (offset == 6) {
++		/* Mesh case with empty address extension field */
++		return ether_addr_equal(eth->h_source, rfc1042_header);
++	} else if (offset + ETH_ALEN <= skb->len) {
++		/* Mesh case with non-empty address extension field */
++		u8 temp[ETH_ALEN];
++
++		skb_copy_bits(skb, offset, temp, ETH_ALEN);
++		return ether_addr_equal(temp, rfc1042_header);
++	}
++
++	return false;
++}
++
+ void ieee80211_amsdu_to_8023s(struct sk_buff *skb, struct sk_buff_head *list,
+ 			      const u8 *addr, enum nl80211_iftype iftype,
+ 			      const unsigned int extra_headroom,
+@@ -857,8 +903,10 @@ void ieee80211_amsdu_to_8023s(struct sk_buff *skb, struct sk_buff_head *list,
+ 		/* the last MSDU has no padding */
+ 		if (subframe_len > remaining)
+ 			goto purge;
+-		/* mitigate A-MSDU aggregation injection attacks */
+-		if (ether_addr_equal(hdr.eth.h_dest, rfc1042_header))
++		/* mitigate A-MSDU aggregation injection attacks, to be
++		 * checked when processing first subframe (offset == 0).
++		 */
++		if (offset == 0 && is_amsdu_aggregation_attack(&hdr.eth, skb, iftype))
+ 			goto purge;
+ 
+ 		offset += sizeof(struct ethhdr);
diff --git a/package/kernel/mac80211/patches/subsys/803b.patch b/package/kernel/mac80211/patches/subsys/803b.patch
new file mode 100644
index 0000000..73380c1
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/803b.patch
@@ -0,0 +1,33 @@
+From d486ff6734ee1ae4efada1b5421cf3640147e5db Mon Sep 17 00:00:00 2001
+From: Johannes Berg <johannes.berg@intel.com>
+Date: Fri, 18 Jul 2025 20:23:06 +0200
+Subject: [PATCH] wifi: cfg80211: reject HTC bit for management frames
+
+[ Upstream commit be06a8c7313943109fa870715356503c4c709cbc ]
+
+Management frames sent by userspace should never have the
+order/HTC bit set, reject that. It could also cause some
+confusion with the length of the buffer and the header so
+the validation might end up wrong.
+
+Link: https://patch.msgid.link/20250718202307.97a0455f0f35.I1805355c7e331352df16611839bc8198c855a33f@changeid
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/wireless/mlme.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/net/wireless/mlme.c b/net/wireless/mlme.c
+index e7fa0608341d8..e0246ed9f66f2 100644
+--- a/net/wireless/mlme.c
++++ b/net/wireless/mlme.c
+@@ -700,7 +700,8 @@ int cfg80211_mlme_mgmt_tx(struct cfg80211_registered_device *rdev,
+ 
+ 	mgmt = (const struct ieee80211_mgmt *)params->buf;
+ 
+-	if (!ieee80211_is_mgmt(mgmt->frame_control))
++	if (!ieee80211_is_mgmt(mgmt->frame_control) ||
++	    ieee80211_has_order(mgmt->frame_control))
+ 		return -EINVAL;
+ 
+ 	stype = le16_to_cpu(mgmt->frame_control) & IEEE80211_FCTL_STYPE;
diff --git a/package/kernel/mac80211/patches/subsys/803c.patch b/package/kernel/mac80211/patches/subsys/803c.patch
new file mode 100644
index 0000000..aeb366f
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/803c.patch
@@ -0,0 +1,38 @@
+From 6854476d9e1aeaaf05ebc98d610061c2075db07d Mon Sep 17 00:00:00 2001
+From: Dmitry Antipov <dmantipov@yandex.ru>
+Date: Wed, 13 Aug 2025 16:52:36 +0300
+Subject: [PATCH] wifi: cfg80211: fix use-after-free in cmp_bss()
+
+[ Upstream commit 26e84445f02ce6b2fe5f3e0e28ff7add77f35e08 ]
+
+Following bss_free() quirk introduced in commit 776b3580178f
+("cfg80211: track hidden SSID networks properly"), adjust
+cfg80211_update_known_bss() to free the last beacon frame
+elements only if they're not shared via the corresponding
+'hidden_beacon_bss' pointer.
+
+Reported-by: syzbot+30754ca335e6fb7e3092@syzkaller.appspotmail.com
+Closes: https://syzkaller.appspot.com/bug?extid=30754ca335e6fb7e3092
+Fixes: 3ab8227d3e7d ("cfg80211: refactor cfg80211_bss_update")
+Signed-off-by: Dmitry Antipov <dmantipov@yandex.ru>
+Link: https://patch.msgid.link/20250813135236.799384-1-dmantipov@yandex.ru
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/wireless/scan.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/net/wireless/scan.c b/net/wireless/scan.c
+index 810293f160a8c..7369172819fdf 100644
+--- a/net/wireless/scan.c
++++ b/net/wireless/scan.c
+@@ -1785,7 +1785,8 @@ cfg80211_update_known_bss(struct cfg80211_registered_device *rdev,
+ 			 */
+ 
+ 			f = rcu_access_pointer(new->pub.beacon_ies);
+-			kfree_rcu((struct cfg80211_bss_ies *)f, rcu_head);
++			if (!new->pub.hidden_beacon_bss)
++				kfree_rcu((struct cfg80211_bss_ies *)f, rcu_head);
+ 			return false;
+ 		}
+ 
diff --git a/package/kernel/mac80211/patches/subsys/803d.patch b/package/kernel/mac80211/patches/subsys/803d.patch
new file mode 100644
index 0000000..5cdb0a3
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/803d.patch
@@ -0,0 +1,42 @@
+From 8e751d46336205abc259ed3990e850a9843fb649 Mon Sep 17 00:00:00 2001
+From: Dan Carpenter <dan.carpenter@linaro.org>
+Date: Fri, 29 Aug 2025 15:48:45 +0300
+Subject: [PATCH] wifi: cfg80211: sme: cap SSID length in
+ __cfg80211_connect_result()
+
+[ Upstream commit 62b635dcd69c4fde7ce1de4992d71420a37e51e3 ]
+
+If the ssid->datalen is more than IEEE80211_MAX_SSID_LEN (32) it would
+lead to memory corruption so add some bounds checking.
+
+Fixes: c38c70185101 ("wifi: cfg80211: Set SSID if it is not already set")
+Signed-off-by: Dan Carpenter <dan.carpenter@linaro.org>
+Link: https://patch.msgid.link/0aaaae4a3ed37c6252363c34ae4904b1604e8e32.1756456951.git.dan.carpenter@linaro.org
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/wireless/sme.c | 5 ++++-
+ 1 file changed, 4 insertions(+), 1 deletion(-)
+
+diff --git a/net/wireless/sme.c b/net/wireless/sme.c
+index e35c3c29cec7d..ed16e852133e7 100644
+--- a/net/wireless/sme.c
++++ b/net/wireless/sme.c
+@@ -886,13 +886,16 @@ void __cfg80211_connect_result(struct net_device *dev,
+ 	if (!wdev->u.client.ssid_len) {
+ 		rcu_read_lock();
+ 		for_each_valid_link(cr, link) {
++			u32 ssid_len;
++
+ 			ssid = ieee80211_bss_get_elem(cr->links[link].bss,
+ 						      WLAN_EID_SSID);
+ 
+ 			if (!ssid || !ssid->datalen)
+ 				continue;
+ 
+-			memcpy(wdev->u.client.ssid, ssid->data, ssid->datalen);
++			ssid_len = min(ssid->datalen, IEEE80211_MAX_SSID_LEN);
++			memcpy(wdev->u.client.ssid, ssid->data, ssid_len);
+ 			wdev->u.client.ssid_len = ssid->datalen;
+ 			break;
+ 		}
-- 
2.46.2.windows.1

