Fdiff --git a/target/linux/generic/pending-5.15/540-fs-ksmbd-fix-create-path.patch b/target/linux/generic/pending-5.15/540-fs-ksmbd-fix-create-path.patch
new file mode 100644
index 00000000000000..ea458f65b1ee93
--- /dev/null
+++ b/target/linux/generic/pending-5.15/540-fs-ksmbd-fix-create-path.patch
@@ -0,0 +1,19 @@
+--- a/fs/ksmbd/vfs.c
++++ b/fs/ksmbd/vfs.c
+@@ -1259,6 +1259,8 @@ int ksmbd_vfs_kern_path_locked(struct ks
+ 					      filepath,
+ 					      flags,
+ 					      path);
++			if (!is_last)
++				next[0] = '/';
+ 			if (err)
+ 				goto out2;
+ 			else if (is_last)
+@@ -1266,7 +1268,6 @@ int ksmbd_vfs_kern_path_locked(struct ks
+ 			path_put(parent_path);
+ 			*parent_path = *path;
+ 
+-			next[0] = '/';
+ 			remain_len -= filename_len + 1;
+ 		}
+ 
