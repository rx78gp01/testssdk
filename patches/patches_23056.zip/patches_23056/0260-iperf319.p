From e1d8da187785e82db4ca766ea822fc866bcfae84 Mon Sep 17 00:00:00 2001
From: Dane Murphy <danem7@gmail.com>
Date: Sat, 17 May 2025 09:01:10 -0700
Subject: [PATCH] iperf3: update to 3.19

Updates iperf3 to the latest upstream release, 3.19

Changelog: https://github.com/esnet/iperf/releases/tag/3.19

Signed-off-by: Dane Murphy <danem7@gmail.com>
---
 net/iperf3/Makefile                     |  4 ++--
 net/iperf3/patches/010-big-endian.patch | 21 ---------------------
 2 files changed, 2 insertions(+), 23 deletions(-)
 delete mode 100644 net/iperf3/patches/010-big-endian.patch

diff --git a/feeds/packages/net/iperf3/Makefile b/feeds/packages/net/iperf3/Makefile
index a5fe604506a3c..585be8ef18ee8 100644
--- a/feeds/packages/net/iperf3/Makefile
+++ b/feeds/packages/net/iperf3/Makefile
@@ -8,12 +8,12 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=iperf
-PKG_VERSION:=3.17.1
-PKG_RELEASE:=4
+PKG_VERSION:=3.19
+PKG_RELEASE:=1
 
 PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.gz
 PKG_SOURCE_URL:=https://downloads.es.net/pub/iperf
-PKG_HASH:=84404ca8431b595e86c473d8f23d8bb102810001f15feaf610effd3b318788aa
+PKG_HASH:=040161da1555ec7411a9d81191049830ef37717d429a94ee6cf0842618e0e29c
 
 PKG_MAINTAINER:=Felix Fietkau <nbd@nbd.name>
 PKG_LICENSE:=BSD-3-Clause
diff --git a/feeds/packages/net/iperf3/patches/010-big-endian.patch b/feeds/packages/net/iperf3/patches/010-big-endian.patch
deleted file mode 100644
index f57ef51a4af4e..0000000000000
--- a/feeds/packages/net/iperf3/patches/010-big-endian.patch
+++ /dev/null
@@ -1,21 +0,0 @@
-From fe09305eb6f907e4eb637b8edd0c8a986187d1dd Mon Sep 17 00:00:00 2001
-From: Rosen Penev <rosenp@gmail.com>
-Date: Sat, 8 Jun 2024 15:23:51 -0700
-Subject: [PATCH] fix crash under big endian musl
-
-iperf_printf is using an int format here but an int64_t variable. The format only needs the first 3 digits. Cast to int to fix it.
----
- src/iperf_api.c | 2 +-
- 1 file changed, 1 insertion(+), 1 deletion(-)
-
---- a/src/iperf_api.c
-+++ b/src/iperf_api.c
-@@ -4056,7 +4056,7 @@ iperf_print_results(struct iperf_test *t
-                                 iperf_printf(test, report_sender_not_available_summary_format, "SUM");
-                         }
-                         else {
--                          iperf_printf(test, report_sum_bw_retrans_format, mbuf, start_time, sender_time, ubuf, nbuf, total_retransmits, report_sender);
-+                          iperf_printf(test, report_sum_bw_retrans_format, mbuf, start_time, sender_time, ubuf, nbuf, (int)total_retransmits, report_sender);
-                         }
-                 } else {
-                     /* Summary sum, TCP without retransmits. */
diff --git a/feeds/packages/net/iperf3/patches/010-y2k.patch b/feeds/packages/net/iperf3/patches/010-y2k.patch
deleted file mode 100644
index 86350d1ad8185..0000000000000
--- a/feeds/packages/net/iperf3/patches/010-y2k.patch
+++ /dev/null
@@ -1,21 +0,0 @@
-From 4c7629f590bb18855e478a826833adb05d2a128b Mon Sep 17 00:00:00 2001
-From: Rosen Penev <rosenp@gmail.com>
-Date: Sat, 8 Jun 2024 15:35:47 -0700
-Subject: [PATCH] fix -Wformat-y2k error
-
-%c potentially prints a 2 digit year. Just use a normal format.
----
- src/iperf_error.c | 2 +-
- 1 file changed, 1 insertion(+), 1 deletion(-)
-
---- a/src/iperf_error.c
-+++ b/src/iperf_error.c
-@@ -99,7 +99,7 @@ iperf_errexit(struct iperf_test *test, c
-     if (test != NULL && test->timestamps) {
- 	time(&now);
- 	ltm = localtime(&now);
--	strftime(iperf_timestrerr, sizeof(iperf_timestrerr), "%c ", ltm);
-+	strftime(iperf_timestrerr, sizeof(iperf_timestrerr), "%Y-%m-%d %H:%M:%S", ltm);
- 	ct = iperf_timestrerr;
-     }
- 
diff --git a/feeds/packages/net/iperf3/patches/030-musl-crash.patch b/feeds/packages/net/iperf3/patches/030-musl-crash.patch
deleted file mode 100644
index bc1df68c8ef7d..0000000000000
--- a/feeds/packages/net/iperf3/patches/030-musl-crash.patch
+++ /dev/null
@@ -1,19 +0,0 @@
-From 3da07ae96f5b40f76b75e1ccd4b20267f6a5988e Mon Sep 17 00:00:00 2001
-From: =?UTF-8?q?Jakub=20Kul=C3=ADk?= <kulikjak@gmail.com>
-Date: Wed, 28 Aug 2024 09:43:04 +0200
-Subject: [PATCH] remove incorrect freeaddrinfo call
-
----
- src/net.c | 1 -
- 1 file changed, 1 deletion(-)
-
---- a/src/net.c
-+++ b/src/net.c
-@@ -145,7 +145,6 @@ create_socket(int domain, int proto, con
-     if ((gerror = getaddrinfo(server, portstr, &hints, &server_res)) != 0) {
- 	if (local)
- 	    freeaddrinfo(local_res);
--        freeaddrinfo(server_res);
-         return -1;
-     }
- 
