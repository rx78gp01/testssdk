From 1627d875b1fb71bd686c96388a47659fe22ae0cc Mon Sep 17 00:00:00 2001
From: Andrea Pesaresi <andreapesaresi82@gmail.com>
Date: Sat, 7 Dec 2024 10:29:09 +0100
Subject: [PATCH] ksmbd-tools: update to version 3.5.3

- manually refresh patch 030-glib.patch

Major changes are:
    fix adduser / addshare prompting on musl libc
    fix use of veto files as global share parameter
    lookup primary group and don't recurse in ksmbd.conf @group handling
    fix a leak and an intermittent auth failure in Kerberos 5
    add global parameter kerberos support

detailed changelog here: https://github.com/cifsd-team/ksmbd-tools/releases/tag/3.5.3

Signed-off-by: Andrea Pesaresi <andreapesaresi82@gmail.com>
(cherry picked from commit 5b058c9949b3e3adcbc35347aa1acc40c3442e2c)
---
 net/ksmbd-tools/Makefile               | 4 ++--
 net/ksmbd-tools/patches/030-glib.patch | 2 +-
 2 files changed, 3 insertions(+), 3 deletions(-)

diff --git a/feeds/packages/net/ksmbd-tools/Makefile b/feeds/packages/net/ksmbd-tools/Makefile
index 4c1b85663b8c2..a08fe368cbce8 100644
--- a/feeds/packages/net/ksmbd-tools/Makefile
+++ b/feeds/packages/net/ksmbd-tools/Makefile
@@ -1,12 +1,12 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=ksmbd-tools
-PKG_VERSION:=3.5.2
+PKG_VERSION:=3.5.3
 PKG_RELEASE:=1
 
 PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.gz
 PKG_SOURCE_URL:=https://github.com/cifsd-team/ksmbd-tools/releases/download/$(PKG_VERSION)
-PKG_HASH:=5da7fb4cb4368f9abf56f6f9fbc17b25e387876bed9ff7ee0d6f1140ef07c8d7
+PKG_HASH:=e8d55cc53825170d7e5213d48a92b8251dc0d1351601283f6d0995cfd789b4d0
 
 PKG_LICENSE:=GPL-2.0-or-later
 PKG_LICENSE_FILES:=COPYING
diff --git a/feeds/packages/net/ksmbd-tools/patches/030-glib.patch b/feeds/packages/net/ksmbd-tools/patches/030-glib.patch
index 49809e9c60ab9..4b9d7a45189c4 100644
--- a/feeds/packages/net/ksmbd-tools/patches/030-glib.patch
+++ b/feeds/packages/net/ksmbd-tools/patches/030-glib.patch
@@ -3,7 +3,7 @@
 @@ -21,6 +21,7 @@ include_dirs = include_directories(
  glib_dep = dependency(
    'glib-2.0',
-   version: '>= 2.44',
+   version: '>= 2.58',
 +  static: true,
  )
  libnl_dep = dependency(
