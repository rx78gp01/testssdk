From f7d40365558f3426b85be35f1f2ba7d01df96dd0 Mon Sep 17 00:00:00 2001
From: Felix Fietkau <nbd@nbd.name>
Date: Sun, 31 Aug 2025 20:28:52 +0200
Subject: [PATCH] kernel: mtk_eth_soc: fix tx vlan tag for llc packets

When sending llc packets with vlan tx offload, the hardware fails to
actually add the tag. Deal with this by fixing it up in software.

Fixes: https://github.com/openwrt/openwrt/issues/19916
Reported-by: Thibaut VARENE <hacks@slashdirt.org>
Signed-off-by: Felix Fietkau <nbd@nbd.name>
---
diff --git a/target/linux/generic/pending-5.15/742-net-ethernet-mtk_eth_soc-fix-tx-vlan-tag-for-llc-pac.patch b/target/linux/generic/pending-5.15/742-net-ethernet-mtk_eth_soc-fix-tx-vlan-tag-for-llc-pac.patch
new file mode 100644
index 00000000000000..7e90a79e5bfe0d
--- /dev/null
+++ b/target/linux/generic/pending-5.15/742-net-ethernet-mtk_eth_soc-fix-tx-vlan-tag-for-llc-pac.patch
@@ -0,0 +1,39 @@
+From: Felix Fietkau <nbd@nbd.name>
+Date: Sun, 31 Aug 2025 20:05:13 +0200
+Subject: [PATCH] net: ethernet: mtk_eth_soc: fix tx vlan tag for llc packets
+
+When sending llc packets with vlan tx offload, the hardware fails to
+actually add the tag. Deal with this by fixing it up in software.
+
+Fixes: 656e705243fd ("net-next: mediatek: add support for MT7623 ethernet")
+Reported-by: Thibaut VARENE <hacks@slashdirt.org>
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+
+--- a/drivers/net/ethernet/mediatek/mtk_eth_soc.c
++++ b/drivers/net/ethernet/mediatek/mtk_eth_soc.c
+@@ -1773,6 +1773,13 @@ static netdev_tx_t mtk_start_xmit(struct
+ 	bool gso = false;
+ 	int tx_num;
+ 
++	if (skb_vlan_tag_present(skb) &&
++	    !eth_proto_is_802_3(eth_hdr(skb)->h_proto)) {
++		skb = __vlan_hwaccel_push_inside(skb);
++		if (!skb)
++			goto dropped;
++	}
++
+ 	/* normally we can rely on the stack not calling this more than once,
+ 	 * however we have 2 queues running on the same ring so we need to lock
+ 	 * the ring access
+@@ -1836,8 +1843,9 @@ static netdev_tx_t mtk_start_xmit(struct
+ 
+ drop:
+ 	spin_unlock(&eth->page_lock);
+-	stats->tx_dropped++;
+ 	dev_kfree_skb_any(skb);
++dropped:
++	stats->tx_dropped++;
+ 	return NETDEV_TX_OK;
+ }
+ 
