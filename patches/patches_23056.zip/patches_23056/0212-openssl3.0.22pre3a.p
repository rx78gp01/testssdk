diff --git a/package/libs/openssl/patches/0013-Enforce-RFC-8446-ticket-lifetime-limit-for-TLS-1.3-c.patch b/package/libs/openssl/patches/0013-Enforce-RFC-8446-ticket-lifetime-limit-for-TLS-1.3-c.patch
new file mode 100644
index 0000000..5c69a52
--- /dev/null
+++ b/package/libs/openssl/patches/0013-Enforce-RFC-8446-ticket-lifetime-limit-for-TLS-1.3-c.patch
@@ -0,0 +1,70 @@
+From 7e82c32134aa39888c7d1af4c65a6bc7a648a07a Mon Sep 17 00:00:00 2001
+From: Abel Tom <abeltom.kernel@gmail.com>
+Date: Wed, 17 Jun 2026 09:56:46 +0200
+Subject: [PATCH 13/41] Enforce RFC 8446 ticket lifetime limit for TLS 1.3
+ client
+
+Add client-side validation to check if session ticket lifetime
+hints exceeds 7 days in TLS1.3 connections and caps it to the
+maximum value of 7 days(604800 seconds).
+
+Modified `CHANGES.md` with the description of updated change.
+
+Resolves: #30808
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Thu Jun 18 12:25:33 2026
+(Merged from https://github.com/openssl/openssl/pull/31174)
+
+(cherry picked from commit 5a85e4152d817749400b0e30ebbbcce738fbfbb5)
+---
+ CHANGES.md               | 12 +++++++++++-
+ ssl/statem/statem_clnt.c |  8 ++++++++
+ 2 files changed, 19 insertions(+), 1 deletion(-)
+
+diff --git a/CHANGES.md b/CHANGES.md
+index b5597f6f70..e71ac7d014 100644
+--- a/CHANGES.md
++++ b/CHANGES.md
+@@ -30,7 +30,17 @@ breaking changes, and mappings for the large list of deprecated functions.
+ 
+ ### Changes between 3.0.21 and 3.0.22 [xx XXX xxxx]
+ 
+- * none yet
++ * Add client-side validation for TLS 1.3 session ticket lifetimes.
++
++   In accordance with [RFC 8446 Section 4.6.1](https://datatracker.ietf.org/doc/html/rfc8446#section-4.6.1),
++   TLS 1.3 clients must not cache session tickets
++   for longer than 7 days (604800 seconds).
++   When processing a new session ticket message with a
++   `ticket_lifetime_hint` value greater than 7 days,
++   the client now caps the lifetime to the
++   maximum permitted value of 7 days (604800 seconds).
++
++   *Abel Thomas*
+ 
+ ### Changes between 3.0.20 and 3.0.21 [9 Jun 2026]
+ 
+diff --git a/ssl/statem/statem_clnt.c b/ssl/statem/statem_clnt.c
+index 4b5f966e5e..f1d8b3d932 100644
+--- a/ssl/statem/statem_clnt.c
++++ b/ssl/statem/statem_clnt.c
+@@ -2540,6 +2540,14 @@ MSG_PROCESS_RETURN tls_process_new_session_ticket(SSL *s, PACKET *pkt)
+     if (SSL_IS_TLS13(s)) {
+         PACKET extpkt;
+ 
++        /*
++         * Fulfilling RFC8446:4.6.1 requirement: Clients MUST NOT cache
++         * tickets for longer than 7 days.
++         */
++        if (ticket_lifetime_hint > 604800) {
++            ticket_lifetime_hint = 604800;
++        }
++
+         if (!PACKET_as_length_prefixed_2(pkt, &extpkt)
+             || PACKET_remaining(pkt) != 0) {
+             SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0014-Fix-failure-checking-on-thread_local-storage-assignm.patch b/package/libs/openssl/patches/0014-Fix-failure-checking-on-thread_local-storage-assignm.patch
new file mode 100644
index 0000000..7a55c6e
--- /dev/null
+++ b/package/libs/openssl/patches/0014-Fix-failure-checking-on-thread_local-storage-assignm.patch
@@ -0,0 +1,80 @@
+From 57c4d0721e2a93514db0992c16e40220cb2d97e0 Mon Sep 17 00:00:00 2001
+From: Neil Horman <nhorman@openssl.org>
+Date: Wed, 10 Jun 2026 09:37:20 +0200
+Subject: [PATCH 14/41] Fix failure checking on thread_local storage assignment
+ in rand_lib
+
+The new malloc failure test caught an asan error in this code:
+Direct leak of 40 byte(s) in 1 object(s) allocated from:
+2025-08-07T03:22:20.3655117Z     #0 0x7fb88d8fd9c7 in malloc ../../../../src/libsanitizer/asan/asan_malloc_linux.cpp:69
+2025-08-07T03:22:20.3655796Z     #1 0x5584f0e4670a in CRYPTO_malloc crypto/mem.c:211
+2025-08-07T03:22:20.3656291Z     #2 0x5584f0e4679d in CRYPTO_zalloc crypto/mem.c:231
+2025-08-07T03:22:20.3657040Z     #3 0x5584f11c4c10 in EVP_RAND_CTX_new crypto/evp/evp_rand.c:353
+2025-08-07T03:22:20.3657656Z     #4 0x5584f0e93b27 in rand_new_drbg crypto/rand/rand_lib.c:666
+2025-08-07T03:22:20.3658289Z     #5 0x5584f0e949d0 in rand_get0_public crypto/rand/rand_lib.c:843
+2025-08-07T03:22:20.3658914Z     #6 0x5584f0e9305b in RAND_bytes_ex crypto/rand/rand_lib.c:490
+2025-08-07T03:22:20.3659486Z     #7 0x5584f0b2405f in SSL_CTX_new_ex ssl/ssl_lib.c:4191
+2025-08-07T03:22:20.3660183Z     #8 0x5584f0ae313c in create_ssl_ctx_pair test/helpers/ssltestlib.c:958
+2025-08-07T03:22:20.3660871Z     #9 0x5584f0adeaf6 in do_handshake test/handshake-memfail.c:56
+2025-08-07T03:22:20.3661539Z     #10 0x5584f0adee50 in test_alloc_failures test/handshake-memfail.c:125
+2025-08-07T03:22:20.3662161Z     #11 0x5584f0cd9da8 in run_tests test/testutil/driver.c:342
+2025-08-07T03:22:20.3662664Z     #12 0x5584f0cda9e5 in main test/testutil/main.c:31
+2025-08-07T03:22:20.3663450Z     #13 0x7fb88d42a1c9  (/lib/x86_64-linux-gnu/libc.so.6+0x2a1c9) (BuildId: 282c2c16e7b6600b0b22ea0c99010d2795752b5f)
+2025-08-07T03:22:20.3664630Z     #14 0x7fb88d42a28a in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2a28a) (BuildId: 282c2c16e7b6600b0b22ea0c99010d2795752b5f)
+2025-08-07T03:22:20.3666608Z     #15 0x5584f0ade864 in _start (/home/runner/work/openssl/openssl/test/handshake-memfail+0x22a864) (BuildId: 19659a44d8bed2c082918d25425f77e3a98df534)
+
+It occurs because when rand_get0_public/rand_get0_private sets an
+EVP_RAND_CTX object in its thread local storage, it neglects to check
+the return code of the operation, which may fail when the associated
+sparse array is expanded.
+
+fix it by checking the return code and failing the get0_[public|private]
+operation so the failure is graceful.
+
+Fixes: https://github.com/openssl/openssl/issues/31375
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+(cherry picked from commit 7f780be21608a2982cdf1c567e5afeb724b1e9a1)
+
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Thu Jun 18 12:38:33 2026
+(Merged from https://github.com/openssl/openssl/pull/31442)
+
+(cherry picked from commit 316bb2015ed4a704f23e99b4db4485b6d0247909)
+---
+ crypto/rand/rand_lib.c | 10 ++++++++--
+ 1 file changed, 8 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/rand/rand_lib.c b/crypto/rand/rand_lib.c
+index aca26cc6f9..cc70e2c6b1 100644
+--- a/crypto/rand/rand_lib.c
++++ b/crypto/rand/rand_lib.c
+@@ -696,7 +696,10 @@ EVP_RAND_CTX *RAND_get0_public(OSSL_LIB_CTX *ctx)
+             return NULL;
+         rand = rand_new_drbg(ctx, primary, SECONDARY_RESEED_INTERVAL,
+             SECONDARY_RESEED_TIME_INTERVAL);
+-        CRYPTO_THREAD_set_local(&dgbl->public, rand);
++        if (!CRYPTO_THREAD_set_local(&dgbl->public, rand)) {
++            EVP_RAND_CTX_free(rand);
++            rand = NULL;
++        }
+     }
+     return rand;
+ }
+@@ -729,7 +732,10 @@ EVP_RAND_CTX *RAND_get0_private(OSSL_LIB_CTX *ctx)
+             return NULL;
+         rand = rand_new_drbg(ctx, primary, SECONDARY_RESEED_INTERVAL,
+             SECONDARY_RESEED_TIME_INTERVAL);
+-        CRYPTO_THREAD_set_local(&dgbl->private, rand);
++        if (!CRYPTO_THREAD_set_local(&dgbl->private, rand)) {
++            EVP_RAND_CTX_free(rand);
++            rand = NULL;
++        }
+     }
+     return rand;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0015-Fix-spelling-mistakes-in-documentation.patch b/package/libs/openssl/patches/0015-Fix-spelling-mistakes-in-documentation.patch
new file mode 100644
index 0000000..b5518f3
--- /dev/null
+++ b/package/libs/openssl/patches/0015-Fix-spelling-mistakes-in-documentation.patch
@@ -0,0 +1,71 @@
+From 77f31ba332d772e72f03ef62662d0cfd24a9056e Mon Sep 17 00:00:00 2001
+From: Carlo Deutschmann <deutschmanncarlo@gmail.com>
+Date: Thu, 18 Jun 2026 19:36:47 +0200
+Subject: [PATCH 15/41] Fix spelling mistakes in documentation
+
+Correct a number of typos found in the man pages:
+ * doc/man7/openssl-core_dispatch.h.pod:    dipatch    -> dispatch
+ * doc/man3/BIO_s_datagram.pod:             hecause    -> because
+ * doc/man3/ASN1_aux_cb.pod:                auxiliarly -> auxiliary
+
+CLA: trivial
+Fixes: 3d9d1ce52904 "Add documentation for newly added ASN1 functions"
+Fixes: 408622b73a18 "BIO_s_dgram: add documentation and hazard warnings"
+Fixes: 329b2a2cde48 "DOCS: add openssl-core_numbers.h(7)"
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Kurt Roeckx <kurt@roeckx.be>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Sun Jun 21 22:50:14 2026
+(Merged from https://github.com/openssl/openssl/pull/31596)
+
+(cherry picked from commit 7a5476687ef1b1efd14fabb05f0a05ba494d1c1e)
+---
+ doc/man3/ASN1_aux_cb.pod             | 2 +-
+ doc/man3/BIO_s_datagram.pod          | 2 +-
+ doc/man7/openssl-core_dispatch.h.pod | 2 +-
+ 3 files changed, 3 insertions(+), 3 deletions(-)
+
+diff --git a/doc/man3/ASN1_aux_cb.pod b/doc/man3/ASN1_aux_cb.pod
+index 9963ea1350..68b230ca1a 100644
+--- a/doc/man3/ASN1_aux_cb.pod
++++ b/doc/man3/ASN1_aux_cb.pod
+@@ -59,7 +59,7 @@ Arbitrary application data
+ 
+ =item I<flags>
+ 
+-Flags which indicate the auxiliarly functionality supported.
++Flags which indicate the auxiliary functionality supported.
+ 
+ The B<ASN1_AFLG_REFCOUNT> flag indicates that objects support reference counting.
+ 
+diff --git a/doc/man3/BIO_s_datagram.pod b/doc/man3/BIO_s_datagram.pod
+index f5bdd831cf..b36bba0221 100644
+--- a/doc/man3/BIO_s_datagram.pod
++++ b/doc/man3/BIO_s_datagram.pod
+@@ -58,7 +58,7 @@ the underlying socket is configured and how it is to be used; see below.
+ 
+ =item
+ 
+-Use of BIO_s_datagram() with an unconnected network socket is hazardous hecause
++Use of BIO_s_datagram() with an unconnected network socket is hazardous because
+ any successful call to BIO_read() results in the peer address used for any
+ subsequent call to BIO_write() being set to the source address of the datagram
+ received by that call to BIO_read(). Thus, unless the caller calls
+diff --git a/doc/man7/openssl-core_dispatch.h.pod b/doc/man7/openssl-core_dispatch.h.pod
+index a19e1331fa..7f99fe2a81 100644
+--- a/doc/man7/openssl-core_dispatch.h.pod
++++ b/doc/man7/openssl-core_dispatch.h.pod
+@@ -24,7 +24,7 @@ are named as follows:
+ 
+ These macros have the form C<OSSL_OP_I<opname>>.
+ 
+-=item dipatch numbers
++=item dispatch numbers
+ 
+ These macros have the form C<OSSL_FUNC_I<opname>_I<funcname>>, where
+ C<I<opname>> is the same as in the macro for the operation this
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0016-crypto-pkcs7-pk7_lib.c-fix-return-value-in-PKCS7_set.patch b/package/libs/openssl/patches/0016-crypto-pkcs7-pk7_lib.c-fix-return-value-in-PKCS7_set.patch
new file mode 100644
index 0000000..7582875
--- /dev/null
+++ b/package/libs/openssl/patches/0016-crypto-pkcs7-pk7_lib.c-fix-return-value-in-PKCS7_set.patch
@@ -0,0 +1,40 @@
+From 947658bbcb2c3dc7f2539e1e3ca34a933703f0d1 Mon Sep 17 00:00:00 2001
+From: Abel Tom <abeltom.kernel@gmail.com>
+Date: Wed, 17 Jun 2026 12:11:29 +0200
+Subject: [PATCH 16/41] crypto/pkcs7/pk7_lib.c: fix return value in
+ PKCS7_set_digest()
+
+Return 0 when the passed object to PKCS7_set_digest() is not of type PKCS7
+digest.
+
+Fixes: c5a55463892d "Add support for digested data PKCS#7 type."
+Resolves: https://github.com/openssl/openssl/issues/31551
+
+Reviewed-by: Matt Caswell <matt@openssl.foundation>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+MergeDate: Mon Jun 22 08:17:32 2026
+(Merged from https://github.com/openssl/openssl/pull/31559)
+
+(cherry picked from commit 206ec55fec48d37960e01df1e12f0ed71a200c35)
+---
+ crypto/pkcs7/pk7_lib.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/pkcs7/pk7_lib.c b/crypto/pkcs7/pk7_lib.c
+index d0fb6589b1..508700fedb 100644
+--- a/crypto/pkcs7/pk7_lib.c
++++ b/crypto/pkcs7/pk7_lib.c
+@@ -535,7 +535,7 @@ int PKCS7_set_digest(PKCS7 *p7, const EVP_MD *md)
+     }
+ 
+     ERR_raise(ERR_LIB_PKCS7, PKCS7_R_WRONG_CONTENT_TYPE);
+-    return 1;
++    return 0;
+ }
+ 
+ STACK_OF(PKCS7_SIGNER_INFO) *PKCS7_get_signer_info(PKCS7 *p7)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0017-CONTRIBUTING.md-add-the-AI-declaration-policy.patch b/package/libs/openssl/patches/0017-CONTRIBUTING.md-add-the-AI-declaration-policy.patch
new file mode 100644
index 0000000..422dad5
--- /dev/null
+++ b/package/libs/openssl/patches/0017-CONTRIBUTING.md-add-the-AI-declaration-policy.patch
@@ -0,0 +1,115 @@
+From cdbb88cb67ed9e7410d7ee2e34abd42143a493b8 Mon Sep 17 00:00:00 2001
+From: Jon Ericson <jon@jlericson.com>
+Date: Thu, 18 Jun 2026 12:14:57 -0700
+Subject: [PATCH 17/41] CONTRIBUTING.md: add the AI declaration policy
+
+References: https://github.com/openssl/general-policies/pull/85
+
+Reviewed-by: Milan Broz <mbroz@openssl.org>
+Reviewed-by: Bob Beck <beck@openssl.org>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Mon Jun 22 10:36:52 2026
+(Merged from https://github.com/openssl/openssl/pull/31604)
+
+(cherry picked from commit f23329efa0fe3785131c715849f2577bc27b128d)
+---
+ CONTRIBUTING.md | 46 ++++++++++++++++++++++++++++++++++++++--------
+ 1 file changed, 38 insertions(+), 8 deletions(-)
+
+diff --git a/CONTRIBUTING.md b/CONTRIBUTING.md
+index cced15347d..e5d7bacfb0 100644
+--- a/CONTRIBUTING.md
++++ b/CONTRIBUTING.md
+@@ -50,7 +50,37 @@ guidelines:
+         git push -f [<repository> [<branch>]]
+     ```
+ 
+- 2. All source files should start with the following text (with
++ 2. Similarly, if a non-trivial portion of a contribution was created
++    by an AI, you must declare which agent and model were used. This
++    is done by adding `Assisted-by: {agent}:{model}` below the commit
++    message:
++
++    ```
++        One-line summary of change with AI-created portions
++
++        Assisted-by: Claude:claude-sonnet-4-6
++    ```
++
++    Multiple Assisted-by trailers can be included if multiple tools were used:
++
++    ```
++        Assisted-by: Claude:claude-sonnet-4-6
++        Assisted-by: ChatGPT:gpt-4o
++        Assisted-by: GitHub Copilot:gpt-4.1
++    ```
++
++    You will need to have signed a v1.1 or later CLA in order to
++    include AI-generated content in your contribution. CLAs signed
++    after June 2026 will have the requisite clauses.
++
++    Consult the [OpenSSL AI Code and Documentation Contribution
++    Policy] if an AI model assisted with the creation of your
++    contribution.
++
++    [OpenSSL AI Code and Documentation Contribution
++    Policy]: <https://openssl-library.org/policies/general/ai-policy/>
++
++ 3. All source files should start with the following text (with
+     appropriate comment characters at the start of each line and the
+     year(s) updated):
+ 
+@@ -63,11 +93,11 @@ guidelines:
+         https://www.openssl.org/source/license.html
+     ```
+ 
+- 3. Patches should be as current as possible; expect to have to rebase
++ 4. Patches should be as current as possible; expect to have to rebase
+     often. We do not accept merge commits, you will have to remove them
+     (usually by rebasing) before it will be acceptable.
+ 
+- 4. Code provided should follow our [coding style] and [documentation policy]
++ 5. Code provided should follow our [coding style] and [documentation policy]
+     and compile without warnings.
+     There is a [Perl tool](util/check-format.pl) that helps
+     finding code formatting mistakes and other coding style nits.
+@@ -80,16 +110,16 @@ guidelines:
+     [coding style]: https://openssl-library.org/policies/technical/coding-style/
+     [documentation policy]: https://openssl-library.org/policies/technical/documentation-policy/
+ 
+- 5. When at all possible, code contributions should include tests. These can
++ 6. When at all possible, code contributions should include tests. These can
+     either be added to an existing test, or completely new.  Please see
+     [test/README.md](test/README.md) for information on the test framework.
+ 
+- 6. New features or changed functionality must include
++ 7. New features or changed functionality must include
+     documentation. Please look at the `.pod` files in `doc/man[1357]` for
+     examples of our style. Run `make doc-nits` to make sure that your
+     documentation changes are clean.
+ 
+- 7. For user visible changes (API changes, behaviour changes, ...),
++ 8. For user visible changes (API changes, behaviour changes, ...),
+     consider adding a note in [CHANGES.md](CHANGES.md).
+     This could be a summarising description of the change, and could
+     explain the grander details.
+@@ -100,7 +130,7 @@ guidelines:
+     with a specific release without having to sift through the higher
+     noise ratio in git-log.
+ 
+- 8. For larger or more important user visible changes, as well as
++ 9. For larger or more important user visible changes, as well as
+     security fixes, please add a line in [NEWS.md](NEWS.md).
+     On exception, it might be worth adding a multi-line entry (such as
+     the entry that announces all the types that became opaque with
+@@ -108,5 +138,5 @@ guidelines:
+     This file helps users get a very quick summary of what comes with a
+     specific release, to see if an upgrade is worth the effort.
+ 
+- 9. Guidelines how to integrate error output of new crypto library modules
++10. Guidelines how to integrate error output of new crypto library modules
+     can be found in [crypto/err/README.md](crypto/err/README.md).
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0018-doc-man3-ASN1_aux_cb.pod-correct-return-code-documen.patch b/package/libs/openssl/patches/0018-doc-man3-ASN1_aux_cb.pod-correct-return-code-documen.patch
new file mode 100644
index 0000000..790a803
--- /dev/null
+++ b/package/libs/openssl/patches/0018-doc-man3-ASN1_aux_cb.pod-correct-return-code-documen.patch
@@ -0,0 +1,121 @@
+From fd9909bf9a324c8f60373fc49ab7cde9e988eac5 Mon Sep 17 00:00:00 2001
+From: Bob Beck <beck@openssl.org>
+Date: Tue, 16 Jun 2026 12:49:52 -0600
+Subject: [PATCH 18/41] doc/man3/ASN1_aux_cb.pod: correct return code
+ documentation for the callbacks
+
+Attempt to make the documentation match the code.
+
+Not attempting to change what the code does at this point, it's
+all very random, and since it's been there, it is effectively established
+public API now.
+
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Mon Jun 22 11:56:58 2026
+(Merged from https://github.com/openssl/openssl/pull/31549)
+
+(cherry picked from commit bf41baa2bf3215625d44f7c0dc438ab1b2e3a3d0)
+---
+ doc/man3/ASN1_aux_cb.pod | 58 +++++++++++++++++++++++++++++++++-------
+ 1 file changed, 49 insertions(+), 9 deletions(-)
+
+diff --git a/doc/man3/ASN1_aux_cb.pod b/doc/man3/ASN1_aux_cb.pod
+index 68b230ca1a..9a38ab168f 100644
+--- a/doc/man3/ASN1_aux_cb.pod
++++ b/doc/man3/ASN1_aux_cb.pod
+@@ -106,9 +106,11 @@ During the processing of an B<ASN1_VALUE> object the callbacks set via
+ I<asn1_cb> or I<asn1_const_cb> will be invoked as a result of various events
+ indicated via the I<operation> parameter. The value of I<*in> will be the
+ B<ASN1_VALUE> object being processed based on the template in I<it>. An
+-additional operation specific parameter may be passed in I<exarg>. The currently
+-supported operations are as follows. The callbacks should return a positive
+-value on success or zero on error, unless otherwise noted below.
++additional operation specific parameter may be passed in I<exarg>. The
++currently supported operations are as follows. Unless noted otherwise below,
++the callbacks should return a positive value on success and zero on error;
++some operations recognise additional return values, and a few do not consult
++the return value at all.
+ 
+ =over 4
+ 
+@@ -130,13 +132,15 @@ I<*pval>.
+ Invoked when processing a B<CHOICE>, B<SEQUENCE> or B<NDEF_SEQUENCE> structure
+ immediately before an B<ASN1_VALUE> is freed. If the callback originally
+ constructed the B<ASN1_VALUE> via B<ASN1_OP_NEW_PRE> then it should free it at
+-this point and return 2 from the callback. Otherwise it should return 1 for
+-success or 0 on error.
++this point and return 2; the caller will then skip its normal freeing. Any
++other return value (including zero) causes the caller to proceed with normal
++freeing; the hook cannot signal an error.
+ 
+ =item B<ASN1_OP_FREE_POST>
+ 
+ Invoked when processing a B<CHOICE>, B<SEQUENCE> or B<NDEF_SEQUENCE> structure
+-immediately after B<ASN1_VALUE> sub-structures are freed.
++immediately after B<ASN1_VALUE> sub-structures are freed. The caller does not
++consult the return value from this hook.
+ 
+ =item B<ASN1_OP_D2I_PRE>
+ 
+@@ -162,7 +166,10 @@ immediately after a "i2d" operation for the B<ASN1_VALUE>.
+ 
+ Invoked when processing a B<SEQUENCE> or B<NDEF_SEQUENCE> structure immediately
+ before printing the B<ASN1_VALUE>. The I<exarg> argument will be a pointer to an
+-B<ASN1_PRINT_ARG> structure (see below).
++B<ASN1_PRINT_ARG> structure (see below). If the callback has fully printed the
++value itself it should return 2; the caller will then skip the per-field
++printing loop and the matching B<ASN1_OP_PRINT_POST> callback. Return zero on
++error or any other positive value to continue with normal printing.
+ 
+ =item B<ASN1_OP_PRINT_POST>
+ 
+@@ -260,8 +267,41 @@ The streaming I/O boundary.
+ 
+ =head1 RETURN VALUES
+ 
+-The callbacks return 0 on error and a positive value on success. Some operations
+-require specific positive success values as noted above.
++In general the callbacks return zero on error and a positive value on
++success. Several operations have additional or different return-value
++semantics, summarised here:
++
++=over 4
++
++=item *
++
++B<ASN1_OP_NEW_PRE> recognises a return of 2, meaning that the callback has
++allocated the B<ASN1_VALUE> itself and normal allocation should be skipped.
++
++=item *
++
++B<ASN1_OP_FREE_PRE> recognises a return of 2, meaning that the callback has
++freed the B<ASN1_VALUE> itself and normal freeing should be skipped. Other
++return values (including zero) cause normal freeing to proceed; the hook
++cannot signal an error.
++
++=item *
++
++B<ASN1_OP_FREE_POST>'s return value is not consulted by the caller.
++
++=item *
++
++B<ASN1_OP_PRINT_PRE> recognises a return of 2, meaning that the callback
++has printed the value itself; the caller will skip the per-field printing
++loop and the matching B<ASN1_OP_PRINT_POST> invocation.
++
++=item *
++
++B<ASN1_OP_STREAM_PRE>, B<ASN1_OP_STREAM_POST>, B<ASN1_OP_DETACHED_PRE>, and
++B<ASN1_OP_DETACHED_POST> treat any non-positive return value (zero or
++negative) as an error.
++
++=back
+ 
+ =head1 SEE ALSO
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0019-pkcs7-Fix-negative-index-handling-in-PKCS7_get_issue.patch b/package/libs/openssl/patches/0019-pkcs7-Fix-negative-index-handling-in-PKCS7_get_issue.patch
new file mode 100644
index 0000000..6c160b3
--- /dev/null
+++ b/package/libs/openssl/patches/0019-pkcs7-Fix-negative-index-handling-in-PKCS7_get_issue.patch
@@ -0,0 +1,86 @@
+From dc2dd9b917eeb7772ff03e2e784cf05e2e6c0e56 Mon Sep 17 00:00:00 2001
+From: Mounir IDRASSI <mounir.idrassi@idrix.fr>
+Date: Tue, 21 Apr 2026 10:32:50 +0900
+Subject: [PATCH 19/41] pkcs7: Fix negative index handling in
+ PKCS7_get_issuer_and_serial()
+
+Reject negative indices before looking up the recipient info stack
+entry.  This makes negative out-of-range indices match the existing
+behavior for too-large positive indices and avoids dereferencing
+a NULL recipient info.
+
+Add a regression test for the negative index case.
+
+Resolves: https://github.com/openssl/openssl/issues/30910
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: David von Oheimb <david.von.oheimb@siemens.com>
+MergeDate: Wed Jun 24 09:10:22 2026
+(Merged from https://github.com/openssl/openssl/pull/30914)
+
+(cherry picked from commit b44fd71741b7b5092c087d227b32298c7fedb520)
+---
+ crypto/pkcs7/pk7_doit.c |  2 +-
+ test/pkcs7_test.c       | 25 +++++++++++++++++++++++++
+ 2 files changed, 26 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/pkcs7/pk7_doit.c b/crypto/pkcs7/pk7_doit.c
+index ad8902f7dd..2da7cbad8e 100644
+--- a/crypto/pkcs7/pk7_doit.c
++++ b/crypto/pkcs7/pk7_doit.c
+@@ -1163,7 +1163,7 @@ PKCS7_ISSUER_AND_SERIAL *PKCS7_get_issuer_and_serial(PKCS7 *p7, int idx)
+     rsk = p7->d.signed_and_enveloped->recipientinfo;
+     if (rsk == NULL)
+         return NULL;
+-    if (sk_PKCS7_RECIP_INFO_num(rsk) <= idx)
++    if (idx < 0 || sk_PKCS7_RECIP_INFO_num(rsk) <= idx)
+         return NULL;
+     ri = sk_PKCS7_RECIP_INFO_value(rsk, idx);
+     return ri->issuer_and_serial;
+diff --git a/test/pkcs7_test.c b/test/pkcs7_test.c
+index 78f624e313..ca069fc0cc 100644
+--- a/test/pkcs7_test.c
++++ b/test/pkcs7_test.c
+@@ -15,6 +15,30 @@
+ #include "internal/nelem.h"
+ #include "testutil.h"
+ 
++static int pkcs7_issuer_and_serial_negative_idx_test(void)
++{
++    PKCS7 *p7 = NULL;
++    PKCS7_RECIP_INFO *ri = NULL;
++    int ret = 0;
++
++    if (!TEST_ptr(p7 = PKCS7_new())
++        || !TEST_true(PKCS7_set_type(p7, NID_pkcs7_signedAndEnveloped))
++        || !TEST_ptr(ri = PKCS7_RECIP_INFO_new())
++        || !TEST_true(PKCS7_add_recipient_info(p7, ri)))
++        goto end;
++    ri = NULL;
++
++    if (!TEST_ptr(PKCS7_get_issuer_and_serial(p7, 0))
++        || !TEST_ptr_null(PKCS7_get_issuer_and_serial(p7, -1)))
++        goto end;
++
++    ret = 1;
++end:
++    PKCS7_RECIP_INFO_free(ri);
++    PKCS7_free(p7);
++    return ret;
++}
++
+ #ifndef OPENSSL_NO_EC
+ static const unsigned char cert_der[] = {
+     0x30, 0x82, 0x01, 0x51, 0x30, 0x81, 0xf7, 0xa0, 0x03, 0x02, 0x01, 0x02,
+@@ -96,6 +120,7 @@ end:
+ 
+ int setup_tests(void)
+ {
++    ADD_TEST(pkcs7_issuer_and_serial_negative_idx_test);
+ #ifndef OPENSSL_NO_EC
+     ADD_TEST(pkcs7_verify_test);
+ #endif /* OPENSSL_NO_EC */
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0020-Prevent-integer-overflow-in-ASN1_mbstring_ncopy.patch b/package/libs/openssl/patches/0020-Prevent-integer-overflow-in-ASN1_mbstring_ncopy.patch
new file mode 100644
index 0000000..4855387
--- /dev/null
+++ b/package/libs/openssl/patches/0020-Prevent-integer-overflow-in-ASN1_mbstring_ncopy.patch
@@ -0,0 +1,73 @@
+From aace9bcf2efaf22094e711c77ad08bfb8c459a56 Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Mon, 15 Jun 2026 20:10:07 +0200
+Subject: [PATCH 20/41] Prevent integer overflow in ASN1_mbstring_ncopy
+
+This prevents a theoretically possible integer overflow
+in OPENSSL_malloc(outlen + 1) at the end of ASN1_mbstring_ncopy,
+when outlen is exactly INT_MAX.
+That affects conversions from MBSTRING_ASC to MBSTRING_UTF8
+and MBSTRING_UTF8 to MBSTRING_ASC,
+because a terminating zero has to be added to the result.
+And also conversions MBSTRING_BMP to MBSTRING_UTF8
+in cases when UTF8 characters 0x800..0xFFFF are encoded
+as 3-byte UTF8-characters and the resulting UTF8-string
+is exactly INT_MAX in size.
+
+Fixes: 97f6b621f7af ("Reject oversized inputs in ASN1_mbstring_ncopy()")
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Wed Jun 24 12:56:59 2026
+(Merged from https://github.com/openssl/openssl/pull/31529)
+
+(cherry picked from commit 430409b4dc66fcbf01b5b35545a91d41ede6af34)
+---
+ crypto/asn1/a_mbstr.c | 20 ++++++++++++++++----
+ 1 file changed, 16 insertions(+), 4 deletions(-)
+
+diff --git a/crypto/asn1/a_mbstr.c b/crypto/asn1/a_mbstr.c
+index 620a8f46d2..e4db21f762 100644
+--- a/crypto/asn1/a_mbstr.c
++++ b/crypto/asn1/a_mbstr.c
+@@ -51,12 +51,24 @@ int ASN1_mbstring_ncopy(ASN1_STRING **out, const unsigned char *in, int len,
+     unsigned char *p;
+     int nchar;
+     int (*cpyfunc)(unsigned long, void *) = NULL;
+-    if (len == -1)
+-        len = strlen((const char *)in);
++    if (len == -1) {
++        size_t len_s = strlen((const char *)in);
++
++        if (len_s >= INT_MAX) {
++            ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
++            return -1;
++        }
++        len = (int)len_s;
++    }
+     if (!mask)
+         mask = DIRSTRING_TYPE;
+-    if (len < 0)
++    if (len < 0) {
++        ERR_raise(ERR_LIB_ASN1, ERR_R_PASSED_INVALID_ARGUMENT);
++        return -1;
++    } else if (len >= INT_MAX) {
++        ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
+         return -1;
++    }
+ 
+     /* First do a string check and work out the number of characters */
+     switch (inform) {
+@@ -295,7 +307,7 @@ static int out_utf8(unsigned long value, void *arg)
+         return len;
+     }
+     outlen = arg;
+-    if (*outlen > INT_MAX - len) {
++    if (*outlen >= INT_MAX - len) {
+         ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
+         return -1;
+     }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0021-crypto-ctype.c-fix-off-by-one-OOB-in-ossl_toascii-os.patch b/package/libs/openssl/patches/0021-crypto-ctype.c-fix-off-by-one-OOB-in-ossl_toascii-os.patch
new file mode 100644
index 0000000..bbccce5
--- /dev/null
+++ b/package/libs/openssl/patches/0021-crypto-ctype.c-fix-off-by-one-OOB-in-ossl_toascii-os.patch
@@ -0,0 +1,49 @@
+From 53c9c524161524ccbdb99b56a26fb14cabb47104 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Tue, 23 Jun 2026 09:48:25 +0200
+Subject: [PATCH 21/41] crypto/ctype.c: fix off-by-one OOB in
+ ossl_toascii()/ossl_fromascii()
+
+Incorrect check for the upper bound allowed the value of 256 to slip
+through, which could lead to OOB read one element beyound the end
+of the os_toascii/os_toebcdic arrays.  Fix that by changing
+the comparison with 256 from strictly great to great-or-equal.
+
+Found by cppcheck.
+
+Fixes: a1df06b36347 "This has been added to avoid the situation where some host ctype.h functions return true for characters > 127.  I.e. they are allowing extended ASCII characters through which then cause problems.  E.g. marking superscript '2' as a number then causes the common (ch - '0') conversion to number to fail miserably.  Likewise letters with diacritical marks can also cause problems."
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Daniel Kubec <kubec@openssl.foundation>
+MergeDate: Thu Jun 25 07:21:08 2026
+(Merged from https://github.com/openssl/openssl/pull/31661)
+---
+ crypto/ctype.c | 4 ++--
+ 1 file changed, 2 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/ctype.c b/crypto/ctype.c
+index ed95e304c7..4f19d6002c 100644
+--- a/crypto/ctype.c
++++ b/crypto/ctype.c
+@@ -226,7 +226,7 @@ static const unsigned short ctype_char_map[128] = {
+ #ifdef CHARSET_EBCDIC
+ int ossl_toascii(int c)
+ {
+-    if (c < -128 || c > 256 || c == EOF)
++    if (c < -128 || c >= 256 || c == EOF)
+         return c;
+     /*
+      * Adjust negatively signed characters.
+@@ -241,7 +241,7 @@ int ossl_toascii(int c)
+ 
+ int ossl_fromascii(int c)
+ {
+-    if (c < -128 || c > 256 || c == EOF)
++    if (c < -128 || c >= 256 || c == EOF)
+         return c;
+     if (c < 0)
+         c += 256;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0022-CONTRIBUTING.md-tweak-wording-with-regards-to-ML-too.patch b/package/libs/openssl/patches/0022-CONTRIBUTING.md-tweak-wording-with-regards-to-ML-too.patch
new file mode 100644
index 0000000..0cd3ceb
--- /dev/null
+++ b/package/libs/openssl/patches/0022-CONTRIBUTING.md-tweak-wording-with-regards-to-ML-too.patch
@@ -0,0 +1,42 @@
+From 470ea80074b78150f73f4cf0d28870191d02555c Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 22 Jun 2026 19:46:51 +0200
+Subject: [PATCH 22/41] CONTRIBUTING.md: tweak wording with regards to ML
+ tooling usage
+
+ML tools do not satisfy the authorship requirement, so they are merely
+used, and not "create" on their own.
+
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Kurt Roeckx <kurt@roeckx.be>
+MergeDate: Thu Jun 25 07:23:34 2026
+(Merged from https://github.com/openssl/openssl/pull/31643)
+---
+ CONTRIBUTING.md | 6 +++---
+ 1 file changed, 3 insertions(+), 3 deletions(-)
+
+diff --git a/CONTRIBUTING.md b/CONTRIBUTING.md
+index e5d7bacfb0..373c69b920 100644
+--- a/CONTRIBUTING.md
++++ b/CONTRIBUTING.md
+@@ -51,12 +51,12 @@ guidelines:
+     ```
+ 
+  2. Similarly, if a non-trivial portion of a contribution was created
+-    by an AI, you must declare which agent and model were used. This
+-    is done by adding `Assisted-by: {agent}:{model}` below the commit
++    using an AI tool, you must declare which agent and model were used.
++    This is done by adding `Assisted-by: {agent}:{model}` below the commit
+     message:
+ 
+     ```
+-        One-line summary of change with AI-created portions
++        One-line summary of change with AI-generated portions
+ 
+         Assisted-by: Claude:claude-sonnet-4-6
+     ```
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0023-crypto-x509-pcy_cache.c-fix-ext_pcons-leak-in-policy.patch b/package/libs/openssl/patches/0023-crypto-x509-pcy_cache.c-fix-ext_pcons-leak-in-policy.patch
new file mode 100644
index 0000000..ddb7d6a
--- /dev/null
+++ b/package/libs/openssl/patches/0023-crypto-x509-pcy_cache.c-fix-ext_pcons-leak-in-policy.patch
@@ -0,0 +1,54 @@
+From b0e8cba529569bbed9f64eba316445f5088ade69 Mon Sep 17 00:00:00 2001
+From: 007bsd <22483432+007bsd@users.noreply.github.com>
+Date: Tue, 23 Jun 2026 21:42:29 +0300
+Subject: [PATCH 23/41] crypto/x509/pcy_cache.c: fix ext_pcons leak in
+ policy_cache_new()
+
+Two early-return paths in policy_cache_new() bypass the just_cleanup:
+label and leak the POLICY_CONSTRAINTS object ext_pcons: (1) when
+certificatePolicies is absent but policyConstraints is present, and
+(2) when policy_cache_create() returns <= 0.  Free ext_pcons before
+each early return.
+
+Assisted-by: Claude:claude-sonnet-4-6
+CLA: trivial
+Fixes: 4acc3e907d29 "Initial support for certificate policy checking and evaluation."
+
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Fri Jun 26 15:26:07 2026
+(Merged from https://github.com/openssl/openssl/pull/31678)
+
+(cherry picked from commit 1f5a44a66df44751d999fc90751ce098975f18a6)
+---
+ crypto/x509/pcy_cache.c | 5 ++++-
+ 1 file changed, 4 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/x509/pcy_cache.c b/crypto/x509/pcy_cache.c
+index 8774539537..d9f486c6dd 100644
+--- a/crypto/x509/pcy_cache.c
++++ b/crypto/x509/pcy_cache.c
+@@ -134,6 +134,7 @@ static int policy_cache_new(X509 *x)
+         /* If not absent some problem with extension */
+         if (i != -1)
+             goto bad_cache;
++        POLICY_CONSTRAINTS_free(ext_pcons);
+         return 1;
+     }
+ 
+@@ -141,8 +142,10 @@ static int policy_cache_new(X509 *x)
+ 
+     /* NB: ext_cpols freed by policy_cache_set_policies */
+ 
+-    if (i <= 0)
++    if (i <= 0) {
++        POLICY_CONSTRAINTS_free(ext_pcons);
+         return i;
++    }
+ 
+     ext_pmaps = X509_get_ext_d2i(x, NID_policy_mappings, &i, NULL);
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0024-test-evp_extra_test.c-add-test-case-for-CVE-2026-427.patch b/package/libs/openssl/patches/0024-test-evp_extra_test.c-add-test-case-for-CVE-2026-427.patch
new file mode 100644
index 0000000..8f5c7cf
--- /dev/null
+++ b/package/libs/openssl/patches/0024-test-evp_extra_test.c-add-test-case-for-CVE-2026-427.patch
@@ -0,0 +1,294 @@
+From e19e485a9ce1472e5d4b1c3362b21a8431a57b94 Mon Sep 17 00:00:00 2001
+From: Alicja Kario <hkario@redhat.com>
+Date: Tue, 16 Jun 2026 17:12:14 +0200
+Subject: [PATCH 24/41] test/evp_extra_test.c: add test case for CVE-2026-42770
+
+Signed-off-by: Alicja Kario <hkario@redhat.com>
+
+Reviewed-by: Igor Ustinov <igus@openssl.foundation>
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+MergeDate: Wed Jun 24 11:56:27 2026
+
+(cherry picked from commit 1cfec91eb67b82066ad493b1150c253231cc2a9f)
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/31702)
+
+(cherry picked from commit c8167c17c206a04efd5b81d52ee5a0d435178f9a)
+---
+ test/evp_extra_test.c | 252 ++++++++++++++++++++++++++++++++++++++++++
+ 1 file changed, 252 insertions(+)
+
+diff --git a/test/evp_extra_test.c b/test/evp_extra_test.c
+index 9b25ec6e28..ed2b924945 100644
+--- a/test/evp_extra_test.c
++++ b/test/evp_extra_test.c
+@@ -3343,6 +3343,257 @@ err:
+     return ret;
+ }
+ #endif /* !OPENSSL_NO_DEPRECATED_3_0 */
++
++/* Test that DHX (X9.42) rejects a malicious peer key during the
++ * derivation phase (specifically EVP_PKEY_derive_set_peer) when the
++ * remote 'q' does not match the local domain parameters but is still
++ * consistent with the remote key share.
++ * (CVE-2026-42770)
++ */
++static int test_dhx_derive_rejects_bad_peer_q(void)
++{
++    int ret = 0;
++    EVP_PKEY *local_key = NULL, *remote_key = NULL;
++    EVP_PKEY_CTX *pctx = NULL, *derive_ctx = NULL;
++    OSSL_PARAM_BLD *bld = NULL;
++    OSSL_PARAM *params = NULL;
++
++    BIGNUM *p = NULL, *g = NULL;
++    BIGNUM *q_valid = NULL, *pub_local = NULL, *priv_local = NULL;
++    BIGNUM *q_bad = NULL, *pub_bad = NULL;
++
++    static const unsigned char bin_p[] = {
++        0x87, 0xa8, 0xe6, 0x1d, 0xb4, 0xb6, 0x66, 0x3c,
++        0xff, 0xbb, 0xd1, 0x9c, 0x65, 0x19, 0x59, 0x99,
++        0x8c, 0xee, 0xf6, 0x08, 0x66, 0x0d, 0xd0, 0xf2,
++        0x5d, 0x2c, 0xee, 0xd4, 0x43, 0x5e, 0x3b, 0x00,
++        0xe0, 0x0d, 0xf8, 0xf1, 0xd6, 0x19, 0x57, 0xd4,
++        0xfa, 0xf7, 0xdf, 0x45, 0x61, 0xb2, 0xaa, 0x30,
++        0x16, 0xc3, 0xd9, 0x11, 0x34, 0x09, 0x6f, 0xaa,
++        0x3b, 0xf4, 0x29, 0x6d, 0x83, 0x0e, 0x9a, 0x7c,
++        0x20, 0x9e, 0x0c, 0x64, 0x97, 0x51, 0x7a, 0xbd,
++        0x5a, 0x8a, 0x9d, 0x30, 0x6b, 0xcf, 0x67, 0xed,
++        0x91, 0xf9, 0xe6, 0x72, 0x5b, 0x47, 0x58, 0xc0,
++        0x22, 0xe0, 0xb1, 0xef, 0x42, 0x75, 0xbf, 0x7b,
++        0x6c, 0x5b, 0xfc, 0x11, 0xd4, 0x5f, 0x90, 0x88,
++        0xb9, 0x41, 0xf5, 0x4e, 0xb1, 0xe5, 0x9b, 0xb8,
++        0xbc, 0x39, 0xa0, 0xbf, 0x12, 0x30, 0x7f, 0x5c,
++        0x4f, 0xdb, 0x70, 0xc5, 0x81, 0xb2, 0x3f, 0x76,
++        0xb6, 0x3a, 0xca, 0xe1, 0xca, 0xa6, 0xb7, 0x90,
++        0x2d, 0x52, 0x52, 0x67, 0x35, 0x48, 0x8a, 0x0e,
++        0xf1, 0x3c, 0x6d, 0x9a, 0x51, 0xbf, 0xa4, 0xab,
++        0x3a, 0xd8, 0x34, 0x77, 0x96, 0x52, 0x4d, 0x8e,
++        0xf6, 0xa1, 0x67, 0xb5, 0xa4, 0x18, 0x25, 0xd9,
++        0x67, 0xe1, 0x44, 0xe5, 0x14, 0x05, 0x64, 0x25,
++        0x1c, 0xca, 0xcb, 0x83, 0xe6, 0xb4, 0x86, 0xf6,
++        0xb3, 0xca, 0x3f, 0x79, 0x71, 0x50, 0x60, 0x26,
++        0xc0, 0xb8, 0x57, 0xf6, 0x89, 0x96, 0x28, 0x56,
++        0xde, 0xd4, 0x01, 0x0a, 0xbd, 0x0b, 0xe6, 0x21,
++        0xc3, 0xa3, 0x96, 0x0a, 0x54, 0xe7, 0x10, 0xc3,
++        0x75, 0xf2, 0x63, 0x75, 0xd7, 0x01, 0x41, 0x03,
++        0xa4, 0xb5, 0x43, 0x30, 0xc1, 0x98, 0xaf, 0x12,
++        0x61, 0x16, 0xd2, 0x27, 0x6e, 0x11, 0x71, 0x5f,
++        0x69, 0x38, 0x77, 0xfa, 0xd7, 0xef, 0x09, 0xca,
++        0xdb, 0x09, 0x4a, 0xe9, 0x1e, 0x1a, 0x15, 0x97
++    };
++    static const unsigned char bin_g[] = {
++        0x3F, 0xB3, 0x2C, 0x9B, 0x73, 0x13, 0x4D, 0x0B,
++        0x2E, 0x77, 0x50, 0x66, 0x60, 0xED, 0xBD, 0x48,
++        0x4C, 0xA7, 0xB1, 0x8F, 0x21, 0xEF, 0x20, 0x54,
++        0x07, 0xF4, 0x79, 0x3A, 0x1A, 0x0B, 0xA1, 0x25,
++        0x10, 0xDB, 0xC1, 0x50, 0x77, 0xBE, 0x46, 0x3F,
++        0xFF, 0x4F, 0xED, 0x4A, 0xAC, 0x0B, 0xB5, 0x55,
++        0xBE, 0x3A, 0x6C, 0x1B, 0x0C, 0x6B, 0x47, 0xB1,
++        0xBC, 0x37, 0x73, 0xBF, 0x7E, 0x8C, 0x6F, 0x62,
++        0x90, 0x12, 0x28, 0xF8, 0xC2, 0x8C, 0xBB, 0x18,
++        0xA5, 0x5A, 0xE3, 0x13, 0x41, 0x00, 0x0A, 0x65,
++        0x01, 0x96, 0xF9, 0x31, 0xC7, 0x7A, 0x57, 0xF2,
++        0xDD, 0xF4, 0x63, 0xE5, 0xE9, 0xEC, 0x14, 0x4B,
++        0x77, 0x7D, 0xE6, 0x2A, 0xAA, 0xB8, 0xA8, 0x62,
++        0x8A, 0xC3, 0x76, 0xD2, 0x82, 0xD6, 0xED, 0x38,
++        0x64, 0xE6, 0x79, 0x82, 0x42, 0x8E, 0xBC, 0x83,
++        0x1D, 0x14, 0x34, 0x8F, 0x6F, 0x2F, 0x91, 0x93,
++        0xB5, 0x04, 0x5A, 0xF2, 0x76, 0x71, 0x64, 0xE1,
++        0xDF, 0xC9, 0x67, 0xC1, 0xFB, 0x3F, 0x2E, 0x55,
++        0xA4, 0xBD, 0x1B, 0xFF, 0xE8, 0x3B, 0x9C, 0x80,
++        0xD0, 0x52, 0xB9, 0x85, 0xD1, 0x82, 0xEA, 0x0A,
++        0xDB, 0x2A, 0x3B, 0x73, 0x13, 0xD3, 0xFE, 0x14,
++        0xC8, 0x48, 0x4B, 0x1E, 0x05, 0x25, 0x88, 0xB9,
++        0xB7, 0xD2, 0xBB, 0xD2, 0xDF, 0x01, 0x61, 0x99,
++        0xEC, 0xD0, 0x6E, 0x15, 0x57, 0xCD, 0x09, 0x15,
++        0xB3, 0x35, 0x3B, 0xBB, 0x64, 0xE0, 0xEC, 0x37,
++        0x7F, 0xD0, 0x28, 0x37, 0x0D, 0xF9, 0x2B, 0x52,
++        0xC7, 0x89, 0x14, 0x28, 0xCD, 0xC6, 0x7E, 0xB6,
++        0x18, 0x4B, 0x52, 0x3D, 0x1D, 0xB2, 0x46, 0xC3,
++        0x2F, 0x63, 0x07, 0x84, 0x90, 0xF0, 0x0E, 0xF8,
++        0xD6, 0x47, 0xD1, 0x48, 0xD4, 0x79, 0x54, 0x51,
++        0x5E, 0x23, 0x27, 0xCF, 0xEF, 0x98, 0xC5, 0x82,
++        0x66, 0x4B, 0x4C, 0x0F, 0x6C, 0xC4, 0x16, 0x59
++    };
++
++    static const unsigned char bin_q_valid[] = {
++        0x8C, 0xF8, 0x36, 0x42, 0xA7, 0x09, 0xA0, 0x97,
++        0xB4, 0x47, 0x99, 0x76, 0x40, 0x12, 0x9D, 0xA2,
++        0x99, 0xB1, 0xA4, 0x7D, 0x1E, 0xB3, 0x75, 0x0B,
++        0xA3, 0x08, 0xB0, 0xFE, 0x64, 0xF5, 0xFB, 0xD3
++    };
++    static const unsigned char bin_local_pub[] = {
++        0x79, 0x6e, 0x15, 0x43, 0x14, 0x70, 0xac, 0x86,
++        0xfa, 0x8a, 0x78, 0xb8, 0xbc, 0xdd, 0x1f, 0x35,
++        0x89, 0xdb, 0xf1, 0x5f, 0xfe, 0x0e, 0x0a, 0x7a,
++        0x41, 0xdd, 0x86, 0x40, 0x88, 0x7f, 0x3c, 0xc3,
++        0xf0, 0x43, 0x9e, 0x28, 0x1f, 0x4c, 0xf3, 0x80,
++        0x0b, 0xac, 0x2d, 0xbd, 0xfc, 0xda, 0x58, 0x9b,
++        0x26, 0xcc, 0x82, 0x85, 0x12, 0x08, 0x5c, 0xe0,
++        0xd3, 0xe5, 0x7a, 0xa1, 0x3c, 0xd9, 0xe7, 0xa4,
++        0x66, 0xd8, 0x81, 0xba, 0xce, 0x91, 0xed, 0x10,
++        0xc6, 0x06, 0x4a, 0xb3, 0x6e, 0x0d, 0x66, 0x36,
++        0x7c, 0x4b, 0xfe, 0xd5, 0x6a, 0x9f, 0x90, 0x7e,
++        0x4d, 0xae, 0xc1, 0x67, 0x32, 0xfb, 0x5c, 0x54,
++        0x89, 0x1c, 0xb0, 0xd2, 0x62, 0x51, 0xfd, 0x61,
++        0xc3, 0x20, 0x40, 0x77, 0x42, 0x46, 0xb3, 0xf8,
++        0xbd, 0xcd, 0x5e, 0xf6, 0x0e, 0x68, 0x47, 0xcd,
++        0xd6, 0x9b, 0xd6, 0xd3, 0x18, 0xd1, 0xcd, 0xa0,
++        0xe8, 0xa3, 0x0a, 0x71, 0x6d, 0xe4, 0xdc, 0x1a,
++        0x4e, 0xb9, 0x9b, 0x06, 0x86, 0xb7, 0x71, 0x20,
++        0xc4, 0xb6, 0x9b, 0x00, 0x05, 0xf6, 0xa8, 0xc3,
++        0xae, 0x76, 0x8d, 0x23, 0xc0, 0x8c, 0x85, 0xbd,
++        0x1d, 0x58, 0xf4, 0x0d, 0xc0, 0x13, 0x8d, 0x62,
++        0x77, 0x43, 0x61, 0x37, 0xae, 0x69, 0x77, 0x9f,
++        0xdc, 0x21, 0x8c, 0x07, 0x1c, 0x14, 0x82, 0x6f,
++        0x47, 0x15, 0x62, 0x03, 0x3e, 0x85, 0xff, 0xc9,
++        0x9a, 0x21, 0x47, 0xd5, 0x39, 0xe2, 0x74, 0x13,
++        0x6a, 0x4a, 0x1e, 0x7f, 0x1d, 0xb9, 0x75, 0x83,
++        0xb5, 0x1d, 0xc0, 0x38, 0x5a, 0x52, 0xd7, 0x38,
++        0x39, 0x63, 0x75, 0x8d, 0x89, 0x33, 0x98, 0xa8,
++        0xd0, 0x13, 0xfd, 0xba, 0xd2, 0x0d, 0xdf, 0x30,
++        0xfb, 0xe0, 0x5f, 0xbb, 0x22, 0x49, 0x91, 0x3a,
++        0xe6, 0x75, 0x1b, 0x6b, 0x24, 0x6a, 0xe5, 0x62,
++        0x2b, 0xa2, 0x6c, 0x48, 0x27, 0x41, 0x7c, 0x2d
++    };
++    static const unsigned char bin_local_priv[] = {
++        0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88,
++        0x99, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66,
++        0x77, 0x88, 0x99, 0x00, 0x11, 0x22, 0x33, 0x44,
++        0x55, 0x66, 0x77, 0x88, 0x99, 0x00, 0x11, 0x22
++    };
++
++    /* Remote malicious parameters */
++    static const unsigned char bin_remote_q[] = { 0x09, 0xf5 };
++    static const unsigned char bin_remote_pub[] = {
++        0x54, 0xc0, 0x57, 0x90, 0x3d, 0x36, 0x22, 0x35,
++        0xa6, 0x5c, 0x03, 0xf0, 0x01, 0xd8, 0xa3, 0xea,
++        0x25, 0x28, 0x36, 0xb3, 0x58, 0x02, 0x50, 0xab,
++        0xdc, 0x0a, 0x10, 0x83, 0x45, 0x1a, 0xf0, 0x12,
++        0x6f, 0xd1, 0x50, 0xf9, 0xe8, 0xd2, 0x12, 0xb3,
++        0x84, 0xae, 0x0c, 0x23, 0xaa, 0x7c, 0x67, 0xfe,
++        0x85, 0x13, 0x68, 0x11, 0x4c, 0xcc, 0x06, 0x1a,
++        0x66, 0x1e, 0x98, 0x6b, 0xd7, 0xe6, 0x3d, 0x25,
++        0x75, 0x13, 0x33, 0x9a, 0x69, 0x14, 0xcb, 0xfa,
++        0xb2, 0x09, 0xad, 0x79, 0x3e, 0xf2, 0x57, 0x04,
++        0xcd, 0x53, 0x2d, 0xdf, 0xb7, 0xe6, 0x93, 0xde,
++        0x70, 0x1d, 0x17, 0xe6, 0x29, 0xef, 0x3c, 0x18,
++        0x4d, 0x40, 0xd5, 0xfe, 0xa1, 0xf9, 0xed, 0xb8,
++        0x9c, 0x5b, 0xf8, 0xd7, 0xaa, 0x19, 0xe3, 0x37,
++        0x4f, 0x80, 0x59, 0x32, 0x15, 0x9c, 0xa7, 0xb5,
++        0xd5, 0x73, 0xb9, 0xe2, 0xf3, 0xc9, 0x4f, 0xe7,
++        0x47, 0xc4, 0xa3, 0xb0, 0x9e, 0x31, 0xaf, 0xa3,
++        0x78, 0x8d, 0x35, 0x83, 0x3a, 0xaf, 0x2a, 0xc8,
++        0xae, 0x8b, 0xc4, 0x85, 0x00, 0x13, 0x14, 0x64,
++        0xe7, 0x93, 0xa2, 0xe0, 0x35, 0x2e, 0x7c, 0x3e,
++        0xd9, 0xda, 0x9f, 0xcf, 0x89, 0xb1, 0x21, 0xbc,
++        0x1c, 0xee, 0x83, 0xc5, 0x44, 0x21, 0x4c, 0xeb,
++        0x33, 0x38, 0xb1, 0x4a, 0xc6, 0x89, 0x19, 0x68,
++        0x35, 0x17, 0x46, 0xea, 0xf6, 0x2b, 0xb5, 0x17,
++        0xeb, 0x98, 0xfc, 0x63, 0x3d, 0x8d, 0x23, 0x5b,
++        0xac, 0x37, 0xbc, 0x08, 0xe4, 0x7f, 0x18, 0x51,
++        0xd0, 0x55, 0x01, 0x94, 0x9a, 0x67, 0x33, 0x96,
++        0x5a, 0xdb, 0xfe, 0x8e, 0x43, 0xf7, 0xc3, 0xb9,
++        0x3c, 0xa7, 0x51, 0x5c, 0xd6, 0xab, 0x36, 0xd7,
++        0xef, 0x26, 0xbb, 0x0f, 0xd6, 0x03, 0x3a, 0xbc,
++        0x39, 0x61, 0x3e, 0x88, 0x0f, 0xff, 0xc8, 0x72,
++        0x9b, 0x03, 0xbf, 0xea, 0xdd, 0xf0, 0x88, 0x33
++    };
++
++    if (!TEST_ptr(p = BN_bin2bn(bin_p, sizeof(bin_p), NULL))
++        || !TEST_ptr(g = BN_bin2bn(bin_g, sizeof(bin_g), NULL)))
++        goto err;
++
++    if (!TEST_ptr(q_valid = BN_bin2bn(bin_q_valid, sizeof(bin_q_valid), NULL))
++        || !TEST_ptr(pub_local
++            = BN_bin2bn(bin_local_pub, sizeof(bin_local_pub), NULL))
++        || !TEST_true(priv_local
++            = BN_bin2bn(bin_local_priv, sizeof(bin_local_priv), NULL)))
++        goto err;
++
++    if (!TEST_ptr(bld = OSSL_PARAM_BLD_new())
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_P, p))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_Q, q_valid))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_G, g))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_PUB_KEY, pub_local))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_PRIV_KEY, priv_local))
++        || !TEST_ptr(params = OSSL_PARAM_BLD_to_param(bld)))
++        goto err;
++
++    if (!TEST_ptr(pctx = EVP_PKEY_CTX_new_from_name(testctx, "DHX", testpropq))
++        || !TEST_int_gt(EVP_PKEY_fromdata_init(pctx), 0)
++        || !TEST_int_gt(EVP_PKEY_fromdata(pctx, &local_key, EVP_PKEY_KEYPAIR, params), 0))
++        goto err;
++
++    OSSL_PARAM_free(params);
++    OSSL_PARAM_BLD_free(bld);
++    EVP_PKEY_CTX_free(pctx);
++    params = NULL;
++    bld = NULL;
++    pctx = NULL;
++
++    if (!TEST_ptr(q_bad = BN_bin2bn(bin_remote_q, sizeof(bin_remote_q), NULL))
++        || !TEST_ptr(pub_bad
++            = BN_bin2bn(bin_remote_pub, sizeof(bin_remote_pub), NULL)))
++        goto err;
++
++    if (!TEST_ptr(bld = OSSL_PARAM_BLD_new())
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_P, p))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_Q, q_bad))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_FFC_G, g))
++        || !TEST_true(OSSL_PARAM_BLD_push_BN(bld, OSSL_PKEY_PARAM_PUB_KEY, pub_bad))
++        || !TEST_ptr(params = OSSL_PARAM_BLD_to_param(bld)))
++        goto err;
++
++    if (!TEST_ptr(pctx = EVP_PKEY_CTX_new_from_name(testctx, "DHX", testpropq))
++        || !TEST_int_gt(EVP_PKEY_fromdata_init(pctx), 0)
++        || !TEST_int_gt(EVP_PKEY_fromdata(pctx, &remote_key, EVP_PKEY_PUBLIC_KEY, params), 0))
++        goto err;
++
++    if (!TEST_ptr(derive_ctx = EVP_PKEY_CTX_new(local_key, NULL))
++        || !TEST_int_gt(EVP_PKEY_derive_init(derive_ctx), 0))
++        goto err;
++
++    /* reject the remote key share, even if it is self-consistent, correct
++     * code needs to use local q, not remote-provided q. */
++    if (!TEST_int_le(EVP_PKEY_derive_set_peer(derive_ctx, remote_key), 0)) {
++        TEST_error("EVP_PKEY_derive_set_peer incorrectly accepted a peer with malicious 'q'");
++        goto err;
++    }
++
++    ret = 1;
++
++err:
++    BN_free(p);
++    BN_free(g);
++    BN_free(q_valid);
++    BN_free(pub_local);
++    BN_free(priv_local);
++    BN_free(q_bad);
++    BN_free(pub_bad);
++    OSSL_PARAM_free(params);
++    OSSL_PARAM_BLD_free(bld);
++    EVP_PKEY_CTX_free(pctx);
++    EVP_PKEY_CTX_free(derive_ctx);
++    EVP_PKEY_free(local_key);
++    EVP_PKEY_free(remote_key);
++    return ret;
++}
+ #endif /* !OPENSSL_NO_DH */
+ 
+ /*
+@@ -6064,6 +6315,7 @@ int setup_tests(void)
+ #ifndef OPENSSL_NO_DEPRECATED_3_0
+     ADD_TEST(test_EVP_PKEY_set1_DH);
+ #endif
++    ADD_TEST(test_dhx_derive_rejects_bad_peer_q);
+ #endif
+ #ifndef OPENSSL_NO_EC
+     ADD_TEST(test_EC_priv_pub);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0025-ensure-writes-are-syncronized-on-windows-in-CRYPTO_T.patch b/package/libs/openssl/patches/0025-ensure-writes-are-syncronized-on-windows-in-CRYPTO_T.patch
new file mode 100644
index 0000000..b0825c5
--- /dev/null
+++ b/package/libs/openssl/patches/0025-ensure-writes-are-syncronized-on-windows-in-CRYPTO_T.patch
@@ -0,0 +1,59 @@
+From 9c893486e51ffba2a3ad0cf7d54825076bab8c3c Mon Sep 17 00:00:00 2001
+From: Neil Horman <nhorman@openssl.org>
+Date: Wed, 24 Jun 2026 15:55:48 -0400
+Subject: [PATCH 25/41] ensure writes are syncronized on windows in
+ CRYPTO_THREAD_run_once
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+We've tried to fix this properly using InitOnceExecuteOnce, but it
+results in an ABI breakage, so we're doing it this way.
+
+on windows, CRYPTO_THREAD_run_once, on weakly memory ordered systems,
+may complete the write of the run once variable lock before some of the
+writes made by the init callback routine complete.  The result is that
+on a heavily multithreaded application, other therads may see the data
+that was meant to be in an initalized state, as in some erroneous
+in-between state, leading to errors.
+
+Fix it by inserting a full memory barrier after we return from the init
+callback, and prior to setting the run once variable to ONCE_DONE.
+
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Tue Jun 30 08:52:22 2026
+(Merged from https://github.com/openssl/openssl/pull/31713)
+---
+ crypto/threads_win.c | 14 ++++++++++++++
+ 1 file changed, 14 insertions(+)
+
+diff --git a/crypto/threads_win.c b/crypto/threads_win.c
+index bc7f77f2ab..7ce97c435a 100644
+--- a/crypto/threads_win.c
++++ b/crypto/threads_win.c
+@@ -143,6 +143,20 @@ int CRYPTO_THREAD_run_once(CRYPTO_ONCE *once, void (*init)(void))
+         result = InterlockedCompareExchange(lock, ONCE_ININIT, ONCE_UNINITED);
+         if (result == ONCE_UNINITED) {
+             init();
++            /*
++             * On weakly ordered systems, it may happen that the write to *lock
++             * below completes prior to some writes in whatever the init()
++             * callback routine above may do.  In this case, other threads
++             * entering here may see unsynchronized data in whatever the init
++             * routine initializes, leading to erroneous behavior.
++             *
++             * We should use InitOnceExecuteOnce here to implement this, but
++             * doing so requires that we modify the definition of the
++             * CRYPTO_ONCE type, which is an ABI breakage.  So instead
++             * just insert a memory barrier here to ensure that any pending
++             * writes are flushed to memory prior to setting ONCE_DONE below
++             */
++            MemoryBarrier();
+             *lock = ONCE_DONE;
+             return 1;
+         }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0026-ssl3_record.c-prevent-max_early_data-overflow-in-oss.patch b/package/libs/openssl/patches/0026-ssl3_record.c-prevent-max_early_data-overflow-in-oss.patch
new file mode 100644
index 0000000..4ac9cff
--- /dev/null
+++ b/package/libs/openssl/patches/0026-ssl3_record.c-prevent-max_early_data-overflow-in-oss.patch
@@ -0,0 +1,41 @@
+From f901148128c40e3bb67de8fbedb820f6a6ed4b69 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 22 Jun 2026 07:56:45 +0200
+Subject: [PATCH 26/41] ssl3_record.c: prevent max_early_data overflow in
+ ossl_early_data_count_ok()
+
+Apply change similar to the one made in d41a9225196b "tls_common.c: prevent
+max_early_data overflow in rlayer_early_data_count_ok()"
+to ossl_early_data_count_ok(), that has similar logic in it
+(as rlayer_early_data_count_ok() has been copied
+from ossl_early_data_count_ok() in 9dd90232d537 "Move early data counting
+out of the SSL object and into the record layer").
+
+Complements: d41a9225196b "tls_common.c: prevent max_early_data overflow in rlayer_early_data_count_ok()"
+Fixes: 70ef40a05e06 "Check max_early_data against the amount of early data we actually receive"
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+MergeDate: Fri Jul  3 19:23:45 2026
+(Merged from https://github.com/openssl/openssl/pull/31726)
+---
+ ssl/record/ssl3_record.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/ssl/record/ssl3_record.c b/ssl/record/ssl3_record.c
+index 6fd2328a12..9cc15d3305 100644
+--- a/ssl/record/ssl3_record.c
++++ b/ssl/record/ssl3_record.c
+@@ -104,7 +104,7 @@ static int ssl3_record_app_data_waiting(SSL *s)
+ 
+ int early_data_count_ok(SSL *s, size_t length, size_t overhead, int send)
+ {
+-    uint32_t max_early_data;
++    uint64_t max_early_data;
+     SSL_SESSION *sess = s->session;
+ 
+     /*
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0027-prov-remove-static-globals-from-provider_init.patch b/package/libs/openssl/patches/0027-prov-remove-static-globals-from-provider_init.patch
new file mode 100644
index 0000000..ae26403
--- /dev/null
+++ b/package/libs/openssl/patches/0027-prov-remove-static-globals-from-provider_init.patch
@@ -0,0 +1,67 @@
+From cf22c0f77e807649242de689e8da6de0541d5a00 Mon Sep 17 00:00:00 2001
+From: Matt Van Horn <mvanhorn@gmail.com>
+Date: Thu, 30 Apr 2026 21:46:43 -0700
+Subject: [PATCH 27/41] prov: remove static globals from provider_init
+
+The default provider stored two function pointers from the core
+dispatch table (c_gettable_params, c_get_params) in file-scope statics,
+written by ossl_default_provider_init() without any synchronization.
+When OSSL_PROVIDER_load() is invoked from multiple threads concurrently,
+TSAN reports a data race on both writes (issue #28935).
+
+c_gettable_params is never read anywhere in the file; it was dead
+storage. c_get_params is only consumed once, inside the same call to
+ossl_default_provider_init(), to seed the provider context via
+ossl_prov_ctx_set0_core_get_params(). It can therefore be a local
+variable rather than file-scope state.
+
+Drop the unused c_gettable_params static together with its dispatch
+case, and scope c_get_params inside the init function. The behavior of
+the default provider is unchanged for single-threaded callers; the
+concurrent-load race goes away because the shared mutable state is
+gone.
+
+CLA: trivial
+Fixes #28935
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Fri Jul  3 19:37:32 2026
+(Merged from https://github.com/openssl/openssl/pull/31634)
+
+(cherry picked from commit 1ce249061e119eba0034ea79f8fc158facbc7e31)
+---
+ providers/defltprov.c | 10 ----------
+ 1 file changed, 10 deletions(-)
+
+diff --git a/providers/defltprov.c b/providers/defltprov.c
+index 6533217b57..da4329aec8 100644
+--- a/providers/defltprov.c
++++ b/providers/defltprov.c
+@@ -34,10 +34,6 @@ static OSSL_FUNC_provider_query_operation_fn deflt_query;
+ #define ALGC(NAMES, FUNC, CHECK) { { NAMES, "provider=default", FUNC }, CHECK }
+ #define ALG(NAMES, FUNC) ALGC(NAMES, FUNC, NULL)
+ 
+-/* Functions provided by the core */
+-static OSSL_FUNC_core_gettable_params_fn *c_gettable_params = NULL;
+-static OSSL_FUNC_core_get_params_fn *c_get_params = NULL;
+-
+ /* Parameters we provide to the core */
+ static const OSSL_PARAM deflt_param_types[] = {
+     OSSL_PARAM_DEFN(OSSL_PROV_PARAM_NAME, OSSL_PARAM_UTF8_PTR, NULL, 0),
+@@ -559,12 +555,6 @@ int ossl_default_provider_init(const OSSL_CORE_HANDLE *handle,
+         return 0;
+     for (; in->function_id != 0; in++) {
+         switch (in->function_id) {
+-        case OSSL_FUNC_CORE_GETTABLE_PARAMS:
+-            c_gettable_params = OSSL_FUNC_core_gettable_params(in);
+-            break;
+-        case OSSL_FUNC_CORE_GET_PARAMS:
+-            c_get_params = OSSL_FUNC_core_get_params(in);
+-            break;
+         case OSSL_FUNC_CORE_GET_LIBCTX:
+             c_get_libctx = OSSL_FUNC_core_get_libctx(in);
+             break;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0028-baseprov-remove-static-globals.patch b/package/libs/openssl/patches/0028-baseprov-remove-static-globals.patch
new file mode 100644
index 0000000..3e8fd4c
--- /dev/null
+++ b/package/libs/openssl/patches/0028-baseprov-remove-static-globals.patch
@@ -0,0 +1,60 @@
+From 658f1d68300b34c404bb0b2fa4c6a8bf11a158e1 Mon Sep 17 00:00:00 2001
+From: Nikola Pajkovsky <nikolap@openssl.org>
+Date: Tue, 16 Jun 2026 08:11:32 +0200
+Subject: [PATCH 28/41] baseprov: remove static globals
+
+c_gettable_params is never read anywhere in the file; it was dead
+storage. c_get_params is only consumed once, inside the same call to
+ossl_default_provider_init(), to seed the provider context via
+ossl_prov_ctx_set0_core_get_params(). It can therefore be a local
+variable rather than file-scope state.
+
+drop the unused c_gettable_params static together with its dispatch
+case, and scope c_get_params inside the init function. The behavior of
+the base provider is unchanged for single-threaded callers; the
+concurrent-load race goes away because the shared mutable state is
+gone.
+
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Fri Jul  3 19:37:34 2026
+(Merged from https://github.com/openssl/openssl/pull/31634)
+
+(cherry picked from commit fdfba64f4fa4f27baec5664201eeaee419298235)
+---
+ providers/baseprov.c | 10 ----------
+ 1 file changed, 10 deletions(-)
+
+diff --git a/providers/baseprov.c b/providers/baseprov.c
+index c64c07e574..d52f6dfbbf 100644
+--- a/providers/baseprov.c
++++ b/providers/baseprov.c
+@@ -29,10 +29,6 @@ static OSSL_FUNC_provider_gettable_params_fn base_gettable_params;
+ static OSSL_FUNC_provider_get_params_fn base_get_params;
+ static OSSL_FUNC_provider_query_operation_fn base_query;
+ 
+-/* Functions provided by the core */
+-static OSSL_FUNC_core_gettable_params_fn *c_gettable_params = NULL;
+-static OSSL_FUNC_core_get_params_fn *c_get_params = NULL;
+-
+ /* Parameters we provide to the core */
+ static const OSSL_PARAM base_param_types[] = {
+     OSSL_PARAM_DEFN(OSSL_PROV_PARAM_NAME, OSSL_PARAM_UTF8_PTR, NULL, 0),
+@@ -135,12 +131,6 @@ int ossl_base_provider_init(const OSSL_CORE_HANDLE *handle,
+         return 0;
+     for (; in->function_id != 0; in++) {
+         switch (in->function_id) {
+-        case OSSL_FUNC_CORE_GETTABLE_PARAMS:
+-            c_gettable_params = OSSL_FUNC_core_gettable_params(in);
+-            break;
+-        case OSSL_FUNC_CORE_GET_PARAMS:
+-            c_get_params = OSSL_FUNC_core_get_params(in);
+-            break;
+         case OSSL_FUNC_CORE_GET_LIBCTX:
+             c_get_libctx = OSSL_FUNC_core_get_libctx(in);
+             break;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0029-fipsprov-remove-c_gettable_params-static-global.patch b/package/libs/openssl/patches/0029-fipsprov-remove-c_gettable_params-static-global.patch
new file mode 100644
index 0000000..8b1a45e
--- /dev/null
+++ b/package/libs/openssl/patches/0029-fipsprov-remove-c_gettable_params-static-global.patch
@@ -0,0 +1,68 @@
+From 7d91368502016de5edcc19234adda54d1c65d606 Mon Sep 17 00:00:00 2001
+From: Nikola Pajkovsky <nikolap@openssl.org>
+Date: Tue, 16 Jun 2026 08:32:35 +0200
+Subject: [PATCH 29/41] fipsprov: remove c_gettable_params static global
+
+c_gettable_params is never read anywhere in the file; it was dead
+storage.
+
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Fri Jul  3 19:37:35 2026
+(Merged from https://github.com/openssl/openssl/pull/31634)
+
+(cherry picked from commit b582229e185bb4c6fb5ece74badafa783906afc4)
+---
+ providers/fips/fipsprov.c | 4 ----
+ test/p_test.c             | 4 ----
+ 2 files changed, 8 deletions(-)
+
+diff --git a/providers/fips/fipsprov.c b/providers/fips/fipsprov.c
+index 909f4df42c..aee553deac 100644
+--- a/providers/fips/fipsprov.c
++++ b/providers/fips/fipsprov.c
+@@ -48,7 +48,6 @@ int FIPS_security_check_enabled(OSSL_LIB_CTX *libctx);
+  */
+ 
+ /* Functions provided by the core */
+-static OSSL_FUNC_core_gettable_params_fn *c_gettable_params;
+ static OSSL_FUNC_core_get_params_fn *c_get_params;
+ OSSL_FUNC_core_thread_start_fn *c_thread_start;
+ static OSSL_FUNC_core_new_error_fn *c_new_error;
+@@ -563,9 +562,6 @@ int OSSL_provider_init_int(const OSSL_CORE_HANDLE *handle,
+         case OSSL_FUNC_CORE_GET_LIBCTX:
+             set_func(c_get_libctx, OSSL_FUNC_core_get_libctx(in));
+             break;
+-        case OSSL_FUNC_CORE_GETTABLE_PARAMS:
+-            set_func(c_gettable_params, OSSL_FUNC_core_gettable_params(in));
+-            break;
+         case OSSL_FUNC_CORE_GET_PARAMS:
+             set_func(c_get_params, OSSL_FUNC_core_get_params(in));
+             break;
+diff --git a/test/p_test.c b/test/p_test.c
+index 355b1bf031..d84a0fa73f 100644
+--- a/test/p_test.c
++++ b/test/p_test.c
+@@ -43,7 +43,6 @@ typedef struct p_test_ctx {
+     OSSL_LIB_CTX *libctx;
+ } P_TEST_CTX;
+ 
+-static OSSL_FUNC_core_gettable_params_fn *c_gettable_params = NULL;
+ static OSSL_FUNC_core_get_params_fn *c_get_params = NULL;
+ static OSSL_FUNC_core_new_error_fn *c_new_error;
+ static OSSL_FUNC_core_set_error_debug_fn *c_set_error_debug;
+@@ -258,9 +257,6 @@ int OSSL_provider_init(const OSSL_CORE_HANDLE *handle,
+ 
+     for (; in->function_id != 0; in++) {
+         switch (in->function_id) {
+-        case OSSL_FUNC_CORE_GETTABLE_PARAMS:
+-            c_gettable_params = OSSL_FUNC_core_gettable_params(in);
+-            break;
+         case OSSL_FUNC_CORE_GET_PARAMS:
+             c_get_params = OSSL_FUNC_core_get_params(in);
+             break;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0030-doc-man3-ASN1_INTEGER_get_int64.pod-fix-a-typo.patch b/package/libs/openssl/patches/0030-doc-man3-ASN1_INTEGER_get_int64.pod-fix-a-typo.patch
new file mode 100644
index 0000000..b6f74c1
--- /dev/null
+++ b/package/libs/openssl/patches/0030-doc-man3-ASN1_INTEGER_get_int64.pod-fix-a-typo.patch
@@ -0,0 +1,35 @@
+From d4177d79faeb459e30bf1a7ddb4dc6c427352257 Mon Sep 17 00:00:00 2001
+From: Joe Orton <jorton@redhat.com>
+Date: Wed, 1 Jul 2026 17:11:54 +0100
+Subject: [PATCH 30/41] doc/man3/ASN1_INTEGER_get_int64.pod: fix a typo
+
+CLA: trivial
+Fixes: 6c5b6cb03566 "ASN1 INTEGER refactor."
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Wed Jul  8 10:18:11 2026
+(Merged from https://github.com/openssl/openssl/pull/31815)
+
+(cherry picked from commit 51584371a27d2e939babcac3a8fd145c0a2f16ac)
+---
+ doc/man3/ASN1_INTEGER_get_int64.pod | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/doc/man3/ASN1_INTEGER_get_int64.pod b/doc/man3/ASN1_INTEGER_get_int64.pod
+index 3bde0b20e6..dd4e1a0bc8 100644
+--- a/doc/man3/ASN1_INTEGER_get_int64.pod
++++ b/doc/man3/ASN1_INTEGER_get_int64.pod
+@@ -108,7 +108,7 @@ B<ASN1_ENUMERATED> structure respectively or NULL if an error occurs. They will
+ only fail due to a memory allocation error.
+ 
+ ASN1_INTEGER_to_BN() and ASN1_ENUMERATED_to_BN() return a B<BIGNUM> structure
+-of NULL if an error occurs. They can fail if the passed type is incorrect
++or NULL if an error occurs. They can fail if the passed type is incorrect
+ (due to programming error) or due to a memory allocation failure.
+ 
+ =head1 SEE ALSO
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0031-Avoid-undefined-behavior-adding-or-subtracting-two-B.patch b/package/libs/openssl/patches/0031-Avoid-undefined-behavior-adding-or-subtracting-two-B.patch
new file mode 100644
index 0000000..b8e1a65
--- /dev/null
+++ b/package/libs/openssl/patches/0031-Avoid-undefined-behavior-adding-or-subtracting-two-B.patch
@@ -0,0 +1,58 @@
+From afe13ce75176ebe5388286793547e18f6f81706e Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.foundation>
+Date: Fri, 10 Jul 2026 11:09:09 +0200
+Subject: [PATCH 31/41] Avoid undefined behavior adding or subtracting two
+ BN_zero() values
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+MergeDate: Fri Jul 10 14:54:48 2026
+(Merged from https://github.com/openssl/openssl/pull/31916)
+
+(cherry picked from commit 1768a5a1be8895f3cf54d418093c337ea1f3238d)
+---
+ crypto/bn/bn_add.c | 7 +++++++
+ 1 file changed, 7 insertions(+)
+
+diff --git a/crypto/bn/bn_add.c b/crypto/bn/bn_add.c
+index 38de39d1b8..52f456850c 100644
+--- a/crypto/bn/bn_add.c
++++ b/crypto/bn/bn_add.c
+@@ -97,6 +97,8 @@ int BN_uadd(BIGNUM *r, const BIGNUM *a, const BIGNUM *b)
+         return 0;
+ 
+     r->top = max;
++    if (max == 0)
++        goto end;
+ 
+     ap = a->d;
+     bp = b->d;
+@@ -116,6 +118,7 @@ int BN_uadd(BIGNUM *r, const BIGNUM *a, const BIGNUM *b)
+     *rp = carry;
+     r->top += carry;
+ 
++end:
+     r->neg = 0;
+     bn_check_top(r);
+     return 1;
+@@ -143,6 +146,9 @@ int BN_usub(BIGNUM *r, const BIGNUM *a, const BIGNUM *b)
+     if (bn_wexpand(r, max) == NULL)
+         return 0;
+ 
++    if (max == 0)
++        goto end;
++
+     ap = a->d;
+     bp = b->d;
+     rp = r->d;
+@@ -162,6 +168,7 @@ int BN_usub(BIGNUM *r, const BIGNUM *a, const BIGNUM *b)
+     while (max && *--rp == 0)
+         max--;
+ 
++end:
+     r->top = max;
+     r->neg = 0;
+     bn_pollute(r);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0032-Fix-a-bug-in-BN_ucmp-when-comparing-constant-time-BI.patch b/package/libs/openssl/patches/0032-Fix-a-bug-in-BN_ucmp-when-comparing-constant-time-BI.patch
new file mode 100644
index 0000000..52b7fd5
--- /dev/null
+++ b/package/libs/openssl/patches/0032-Fix-a-bug-in-BN_ucmp-when-comparing-constant-time-BI.patch
@@ -0,0 +1,63 @@
+From 8c360c78346c2a8f5549d2a85c2e6fe7c63c7b0b Mon Sep 17 00:00:00 2001
+From: Igor Ustinov <igus@openssl.foundation>
+Date: Thu, 9 Jul 2026 08:37:10 +0200
+Subject: [PATCH 32/41] Fix a bug in BN_ucmp() when comparing constant-time
+ BIGNUMs of different lengths
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Fri Jul 10 15:12:02 2026
+(Merged from https://github.com/openssl/openssl/pull/31904)
+
+(cherry picked from commit bd873e74b9d98e982d31b2c998a16396157d2d5c)
+---
+ crypto/bn/bn_lib.c | 22 ++++++++++++++++++++--
+ 1 file changed, 20 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/bn/bn_lib.c b/crypto/bn/bn_lib.c
+index f6695bea18..161730ce79 100644
+--- a/crypto/bn/bn_lib.c
++++ b/crypto/bn/bn_lib.c
+@@ -612,19 +612,37 @@ int BN_ucmp(const BIGNUM *a, const BIGNUM *b)
+     int i;
+     BN_ULONG t1, t2, *ap, *bp;
+ 
++    /*
++     * As it is a public API function, we should handle NULL parameters in
++     * some way. The function can’t return an error, so let’s define that NULL
++     * is less than any BIGNUM.
++     */
++    if (!ossl_assert(a != NULL && b != NULL))
++        return (b == NULL) - (a == NULL);
++
+     ap = a->d;
+     bp = b->d;
+ 
+     if (BN_get_flags(a, BN_FLG_CONSTTIME)
+-        && a->top == b->top) {
++        || BN_get_flags(b, BN_FLG_CONSTTIME)) {
+         int res = 0;
++        int min_top = a->top < b->top ? a->top : b->top;
+ 
+-        for (i = 0; i < b->top; i++) {
++        for (i = 0; i < min_top; i++) {
+             res = constant_time_select_int(constant_time_lt_bn(ap[i], bp[i]),
+                 -1, res);
+             res = constant_time_select_int(constant_time_lt_bn(bp[i], ap[i]),
+                 1, res);
+         }
++
++        for (i = min_top; i < a->top; ++i)
++            res = constant_time_select_int((int)constant_time_is_zero_bn(ap[i]),
++                res, 1);
++
++        for (i = min_top; i < b->top; ++i)
++            res = constant_time_select_int((int)constant_time_is_zero_bn(bp[i]),
++                res, -1);
++
+         return res;
+     }
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0033-Document-the-effect-of-SSL_VERIFY_FAIL_IF_NO_PEER_CE.patch b/package/libs/openssl/patches/0033-Document-the-effect-of-SSL_VERIFY_FAIL_IF_NO_PEER_CE.patch
new file mode 100644
index 0000000..d59418c
--- /dev/null
+++ b/package/libs/openssl/patches/0033-Document-the-effect-of-SSL_VERIFY_FAIL_IF_NO_PEER_CE.patch
@@ -0,0 +1,34 @@
+From 5e22650f4f475f968923c2196e0b251f2734fc24 Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.foundation>
+Date: Tue, 7 Jul 2026 12:32:13 +0200
+Subject: [PATCH 33/41] Document the effect of SSL_VERIFY_FAIL_IF_NO_PEER_CERT
+ on post-handshake auth
+
+Reviewed-by: Matt Caswell <matt@openssl.foundation>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+MergeDate: Fri Jul 10 15:45:39 2026
+(Merged from https://github.com/openssl/openssl/pull/31876)
+
+(cherry picked from commit 3bf2aba5f5e2e602b7b72b71d91e3befb08e9e94)
+---
+ doc/man3/SSL_CTX_set_verify.pod | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/doc/man3/SSL_CTX_set_verify.pod b/doc/man3/SSL_CTX_set_verify.pod
+index 346aa84529..ac604b5e76 100644
+--- a/doc/man3/SSL_CTX_set_verify.pod
++++ b/doc/man3/SSL_CTX_set_verify.pod
+@@ -74,7 +74,9 @@ SSL_CTX_set_client_cert_cb() if no certificate is provided at initialization.
+ 
+ SSL_verify_client_post_handshake() causes a CertificateRequest message to be
+ sent by a server on the given B<ssl> connection. The SSL_VERIFY_PEER flag must
+-be set; the SSL_VERIFY_POST_HANDSHAKE flag is optional.
++be set; the SSL_VERIFY_POST_HANDSHAKE flag is optional. The
++SSL_VERIFY_FAIL_IF_NO_PEER_CERT flag is also applicable and has the same
++effect as with the client authentication during the handshake.
+ 
+ =head1 NOTES
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0034-pkcs12-free-PKCS7-elements-on-error-in-PKCS12_unpack.patch b/package/libs/openssl/patches/0034-pkcs12-free-PKCS7-elements-on-error-in-PKCS12_unpack.patch
new file mode 100644
index 0000000..0859e5e
--- /dev/null
+++ b/package/libs/openssl/patches/0034-pkcs12-free-PKCS7-elements-on-error-in-PKCS12_unpack.patch
@@ -0,0 +1,33 @@
+From 86410a0d80b6f26d29d4cd169ac7dd6f3c277ccc Mon Sep 17 00:00:00 2001
+From: Naveed Khan <dxbnaveed.k@gmail.com>
+Date: Sat, 4 Jul 2026 22:39:47 +0530
+Subject: [PATCH 34/41] pkcs12: free PKCS7 elements on error in
+ PKCS12_unpack_authsafes
+
+Fixes: b536880c4572 "Add library context and property query support into the PKCS12 API"
+
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+MergeDate: Fri Jul 10 15:48:37 2026
+(Merged from https://github.com/openssl/openssl/pull/31862)
+
+(cherry picked from commit b1393a04464eaf8b769bb6dc606d36a7734e73aa)
+---
+ crypto/pkcs12/p12_add.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/pkcs12/p12_add.c b/crypto/pkcs12/p12_add.c
+index 5925c35111..c0063f5514 100644
+--- a/crypto/pkcs12/p12_add.c
++++ b/crypto/pkcs12/p12_add.c
+@@ -216,6 +216,6 @@ STACK_OF(PKCS7) *PKCS12_unpack_authsafes(const PKCS12 *p12)
+     }
+     return p7s;
+ err:
+-    sk_PKCS7_free(p7s);
++    sk_PKCS7_pop_free(p7s, PKCS7_free);
+     return NULL;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0035-Don-t-raise-NOT_ENOUGH_DATA-on-a-clean-EOF-at-an-obj.patch b/package/libs/openssl/patches/0035-Don-t-raise-NOT_ENOUGH_DATA-on-a-clean-EOF-at-an-obj.patch
new file mode 100644
index 0000000..7854d11
--- /dev/null
+++ b/package/libs/openssl/patches/0035-Don-t-raise-NOT_ENOUGH_DATA-on-a-clean-EOF-at-an-obj.patch
@@ -0,0 +1,313 @@
+From 430472298fec6f395f274d1277b6ea4b50c8bc94 Mon Sep 17 00:00:00 2001
+From: Marc Gutman <marcg@activestate.com>
+Date: Thu, 9 Jul 2026 15:23:28 -0500
+Subject: [PATCH 35/41] Don't raise NOT_ENOUGH_DATA on a clean EOF at an object
+ boundary
+
+asn1_d2i_read_bio() reads one ASN.1 object at a time from a BIO.  Callers
+commonly loop, decoding concatenated DER values until the call fails, and
+rely on a failure with no queued error to recognise a clean end of input.
+CPython's ssl module does this in _add_ca_certs() when loading the Windows
+certificate store via SSLContext.load_verify_locations(cadata=...); it
+re-raises any leftover ASN.1 error other than ASN1_R_HEADER_TOO_LONG as
+fatal.
+
+Commit 9eb6922c59 ("asn1: raise NOT_ENOUGH_DATA on header EOF") changed the
+BIO_read() check from "i < 0" to "i <= 0", so a clean EOF (BIO_read()
+returning 0, as an exhausted BIO_new_mem_buf does) on an object boundary now
+raises ASN1_R_NOT_ENOUGH_DATA instead of failing with an empty error queue.
+The rewrite in commit 35852da1d9 carried this behaviour forward.  As a
+result Python 3 on Windows fails to initialise an SSLContext with:
+
+    ssl.SSLError: [ASN1: NOT_ENOUGH_DATA] not enough data
+
+Raise ASN1_R_NOT_ENOUGH_DATA only on an actual read error, on an EOF in the
+middle of an object (some bytes already buffered), or on an EOF while still
+inside an indefinite-length value awaiting its end-of-contents octets - all
+of which are genuine truncation.  A clean EOF at a top-level object boundary
+again fails without queuing an error, restoring the long-standing behaviour
+that looping callers depend on.
+
+Add regression tests covering the clean-EOF, truncated, indefinite-length
+truncation and partial-header cases, and document the read behaviour in
+ASN1_item_d2i_bio(3).
+
+Fixes #31807
+
+Assisted-by: Claude:claude-opus-4-8
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Igor Ustinov <igus@openssl.foundation>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Mon Jul 13 08:05:03 2026
+(Merged from https://github.com/openssl/openssl/pull/31818)
+
+(cherry picked from commit d7e77b66cabb770932091ed5986221e0d1e57144)
+---
+ crypto/asn1/a_d2i_fp.c         |  15 ++-
+ doc/man3/ASN1_item_d2i_bio.pod |  18 +++-
+ test/asn1_decode_test.c        | 165 +++++++++++++++++++++++++++++++++
+ 3 files changed, 196 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/asn1/a_d2i_fp.c b/crypto/asn1/a_d2i_fp.c
+index dcbb6d9a9e..f7d1026d92 100644
+--- a/crypto/asn1/a_d2i_fp.c
++++ b/crypto/asn1/a_d2i_fp.c
+@@ -139,7 +139,20 @@ int asn1_d2i_read_bio(BIO *in, BUF_MEM **pb)
+             }
+             i = BIO_read(in, &(b->data[len]), want);
+             if (i <= 0) {
+-                ERR_raise(ERR_LIB_ASN1, ASN1_R_NOT_ENOUGH_DATA);
++                /*
++                 * A read error (i < 0), an EOF in the middle of an object
++                 * (diff != 0, some bytes already buffered), or an EOF while
++                 * still inside an indefinite-length constructed value awaiting
++                 * its end-of-contents octets (eos != 0) all mean the input is
++                 * truncated.  Only a clean EOF at a top-level object boundary
++                 * (i == 0, diff == 0, eos == 0) is the normal end of input:
++                 * fail without queuing an error so that callers looping over
++                 * concatenated DER values (e.g. the libcrypto d2i_*_bio()
++                 * consumers in CPython's ssl module) terminate cleanly instead
++                 * of seeing a spurious ASN1_R_NOT_ENOUGH_DATA.
++                 */
++                if (i < 0 || diff != 0 || eos != 0)
++                    ERR_raise(ERR_LIB_ASN1, ASN1_R_NOT_ENOUGH_DATA);
+                 goto err;
+             }
+             if (i > 0) {
+diff --git a/doc/man3/ASN1_item_d2i_bio.pod b/doc/man3/ASN1_item_d2i_bio.pod
+index bdf5c48096..d5c302f363 100644
+--- a/doc/man3/ASN1_item_d2i_bio.pod
++++ b/doc/man3/ASN1_item_d2i_bio.pod
+@@ -51,6 +51,16 @@ B<OSSL_LIB_CTX> provided in the I<libctx> parameter and the property query
+ string in I<propq>. See L<crypto(7)/ALGORITHM FETCHING> for more information
+ about algorithm fetching.
+ 
++When reading from I<in>, decoding consumes one complete DER-encoded structure
++and leaves any following bytes in the BIO, so concatenated structures can be
++read with successive calls. Reaching the end of the input cleanly, at a
++structure boundary, is not treated as an error: the function returns NULL
++without adding to the error queue. If the end of the input is reached in the
++middle of a structure, or an indefinite-length value is missing its
++end-of-contents octets (that is, the input is truncated), an error is queued
++with reason code B<ASN1_R_NOT_ENOUGH_DATA>. The same applies to
++ASN1_item_d2i_fp_ex().
++
+ ASN1_item_d2i_bio() is the same as ASN1_item_d2i_bio_ex() except that the
+ default B<OSSL_LIB_CTX> is used (i.e. NULL) and with a NULL property query
+ string.
+@@ -69,6 +79,12 @@ using the ASN.1 template I<it> and returns the result in a memory BIO.
+ 
+ ASN1_item_d2i_bio() returns a pointer to an B<ASN1_VALUE> or NULL.
+ 
++The ASN1_item_d2i_bio() and ASN1_item_d2i_fp() functions, including their
++B<_ex> variants, also return NULL at a clean end of input. In that case the
++error queue is left unchanged, so a caller reading concatenated structures in
++a loop can distinguish a clean end of input from a decoding error by
++inspecting the error queue, for example with L<ERR_peek_error(3)>.
++
+ ASN1_item_i2d_mem_bio() returns a pointer to a memory BIO or NULL on error.
+ 
+ =head1 HISTORY
+@@ -78,7 +94,7 @@ and ASN1_item_i2d_mem_bio() were added in OpenSSL 3.0.
+ 
+ =head1 COPYRIGHT
+ 
+-Copyright 2021 The OpenSSL Project Authors. All Rights Reserved.
++Copyright 2021-2026 The OpenSSL Project Authors. All Rights Reserved.
+ 
+ Licensed under the Apache License 2.0 (the "License").  You may not use
+ this file except in compliance with the License.  You can obtain a copy
+diff --git a/test/asn1_decode_test.c b/test/asn1_decode_test.c
+index 74bd30c95e..2feed6ba93 100644
+--- a/test/asn1_decode_test.c
++++ b/test/asn1_decode_test.c
+@@ -13,7 +13,11 @@
+ #include <openssl/rand.h>
+ #include <openssl/asn1t.h>
+ #include <openssl/obj_mac.h>
++#include <openssl/bio.h>
++#include <openssl/buffer.h>
++#include <openssl/err.h>
+ #include "internal/numbers.h"
++#include "internal/asn1.h"
+ #include "testutil.h"
+ 
+ #ifdef __GNUC__
+@@ -215,6 +219,163 @@ err:
+     return ret;
+ }
+ 
++/*
++ * A minimal, complete DER object: SEQUENCE { INTEGER 0 }.
++ * asn1_d2i_read_bio() should consume exactly these bytes.
++ */
++static const unsigned char one_obj[] = {
++    0x30, 0x03, /* SEQUENCE, length 3 */
++    0x02, 0x01, 0x00 /*   INTEGER 0        */
++};
++
++/*
++ * Reading concatenated DER objects from a BIO must stop cleanly at EOF:
++ * once the input is exhausted on an object boundary, asn1_d2i_read_bio()
++ * returns < 0 and must NOT leave an error on the queue.  Callers that loop
++ * over concatenated values (e.g. CPython's ssl module loading the Windows
++ * certificate store via d2i_X509_bio()) rely on this to detect end-of-input;
++ * a spurious ASN1_R_NOT_ENOUGH_DATA there is reported as a fatal error.
++ */
++static int test_d2i_read_bio_clean_eof(void)
++{
++    unsigned char two_objs[sizeof(one_obj) * 2];
++    BIO *bio = NULL;
++    BUF_MEM *buf = NULL;
++    int ret = 0;
++
++    memcpy(two_objs, one_obj, sizeof(one_obj));
++    memcpy(two_objs + sizeof(one_obj), one_obj, sizeof(one_obj));
++
++    if (!TEST_ptr(bio = BIO_new_mem_buf(two_objs, sizeof(two_objs))))
++        goto err;
++    ERR_clear_error();
++
++    /* Both complete objects are read, one per call. */
++    if (!TEST_int_eq(asn1_d2i_read_bio(bio, &buf), (int)sizeof(one_obj)))
++        goto err;
++    BUF_MEM_free(buf);
++    buf = NULL;
++    if (!TEST_int_eq(asn1_d2i_read_bio(bio, &buf), (int)sizeof(one_obj)))
++        goto err;
++    BUF_MEM_free(buf);
++    buf = NULL;
++
++    /* Clean EOF: failure return, but no error must be queued. */
++    if (!TEST_int_lt(asn1_d2i_read_bio(bio, &buf), 0))
++        goto err;
++    if (!TEST_ulong_eq(ERR_peek_error(), 0))
++        goto err;
++
++    ret = 1;
++err:
++    BUF_MEM_free(buf);
++    BIO_free(bio);
++    return ret;
++}
++
++/*
++ * In contrast, hitting EOF in the middle of an object is genuine truncation
++ * and must still be reported as ASN1_R_NOT_ENOUGH_DATA.
++ */
++static int test_d2i_read_bio_truncated(void)
++{
++    static const unsigned char truncated[] = {
++        0x30, 0x05, /* SEQUENCE claims 5 content bytes ... */
++        0x02, 0x01 /* ... but only 2 are present         */
++    };
++    BIO *bio = NULL;
++    BUF_MEM *buf = NULL;
++    unsigned long e;
++    int ret = 0;
++
++    if (!TEST_ptr(bio = BIO_new_mem_buf(truncated, sizeof(truncated))))
++        goto err;
++    ERR_clear_error();
++
++    if (!TEST_int_lt(asn1_d2i_read_bio(bio, &buf), 0))
++        goto err;
++    e = ERR_peek_last_error();
++    if (!TEST_int_eq(ERR_GET_LIB(e), ERR_LIB_ASN1)
++        || !TEST_int_eq(ERR_GET_REASON(e), ASN1_R_NOT_ENOUGH_DATA))
++        goto err;
++
++    ret = 1;
++err:
++    BUF_MEM_free(buf);
++    BIO_free(bio);
++    return ret;
++}
++
++/*
++ * An EOF reached while still inside an indefinite-length constructed value,
++ * before its end-of-contents octets, is truncation too (not a clean boundary),
++ * so it must also report ASN1_R_NOT_ENOUGH_DATA rather than an empty queue.
++ */
++static int test_d2i_read_bio_indefinite_truncated(void)
++{
++    /* SEQUENCE (indefinite) { INTEGER 0 } with the 00 00 EOC missing */
++    static const unsigned char truncated_indefinite[] = {
++        0x30, 0x80, /* SEQUENCE, indefinite length */
++        0x02, 0x01, 0x00 /* INTEGER 0; no end-of-contents octets follow */
++    };
++    BIO *bio = NULL;
++    BUF_MEM *buf = NULL;
++    unsigned long e;
++    int ret = 0;
++
++    bio = BIO_new_mem_buf(truncated_indefinite, sizeof(truncated_indefinite));
++    if (!TEST_ptr(bio))
++        goto err;
++    ERR_clear_error();
++
++    if (!TEST_int_lt(asn1_d2i_read_bio(bio, &buf), 0))
++        goto err;
++    e = ERR_peek_last_error();
++    if (!TEST_int_eq(ERR_GET_LIB(e), ERR_LIB_ASN1)
++        || !TEST_int_eq(ERR_GET_REASON(e), ASN1_R_NOT_ENOUGH_DATA))
++        goto err;
++
++    ret = 1;
++err:
++    BUF_MEM_free(buf);
++    BIO_free(bio);
++    return ret;
++}
++
++/*
++ * An EOF reached part-way through an object's header, with some header bytes
++ * already buffered, is truncation as well.  This exercises the "diff != 0" arm
++ * of the header-read check (distinct from the body read handled elsewhere).
++ */
++static int test_d2i_read_bio_partial_header(void)
++{
++    /* SEQUENCE with a 2-byte long-form length, but only one length byte given */
++    static const unsigned char partial_header[] = {
++        0x30, 0x82, 0x01 /* SEQUENCE, length declared as 2 bytes, 1 present */
++    };
++    BIO *bio = NULL;
++    BUF_MEM *buf = NULL;
++    unsigned long e;
++    int ret = 0;
++
++    if (!TEST_ptr(bio = BIO_new_mem_buf(partial_header, sizeof(partial_header))))
++        goto err;
++    ERR_clear_error();
++
++    if (!TEST_int_lt(asn1_d2i_read_bio(bio, &buf), 0))
++        goto err;
++    e = ERR_peek_last_error();
++    if (!TEST_int_eq(ERR_GET_LIB(e), ERR_LIB_ASN1)
++        || !TEST_int_eq(ERR_GET_REASON(e), ASN1_R_NOT_ENOUGH_DATA))
++        goto err;
++
++    ret = 1;
++err:
++    BUF_MEM_free(buf);
++    BIO_free(bio);
++    return ret;
++}
++
+ int setup_tests(void)
+ {
+ #ifndef OPENSSL_NO_DEPRECATED_3_0
+@@ -226,5 +387,9 @@ int setup_tests(void)
+     ADD_TEST(test_uint64);
+     ADD_TEST(test_invalid_template);
+     ADD_TEST(test_reuse_asn1_object);
++    ADD_TEST(test_d2i_read_bio_clean_eof);
++    ADD_TEST(test_d2i_read_bio_truncated);
++    ADD_TEST(test_d2i_read_bio_indefinite_truncated);
++    ADD_TEST(test_d2i_read_bio_partial_header);
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0036-poly1305-reject-no-key-update-and-NULL-key-params.patch b/package/libs/openssl/patches/0036-poly1305-reject-no-key-update-and-NULL-key-params.patch
new file mode 100644
index 0000000..7a97e4a
--- /dev/null
+++ b/package/libs/openssl/patches/0036-poly1305-reject-no-key-update-and-NULL-key-params.patch
@@ -0,0 +1,146 @@
+From a990de3cc43633766215e2337022f6efd0539704 Mon Sep 17 00:00:00 2001
+From: Mounir IDRASSI <mounir.idrassi@idrix.fr>
+Date: Wed, 3 Jun 2026 23:44:22 +0900
+Subject: [PATCH 36/41] poly1305: reject no-key update and NULL key params
+
+Poly1305 permits EVP_MAC_init(ctx, NULL, 0, ...) as part of staged
+initialization. If no key has been installed, update still dispatched
+into the uninitialized Poly1305 state, which can crash on POLY1305_ASM
+builds.
+
+Guard update with the same key_set check used by final and report no key set.
+
+Also reject an explicit OSSL_MAC_PARAM_KEY whose data pointer is NULL before
+calling Poly1305_Init(), even when the supplied size is POLY1305_KEY_SIZE.
+
+Fixes #31332
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Daniel Kubec <kubec@openssl.foundation>
+MergeDate: Mon Jul 13 15:44:48 2026
+(Merged from https://github.com/openssl/openssl/pull/31382)
+
+(cherry picked from commit 95f95b59dded1ad376458152e4c8533018ee2f43)
+---
+ .../implementations/macs/poly1305_prov.c      |  6 +-
+ test/evp_extra_test.c                         | 69 ++++++++++++++++++-
+ 2 files changed, 71 insertions(+), 4 deletions(-)
+
+diff --git a/providers/implementations/macs/poly1305_prov.c b/providers/implementations/macs/poly1305_prov.c
+index b7ecbbd1fa..0ff5d7036d 100644
+--- a/providers/implementations/macs/poly1305_prov.c
++++ b/providers/implementations/macs/poly1305_prov.c
+@@ -82,7 +82,7 @@ static size_t poly1305_size(void)
+ static int poly1305_setkey(struct poly1305_data_st *ctx,
+     const unsigned char *key, size_t keylen)
+ {
+-    if (keylen != POLY1305_KEY_SIZE) {
++    if (key == NULL || keylen != POLY1305_KEY_SIZE) {
+         ERR_raise(ERR_LIB_PROV, PROV_R_INVALID_KEY_LENGTH);
+         return 0;
+     }
+@@ -111,6 +111,10 @@ static int poly1305_update(void *vmacctx, const unsigned char *data,
+ {
+     struct poly1305_data_st *ctx = vmacctx;
+ 
++    if (!ctx->key_set) {
++        ERR_raise(ERR_LIB_PROV, PROV_R_NO_KEY_SET);
++        return 0;
++    }
+     ctx->updated = 1;
+     if (datalen == 0)
+         return 1;
+diff --git a/test/evp_extra_test.c b/test/evp_extra_test.c
+index ed2b924945..d62fe42cc7 100644
+--- a/test/evp_extra_test.c
++++ b/test/evp_extra_test.c
+@@ -1727,20 +1727,83 @@ out:
+ }
+ 
+ #ifndef OPENSSL_NO_POLY1305
+-/* Test that EVP_MAC_final fails for Poly1305 when no key was set */
++/* Test Poly1305 no-key failures and staged key initialization */
+ static int test_evp_mac_poly1305_no_key(void)
+ {
+     int ret = 0;
+     EVP_MAC *mac = NULL;
+     EVP_MAC_CTX *ctx = NULL;
++    /* RFC 7539 Poly1305 test vector. */
++    static const unsigned char staged_data[] = "Cryptographic Forum Research Group";
++    static const unsigned char expected[16] = {
++        0xa8, 0x06, 0x1d, 0xc1, 0x30, 0x51, 0x36, 0xc6,
++        0xc2, 0x2b, 0x8b, 0xaf, 0x0c, 0x01, 0x27, 0xa9
++    };
++    unsigned char no_key_data[16] = { 0 };
++    unsigned char key[32] = {
++        0x85, 0xd6, 0xbe, 0x78, 0x57, 0x55, 0x6d, 0x33,
++        0x7f, 0x44, 0x52, 0xfe, 0x42, 0xd5, 0x06, 0xa8,
++        0x01, 0x03, 0x80, 0x8a, 0xfb, 0x0d, 0xb2, 0xfd,
++        0x4a, 0xbf, 0xf6, 0xaf, 0x41, 0x49, 0xf5, 0x1b
++    };
+     unsigned char out[16];
++    OSSL_PARAM key_params[2];
++    OSSL_PARAM null_key_params[2];
+     size_t outl = 0;
+ 
++    key_params[0] = OSSL_PARAM_construct_octet_string(OSSL_MAC_PARAM_KEY,
++        key, sizeof(key));
++    key_params[1] = OSSL_PARAM_construct_end();
++    null_key_params[0] = OSSL_PARAM_construct_octet_string(OSSL_MAC_PARAM_KEY,
++        NULL, sizeof(key));
++    null_key_params[1] = OSSL_PARAM_construct_end();
++
+     if (!TEST_ptr(mac = EVP_MAC_fetch(testctx, "Poly1305", testpropq))
+         || !TEST_ptr(ctx = EVP_MAC_CTX_new(mac))
+-        || !TEST_int_eq(EVP_MAC_init(ctx, NULL, 0, NULL), 1)
+-        || !TEST_int_eq(EVP_MAC_final(ctx, out, &outl, sizeof(out)), 0))
++        || !TEST_int_eq(EVP_MAC_init(ctx, NULL, 0, NULL), 1))
++        goto err;
++
++    ERR_clear_error();
++    if (!TEST_int_eq(EVP_MAC_update(ctx, no_key_data, sizeof(no_key_data)), 0)
++        || !TEST_int_eq(ERR_GET_REASON(ERR_get_error()), PROV_R_NO_KEY_SET))
++        goto err;
++
++    /* The failed update must not block staged key initialization. */
++    if (!TEST_int_eq(EVP_MAC_CTX_set_params(ctx, key_params), 1)
++        || !TEST_int_eq(EVP_MAC_update(ctx, staged_data,
++                            sizeof(staged_data) - 1),
++            1)
++        || !TEST_int_eq(EVP_MAC_final(ctx, out, &outl, sizeof(out)), 1)
++        || !TEST_size_t_eq(outl, sizeof(expected))
++        || !TEST_mem_eq(out, outl, expected, sizeof(expected)))
++        goto err;
++
++    EVP_MAC_CTX_free(ctx);
++    ctx = NULL;
++
++    if (!TEST_ptr(ctx = EVP_MAC_CTX_new(mac))
++        || !TEST_int_eq(EVP_MAC_init(ctx, NULL, 0, NULL), 1))
++        goto err;
++
++    ERR_clear_error();
++    if (!TEST_int_eq(EVP_MAC_final(ctx, out, &outl, sizeof(out)), 0)
++        || !TEST_int_eq(ERR_GET_REASON(ERR_get_error()), PROV_R_NO_KEY_SET))
++        goto err;
++
++    ERR_clear_error();
++    if (!TEST_int_eq(EVP_MAC_init(ctx, NULL, 0, null_key_params), 0)
++        || !TEST_int_eq(ERR_GET_REASON(ERR_get_error()),
++            PROV_R_INVALID_KEY_LENGTH))
++        goto err;
++
++    ERR_clear_error();
++    if (!TEST_int_eq(EVP_MAC_CTX_set_params(ctx, null_key_params), 0)
++        || !TEST_int_eq(ERR_GET_REASON(ERR_get_error()),
++            PROV_R_INVALID_KEY_LENGTH))
+         goto err;
++
++    EVP_MAC_CTX_free(ctx);
++    ctx = NULL;
+     ret = 1;
+ err:
+     EVP_MAC_CTX_free(ctx);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0037-x509-avoid-NULL-memcmp-argument-in-nc_dn.patch b/package/libs/openssl/patches/0037-x509-avoid-NULL-memcmp-argument-in-nc_dn.patch
new file mode 100644
index 0000000..6b0232f
--- /dev/null
+++ b/package/libs/openssl/patches/0037-x509-avoid-NULL-memcmp-argument-in-nc_dn.patch
@@ -0,0 +1,48 @@
+From c8475727165cb782a379781b530ef61e6f2abe2c Mon Sep 17 00:00:00 2001
+From: Mounir IDRASSI <mounir.idrassi@idrix.fr>
+Date: Wed, 1 Jul 2026 23:43:18 +0900
+Subject: [PATCH 37/41] x509: avoid NULL memcmp argument in nc_dn()
+
+An empty directoryName constraint has canon_enc == NULL and
+canon_enclen == 0. nc_dn() must not pass that pointer to
+memcmp(), even with a zero length.
+
+Return X509_V_OK before comparing an empty base Name. This preserves
+current match semantics and avoids UBSan-visible undefined behaviour.
+
+Fixes #31687
+Fixes #31688
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Daniel Kubec <kubec@openssl.foundation>
+MergeDate: Fri Jul 10 15:51:01 2026
+
+(cherry picked from commit fce540139a7cf4de64d9ce8e17b9180778e12f4e)
+
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/31923)
+---
+ crypto/x509/v3_ncons.c | 6 ++++++
+ 1 file changed, 6 insertions(+)
+
+diff --git a/crypto/x509/v3_ncons.c b/crypto/x509/v3_ncons.c
+index 21380013f2..92a51a6842 100644
+--- a/crypto/x509/v3_ncons.c
++++ b/crypto/x509/v3_ncons.c
+@@ -583,6 +583,12 @@ static int nc_dn(const X509_NAME *nm, const X509_NAME *base)
+         return X509_V_ERR_OUT_OF_MEM;
+     if (base->canon_enclen > nm->canon_enclen)
+         return X509_V_ERR_PERMITTED_VIOLATION;
++    /*
++     * An empty base Name has no canonical encoding (canon_enc == NULL) and is
++     * a prefix of every Name, so it matches unconditionally.
++     */
++    if (base->canon_enclen == 0)
++        return X509_V_OK;
+     if (memcmp(base->canon_enc, nm->canon_enc, base->canon_enclen))
+         return X509_V_ERR_PERMITTED_VIOLATION;
+     return X509_V_OK;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0038-test-cover-empty-directoryName-name-constraints.patch b/package/libs/openssl/patches/0038-test-cover-empty-directoryName-name-constraints.patch
new file mode 100644
index 0000000..5d8100b
--- /dev/null
+++ b/package/libs/openssl/patches/0038-test-cover-empty-directoryName-name-constraints.patch
@@ -0,0 +1,141 @@
+From 9976cfad448ec6e62cb412aab92d25b0d4b8ca96 Mon Sep 17 00:00:00 2001
+From: Mounir IDRASSI <mounir.idrassi@idrix.fr>
+Date: Wed, 1 Jul 2026 23:43:18 +0900
+Subject: [PATCH 38/41] test: cover empty directoryName name constraints
+
+Add NAME_CONSTRAINTS_check() coverage for empty directoryName
+subtrees in both excluded and permitted constraints.
+
+The tests assert the existing results in ordinary builds and catch
+the NULL memcmp() argument when run under UBSan.
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Daniel Kubec <kubec@openssl.foundation>
+MergeDate: Fri Jul 10 15:51:03 2026
+
+(cherry picked from commit 7f4ac8022492a54aedd0100af4e624600d60c590)
+
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/31923)
+---
+ test/v3ext.c | 97 ++++++++++++++++++++++++++++++++++++++++++++++++++++
+ 1 file changed, 97 insertions(+)
+
+diff --git a/test/v3ext.c b/test/v3ext.c
+index 5f6507a118..c0c3e07689 100644
+--- a/test/v3ext.c
++++ b/test/v3ext.c
+@@ -459,6 +459,101 @@ end:
+ 
+ #endif /* OPENSSL_NO_RFC3779 */
+ 
++/*
++ * nameConstraints extnValue contents with one empty directoryName subtree.
++ * Empty X509_NAME has canon_enc == NULL / canon_enclen == 0.
++ *
++ *   SEQUENCE { [0|1] { SEQUENCE { [4] { SEQUENCE {} } } } }
++ */
++static const unsigned char nc_excluded_empty_dirname[] = {
++    0x30, 0x08, 0xa1, 0x06, 0x30, 0x04, 0xa4, 0x02, 0x30, 0x00
++};
++static const unsigned char nc_permitted_empty_dirname[] = {
++    0x30, 0x08, 0xa0, 0x06, 0x30, 0x04, 0xa4, 0x02, 0x30, 0x00
++};
++
++/* Decode a raw nameConstraints extnValue into a NAME_CONSTRAINTS object. */
++static NAME_CONSTRAINTS *nc_empty_dirname_from_der(const unsigned char *der,
++    unsigned int der_len)
++{
++    NAME_CONSTRAINTS *nc = NULL;
++    ASN1_OCTET_STRING *os = NULL;
++    X509_EXTENSION *ext = NULL;
++
++    os = ASN1_OCTET_STRING_new();
++    if (!TEST_ptr(os)
++        || !TEST_true(ASN1_OCTET_STRING_set(os, der, der_len)))
++        goto end;
++    ext = X509_EXTENSION_create_by_NID(NULL, NID_name_constraints,
++        1 /* critical */, os);
++    if (!TEST_ptr(ext))
++        goto end;
++    nc = X509V3_EXT_d2i(ext);
++
++end:
++    X509_EXTENSION_free(ext);
++    ASN1_OCTET_STRING_free(os);
++    return nc;
++}
++
++/* Build a minimal certificate with a non-empty subject DN. */
++static X509 *nc_empty_dirname_subject(const char *cn)
++{
++    X509 *x = NULL;
++    X509_NAME *nm = NULL;
++
++    if (!TEST_ptr(x = X509_new()))
++        goto err;
++    nm = X509_NAME_new();
++    if (!TEST_ptr(nm)
++        || !TEST_true(X509_NAME_add_entry_by_txt(nm, "CN", MBSTRING_ASC,
++            (const unsigned char *)cn, -1, -1, 0))
++        || !TEST_true(X509_set_subject_name(x, nm)))
++        goto err;
++    X509_NAME_free(nm);
++    return x;
++
++err:
++    X509_NAME_free(nm);
++    X509_free(x);
++    return NULL;
++}
++
++/* Check an empty directoryName constraint against a non-empty subject DN. */
++static int nc_check_empty_dirname(const unsigned char *der, unsigned int der_len,
++    int expected)
++{
++    int ok = 0;
++    NAME_CONSTRAINTS *nc = NULL;
++    X509 *x = NULL;
++
++    if (!TEST_ptr(nc = nc_empty_dirname_from_der(der, der_len))
++        || !TEST_ptr(x = nc_empty_dirname_subject("leaf.example"))
++        || !TEST_int_eq(NAME_CONSTRAINTS_check(x, nc), expected))
++        goto end;
++
++    ok = 1;
++
++end:
++    X509_free(x);
++    NAME_CONSTRAINTS_free(nc);
++    return ok;
++}
++
++/* Empty excluded directoryName matches the subject DN: excluded violation. */
++static int test_nc_empty_dirname_excluded(void)
++{
++    return nc_check_empty_dirname(nc_excluded_empty_dirname,
++        sizeof(nc_excluded_empty_dirname), X509_V_ERR_EXCLUDED_VIOLATION);
++}
++
++/* Empty permitted directoryName matches the subject DN: permitted. */
++static int test_nc_empty_dirname_permitted(void)
++{
++    return nc_check_empty_dirname(nc_permitted_empty_dirname,
++        sizeof(nc_permitted_empty_dirname), X509_V_OK);
++}
++
+ OPT_TEST_DECLARE_USAGE("cert.pem\n")
+ 
+ int setup_tests(void)
+@@ -479,5 +574,7 @@ int setup_tests(void)
+     ADD_TEST(test_addr_fam_len);
+     ADD_TEST(test_addr_subset);
+ #endif /* OPENSSL_NO_RFC3779 */
++    ADD_TEST(test_nc_empty_dirname_excluded);
++    ADD_TEST(test_nc_empty_dirname_permitted);
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0039-DH-harden-empty-fromdata.patch b/package/libs/openssl/patches/0039-DH-harden-empty-fromdata.patch
new file mode 100644
index 0000000..3ad65c7
--- /dev/null
+++ b/package/libs/openssl/patches/0039-DH-harden-empty-fromdata.patch
@@ -0,0 +1,516 @@
+From ce605796d347715e5d2380d93b3d728488d68216 Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <openssl-users@dukhovni.org>
+Date: Mon, 25 May 2026 00:40:41 +1000
+Subject: [PATCH 39/41] DH: harden empty fromdata
+
+EVP_PKEY_fromdata for DH/DHX accepts an empty array and yields a
+DH with NULL params.p / params.g.  Several DH check entry points
+(DH_check, DH_check_params, DH_check_pub_key) then read
+dh->params.p / .g via BN_num_bits or BN_is_odd before any NULL
+check.  Add defensive guards at the top of each that report
+failure via *ret without dereferencing NULL; the existing
+return-1-with-flags contract is preserved.
+
+A new test_fromdata in endecode_test drives every supported
+keymgmt with an empty OSSL_PARAM[] for both EVP_PKEY_PUBLIC_KEY
+and EVP_PKEY_KEYPAIR selections, and tests that any returned key
+is sufficiently well behaved.
+
+Add a parameterised dup sweep to test/endecode_test.c covering
+every supported public-key algorithm in three shapes: full
+keypair, public-only, and embryonic (parameters-only).
+
+While here, stop endecode_test from silently passing when key
+generation fails: setup_tests() now returns its accumulated
+status, MAKE_*KEYS no longer short-circuits, and each
+ADD_TEST_SUITE is now conditional on keygen success.  Guard the
+explicit-EC-curve tests with OPENSSL_NO_EC_EXPLICIT_CURVES.
+
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Reviewed-by: Nikola Pajkovsky <nikolap@openssl.org>
+MergeDate: Thu Jul 23 08:35:26 2026
+(Merged from https://github.com/openssl/openssl/pull/31280)
+---
+ crypto/dh/dh_check.c |  22 +++
+ test/endecode_test.c | 397 ++++++++++++++++++++++++++++++++++++++++++-
+ 2 files changed, 418 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/dh/dh_check.c b/crypto/dh/dh_check.c
+index 2391f8cf1a..2345e72600 100644
+--- a/crypto/dh/dh_check.c
++++ b/crypto/dh/dh_check.c
+@@ -73,6 +73,14 @@ int DH_check_params(const DH *dh, int *ret)
+     BN_CTX *ctx = NULL;
+ 
+     *ret = 0;
++    /*
++     * A DH with no modulus or generator cannot be checked.  Report
++     * the failure via |*ret| rather than dereferencing NULL below.
++     */
++    if (dh->params.p == NULL || dh->params.g == NULL) {
++        *ret = DH_NOT_SUITABLE_GENERATOR | DH_CHECK_P_NOT_PRIME;
++        return 1;
++    }
+     ctx = BN_CTX_new_ex(dh->libctx);
+     if (ctx == NULL)
+         goto err;
+@@ -149,6 +157,11 @@ int DH_check(const DH *dh, int *ret)
+     int nid = DH_get_nid((DH *)dh);
+ 
+     *ret = 0;
++    /* A DH with no modulus or generator cannot be checked. */
++    if (dh->params.p == NULL || dh->params.g == NULL) {
++        *ret = DH_NOT_SUITABLE_GENERATOR | DH_CHECK_P_NOT_PRIME;
++        return 1;
++    }
+     if (nid != NID_undef)
+         return 1;
+ 
+@@ -249,6 +262,15 @@ int DH_check_pub_key_ex(const DH *dh, const BIGNUM *pub_key)
+  */
+ int DH_check_pub_key(const DH *dh, const BIGNUM *pub_key, int *ret)
+ {
++    *ret = 0;
++    /*
++     * Without a modulus we cannot check anything; signal failure via
++     * |*ret| rather than crashing in BN_num_bits below.
++     */
++    if (dh->params.p == NULL) {
++        *ret = DH_CHECK_PUBKEY_INVALID;
++        return 1;
++    }
+     /* Don't do any checks at all with an excessively large modulus */
+     if (BN_num_bits(dh->params.p) > OPENSSL_DH_CHECK_MAX_MODULUS_BITS) {
+         ERR_raise(ERR_LIB_DH, DH_R_MODULUS_TOO_LARGE);
+diff --git a/test/endecode_test.c b/test/endecode_test.c
+index d20277115a..d8aadb9426 100644
+--- a/test/endecode_test.c
++++ b/test/endecode_test.c
+@@ -865,6 +865,383 @@ static int test_public_via_MSBLOB(const char *type, EVP_PKEY *key)
+         test_mem, check_public_MSBLOB, dump_der, 0);
+ }
+ 
++/*
++ * Build a public-only EVP_PKEY of the same algorithm as |src| by
++ * round-tripping the public component through OSSL_PARAMs.
++ */
++static EVP_PKEY *make_public_only_copy(EVP_PKEY *src)
++{
++    OSSL_PARAM *params = NULL;
++    EVP_PKEY_CTX *cctx = NULL;
++    EVP_PKEY *pub = NULL;
++
++    if (!EVP_PKEY_todata(src, EVP_PKEY_PUBLIC_KEY, &params))
++        goto end;
++    if ((cctx = EVP_PKEY_CTX_new_from_pkey(NULL, src, NULL)) == NULL
++        || EVP_PKEY_fromdata_init(cctx) <= 0
++        || EVP_PKEY_fromdata(cctx, &pub, EVP_PKEY_PUBLIC_KEY, params) <= 0) {
++        EVP_PKEY_free(pub);
++        pub = NULL;
++    }
++end:
++    OSSL_PARAM_free(params);
++    EVP_PKEY_CTX_free(cctx);
++    return pub;
++}
++
++/*
++ * Build an "embryonic" EVP_PKEY of the same algorithm as |src|: just
++ * the keymgmt-bound type and (where applicable) domain parameters,
++ * with no key material.
++ */
++static EVP_PKEY *make_embryonic_copy(EVP_PKEY *src)
++{
++    EVP_PKEY *embryo = EVP_PKEY_new();
++
++    if (embryo == NULL)
++        return NULL;
++    if (EVP_PKEY_copy_parameters(embryo, src) <= 0) {
++        EVP_PKEY_free(embryo);
++        return NULL;
++    }
++    return embryo;
++}
++
++/*
++ * Check that EVP_PKEY_dup() works for every supported provider-backed
++ * key type, and that the duplicate compares equal to the original.
++ *
++ * Exercised in three shapes:
++ *   1. The full keypair |key| (typically pub + priv).
++ *   2. A public-only key derived from |key|.
++ *   3. An "embryonic" key (algorithm + domain parameters only, no
++ *      key material) produced with EVP_PKEY_copy_parameters().
++ */
++static int test_dup(const char *type, EVP_PKEY *key)
++{
++    EVP_PKEY *dup = NULL;
++    EVP_PKEY *pub_only = NULL;
++    EVP_PKEY *embryo = NULL;
++    int ok = 0;
++
++    if (!TEST_ptr(key)) {
++        TEST_info("%s: no source key", type);
++        return 0;
++    }
++
++    /* 1. Dup the full keypair. */
++    if (!TEST_ptr(dup = EVP_PKEY_dup(key))) {
++        TEST_info("%s: EVP_PKEY_dup of keypair returned NULL", type);
++        goto end;
++    }
++    if (!TEST_int_eq(EVP_PKEY_eq(key, dup), 1)) {
++        TEST_info("%s: keypair dup does not compare equal to original", type);
++        goto end;
++    }
++    EVP_PKEY_free(dup);
++    dup = NULL;
++
++    /* 2. Dup a public-only copy of the same key. */
++    if (!TEST_ptr(pub_only = make_public_only_copy(key))) {
++        TEST_info("%s: could not derive a public-only key", type);
++        goto end;
++    }
++    if (!TEST_ptr(dup = EVP_PKEY_dup(pub_only))) {
++        TEST_info("%s: EVP_PKEY_dup of public-only key returned NULL", type);
++        goto end;
++    }
++    if (!TEST_int_eq(EVP_PKEY_eq(pub_only, dup), 1)) {
++        TEST_info("%s: public-only dup does not compare equal to original",
++            type);
++        goto end;
++    }
++    EVP_PKEY_free(dup);
++    dup = NULL;
++
++    /*
++     * 3. Dup an embryonic key (algorithm + domain parameters only,
++     * no key bits).  Some keymgmts (RSA, RSA-PSS) refuse to build
++     * such a key via EVP_PKEY_copy_parameters(); treat that as a
++     * graceful skip.  Where an embryo can be built we compare via
++     * EVP_PKEY_parameters_eq() since EVP_PKEY_eq() requires key
++     * bits to match.  Algorithms with no domain parameters may
++     * legitimately answer -2 ("nothing to compare").
++     */
++    embryo = make_embryonic_copy(key);
++    if (embryo != NULL) {
++        if (!TEST_ptr(dup = EVP_PKEY_dup(embryo))) {
++            TEST_info("%s: EVP_PKEY_dup of embryonic key returned NULL", type);
++            goto end;
++        }
++        {
++            int eq = EVP_PKEY_parameters_eq(embryo, dup);
++
++            if (!TEST_true(eq == 1 || eq == -2)) {
++                TEST_info("%s: embryonic dup parameters_eq %d (want 1 or -2)",
++                    type, eq);
++                goto end;
++            }
++        }
++    } else {
++        TEST_info("%s: skipping embryonic dup (no params-only key shape)",
++            type);
++    }
++
++    ok = 1;
++end:
++    EVP_PKEY_free(dup);
++    EVP_PKEY_free(pub_only);
++    EVP_PKEY_free(embryo);
++    return ok;
++}
++
++/*
++ * Drive EVP_PKEY_fromdata with the supplied OSSL_PARAM[] (NULL =
++ * empty array) for the given selection.  Either outcome is accepted:
++ * fromdata may reject the input, or it may succeed and yield a key
++ * with at most algorithm-bound parameters.  In the success case a
++ * battery of common consumer ops must not crash on the resulting
++ * key; their return values are not asserted.
++ */
++static int run_empty_fromdata_probe(const char *type, EVP_PKEY_CTX *cctx,
++    int selection, OSSL_PARAM *params, const char *selname)
++{
++    EVP_PKEY *pkey = NULL;
++    OSSL_PARAM empty[1];
++    int r;
++    int ok = 0;
++
++    if (params == NULL) {
++        empty[0] = OSSL_PARAM_construct_end();
++        params = empty;
++    }
++
++    if (!TEST_int_gt(EVP_PKEY_fromdata_init(cctx), 0)) {
++        TEST_info("%s: fromdata_init failed (%s)", type, selname);
++        goto end;
++    }
++    r = EVP_PKEY_fromdata(cctx, &pkey, selection, params);
++    if (r <= 0) {
++        /* Rejection is fine, but the out-pointer must remain NULL. */
++        if (!TEST_ptr_null(pkey)) {
++            TEST_info("%s: fromdata returned %d but pkey != NULL (%s)",
++                type, r, selname);
++            goto end;
++        }
++        ok = 1;
++        goto end;
++    }
++    if (!TEST_ptr(pkey)) {
++        TEST_info("%s: fromdata returned %d but pkey == NULL (%s)",
++            type, r, selname);
++        goto end;
++    }
++    /*
++     * Walk a battery of common consumer ops on the resulting key.
++     * Their return values are not asserted - a contentless key may
++     * fail every op - only crashing is forbidden.
++     */
++    (void)EVP_PKEY_get_bits(pkey);
++    (void)EVP_PKEY_get_security_bits(pkey);
++    (void)EVP_PKEY_get_size(pkey);
++    (void)EVP_PKEY_eq(pkey, pkey);
++    (void)EVP_PKEY_parameters_eq(pkey, pkey);
++    {
++        OSSL_PARAM *out = NULL;
++
++        if (EVP_PKEY_todata(pkey, selection, &out) > 0)
++            OSSL_PARAM_free(out);
++    }
++    {
++        EVP_PKEY *clone = EVP_PKEY_dup(pkey);
++
++        EVP_PKEY_free(clone);
++    }
++    {
++        BIO *bio = BIO_new(BIO_s_null());
++
++        if (bio != NULL) {
++            (void)EVP_PKEY_print_public(bio, pkey, 0, NULL);
++            (void)EVP_PKEY_print_private(bio, pkey, 0, NULL);
++            (void)EVP_PKEY_print_params(bio, pkey, 0, NULL);
++            BIO_free(bio);
++        }
++    }
++    {
++        /* The param/public/private/pairwise check family. */
++        EVP_PKEY_CTX *vctx = EVP_PKEY_CTX_new_from_pkey(NULL, pkey, NULL);
++
++        if (vctx != NULL) {
++            (void)EVP_PKEY_param_check(vctx);
++            (void)EVP_PKEY_param_check_quick(vctx);
++            (void)EVP_PKEY_public_check(vctx);
++            (void)EVP_PKEY_public_check_quick(vctx);
++            (void)EVP_PKEY_private_check(vctx);
++            (void)EVP_PKEY_pairwise_check(vctx);
++            EVP_PKEY_CTX_free(vctx);
++        }
++    }
++    ok = 1;
++end:
++    EVP_PKEY_free(pkey);
++    return ok;
++}
++
++static int probe_empty_fromdata(const char *type, EVP_PKEY *prototype,
++    int selection, const char *selname)
++{
++    EVP_PKEY_CTX *cctx = NULL;
++    int ok = 0;
++
++    if (!TEST_ptr(cctx = EVP_PKEY_CTX_new_from_pkey(NULL, prototype, NULL))) {
++        TEST_info("%s: CTX alloc failed for empty fromdata (%s)",
++            type, selname);
++        goto end;
++    }
++    ok = run_empty_fromdata_probe(type, cctx, selection, NULL, selname);
++end:
++    EVP_PKEY_CTX_free(cctx);
++    return ok;
++}
++
++/*
++ * Drive EVP_PKEY_fromdata with an empty OSSL_PARAM[] for both
++ * EVP_PKEY_PUBLIC_KEY and EVP_PKEY_KEYPAIR selections.  Either
++ * outcome is acceptable: fromdata rejects, or it succeeds and the
++ * resulting key survives the consumer-op battery without crashing.
++ */
++static int test_fromdata(const char *type, EVP_PKEY *prototype)
++{
++    if (!TEST_ptr(prototype)) {
++        TEST_info("%s: no prototype key", type);
++        return 0;
++    }
++    if (!probe_empty_fromdata(type, prototype, EVP_PKEY_PUBLIC_KEY,
++            "EVP_PKEY_PUBLIC_KEY"))
++        return 0;
++    if (!probe_empty_fromdata(type, prototype, EVP_PKEY_KEYPAIR,
++            "EVP_PKEY_KEYPAIR"))
++        return 0;
++    return 1;
++}
++
++/*
++ * Named-group-only partial-shape variants for prototype-matrix
++ * algorithms, plus any keymgmts without a keygen path.  Each entry
++ * is one (name, selection, params-builder) shape; a NULL builder
++ * means "use an empty OSSL_PARAM[]".  Algorithms not loadable under
++ * the active provider set are silently skipped.
++ */
++typedef int (*fromdata_shape_build_fn)(OSSL_PARAM_BLD *bld);
++
++struct fromdata_shape {
++    const char *name; /* keymgmt algorithm name */
++    int selection; /* EVP_PKEY_PUBLIC_KEY / KEYPAIR / etc. */
++    fromdata_shape_build_fn build; /* NULL -> empty OSSL_PARAM[] */
++    const char *label; /* diagnostic label */
++};
++
++#ifndef OPENSSL_NO_DH
++static int build_dh_named_group(OSSL_PARAM_BLD *bld)
++{
++    return OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME,
++        "ffdhe2048", 0);
++}
++#endif
++
++#ifndef OPENSSL_NO_EC
++static int build_ec_named_group(OSSL_PARAM_BLD *bld)
++{
++    return OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME,
++        "P-256", 0);
++}
++#ifndef OPENSSL_NO_SM2
++static int build_sm2_named_group(OSSL_PARAM_BLD *bld)
++{
++    return OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME,
++        "SM2", 0);
++}
++#endif
++#endif
++
++#if defined(OPENSSL_NO_DH) && defined(OPENSSL_NO_EC)
++#undef TEST_FROMDATA_NO_KEYGEN
++#else
++#define TEST_FROMDATA_NO_KEYGEN
++static const struct fromdata_shape no_keygen_shapes[] = {
++/* Named-group-only partial shapes. */
++#ifndef OPENSSL_NO_DH
++    { "DH", EVP_PKEY_KEYPAIR, build_dh_named_group,
++        "DH / named group only / KEYPAIR" },
++    { "DH", EVP_PKEY_PUBLIC_KEY, build_dh_named_group,
++        "DH / named group only / PUBLIC_KEY" },
++#endif
++#ifndef OPENSSL_NO_EC
++    { "EC", EVP_PKEY_KEYPAIR, build_ec_named_group,
++        "EC / group only / KEYPAIR" },
++    { "EC", EVP_PKEY_PUBLIC_KEY, build_ec_named_group,
++        "EC / group only / PUBLIC_KEY" },
++#ifndef OPENSSL_NO_SM2
++    { "SM2", EVP_PKEY_KEYPAIR, build_sm2_named_group,
++        "SM2 / group only / KEYPAIR" },
++#endif
++#endif
++};
++
++/*
++ * Probe An algorithm by name rather than a prototype key, for keymgmts without
++ * a keygen path.  Algorithms not loadable under the active provider set are
++ * silently skipped.  |params| may be NULL (= empty OSSL_PARAM[]) or a
++ * caller-built partial array.
++ */
++static int probe_fromdata_by_name(const char *name, int selection,
++    OSSL_PARAM *params, const char *selname)
++{
++    EVP_PKEY_CTX *cctx = NULL;
++    int ok = 1;
++
++    cctx = EVP_PKEY_CTX_new_from_name(NULL, name, NULL);
++    if (cctx == NULL)
++        return 1;
++    ok = run_empty_fromdata_probe(name, cctx, selection, params, selname);
++    EVP_PKEY_CTX_free(cctx);
++    return ok;
++}
++
++static int test_fromdata_no_keygen(void)
++{
++    size_t i;
++
++    for (i = 0; i < OSSL_NELEM(no_keygen_shapes); i++) {
++        const struct fromdata_shape *s = &no_keygen_shapes[i];
++        OSSL_PARAM_BLD *bld = NULL;
++        OSSL_PARAM *params = NULL;
++        int ok;
++
++        if (s->build != NULL) {
++            if (!TEST_ptr(bld = OSSL_PARAM_BLD_new()))
++                return 0;
++            if (!s->build(bld)) {
++                TEST_info("%s: builder failed", s->label);
++                OSSL_PARAM_BLD_free(bld);
++                return 0;
++            }
++            params = OSSL_PARAM_BLD_to_param(bld);
++            if (!TEST_ptr(params)) {
++                OSSL_PARAM_BLD_free(bld);
++                return 0;
++            }
++        }
++        ok = probe_fromdata_by_name(s->name, s->selection, params, s->label);
++        OSSL_PARAM_free(params);
++        OSSL_PARAM_BLD_free(bld);
++        if (!ok)
++            return 0;
++    }
++    return 1;
++}
++#endif
++
+ #define KEYS(KEYTYPE) \
+     static EVP_PKEY *key_##KEYTYPE = NULL
+ #define MAKE_KEYS(KEYTYPE, KEYTYPEstr, params) \
+@@ -908,6 +1285,14 @@ static int test_public_via_MSBLOB(const char *type, EVP_PKEY *key)
+     static int test_public_##KEYTYPE##_via_PEM(void)                      \
+     {                                                                     \
+         return test_public_via_PEM(KEYTYPEstr, key_##KEYTYPE, fips);      \
++    }                                                                     \
++    static int test_dup_##KEYTYPE(void)                                   \
++    {                                                                     \
++        return test_dup(KEYTYPEstr, key_##KEYTYPE);                       \
++    }                                                                     \
++    static int test_fromdata_##KEYTYPE(void)                              \
++    {                                                                     \
++        return test_fromdata(KEYTYPEstr, key_##KEYTYPE);                  \
+     }
+ 
+ #define ADD_TEST_SUITE(KEYTYPE)                     \
+@@ -916,7 +1301,9 @@ static int test_public_via_MSBLOB(const char *type, EVP_PKEY *key)
+     ADD_TEST(test_protected_##KEYTYPE##_via_DER);   \
+     ADD_TEST(test_protected_##KEYTYPE##_via_PEM);   \
+     ADD_TEST(test_public_##KEYTYPE##_via_DER);      \
+-    ADD_TEST(test_public_##KEYTYPE##_via_PEM)
++    ADD_TEST(test_public_##KEYTYPE##_via_PEM);      \
++    ADD_TEST(test_dup_##KEYTYPE);                   \
++    ADD_TEST(test_fromdata_##KEYTYPE)
+ 
+ #define IMPLEMENT_TEST_SUITE_PARAMS(KEYTYPE, KEYTYPEstr)       \
+     static int test_params_##KEYTYPE##_via_DER(void)           \
+@@ -1475,6 +1862,14 @@ int setup_tests(void)
+ #ifndef OPENSSL_NO_RC4
+         ADD_TEST_SUITE_PROTECTED_PVK(RSA);
+ #endif
++
++        /*
++         * Named-group-only partial shapes for DH and EC/SM2.  Each
++         * shape is silently skipped if the algorithm is not loadable.
++         */
++#ifdef TEST_FROMDATA_NO_KEYGEN
++        ADD_TEST(test_fromdata_no_keygen);
++#endif
+     }
+ 
+     return 1;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0040-Improve-TLS-handling-of-EC-point-formats-3.0.patch b/package/libs/openssl/patches/0040-Improve-TLS-handling-of-EC-point-formats-3.0.patch
new file mode 100644
index 0000000..84ff85d
--- /dev/null
+++ b/package/libs/openssl/patches/0040-Improve-TLS-handling-of-EC-point-formats-3.0.patch
@@ -0,0 +1,346 @@
+From 8f04db7c12d7ce696165fa16ba718ed622e151dd Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <viktor@openssl.org>
+Date: Sat, 20 Jun 2026 00:28:36 +1000
+Subject: [PATCH 40/41] Improve TLS handling of EC point formats (3.0)
+
+The ec_point_formats extension no longer plays any role in EC
+certificate selection or acceptance: tls1_check_pkey_comp() with
+its callers in tls1_check_cert_param(), tls12_check_peer_sigalg()
+and tls1_check_chain() are removed.  TLS 1.3 disregards
+ec_point_formats already, and we can decode any form a peer might
+send, so refusing a compressed peer cert in TLS 1.2 because we
+didn't advertise compressed buys nothing.
+
+A new 33-compressed-spki ssl_new test verifies that a compressed
+EC leaf certificate handshakes at both TLS 1.2 and TLS 1.3 without
+either side opting into LegacyECPointFormats.
+
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Mon Jul 27 03:30:04 2026
+(Merged from https://github.com/openssl/openssl/pull/31621)
+---
+ ssl/t1_lib.c                             | 57 -----------------
+ test/certs/server-ec-compressed-cert.pem | 12 ++++
+ test/certs/server-ec-compressed-key.pem  |  5 ++
+ test/recipes/80-test_ssl_new.t           |  4 +-
+ test/ssl-tests/33-compressed-spki.cnf    | 76 ++++++++++++++++++++++
+ test/ssl-tests/33-compressed-spki.cnf.in | 81 ++++++++++++++++++++++++
+ 6 files changed, 177 insertions(+), 58 deletions(-)
+ create mode 100644 test/certs/server-ec-compressed-cert.pem
+ create mode 100644 test/certs/server-ec-compressed-key.pem
+ create mode 100644 test/ssl-tests/33-compressed-spki.cnf
+ create mode 100644 test/ssl-tests/33-compressed-spki.cnf.in
+
+diff --git a/ssl/t1_lib.c b/ssl/t1_lib.c
+index ac5ae3da2e..bede499058 100644
+--- a/ssl/t1_lib.c
++++ b/ssl/t1_lib.c
+@@ -865,53 +865,6 @@ void tls1_get_formatlist(SSL *s, const unsigned char **pformats,
+     }
+ }
+ 
+-/* Check a key is compatible with compression extension */
+-static int tls1_check_pkey_comp(SSL *s, EVP_PKEY *pkey)
+-{
+-    unsigned char comp_id;
+-    size_t i;
+-    int point_conv;
+-
+-    /* If not an EC key nothing to check */
+-    if (!EVP_PKEY_is_a(pkey, "EC"))
+-        return 1;
+-
+-    /* Get required compression id */
+-    point_conv = EVP_PKEY_get_ec_point_conv_form(pkey);
+-    if (point_conv == 0)
+-        return 0;
+-    if (point_conv == POINT_CONVERSION_UNCOMPRESSED) {
+-        comp_id = TLSEXT_ECPOINTFORMAT_uncompressed;
+-    } else if (SSL_IS_TLS13(s)) {
+-        /*
+-         * ec_point_formats extension is not used in TLSv1.3 so we ignore
+-         * this check.
+-         */
+-        return 1;
+-    } else {
+-        int field_type = EVP_PKEY_get_field_type(pkey);
+-
+-        if (field_type == NID_X9_62_prime_field)
+-            comp_id = TLSEXT_ECPOINTFORMAT_ansiX962_compressed_prime;
+-        else if (field_type == NID_X9_62_characteristic_two_field)
+-            comp_id = TLSEXT_ECPOINTFORMAT_ansiX962_compressed_char2;
+-        else
+-            return 0;
+-    }
+-    /*
+-     * If point formats extension present check it, otherwise everything is
+-     * supported (see RFC4492).
+-     */
+-    if (s->ext.peer_ecpointformats == NULL)
+-        return 1;
+-
+-    for (i = 0; i < s->ext.peer_ecpointformats_len; i++) {
+-        if (s->ext.peer_ecpointformats[i] == comp_id)
+-            return 1;
+-    }
+-    return 0;
+-}
+-
+ /* Return group id of a key */
+ static uint16_t tls1_get_group_id(EVP_PKEY *pkey)
+ {
+@@ -936,9 +889,6 @@ static int tls1_check_cert_param(SSL *s, X509 *x, int check_ee_md)
+     /* If not EC nothing to do */
+     if (!EVP_PKEY_is_a(pkey, "EC"))
+         return 1;
+-    /* Check compression */
+-    if (!tls1_check_pkey_comp(s, pkey))
+-        return 0;
+     group_id = tls1_get_group_id(pkey);
+     /*
+      * For a server we allow the certificate to not be in our list of supported
+@@ -1523,13 +1473,6 @@ int tls12_check_peer_sigalg(SSL *s, uint16_t sig, EVP_PKEY *pkey)
+ 
+     if (pkeyid == EVP_PKEY_EC) {
+ 
+-        /* Check point compression is permitted */
+-        if (!tls1_check_pkey_comp(s, pkey)) {
+-            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER,
+-                SSL_R_ILLEGAL_POINT_COMPRESSION);
+-            return 0;
+-        }
+-
+         /* For TLS 1.3 or Suite B check curve matches signature algorithm */
+         if (SSL_IS_TLS13(s) || tls1_suiteb(s)) {
+             int curve = ssl_get_EC_curve_nid(pkey);
+diff --git a/test/certs/server-ec-compressed-cert.pem b/test/certs/server-ec-compressed-cert.pem
+new file mode 100644
+index 0000000000..4e97f49af2
+--- /dev/null
++++ b/test/certs/server-ec-compressed-cert.pem
+@@ -0,0 +1,12 @@
++-----BEGIN CERTIFICATE-----
++MIIBrzCCATSgAwIBAgIBAjAKBggqhkjOPQQDAjAbMRkwFwYDVQQDDBBFQ0RTQSBQ
++LTM4NCByb290MCAXDTI2MDYxOTE4MDA1OFoYDzIxMjYwNTI2MTgwMDU4WjAZMRcw
++FQYDVQQDDA5zZXJ2ZXIuZXhhbXBsZTA5MBMGByqGSM49AgEGCCqGSM49AwEHAyIA
++A4Mt9T6fKt3APp8/Frw65PDi2eMYdZK98nhBW9pA1Ccho4GIMIGFMB0GA1UdDgQW
++BBTozN8kakexZEnc26PUo5K2W9ptbTAfBgNVHSMEGDAWgBQm0I8de1/cHn9BgH1j
++yhx1gdaFaTAJBgNVHRMEAjAAMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcD
++AjAZBgNVHREEEjAQgg5zZXJ2ZXIuZXhhbXBsZTAKBggqhkjOPQQDAgNpADBmAjEA
++hvcNLTyL7vamQEJet5uvOXH7NKPHlG8sbfPvGS/AQ0yk6ARdc1Y1gV6FAnmnQUhX
++AjEA2HMTkh+h2ZDm68uRnhsNXIxI4dYF/nr5bdxw8XKN4P84Mg4gs37/IPoVN9jG
++Y4yh
++-----END CERTIFICATE-----
+diff --git a/test/certs/server-ec-compressed-key.pem b/test/certs/server-ec-compressed-key.pem
+new file mode 100644
+index 0000000000..98218fcb3c
+--- /dev/null
++++ b/test/certs/server-ec-compressed-key.pem
+@@ -0,0 +1,5 @@
++-----BEGIN PRIVATE KEY-----
++MGcCAQAwEwYHKoZIzj0CAQYIKoZIzj0DAQcETTBLAgEBBCAb1VgxSUhJyh43soLb
++FMsebjWSp/Hma3kSyw6lT4txDaEkAyIAA4Mt9T6fKt3APp8/Frw65PDi2eMYdZK9
++8nhBW9pA1Cch
++-----END PRIVATE KEY-----
+diff --git a/test/recipes/80-test_ssl_new.t b/test/recipes/80-test_ssl_new.t
+index fe03607419..b89650d1ba 100644
+--- a/test/recipes/80-test_ssl_new.t
++++ b/test/recipes/80-test_ssl_new.t
+@@ -38,7 +38,7 @@ map { s/\^// } @conf_files if $^O eq "VMS";
+ 
+ # We hard-code the number of tests to double-check that the globbing above
+ # finds all files as expected.
+-plan tests => 30;
++plan tests => 31;
+ 
+ # Some test results depend on the configuration of enabled protocols. We only
+ # verify generated sources in the default configuration.
+@@ -84,6 +84,7 @@ my %conf_dependent_tests = (
+   "27-ticket-appdata.cnf" => !$is_default_tls,
+   "28-seclevel.cnf" => disabled("tls1_2") || $no_ec,
+   "30-extended-master-secret.cnf" => disabled("tls1_2"),
++  "33-compressed-spki.cnf" => disabled("tls1_2") || disabled("tls1_3") || $no_ec,
+ );
+ 
+ # Add your test here if it should be skipped for some compile-time
+@@ -118,6 +119,7 @@ my %skip = (
+   "25-cipher.cnf" => disabled("ec") || disabled("tls1_2"),
+   "26-tls13_client_auth.cnf" => disabled("tls1_3") || ($no_ec && $no_dh),
+   "29-dtls-sctp-label-bug.cnf" => disabled("sctp") || disabled("sock"),
++  "33-compressed-spki.cnf" => disabled("tls1_2") || disabled("tls1_3") || $no_ec,
+ );
+ 
+ foreach my $conf (@conf_files) {
+diff --git a/test/ssl-tests/33-compressed-spki.cnf b/test/ssl-tests/33-compressed-spki.cnf
+new file mode 100644
+index 0000000000..fd9816a27e
+--- /dev/null
++++ b/test/ssl-tests/33-compressed-spki.cnf
+@@ -0,0 +1,76 @@
++# Generated with generate_ssl_tests.pl
++
++num_tests = 2
++
++test-0 = 0-tls12-compressed-spki
++test-1 = 1-tls13-compressed-spki
++# ===========================================================
++
++[0-tls12-compressed-spki]
++ssl_conf = 0-tls12-compressed-spki-ssl
++
++[0-tls12-compressed-spki-ssl]
++server = 0-tls12-compressed-spki-server
++client = 0-tls12-compressed-spki-client
++
++[0-tls12-compressed-spki-server]
++Certificate = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-cert.pem
++CipherString = DEFAULT
++ClientCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++MaxProtocol = TLSv1.2
++MinProtocol = TLSv1.2
++PrivateKey = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-key.pem
++VerifyCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++VerifyMode = Require
++
++[0-tls12-compressed-spki-client]
++Certificate = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-cert.pem
++CipherString = ECDHE-ECDSA-AES128-GCM-SHA256
++MaxProtocol = TLSv1.2
++MinProtocol = TLSv1.2
++PrivateKey = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-key.pem
++VerifyCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++VerifyMode = Peer
++
++[test-0]
++ExpectedClientCertType = P-256
++ExpectedProtocol = TLSv1.2
++ExpectedResult = Success
++ExpectedServerCertType = P-256
++
++
++# ===========================================================
++
++[1-tls13-compressed-spki]
++ssl_conf = 1-tls13-compressed-spki-ssl
++
++[1-tls13-compressed-spki-ssl]
++server = 1-tls13-compressed-spki-server
++client = 1-tls13-compressed-spki-client
++
++[1-tls13-compressed-spki-server]
++Certificate = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-cert.pem
++CipherString = DEFAULT
++ClientCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++MaxProtocol = TLSv1.3
++MinProtocol = TLSv1.3
++PrivateKey = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-key.pem
++VerifyCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++VerifyMode = Require
++
++[1-tls13-compressed-spki-client]
++Certificate = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-cert.pem
++CipherString = DEFAULT
++MaxProtocol = TLSv1.3
++MinProtocol = TLSv1.3
++PrivateKey = ${ENV::TEST_CERTS_DIR}/server-ec-compressed-key.pem
++VerifyCAFile = ${ENV::TEST_CERTS_DIR}/p384-root.pem
++VerifyMode = Peer
++
++[test-1]
++ExpectedClientCertType = P-256
++ExpectedProtocol = TLSv1.3
++ExpectedResult = Success
++ExpectedServerCertType = P-256
++
++
+diff --git a/test/ssl-tests/33-compressed-spki.cnf.in b/test/ssl-tests/33-compressed-spki.cnf.in
+new file mode 100644
+index 0000000000..06302a46a9
+--- /dev/null
++++ b/test/ssl-tests/33-compressed-spki.cnf.in
+@@ -0,0 +1,81 @@
++# -*- mode: perl; -*-
++# Copyright 2026 The OpenSSL Project Authors. All Rights Reserved.
++#
++# Licensed under the Apache License 2.0 (the "License").  You may not use
++# this file except in compliance with the License.  You can obtain a copy
++# in the file LICENSE in the source distribution or at
++# https://www.openssl.org/source/license.html
++
++
++## End-to-end check that compressed-form EC leaf certificates
++## (server-ec-compressed-cert.pem, P-256 named curve, SPKI bit-string
++## leading byte 0x02 or 0x03, anchored to the P-384 EC root) work at
++## both TLS 1.2 and TLS 1.3 in both directions: the client presents
++## the same compressed leaf to a server that requires client
++## authentication, exercising X.509 acceptance of compressed point
++## form on both sides simultaneously.  The ec_point_formats extension
++## no longer affects X.509 cert selection or acceptance, so neither
++## peer opts into LegacyECPointFormats; the default ec_point_formats
++## lists ('uncompressed' only) and the compressed leaves coexist.
++
++package ssltests;
++use OpenSSL::Test::Utils;
++
++our @tests = ();
++
++unless (disabled("ec") || disabled("tls1_2") || disabled("tls1_3")) {
++@tests = (
++    {
++        name => "tls12-compressed-spki",
++        server => {
++            "Certificate"  => test_pem("server-ec-compressed-cert.pem"),
++            "PrivateKey"   => test_pem("server-ec-compressed-key.pem"),
++            "VerifyCAFile" => test_pem("p384-root.pem"),
++            "ClientCAFile" => test_pem("p384-root.pem"),
++            "VerifyMode"   => "Require",
++            "MinProtocol"  => "TLSv1.2",
++            "MaxProtocol"  => "TLSv1.2",
++        },
++        client => {
++            "Certificate"  => test_pem("server-ec-compressed-cert.pem"),
++            "PrivateKey"   => test_pem("server-ec-compressed-key.pem"),
++            "VerifyCAFile" => test_pem("p384-root.pem"),
++            "MinProtocol"  => "TLSv1.2",
++            "MaxProtocol"  => "TLSv1.2",
++            "CipherString" => "ECDHE-ECDSA-AES128-GCM-SHA256",
++        },
++        test => {
++            "ExpectedResult"         => "Success",
++            "ExpectedProtocol"       => "TLSv1.2",
++            "ExpectedServerCertType" => "P-256",
++            "ExpectedClientCertType" => "P-256",
++        },
++    },
++
++    {
++        name => "tls13-compressed-spki",
++        server => {
++            "Certificate"  => test_pem("server-ec-compressed-cert.pem"),
++            "PrivateKey"   => test_pem("server-ec-compressed-key.pem"),
++            "VerifyCAFile" => test_pem("p384-root.pem"),
++            "ClientCAFile" => test_pem("p384-root.pem"),
++            "VerifyMode"   => "Require",
++            "MinProtocol"  => "TLSv1.3",
++            "MaxProtocol"  => "TLSv1.3",
++        },
++        client => {
++            "Certificate"  => test_pem("server-ec-compressed-cert.pem"),
++            "PrivateKey"   => test_pem("server-ec-compressed-key.pem"),
++            "VerifyCAFile" => test_pem("p384-root.pem"),
++            "MinProtocol"  => "TLSv1.3",
++            "MaxProtocol"  => "TLSv1.3",
++        },
++        test => {
++            "ExpectedResult"         => "Success",
++            "ExpectedProtocol"       => "TLSv1.3",
++            "ExpectedServerCertType" => "P-256",
++            "ExpectedClientCertType" => "P-256",
++        },
++    },
++);
++}
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0041-crypto-pkcs12-p12_decr.c-fix-EVP_CIPHER_CTX_ctrl-err.patch b/package/libs/openssl/patches/0041-crypto-pkcs12-p12_decr.c-fix-EVP_CIPHER_CTX_ctrl-err.patch
new file mode 100644
index 0000000..3e3067d
--- /dev/null
+++ b/package/libs/openssl/patches/0041-crypto-pkcs12-p12_decr.c-fix-EVP_CIPHER_CTX_ctrl-err.patch
@@ -0,0 +1,57 @@
+From bd1685368f7df78e2f0a629fc1f3bf79913a6319 Mon Sep 17 00:00:00 2001
+From: Adel-Ayoub <adelayoub.maaziz@gmail.com>
+Date: Fri, 3 Jul 2026 17:47:50 +0100
+Subject: [PATCH 41/41] crypto/pkcs12/p12_decr.c: fix EVP_CIPHER_CTX_ctrl error
+ checks
+
+EVP_CIPHER_CTX_ctrl() reports failure of the EVP_CTRL_AEAD_TLS1_AAD
+and EVP_CTRL_AEAD_SET_TAG controls as 0, not as a negative value,
+so the "< 0" checks on the cipher-with-MAC path cannot detect any
+failure.  A return of 0 means a failed or unsupported control, or
+for EVP_CTRL_AEAD_TLS1_AAD a zero MAC length, none of which is
+usable here.
+
+Change both checks to "<= 0", matching the EVP_CTRL_AEAD_GET_TAG
+check fixed by commit 674c23d2656e in this function.
+
+Follow-up to https://github.com/openssl/openssl/pull/30923.
+
+Fixes: ea0add4a8227 "New GOST PKCS12 standard support"
+
+CLA: trivial
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Jakub Zelenka <jakub.zelenka@openssl.foundation>
+MergeDate: Mon Jul 27 10:27:42 2026
+(Merged from https://github.com/openssl/openssl/pull/31848)
+---
+ crypto/pkcs12/p12_decr.c | 5 +++--
+ 1 file changed, 3 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/pkcs12/p12_decr.c b/crypto/pkcs12/p12_decr.c
+index 730048b839..f23ef71b09 100644
+--- a/crypto/pkcs12/p12_decr.c
++++ b/crypto/pkcs12/p12_decr.c
+@@ -47,7 +47,8 @@ unsigned char *PKCS12_pbe_crypt_ex(const X509_ALGOR *algor,
+     if ((EVP_CIPHER_get_flags(EVP_CIPHER_CTX_get0_cipher(ctx))
+             & EVP_CIPH_FLAG_CIPHER_WITH_MAC)
+         != 0) {
+-        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_TLS1_AAD, 0, &mac_len) < 0) {
++        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_TLS1_AAD, 0, &mac_len)
++            <= 0) {
+             ERR_raise(ERR_LIB_PKCS12, ERR_R_INTERNAL_ERROR);
+             goto err;
+         }
+@@ -62,7 +63,7 @@ unsigned char *PKCS12_pbe_crypt_ex(const X509_ALGOR *algor,
+             inlen -= mac_len;
+             if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_TAG,
+                     (int)mac_len, (unsigned char *)in + inlen)
+-                < 0) {
++                <= 0) {
+                 ERR_raise(ERR_LIB_PKCS12, ERR_R_INTERNAL_ERROR);
+                 goto err;
+             }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0042-Update-CHANGES-NEWS-to-mention-the-HollowByte-fix.patch b/package/libs/openssl/patches/0042-Update-CHANGES-NEWS-to-mention-the-HollowByte-fix.patch
new file mode 100644
index 0000000..d2e10b2
--- /dev/null
+++ b/package/libs/openssl/patches/0042-Update-CHANGES-NEWS-to-mention-the-HollowByte-fix.patch
@@ -0,0 +1,58 @@
+From d01f86f219489d333cb9fafe040c5f9ad13ea969 Mon Sep 17 00:00:00 2001
+From: Matt Caswell <matt@openssl.foundation>
+Date: Wed, 22 Jul 2026 09:13:18 +0100
+Subject: [PATCH 42/48] Update CHANGES/NEWS to mention the HollowByte fix
+
+Add a previously missing CHANGES.md/NEWS.md entry for the Hollowbyte fix.
+
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Wed Jul 29 09:19:06 2026
+(Merged from https://github.com/openssl/openssl/pull/32043)
+---
+ CHANGES.md | 14 ++++++++++++++
+ NEWS.md    |  2 ++
+ 2 files changed, 16 insertions(+)
+
+diff --git a/CHANGES.md b/CHANGES.md
+index e71ac7d014..48092db90b 100644
+--- a/CHANGES.md
++++ b/CHANGES.md
+@@ -44,6 +44,20 @@ breaking changes, and mappings for the large list of deprecated functions.
+ 
+ ### Changes between 3.0.20 and 3.0.21 [9 Jun 2026]
+ 
++ * Fixed excessive allocation of the handshake message buffer (aka HollowByte)
++
++   Previously, we would allocate a buffer large enough to hold the full size of
++   an incoming handshake message as advertised by the peer. This could be quite
++   large (although it is bounded, e.g. for ClientHello this is approximately
++   128 KiB). If the peer then fails to send the full handshake message, then the
++   endpoint is left waiting for the remainder of the message to arrive and the
++   memory is still allocated (i.e. a Slowloris attack). To prevent this, we
++   incrementally grow the buffer as we receive the data.
++
++   This issue was reported by Okta Red Team.
++
++   *Matt Caswell*
++
+  * Fixed heap use-after-free in `PKCS7_verify()`.
+ 
+    Severity: High
+diff --git a/NEWS.md b/NEWS.md
+index 03246341aa..42b21d977e 100644
+--- a/NEWS.md
++++ b/NEWS.md
+@@ -57,6 +57,8 @@ This release incorporates the following bug fixes and mitigations:
+     and AES-SIV modes.
+     ([CVE-2026-45446])
+ 
++  * Fixed excessive allocation of the handshake message buffer (aka HollowByte)
++
+ ### Major changes between OpenSSL 3.0.19 and OpenSSL 3.0.20 [7 Apr 2026]
+ 
+ OpenSSL 3.0.20 is a security patch release. The most severe CVE fixed in this
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0043-cms-fix-AuthenticatedData-authAttrs-and-unauthAttrs-.patch b/package/libs/openssl/patches/0043-cms-fix-AuthenticatedData-authAttrs-and-unauthAttrs-.patch
new file mode 100644
index 0000000..26efce6
--- /dev/null
+++ b/package/libs/openssl/patches/0043-cms-fix-AuthenticatedData-authAttrs-and-unauthAttrs-.patch
@@ -0,0 +1,112 @@
+From 429ea9a2f006511b9e2cbd7e59472a33571883f7 Mon Sep 17 00:00:00 2001
+From: Jakub Zelenka <jakub.zelenka@openssl.foundation>
+Date: Wed, 15 Jul 2026 12:20:03 +0200
+Subject: [PATCH 43/48] cms: fix AuthenticatedData authAttrs and unauthAttrs
+ element type
+
+The CMS_AuthenticatedData ASN.1 template declared the authAttrs and
+unauthAttrs fields as X509_ALGOR, whereas per RFC 5652 section 9.1 they
+are [2] and [3] IMPLICIT SET OF Attribute and the CMS_AuthenticatedData
+structure already declares them as STACK_OF(X509_ATTRIBUTE). The implicit
+tags [2] and [3] were already correct, so only the element type was wrong.
+
+An Attribute (SEQUENCE { type, SET OF value }) is structurally accepted as
+an AlgorithmIdentifier (SEQUENCE { algorithm, ANY OPTIONAL }), so parsing
+did not fail; the attributes were merely misinterpreted, e.g. cms -cmsout
+-print rendered them as algorithm/parameter instead of decoding them as
+attributes. Use X509_ATTRIBUTE with the existing tags so the template
+matches the structure.
+
+Add a parse test using a BouncyCastle-generated AuthenticatedData message
+carrying an authenticated and an unauthenticated attribute, asserting both
+are decoded as SET OF Attribute.
+
+Assisted-by: Claude:claude-opus-4-8
+
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+MergeDate: Wed Jul 29 10:52:08 2026
+(Merged from https://github.com/openssl/openssl/pull/31960)
+---
+ crypto/cms/cms_asn1.c                         |  4 +--
+ test/recipes/80-test_cms.t                    | 25 ++++++++++++++++++-
+ .../80-test_cms_data/authenticated_attrs.pem  |  8 ++++++
+ 3 files changed, 34 insertions(+), 3 deletions(-)
+ create mode 100644 test/recipes/80-test_cms_data/authenticated_attrs.pem
+
+diff --git a/crypto/cms/cms_asn1.c b/crypto/cms/cms_asn1.c
+index 3d420974b2..1c88dff503 100644
+--- a/crypto/cms/cms_asn1.c
++++ b/crypto/cms/cms_asn1.c
+@@ -255,9 +255,9 @@ ASN1_NDEF_SEQUENCE(CMS_AuthenticatedData) = {
+     ASN1_SIMPLE(CMS_AuthenticatedData, macAlgorithm, X509_ALGOR),
+     ASN1_IMP(CMS_AuthenticatedData, digestAlgorithm, X509_ALGOR, 1),
+     ASN1_SIMPLE(CMS_AuthenticatedData, encapContentInfo, CMS_EncapsulatedContentInfo),
+-    ASN1_IMP_SET_OF_OPT(CMS_AuthenticatedData, authAttrs, X509_ALGOR, 2),
++    ASN1_IMP_SET_OF_OPT(CMS_AuthenticatedData, authAttrs, X509_ATTRIBUTE, 2),
+     ASN1_SIMPLE(CMS_AuthenticatedData, mac, ASN1_OCTET_STRING),
+-    ASN1_IMP_SET_OF_OPT(CMS_AuthenticatedData, unauthAttrs, X509_ALGOR, 3)
++    ASN1_IMP_SET_OF_OPT(CMS_AuthenticatedData, unauthAttrs, X509_ATTRIBUTE, 3)
+ } static_ASN1_NDEF_SEQUENCE_END(CMS_AuthenticatedData)
+ 
+ ASN1_NDEF_SEQUENCE(CMS_CompressedData)
+diff --git a/test/recipes/80-test_cms.t b/test/recipes/80-test_cms.t
+index 2f850c6e0e..78bc31d1ca 100644
+--- a/test/recipes/80-test_cms.t
++++ b/test/recipes/80-test_cms.t
+@@ -51,7 +51,7 @@ my ($no_des, $no_dh, $no_dsa, $no_ec, $no_ec2m, $no_rc2, $no_zlib)
+ 
+ $no_rc2 = 1 if disabled("legacy");
+ 
+-plan tests => 26;
++plan tests => 27;
+ 
+ ok(run(test(["pkcs7_test"])), "test pkcs7");
+ 
+@@ -942,6 +942,29 @@ subtest "CMS Decrypt message encrypted with OpenSSL 1.1.1\n" => sub {
+     }
+ };
+ 
++subtest "CMS parse authenticatedData authAttrs and unauthAttrs\n" => sub {
++    plan tests => 3;
++
++    # BouncyCastle authenticatedData (HMAC-SHA256, KEK) carrying both an
++    # authenticated and an unauthenticated attribute. Per RFC 5652 these are
++    # SET OF Attribute, so with the CMS_AuthenticatedData template fixed to use
++    # X509_ATTRIBUTE they are rendered as attributes (object:/set:) rather than
++    # as an X509_ALGOR (algorithm:/parameter:) they were misparsed into before.
++    my $exit = 0;
++    my $dump = join "\n",
++               run(app(["openssl", "cms", @defaultprov, "-cmsout", "-noout",
++                        "-print", "-inform", "PEM",
++                        "-in", catfile($datadir, "authenticated_attrs.pem")]),
++                   capture => 1,
++                   statusvar => $exit);
++
++    is($exit, 0, "parse authenticatedData with attributes");
++    ok($dump =~ /authAttrs:.*?object:.*?1\.3\.6\.1\.4\.1\.5949\.99\.1.*?UTF8STRING:auth-attr-value/s,
++       "authAttrs parsed as SET OF Attribute");
++    ok($dump =~ /unauthAttrs:.*?object:.*?1\.3\.6\.1\.4\.1\.5949\.99\.2.*?UTF8STRING:unauth-attr-value/s,
++       "unauthAttrs parsed as SET OF Attribute");
++};
++
+ subtest "CAdES <=> CAdES consistency tests\n" => sub {
+     plan tests => (scalar @smime_cms_cades_tests);
+ 
+diff --git a/test/recipes/80-test_cms_data/authenticated_attrs.pem b/test/recipes/80-test_cms_data/authenticated_attrs.pem
+new file mode 100644
+index 0000000000..4f3d212698
+--- /dev/null
++++ b/test/recipes/80-test_cms_data/authenticated_attrs.pem
+@@ -0,0 +1,8 @@
++-----BEGIN CMS-----
++MIAGCyqGSIb3DQEJEAECoIAwgAIBADFDokECAQQwBQQDwP7gMAsGCWCGSAFlAwQB
++BQQoWM396pUOzWW6mFsNvr+XXTLufCrvzG3jiTOX+l3LpSXbXHhhpadw5DAMBggq
++hkiG9w0CCQUAoQsGCWCGSAFlAwQCATCABgkqhkiG9w0BBwGggCSABB5IZWxsbyBB
++dXRoZW50aWNhdGVkRGF0YSB3b3JsZAoAAAAAAACiIDAeBgkrBgEEAa49YwExEQwP
++YXV0aC1hdHRyLXZhbHVlBCB9kCl8ic3e5461oodeDSyR7heZxtdN7G/N+oqerDIj
++PqMiMCAGCSsGAQQBrj1jAjETDBF1bmF1dGgtYXR0ci12YWx1ZQAAAAAAAA==
++-----END CMS-----
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0044-pkcs7-null-guard-enveloped-and-signedAndEnveloped-ar.patch b/package/libs/openssl/patches/0044-pkcs7-null-guard-enveloped-and-signedAndEnveloped-ar.patch
new file mode 100644
index 0000000..64858a7
--- /dev/null
+++ b/package/libs/openssl/patches/0044-pkcs7-null-guard-enveloped-and-signedAndEnveloped-ar.patch
@@ -0,0 +1,121 @@
+From e832fdccdd0785d3edaf528bb66fae655dd9d7f6 Mon Sep 17 00:00:00 2001
+From: Abel Thomas <abeltom.kernel@gmail.com>
+Date: Thu, 9 Jul 2026 14:22:50 +0200
+Subject: [PATCH 44/48] pkcs7: null-guard enveloped and signedAndEnveloped arms
+ in PKCS7_stream
+
+Dereferences of `p7->d.enveloped->enc_data` and
+`p7->d.signed_and_enveloped->enc_data` crash with UBSan when the union
+member is NULL after parsing a minimal/malformed input. Mirror the guard
+added for the signed arm in PR #30351.
+
+Added unit-tests to validate the change.
+
+Fixes: #31682
+
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Jakub Zelenka <jakub.zelenka@openssl.foundation>
+MergeDate: Wed Jul 29 16:51:46 2026
+(Merged from https://github.com/openssl/openssl/pull/31716)
+
+(cherry picked from commit 32f5a5183c7f55d5dcf42f433d38c5946c1d0b7e)
+---
+ crypto/pkcs7/pk7_lib.c |  8 +++++++
+ test/pkcs7_test.c      | 50 ++++++++++++++++++++++++++++++++++++++++++
+ 2 files changed, 58 insertions(+)
+
+diff --git a/crypto/pkcs7/pk7_lib.c b/crypto/pkcs7/pk7_lib.c
+index 508700fedb..c5b2bb11d6 100644
+--- a/crypto/pkcs7/pk7_lib.c
++++ b/crypto/pkcs7/pk7_lib.c
+@@ -722,6 +722,10 @@ int PKCS7_stream(unsigned char ***boundary, PKCS7 *p7)
+         break;
+ 
+     case NID_pkcs7_signedAndEnveloped:
++        if (p7->d.signed_and_enveloped == NULL || p7->d.signed_and_enveloped->enc_data == NULL) {
++            ERR_raise(ERR_LIB_PKCS7, PKCS7_R_NO_CONTENT);
++            break;
++        }
+         os = p7->d.signed_and_enveloped->enc_data->enc_data;
+         if (os == NULL) {
+             os = ASN1_OCTET_STRING_new();
+@@ -730,6 +734,10 @@ int PKCS7_stream(unsigned char ***boundary, PKCS7 *p7)
+         break;
+ 
+     case NID_pkcs7_enveloped:
++        if (p7->d.enveloped == NULL || p7->d.enveloped->enc_data == NULL) {
++            ERR_raise(ERR_LIB_PKCS7, PKCS7_R_NO_CONTENT);
++            break;
++        }
+         os = p7->d.enveloped->enc_data->enc_data;
+         if (os == NULL) {
+             os = ASN1_OCTET_STRING_new();
+diff --git a/test/pkcs7_test.c b/test/pkcs7_test.c
+index ca069fc0cc..7449c783bd 100644
+--- a/test/pkcs7_test.c
++++ b/test/pkcs7_test.c
+@@ -118,11 +118,61 @@ end:
+ }
+ #endif /* OPENSSL_NO_EC */
+ 
++static int pkcs7_stream_enveloped_no_content_test(void)
++{
++    int ret = 0;
++    PKCS7 *p7 = NULL;
++    BIO *sink = NULL;
++    BIO *bio = NULL;
++
++    const unsigned char data_enveloped_no_body[] = { 0x30, 0x0b, 0x06, 0x09,
++        0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x03 };
++    const unsigned char *ptr_env_no_body = data_enveloped_no_body;
++
++    ret = TEST_ptr(p7 = d2i_PKCS7(NULL, &ptr_env_no_body,
++                       sizeof(data_enveloped_no_body)))
++        && TEST_ptr(sink = BIO_new(BIO_s_null()))
++        && TEST_ptr_null(bio = BIO_new_PKCS7(sink, p7))
++        && TEST_int_eq(ERR_GET_REASON(ERR_peek_last_error()),
++            PKCS7_R_NO_CONTENT);
++
++    BIO_free(bio);
++    BIO_free(sink);
++    PKCS7_free(p7);
++    return ret;
++}
++
++static int pkcs7_stream_enveloped_signed_no_content_test(void)
++{
++    int ret = 0;
++    PKCS7 *p7 = NULL;
++    BIO *sink = NULL;
++    BIO *bio = NULL;
++
++    const unsigned char data_enveloped_signed_no_body[] = { 0x30, 0x0b, 0x06,
++        0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x04 };
++    const unsigned char *ptr_env_signed_no_body = data_enveloped_signed_no_body;
++
++    ret = TEST_ptr(p7 = d2i_PKCS7(NULL, &ptr_env_signed_no_body,
++                       sizeof(data_enveloped_signed_no_body)))
++        && TEST_ptr(sink = BIO_new(BIO_s_null()))
++        && TEST_ptr_null(bio = BIO_new_PKCS7(sink, p7))
++        && TEST_int_eq(ERR_GET_REASON(ERR_peek_last_error()),
++            PKCS7_R_NO_CONTENT);
++
++    BIO_free(bio);
++    BIO_free(sink);
++    PKCS7_free(p7);
++    return ret;
++}
++
+ int setup_tests(void)
+ {
+     ADD_TEST(pkcs7_issuer_and_serial_negative_idx_test);
+ #ifndef OPENSSL_NO_EC
+     ADD_TEST(pkcs7_verify_test);
+ #endif /* OPENSSL_NO_EC */
++    ADD_TEST(pkcs7_stream_enveloped_no_content_test);
++    ADD_TEST(pkcs7_stream_enveloped_signed_no_content_test);
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0045-Add-value_barrier-in-MOD_EXP_CTIME_COPY_FROM_PREBUF.patch b/package/libs/openssl/patches/0045-Add-value_barrier-in-MOD_EXP_CTIME_COPY_FROM_PREBUF.patch
new file mode 100644
index 0000000..0668b9f
--- /dev/null
+++ b/package/libs/openssl/patches/0045-Add-value_barrier-in-MOD_EXP_CTIME_COPY_FROM_PREBUF.patch
@@ -0,0 +1,39 @@
+From 38d6c2d5fd6c721f40d800c7bec7a2dee2696593 Mon Sep 17 00:00:00 2001
+From: Kurt Roeckx <kurt@roeckx.be>
+Date: Tue, 14 Jul 2026 19:20:21 +0200
+Subject: [PATCH 45/48] Add value_barrier in MOD_EXP_CTIME_COPY_FROM_PREBUF
+
+Without it, compilers can figure out the possible values and optimize
+based on it.
+
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Wed Jul 29 17:04:46 2026
+(Merged from https://github.com/openssl/openssl/pull/31957)
+
+(cherry picked from commit f8c26111bab30399d0c9262269089639ff8e4746)
+---
+ crypto/bn/bn_exp.c | 5 +++--
+ 1 file changed, 3 insertions(+), 2 deletions(-)
+
+diff --git a/crypto/bn/bn_exp.c b/crypto/bn/bn_exp.c
+index 1d2c971b85..cbc9f4b385 100644
+--- a/crypto/bn/bn_exp.c
++++ b/crypto/bn/bn_exp.c
+@@ -573,8 +573,9 @@ static int MOD_EXP_CTIME_COPY_FROM_PREBUF(BIGNUM *b, int top,
+             BN_ULONG acc = 0;
+ 
+             for (j = 0; j < xstride; j++) {
+-                acc |= ((table[j + 0 * xstride] & y0) | (table[j + 1 * xstride] & y1) | (table[j + 2 * xstride] & y2) | (table[j + 3 * xstride] & y3))
+-                    & ((BN_ULONG)0 - (constant_time_eq_int(j, idx) & 1));
++                acc |= ((table[j + 0 * xstride] & value_barrier_bn(y0)) | (table[j + 1 * xstride] & value_barrier_bn(y1))
++                           | (table[j + 2 * xstride] & value_barrier_bn(y2)) | (table[j + 3 * xstride] & value_barrier_bn(y3)))
++                    & value_barrier_bn((BN_ULONG)0 - (constant_time_eq_int(j, idx) & 1));
+             }
+ 
+             b->d[i] = acc;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0046-Add-value_barrier-in-BN_consttime_swap.patch b/package/libs/openssl/patches/0046-Add-value_barrier-in-BN_consttime_swap.patch
new file mode 100644
index 0000000..06329f1
--- /dev/null
+++ b/package/libs/openssl/patches/0046-Add-value_barrier-in-BN_consttime_swap.patch
@@ -0,0 +1,57 @@
+From 0c306f0ad0a825c5765dad280c4cacc3b12b39f0 Mon Sep 17 00:00:00 2001
+From: Kurt Roeckx <kurt@roeckx.be>
+Date: Tue, 14 Jul 2026 19:40:42 +0200
+Subject: [PATCH 46/48] Add value_barrier in BN_consttime_swap
+
+Without it, compilers can figure out the possible values and optimize
+based on it.
+
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Wed Jul 29 17:04:47 2026
+(Merged from https://github.com/openssl/openssl/pull/31957)
+
+(cherry picked from commit 1d7a8dd73ff9e0fc197611433b9b60b4b5f5465c)
+---
+ crypto/bn/bn_lib.c | 8 ++++----
+ 1 file changed, 4 insertions(+), 4 deletions(-)
+
+diff --git a/crypto/bn/bn_lib.c b/crypto/bn/bn_lib.c
+index 161730ce79..d17119e9e6 100644
+--- a/crypto/bn/bn_lib.c
++++ b/crypto/bn/bn_lib.c
+@@ -874,11 +874,11 @@ void BN_consttime_swap(BN_ULONG condition, BIGNUM *a, BIGNUM *b, int nwords)
+ 
+     condition = ((~condition & ((condition - 1))) >> (BN_BITS2 - 1)) - 1;
+ 
+-    t = (a->top ^ b->top) & condition;
++    t = (a->top ^ b->top) & value_barrier_bn(condition);
+     a->top ^= t;
+     b->top ^= t;
+ 
+-    t = (a->neg ^ b->neg) & condition;
++    t = (a->neg ^ b->neg) & value_barrier_bn(condition);
+     a->neg ^= t;
+     b->neg ^= t;
+ 
+@@ -906,13 +906,13 @@ void BN_consttime_swap(BN_ULONG condition, BIGNUM *a, BIGNUM *b, int nwords)
+ 
+ #define BN_CONSTTIME_SWAP_FLAGS (BN_FLG_CONSTTIME | BN_FLG_FIXED_TOP)
+ 
+-    t = ((a->flags ^ b->flags) & BN_CONSTTIME_SWAP_FLAGS) & condition;
++    t = ((a->flags ^ b->flags) & BN_CONSTTIME_SWAP_FLAGS) & value_barrier_bn(condition);
+     a->flags ^= t;
+     b->flags ^= t;
+ 
+     /* conditionally swap the data */
+     for (i = 0; i < nwords; i++) {
+-        t = (a->d[i] ^ b->d[i]) & condition;
++        t = (a->d[i] ^ b->d[i]) & value_barrier_bn(condition);
+         a->d[i] ^= t;
+         b->d[i] ^= t;
+     }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0047-Apply-suggestion-from-andrewkdinh.patch b/package/libs/openssl/patches/0047-Apply-suggestion-from-andrewkdinh.patch
new file mode 100644
index 0000000..4487454
--- /dev/null
+++ b/package/libs/openssl/patches/0047-Apply-suggestion-from-andrewkdinh.patch
@@ -0,0 +1,35 @@
+From a50aa72aba6c3fcaf85faa93513e2798e25efa2c Mon Sep 17 00:00:00 2001
+From: Kurt Roeckx <kurt@roeckx.be>
+Date: Wed, 15 Jul 2026 15:44:38 +0200
+Subject: [PATCH 47/48] Apply suggestion from @andrewkdinh
+
+Co-authored-by: Andrew Dinh <andrewd@openssl.org>
+
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Reviewed-by: Eugene Syromiatnikov <esyr@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+MergeDate: Wed Jul 29 17:04:49 2026
+(Merged from https://github.com/openssl/openssl/pull/31957)
+
+(cherry picked from commit 33482fbddcf137dde9bd84ae12f2f02cbc358c78)
+---
+ crypto/bn/bn_exp.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/bn/bn_exp.c b/crypto/bn/bn_exp.c
+index cbc9f4b385..7705dc06cd 100644
+--- a/crypto/bn/bn_exp.c
++++ b/crypto/bn/bn_exp.c
+@@ -552,7 +552,7 @@ static int MOD_EXP_CTIME_COPY_FROM_PREBUF(BIGNUM *b, int top,
+             BN_ULONG acc = 0;
+ 
+             for (j = 0; j < width; j++) {
+-                acc |= table[j] & ((BN_ULONG)0 - (constant_time_eq_int(j, idx) & 1));
++                acc |= table[j] & value_barrier_bn((BN_ULONG)0 - (constant_time_eq_int(j, idx) & 1));
+             }
+ 
+             b->d[i] = acc;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0048-include-internal-constant_time.h-add-value_barrier_b.patch b/package/libs/openssl/patches/0048-include-internal-constant_time.h-add-value_barrier_b.patch
new file mode 100644
index 0000000..479209b
--- /dev/null
+++ b/package/libs/openssl/patches/0048-include-internal-constant_time.h-add-value_barrier_b.patch
@@ -0,0 +1,53 @@
+From ea0caf4861381e39888ea5a2ed39d0ff896d01c5 Mon Sep 17 00:00:00 2001
+From: Lukas Gerlach <s8lugerl@stud.uni-saarland.de>
+Date: Sun, 5 May 2024 14:27:26 +0300
+Subject: [PATCH 48/48] include/internal/constant_time.h: add
+ value_barrier_bn()
+
+A build breakage has been introduced on openssl-3.0 by commits
+38d6c2d5fd6c "Add value_barrier in MOD_EXP_CTIME_COPY_FROM_PREBUF",
+0c306f0ad0a8 "Add value_barrier in BN_consttime_swap", and a50aa72aba6c
+"Apply suggestion from @andrewkdinh" due to missing value_barrier_bn(),
+originally introduced in commit aaa1bda7187c "Optimizated calculation
+of shared power of 2 in bn_gcd".  Cherry-pick the part of the commit
+that contains the function definition.
+
+Fixes: 38d6c2d5fd6c "Add value_barrier in MOD_EXP_CTIME_COPY_FROM_PREBUF"
+Fixes: 0c306f0ad0a8 "Add value_barrier in BN_consttime_swap"
+Fixes: a50aa72aba6c "Apply suggestion from @andrewkdinh"
+References: aaa1bda7187c "Optimizated calculation of shared power of 2 in bn_gcd"
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Milan Broz <mbroz@openssl.org>
+Reviewed-by: Norbert Pocs <norbertp@openssl.org>
+MergeDate: Thu Jul 30 12:17:44 2026
+(Merged from https://github.com/openssl/openssl/pull/32118)
+---
+ include/internal/constant_time.h | 11 +++++++++++
+ 1 file changed, 11 insertions(+)
+
+diff --git a/include/internal/constant_time.h b/include/internal/constant_time.h
+index 3a634c5617..0f8540bc74 100644
+--- a/include/internal/constant_time.h
++++ b/include/internal/constant_time.h
+@@ -139,6 +139,17 @@ static ossl_inline uint64_t constant_time_lt_64(uint64_t a, uint64_t b)
+ }
+ 
+ #ifdef BN_ULONG
++static ossl_inline BN_ULONG value_barrier_bn(BN_ULONG a)
++{
++#if !defined(OPENSSL_NO_ASM) && defined(__GNUC__)
++    BN_ULONG r;
++    __asm__("" : "=r"(r) : "0"(a));
++#else
++    volatile BN_ULONG r = a;
++#endif
++    return r;
++}
++
+ static ossl_inline BN_ULONG constant_time_msb_bn(BN_ULONG a)
+ {
+     return 0 - (a >> (sizeof(a) * 8 - 1));
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

