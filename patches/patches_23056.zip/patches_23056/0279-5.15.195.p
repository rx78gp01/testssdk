diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .194
-LINUX_KERNEL_HASH-5.15.194 = 348d6faada05fd4684450cd7c4e666c3c98cdb96f2309b1520c9a92a378c267e
+LINUX_VERSION-5.15 = .195
+LINUX_KERNEL_HASH-5.15.195 = 23d080dc32f99d3939c3d1bd65a68ed85b8f934f92cc1841a63f898dcdb9a441
