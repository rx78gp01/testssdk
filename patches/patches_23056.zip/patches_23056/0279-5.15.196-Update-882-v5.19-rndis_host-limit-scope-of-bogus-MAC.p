diff --git a/target/linux/generic/backport-5.15/882-v5.19-rndis_host-limit-scope-of-bogus-MAC-address-detectio.patch b/target/linux/generic/backport-5.15/882-v5.19-rndis_host-limit-scope-of-bogus-MAC-address-detectio.patch
index bdd812c..f93354b 100644
--- a/target/linux/generic/backport-5.15/882-v5.19-rndis_host-limit-scope-of-bogus-MAC-address-detectio.patch
+++ b/target/linux/generic/backport-5.15/882-v5.19-rndis_host-limit-scope-of-bogus-MAC-address-detectio.patch
@@ -30,8 +30,8 @@ Signed-off-by: Lech Perczak <lech.perczak@gmail.com>
 -	if (bp[0] & 0x02)
 -		eth_hw_addr_random(net);
 -	else
--		ether_addr_copy(net->dev_addr, bp);
-+	ether_addr_copy(net->dev_addr, bp);
+-		eth_hw_addr_set(net, bp);
++	eth_hw_addr_set(net, bp);
  
  	/* set a nonzero filter to enable data transfers */
  	memset(u.set, 0, sizeof *u.set);
-- 
2.46.2.windows.1

