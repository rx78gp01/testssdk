From 00b6462cb00c87dc5c9678e61c6e35f63d616de9 Mon Sep 17 00:00:00 2001
From: Martin Schiller <ms@dev.tdt.de>
Date: Mon, 2 Feb 2026 10:50:42 +0100
Subject: [PATCH] openssl: update to version 3.0.20

OpenSSL 3.0.19 is a security patch release. The most severe CVE fixed
in this release is High.

This release incorporates the following bug fixes and mitigations:

 * Fixed Stack buffer overflow in CMS AuthEnvelopedData parsing.
   (CVE-2025-15467)

 * Fixed Heap out-of-bounds write in BIO_f_linebuffer on short writes.
   (CVE-2025-68160)

 * Fixed Unauthenticated/unencrypted trailing bytes with low-level OCB
   function calls. (CVE-2025-69418)

 * Fixed Out of bounds write in PKCS12_get_friendlyname() UTF-8
   conversion. (CVE-2025-69419)

 * Fixed Missing ASN1_TYPE validation in TS_RESP_verify_response()
   function. (CVE-2025-69420)

 * Fixed NULL Pointer Dereference in PKCS12_item_decrypt_d2i_ex()
   function. (CVE-2025-69421)

 * Fixed Missing ASN1_TYPE validation in PKCS#12 parsing.
   (CVE-2026-22795)

 * Fixed ASN1_TYPE Type Confusion in the PKCS7_digest_from_attributes()
   function. (CVE-2026-22796)

Signed-off-by: Martin Schiller <ms@dev.tdt.de>
Link: https://github.com/openwrt/openwrt/pull/21832
Signed-off-by: Hauke Mehrtens <hauke@hauke-m.de>
---
 package/libs/openssl/Makefile                 |  4 +-
 .../patches/140-allow-prefer-chacha20.patch   | 42 +++++++++----------
 ...default-to-not-use-digests-in-engine.patch | 16 +++----
 ...to-ignore-error-when-closing-session.patch |  5 +--
 4 files changed, 32 insertions(+), 35 deletions(-)

diff --git a/package/libs/openssl/Makefile b/package/libs/openssl/Makefile
index 70d64d67116de7..cd2d3af06a664f 100644
--- a/package/libs/openssl/Makefile
+++ b/package/libs/openssl/Makefile
@@ -8,7 +8,7 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=openssl
-PKG_VERSION:=3.0.19
+PKG_VERSION:=3.0.21
 PKG_RELEASE:=1
 PKG_BUILD_FLAGS:=no-mips16 gc-sections no-lto
 
@@ -21,7 +21,7 @@ PKG_SOURCE_URL:= \
 	https://www.openssl.org/source/old/$(PKG_BASE)/ \
 	https://github.com/openssl/openssl/releases/download/$(PKG_NAME)-$(PKG_VERSION)/
 
-PKG_HASH:=fa5a4143b8aae18be53ef2f3caf29a2e0747430b8bc74d32d88335b94ab63072
+PKG_HASH:=617e29af8e421f46649484a4937e48c685e47f46488167c982f88bc4ec1d522f
 
 PKG_LICENSE:=Apache-2.0
 PKG_LICENSE_FILES:=LICENSE.txt

