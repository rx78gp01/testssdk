diff --git a/package/network/services/hostapd/patches/9999-hostapd_conf.patch b/package/network/services/hostapd/patches/9999-hostapd_conf.patch
new file mode 100644
index 0000000..0c7e228
--- /dev/null
+++ b/package/network/services/hostapd/patches/9999-hostapd_conf.patch
@@ -0,0 +1,18 @@
+diff --git a/src/ap/hostapd.c b/src/ap/hostapd.c
+index 4b88641..4a3bc47 100644
+--- a/src/ap/hostapd.c
++++ b/src/ap/hostapd.c
+@@ -2581,8 +2581,8 @@ hostapd_interface_init_bss(struct hapd_interfaces *interfaces, const char *phy,
+ 		}
+ 	}
+ 
+-	wpa_printf(MSG_INFO, "Configuration file: %s (phy %s)%s",
+-		   config_fname, phy, iface ? "" : " --> new PHY");
++	wpa_printf(MSG_INFO, "Loading configuration file: (phy %s)%s",
++		   phy, iface ? "" : " --> new PHY");
+ 	if (iface) {
+ 		struct hostapd_config *conf;
+ 		struct hostapd_bss_config **tmp_conf;
+-- 
+2.38.1.windows.1
+
-- 
2.38.1.windows.1

