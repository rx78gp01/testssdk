diff --git a/package/libs/openssl/patches/0002-doc-clarify-X509_NAME_ENTRY-get_object-get_data-memo.patch b/package/libs/openssl/patches/0002-doc-clarify-X509_NAME_ENTRY-get_object-get_data-memo.patch
new file mode 100644
index 0000000..3758e22
--- /dev/null
+++ b/package/libs/openssl/patches/0002-doc-clarify-X509_NAME_ENTRY-get_object-get_data-memo.patch
@@ -0,0 +1,57 @@
+From 6a6e539b6bc3d9488b7378cf454dbac4fcd90579 Mon Sep 17 00:00:00 2001
+From: kovan <xaum.io@gmail.com>
+Date: Mon, 2 Feb 2026 11:31:42 +0100
+Subject: [PATCH 2/7] doc: clarify X509_NAME_ENTRY get_object/get_data memory
+ semantics
+
+- Fix typos: "in and ASN1_OBJECT" -> "in an ASN1_OBJECT"
+- Clarify that returned pointers are internal and must not be freed
+
+Fixes https://github.com/openssl/openssl/issues/28156
+
+Assisted-by: Claude:claude-opus-4-5
+Reviewed-by: Andrew Dinh <andrewd@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Merge-date: Thu Aug 27 13:27:26 2026
+Merged-from: https://github.com/openssl/openssl/pull/29887
+(cherry picked from commit dadf861592f4374b4c6fe55ad43e508fc69e109b)
+---
+ doc/man3/X509_NAME_ENTRY_get_object.pod | 12 ++++++------
+ 1 file changed, 6 insertions(+), 6 deletions(-)
+
+diff --git a/doc/man3/X509_NAME_ENTRY_get_object.pod b/doc/man3/X509_NAME_ENTRY_get_object.pod
+index 7533a586b1..1e0ffde5c1 100644
+--- a/doc/man3/X509_NAME_ENTRY_get_object.pod
++++ b/doc/man3/X509_NAME_ENTRY_get_object.pod
+@@ -31,10 +31,10 @@ X509_NAME_ENTRY_create_by_OBJ - X509_NAME_ENTRY utility functions
+ =head1 DESCRIPTION
+ 
+ X509_NAME_ENTRY_get_object() retrieves the field name of B<ne> in
+-and B<ASN1_OBJECT> structure.
++an B<ASN1_OBJECT> structure.
+ 
+ X509_NAME_ENTRY_get_data() retrieves the field value of B<ne> in
+-and B<ASN1_STRING> structure.
++an B<ASN1_STRING> structure.
+ 
+ X509_NAME_ENTRY_set_object() sets the field name of B<ne> to B<obj>.
+ 
+@@ -66,11 +66,11 @@ set first so the relevant field information can be looked up internally.
+ 
+ =head1 RETURN VALUES
+ 
+-X509_NAME_ENTRY_get_object() returns a valid B<ASN1_OBJECT> structure if it is
+-set or NULL if an error occurred.
++X509_NAME_ENTRY_get_object() returns an internal pointer to a valid
++B<ASN1_OBJECT> structure if it is set, or NULL if an error occurred.
+ 
+-X509_NAME_ENTRY_get_data() returns a valid B<ASN1_STRING> structure if it is set
+-or NULL if an error occurred.
++X509_NAME_ENTRY_get_data() returns an internal pointer to a valid
++B<ASN1_STRING> structure if it is set, or NULL if an error occurred.
+ 
+ X509_NAME_ENTRY_set_object() and X509_NAME_ENTRY_set_data() return 1 on success
+ or 0 on error.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0004-update-cms_pwri_kek_oob.der-blob-to-use-a-16-byte-IV.patch b/package/libs/openssl/patches/0004-update-cms_pwri_kek_oob.der-blob-to-use-a-16-byte-IV.patch
new file mode 100644
index 0000000..427d013
--- /dev/null
+++ b/package/libs/openssl/patches/0004-update-cms_pwri_kek_oob.der-blob-to-use-a-16-byte-IV.patch
@@ -0,0 +1,45 @@
+From a4eccbd87808ca3b07c7f7e992dd8bcff2f102ae Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Tue, 23 Jun 2026 17:32:24 +0200
+Subject: [PATCH 4/7] update cms_pwri_kek_oob.der blob to use a 16 byte IV
+ value
+
+This changes the PWRI-KEK blob to use a 16 byte long IV value
+which is needed for AES-128-CFB.
+
+Thus ./test/recipes/80-test_cmsapi_data/cms_pwri_kek_oob.der changes
+
+from:
+   69:d=6  hl=2 l=  11 prim: OBJECT            :id-alg-PWRI-KEK
+   82:d=6  hl=2 l=  11 cons: SEQUENCE
+   84:d=7  hl=2 l=   9 prim: OBJECT            :aes-128-cfb
+   95:d=5  hl=2 l=   2 prim: OCTET STRING      [HEX DUMP]:0000
+
+to: 69:d=6  hl=2 l=  11 prim: OBJECT            :id-alg-PWRI-KEK
+   82:d=6  hl=2 l=  29 cons: SEQUENCE
+   84:d=7  hl=2 l=   9 prim: OBJECT            :aes-128-cfb
+   95:d=7  hl=2 l=  16 prim: OCTET STRING      [HEX DUMP]:00000000000000000000000000000000
+  113:d=5  hl=2 l=   2 prim: OCTET STRING      [HEX DUMP]:0000
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Mounir Idrassi <mounir.idrassi@idrix.fr>
+Merge-date: Thu Aug 27 15:07:57 2026
+Merged-from: https://github.com/openssl/openssl/pull/32394
+(cherry picked from commit 4cf673a3d50b0d04d65c54c6ebb6932bb9040cf4)
+---
+ .../80-test_cmsapi_data/cms_pwri_kek_oob.der    | Bin 193 -> 211 bytes
+ 1 file changed, 0 insertions(+), 0 deletions(-)
+
+diff --git a/test/recipes/80-test_cmsapi_data/cms_pwri_kek_oob.der b/test/recipes/80-test_cmsapi_data/cms_pwri_kek_oob.der
+index c3ef3abd10e6b0a57b1eef985b0c8c43cb057371..5e7302d0fad70315c902a4447902deaa4be1458e 100644
+GIT binary patch
+delta 84
+zcmX@ec$rb!pz#75r&gOs+jm|@cIE|*hYT9`Gcht7#w?DSD6Ofh!^RDj<P>1$G>~QE
+VOlb39Ol4+aWML6tKm!xwlK{+75&HlD
+
+delta 66
+zcmcc2c#u)rpm84?r&gOs+jm|@cIE|*8w?uPGBGk6dM);tD6J_i#l{Vl<P>1$G~j0A
+ROlb39Ol4+aWSLl)1OSWB5orJb
+
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0005-Restore-the-check-for-missing-IV-param-in-evp_cipher.patch b/package/libs/openssl/patches/0005-Restore-the-check-for-missing-IV-param-in-evp_cipher.patch
new file mode 100644
index 0000000..1e54334
--- /dev/null
+++ b/package/libs/openssl/patches/0005-Restore-the-check-for-missing-IV-param-in-evp_cipher.patch
@@ -0,0 +1,147 @@
+From 9ebf997cb32fa0ce7eb7b912ed1498443f64e3cd Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Tue, 23 Jun 2026 16:35:05 +0200
+Subject: [PATCH 5/7] Restore the check for missing IV param in
+ evp_cipher_asn1_to_param_ex
+
+STREAM ciphers (RC4) and WRAP MODE ciphers (CMS3DESwrap) do not have an IV
+parameter value, all other ciphers need an IV value, previously the missing
+IV param value was handled as an error condition.
+The check that an IV value is there was accidentally removed for all ciphers.
+This restores the check for all ciphers except RC4.
+
+Fixes: 114d99b46bfb ("Fix incomplete checks for EVP_CIPHER_asn1_to_param")
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Mounir Idrassi <mounir.idrassi@idrix.fr>
+Merge-date: Thu Aug 27 15:07:58 2026
+Merged-from: https://github.com/openssl/openssl/pull/32394
+(cherry picked from commit 1671f994548a1a33246859ab6cc43200b1c65d87)
+---
+ crypto/evp/evp_lib.c                          |   4 +-
+ test/cmsapitest.c                             |  40 +++++++++++++++++-
+ test/recipes/80-test_cmsapi.t                 |   1 +
+ .../80-test_cmsapi_data/cms_pwri_kek_NoIV.der | Bin 0 -> 193 bytes
+ 4 files changed, 42 insertions(+), 3 deletions(-)
+ create mode 100644 test/recipes/80-test_cmsapi_data/cms_pwri_kek_NoIV.der
+
+diff --git a/crypto/evp/evp_lib.c b/crypto/evp/evp_lib.c
+index 95b8bf3274..474886c0d2 100644
+--- a/crypto/evp/evp_lib.c
++++ b/crypto/evp/evp_lib.c
+@@ -210,7 +210,9 @@ int evp_cipher_asn1_to_param_ex(EVP_CIPHER_CTX *c, ASN1_TYPE *type,
+             break;
+ 
+         default:
+-            ret = EVP_CIPHER_get_asn1_iv(c, type) >= 0 ? 1 : -1;
++            ret = EVP_CIPHER_get_asn1_iv(c, type);
++            if (ret == 0 && EVP_CIPHER_CTX_get_iv_length(c) == 0)
++                ret = 1;
+         }
+     } else if (cipher->prov != NULL) {
+         OSSL_PARAM params[3], *p = params;
+diff --git a/test/cmsapitest.c b/test/cmsapitest.c
+index df5f8d59dc..0f67a9717f 100644
+--- a/test/cmsapitest.c
++++ b/test/cmsapitest.c
+@@ -21,6 +21,7 @@ static EVP_PKEY *privkey = NULL;
+ static char *derin = NULL;
+ static char *too_long_iv_cms_in = NULL;
+ static char *pwri_kek_oob_der_in = NULL;
++static char *pwri_kek_no_iv_in = NULL;
+ static char *ec_recip_in = NULL;
+ 
+ /*
+@@ -712,6 +713,39 @@ end:
+     return ret;
+ }
+ 
++static int test_pwri_kek_unwrap_no_iv_key(void)
++{
++    BIO *in = NULL;
++    CMS_ContentInfo *cms = NULL;
++    unsigned long err = 0;
++    int ret = 0;
++
++    if (!TEST_ptr(in = BIO_new_file(pwri_kek_no_iv_in, "rb"))
++        || !TEST_ptr(cms = d2i_CMS_bio(in, NULL)))
++        goto end;
++
++    /*
++     * Due to the missing IV, the unwrap must fail with
++     * CMS_R_CIPHER_PARAMETER_INITIALISATION_ERROR.
++     */
++    if (!TEST_false(CMS_decrypt_set1_password(cms,
++            (unsigned char *)"password", -1)))
++        goto end;
++
++    err = ERR_peek_last_error();
++    if (!TEST_int_eq(ERR_GET_LIB(err), ERR_LIB_CMS)
++        || !TEST_int_eq(ERR_GET_REASON(err),
++            CMS_R_CIPHER_PARAMETER_INITIALISATION_ERROR))
++        goto end;
++
++    ERR_clear_error();
++    ret = 1;
++end:
++    CMS_ContentInfo_free(cms);
++    BIO_free(in);
++    return ret;
++}
++
+ #ifndef OPENSSL_NO_EC
+ 
+ /*
+@@ -805,7 +839,7 @@ end:
+ }
+ #endif
+ 
+-OPT_TEST_DECLARE_USAGE("certfile privkeyfile derfile tooLongIVpem pwriKekOobDer ecrecip\n")
++OPT_TEST_DECLARE_USAGE("certfile privkeyfile derfile tooLongIVpem pwriKekOobDer pwriKekNoIv ecrecip\n")
+ 
+ int setup_tests(void)
+ {
+@@ -822,7 +856,8 @@ int setup_tests(void)
+         || !TEST_ptr(derin = test_get_argument(2))
+         || !TEST_ptr(too_long_iv_cms_in = test_get_argument(3))
+         || !TEST_ptr(pwri_kek_oob_der_in = test_get_argument(4))
+-        || !TEST_ptr(ec_recip_in = test_get_argument(5)))
++        || !TEST_ptr(pwri_kek_no_iv_in = test_get_argument(5))
++        || !TEST_ptr(ec_recip_in = test_get_argument(6)))
+         return 0;
+ 
+     certbio = BIO_new_file(certin, "r");
+@@ -862,6 +897,7 @@ int setup_tests(void)
+     ADD_ALL_TESTS(test_d2i_CMS_decode, 2);
+     ADD_TEST(test_cms_aesgcm_iv_too_long);
+     ADD_TEST(test_pwri_kek_unwrap_short_encrypted_key);
++    ADD_TEST(test_pwri_kek_unwrap_no_iv_key);
+ 
+ #ifndef OPENSSL_NO_EC
+     ADD_TEST(test_kari_wrap_pad_unwrap_overflow);
+diff --git a/test/recipes/80-test_cmsapi.t b/test/recipes/80-test_cmsapi.t
+index 1f5f7ae233..840a00b33f 100644
+--- a/test/recipes/80-test_cmsapi.t
++++ b/test/recipes/80-test_cmsapi.t
+@@ -21,5 +21,6 @@ ok(run(test(["cmsapitest", srctop_file("test", "certs", "servercert.pem"),
+              srctop_file("test", "recipes", "80-test_cmsapi_data", "encryptedData.der"),
+              srctop_file("test", "recipes", "80-test_cmsapi_data", "encDataWithTooLongIV.pem"),
+              srctop_file("test", "recipes", "80-test_cmsapi_data", "cms_pwri_kek_oob.der"),
++             srctop_file("test", "recipes", "80-test_cmsapi_data", "cms_pwri_kek_NoIV.der"),
+              srctop_file("test", "smime-certs", "smec1.pem")])),
+              "running cmsapitest");
+diff --git a/test/recipes/80-test_cmsapi_data/cms_pwri_kek_NoIV.der b/test/recipes/80-test_cmsapi_data/cms_pwri_kek_NoIV.der
+new file mode 100644
+index 0000000000000000000000000000000000000000..c3ef3abd10e6b0a57b1eef985b0c8c43cb057371
+GIT binary patch
+literal 193
+zcmXqL+{ebL)#lOmotKfFc|qd_gT}Q?jLe2!i#?ba85StRC0Th4#8?FEa~A$hV(x0n
+zFrRcQQS~(+6B7r6ffO4z)C5ieW=;ccHqL}L55`nx7Dg5pCI$wB7`P$qj0Um@Stb?%
+z*}W&;-kY#&W8?d>8TmW9IT{Q$uJ-6FX$+dodfRzpO2J!$Gg}?F()_mBI35*0&tMe5
+VHoNtcLX?S)y&B`}phcqR3jwDUJP7~*
+
+literal 0
+HcmV?d00001
+
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0006-ocsp-Reject-update-times-X509_cmp_time-cannot-compar.patch b/package/libs/openssl/patches/0006-ocsp-Reject-update-times-X509_cmp_time-cannot-compar.patch
new file mode 100644
index 0000000..8eb5af4
--- /dev/null
+++ b/package/libs/openssl/patches/0006-ocsp-Reject-update-times-X509_cmp_time-cannot-compar.patch
@@ -0,0 +1,171 @@
+From c059f726d706e311a3c76b544e6e4fc063646566 Mon Sep 17 00:00:00 2001
+From: Mounir IDRASSI <mounir.idrassi@idrix.fr>
+Date: Sat, 15 Aug 2026 22:17:44 +0900
+Subject: [PATCH 6/7] ocsp: Reject update times X509_cmp_time() cannot compare
+
+OCSP_check_validity() accepts GeneralizedTime forms that
+X509_cmp_time() cannot compare. The latter requires the canonical RFC
+5280 form and returns 0 for numeric UTC offsets and fractional seconds.
+That error was treated as an in-range result, allowing OCSP freshness
+checks to be bypassed.
+
+Treat errors from the initial thisUpdate and nextUpdate comparisons as
+field errors. Run the optional maximum-age check only after the initial
+thisUpdate comparison succeeds, avoiding a duplicate field error.
+
+Add regression coverage for offset and fractional forms, including the
+maximum-age path.
+
+Fixes #32377
+
+Assisted-by: Codex:gpt-5.6-sol
+Signed-off-by: Mounir IDRASSI <mounir.idrassi@amcrypto.jp>
+Reviewed-by: Bob Beck <beck@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.foundation>
+Merge-date: Thu Aug 27 15:15:28 2026
+Merged-from: https://github.com/openssl/openssl/pull/32396
+(cherry picked from commit 6ceaf1dfe6729853961c6f53e97e635e82da9168)
+---
+ crypto/ocsp/ocsp_cl.c | 18 ++++++++++----
+ test/ocspapitest.c    | 55 +++++++++++++++++++++++++++++++++++++++++++
+ 2 files changed, 68 insertions(+), 5 deletions(-)
+
+diff --git a/crypto/ocsp/ocsp_cl.c b/crypto/ocsp/ocsp_cl.c
+index 8cf49ca467..55d7f9a6e0 100644
+--- a/crypto/ocsp/ocsp_cl.c
++++ b/crypto/ocsp/ocsp_cl.c
+@@ -310,7 +310,7 @@ int OCSP_resp_find_status(OCSP_BASICRESP *bs, OCSP_CERTID *id, int *status,
+ int OCSP_check_validity(ASN1_GENERALIZEDTIME *thisupd,
+     ASN1_GENERALIZEDTIME *nextupd, long nsec, long maxsec)
+ {
+-    int ret = 1;
++    int ret = 1, cmp;
+     time_t t_now, t_tmp;
+ 
+     time(&t_now);
+@@ -320,16 +320,20 @@ int OCSP_check_validity(ASN1_GENERALIZEDTIME *thisupd,
+         ret = 0;
+     } else {
+         t_tmp = t_now + nsec;
+-        if (X509_cmp_time(thisupd, &t_tmp) > 0) {
++        cmp = X509_cmp_time(thisupd, &t_tmp);
++        if (cmp == 0) {
++            ERR_raise(ERR_LIB_OCSP, OCSP_R_ERROR_IN_THISUPDATE_FIELD);
++            ret = 0;
++        } else if (cmp > 0) {
+             ERR_raise(ERR_LIB_OCSP, OCSP_R_STATUS_NOT_YET_VALID);
+             ret = 0;
+         }
+ 
+         /*
+          * If maxsec specified check thisUpdate is not more than maxsec in
+-         * the past
++         * the past. Skip this check if thisUpdate could not be compared above.
+          */
+-        if (maxsec >= 0) {
++        if (cmp != 0 && maxsec >= 0) {
+             t_tmp = t_now - maxsec;
+             if (X509_cmp_time(thisupd, &t_tmp) < 0) {
+                 ERR_raise(ERR_LIB_OCSP, OCSP_R_STATUS_TOO_OLD);
+@@ -347,7 +351,11 @@ int OCSP_check_validity(ASN1_GENERALIZEDTIME *thisupd,
+         ret = 0;
+     } else {
+         t_tmp = t_now - nsec;
+-        if (X509_cmp_time(nextupd, &t_tmp) < 0) {
++        cmp = X509_cmp_time(nextupd, &t_tmp);
++        if (cmp == 0) {
++            ERR_raise(ERR_LIB_OCSP, OCSP_R_ERROR_IN_NEXTUPDATE_FIELD);
++            ret = 0;
++        } else if (cmp < 0) {
+             ERR_raise(ERR_LIB_OCSP, OCSP_R_STATUS_EXPIRED);
+             ret = 0;
+         }
+diff --git a/test/ocspapitest.c b/test/ocspapitest.c
+index 905d368741..b98cd9a2ee 100644
+--- a/test/ocspapitest.c
++++ b/test/ocspapitest.c
+@@ -11,12 +11,14 @@
+ 
+ #include <openssl/opensslconf.h>
+ #include <openssl/crypto.h>
++#include <openssl/err.h>
+ #include <openssl/ocsp.h>
+ #include <openssl/x509.h>
+ #include <openssl/asn1.h>
+ #include <openssl/pem.h>
+ 
+ #include "testutil.h"
++#include "internal/nelem.h"
+ 
+ static const char *certstr;
+ static const char *privkeystr;
+@@ -213,6 +215,57 @@ err:
+     return ret;
+ }
+ 
++static const struct {
++    const char *thisupd;
++    const char *nextupd;
++    long maxsec;
++    int reason;
++} invalid_update_tests[] = {
++    { "99991231235959+0100", NULL, 60,
++        OCSP_R_ERROR_IN_THISUPDATE_FIELD },
++    { "20000101000000Z", "20000102000000.5Z", -1,
++        OCSP_R_ERROR_IN_NEXTUPDATE_FIELD },
++    /* Canonical forms must keep their existing, specific reasons */
++    { "20000101000000Z", NULL, 60, OCSP_R_STATUS_TOO_OLD },
++    { "20000101000000Z", "20000102000000Z", -1,
++        OCSP_R_STATUS_EXPIRED },
++};
++
++static int test_invalid_update_time(int idx)
++{
++    ASN1_GENERALIZEDTIME *thisupd = NULL, *nextupd = NULL;
++    unsigned long errcode;
++    int ret = 0;
++
++    if (!TEST_ptr(thisupd = ASN1_GENERALIZEDTIME_new())
++        || !TEST_true(ASN1_GENERALIZEDTIME_set_string(
++            thisupd, invalid_update_tests[idx].thisupd)))
++        goto err;
++    if (invalid_update_tests[idx].nextupd != NULL
++        && (!TEST_ptr(nextupd = ASN1_GENERALIZEDTIME_new())
++            || !TEST_true(ASN1_GENERALIZEDTIME_set_string(
++                nextupd, invalid_update_tests[idx].nextupd))))
++        goto err;
++
++    ERR_clear_error();
++    if (!TEST_false(OCSP_check_validity(
++            thisupd, nextupd, 0, invalid_update_tests[idx].maxsec)))
++        goto err;
++    errcode = ERR_get_error();
++    if (!TEST_int_eq(ERR_GET_LIB(errcode), ERR_LIB_OCSP)
++        || !TEST_int_eq(ERR_GET_REASON(errcode),
++            invalid_update_tests[idx].reason)
++        || !TEST_ulong_eq(ERR_peek_error(), 0))
++        goto err;
++    ret = 1;
++
++err:
++    ERR_clear_error();
++    ASN1_GENERALIZEDTIME_free(thisupd);
++    ASN1_GENERALIZEDTIME_free(nextupd);
++    return ret;
++}
++
+ #endif /* OPENSSL_NO_OCSP */
+ 
+ OPT_TEST_DECLARE_USAGE("certfile privkeyfile\n")
+@@ -231,6 +284,8 @@ int setup_tests(void)
+     ADD_TEST(test_resp_signer);
+     ADD_ALL_TESTS(test_access_description, 3);
+     ADD_TEST(test_ocsp_url_svcloc_new);
++    ADD_ALL_TESTS(test_invalid_update_time,
++        OSSL_NELEM(invalid_update_tests));
+ #endif
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0007-docs-fix-doubled-words-in-man-pages-and-design-docs.patch b/package/libs/openssl/patches/0007-docs-fix-doubled-words-in-man-pages-and-design-docs.patch
new file mode 100644
index 0000000..03f2346
--- /dev/null
+++ b/package/libs/openssl/patches/0007-docs-fix-doubled-words-in-man-pages-and-design-docs.patch
@@ -0,0 +1,114 @@
+From 3dc109a97a9f793c040c130ce9d2de4db7d475c7 Mon Sep 17 00:00:00 2001
+From: zaveshaa <zaveshaa@gmail.com>
+Date: Sun, 23 Aug 2026 10:39:26 +0300
+Subject: [PATCH 7/7] docs: fix doubled words in man pages and design docs
+
+Fix 23 occurrences of accidentally doubled words like 'in in',
+'the the', 'been been' across man1/man3/man7 pages, internal
+documentation and design documents.
+
+CLA: trivial
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+Reviewed-by: Paul Dale <paul.dale@oracle.com>
+Merge-date: Thu Aug 27 16:00:39 2026
+Merged-from: https://github.com/openssl/openssl/pull/32461
+(cherry picked from commit 6b736d031e9bc7df908292f7f0a09ed5fd562f5a)
+---
+ doc/internal/man3/OPTIONS.pod            | 4 ++--
+ doc/internal/man7/VERSION.pod            | 2 +-
+ doc/man3/SSL_CTX_set_tmp_dh_callback.pod | 2 +-
+ doc/man3/SSL_in_init.pod                 | 2 +-
+ doc/man7/EVP_MAC-Poly1305.pod            | 2 +-
+ doc/man7/provider-digest.pod             | 2 +-
+ 6 files changed, 7 insertions(+), 7 deletions(-)
+
+diff --git a/doc/internal/man3/OPTIONS.pod b/doc/internal/man3/OPTIONS.pod
+index dbdd39a2ee..2e8c356961 100644
+--- a/doc/internal/man3/OPTIONS.pod
++++ b/doc/internal/man3/OPTIONS.pod
+@@ -189,7 +189,7 @@ B<OPT_PARAMETERS> macro:
+     OPT_PARAMETERS()
+     {OPT_PARAM_STR, 1, '-', "Parameters:\n"}
+ 
+-Every "option" after after this should contain the parameter and
++Every "option" after this should contain the parameter and
+ the help string:
+ 
+     {"text", 0, 0, "Words to display (optional)"},
+@@ -247,7 +247,7 @@ The opt_arg() function returns the option's argument value, if there is one.
+ The opt_unknown() function returns the unknown option.
+ In an option list, there can be at most one option with the empty string.
+ This is a "wildcard" or "unknown" option. For example, it allows an
+-option to be be taken as digest algorithm, like C<-sha1>. The function
++option to be taken as digest algorithm, like C<-sha1>. The function
+ opt_md() takes the specified I<name> and fills in the digest into I<mdp>.
+ The functions opt_cipher(), opt_cipher_any() and opt_cipher_silent()
+ each takes the specified I<name> and fills in the cipher into I<cipherp>.
+diff --git a/doc/internal/man7/VERSION.pod b/doc/internal/man7/VERSION.pod
+index 4bc8ba6b93..8594d6237e 100644
+--- a/doc/internal/man7/VERSION.pod
++++ b/doc/internal/man7/VERSION.pod
+@@ -89,7 +89,7 @@ the string will be C<3.0.0>.
+ =item $config{full_version}
+ 
+ The fully loaded version number, a string composed from $config{version},
+-$config{prerelease} and $config{build_metadata}.  See   See L</EXAMPLES> for
++$config{prerelease} and $config{build_metadata}.  See L</EXAMPLES> for
+ a few examples.
+ 
+ =back
+diff --git a/doc/man3/SSL_CTX_set_tmp_dh_callback.pod b/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
+index 902cefdfa3..80845fe357 100644
+--- a/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
++++ b/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
+@@ -66,7 +66,7 @@ it off. The default setting is off.
+ 
+ If "auto" DH parameters are switched on then the parameters will be selected to
+ be consistent with the size of the key associated with the server's certificate.
+-If there is no certificate (e.g. for PSK ciphersuites), then it it will be
++If there is no certificate (e.g. for PSK ciphersuites), then it will be
+ consistent with the size of the negotiated symmetric cipher key.
+ 
+ Applications may supply their own DH parameters instead of using the built-in
+diff --git a/doc/man3/SSL_in_init.pod b/doc/man3/SSL_in_init.pod
+index 315d870284..95e158433f 100644
+--- a/doc/man3/SSL_in_init.pod
++++ b/doc/man3/SSL_in_init.pod
+@@ -69,7 +69,7 @@ format. These are:
+ 
+ =item TLS_ST_BEFORE
+ 
+-No handshake messages have yet been been sent or received.
++No handshake messages have yet been sent or received.
+ 
+ =item TLS_ST_OK
+ 
+diff --git a/doc/man7/EVP_MAC-Poly1305.pod b/doc/man7/EVP_MAC-Poly1305.pod
+index a942226cd8..8c3068a837 100644
+--- a/doc/man7/EVP_MAC-Poly1305.pod
++++ b/doc/man7/EVP_MAC-Poly1305.pod
+@@ -46,7 +46,7 @@ Gets the MAC size.
+ 
+ =back
+ 
+-The "size" parameter can also be retrieved with with EVP_MAC_CTX_get_mac_size().
++The "size" parameter can also be retrieved with EVP_MAC_CTX_get_mac_size().
+ The length of the "size" parameter should not exceed that of an B<unsigned int>.
+ 
+ =head1 NOTES
+diff --git a/doc/man7/provider-digest.pod b/doc/man7/provider-digest.pod
+index cac53ac291..28cefcab9a 100644
+--- a/doc/man7/provider-digest.pod
++++ b/doc/man7/provider-digest.pod
+@@ -154,7 +154,7 @@ provider side digest context I<dctx> to I<params>.
+ Any parameter settings are additional to any that were previously set.
+ Passing NULL for I<params> should return true.
+ 
+-OSSL_FUNC_digest_get_ctx_params() gets digest operation details details from
++OSSL_FUNC_digest_get_ctx_params() gets digest operation details from
+ the given provider side digest context I<dctx> and stores them in I<params>.
+ Passing NULL for I<params> should return true.
+ 
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

