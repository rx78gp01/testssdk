diff --git a/package/kernel/ath10k-ct/patches/999-Update-mac.c.patch b/package/kernel/ath10k-ct/patches/999-Update-mac.c.patch
new file mode 100644
index 0000000..d1583ab
--- /dev/null
+++ b/package/kernel/ath10k-ct/patches/999-Update-mac.c.patch
@@ -0,0 +1,34 @@
+From 1b2ef193f353f0f17d57a43b272403e0bdc11bfb Mon Sep 17 00:00:00 2001
+From: rx78gp01 <rx78gp01@users.noreply.github.com>
+Date: Mon, 11 Sep 2023 14:00:40 +0800
+Subject: [PATCH] Update mac.c
+
+---
+ ath10k-5.15/mac.c | 7 ++++---
+ 1 file changed, 4 insertions(+), 3 deletions(-)
+
+diff --git a/ath10k-5.15/mac.c b/ath10k-5.15/mac.c
+index ba5d366..87c29ef 100644
+--- a/ath10k-5.15/mac.c
++++ b/ath10k-5.15/mac.c
+@@ -4816,13 +4816,14 @@ static int ath10k_mac_tx(struct ath10k *ar,
+ 		ath10k_tx_h_8023(skb);
+ 		break;
+ 	case ATH10K_HW_TXRX_RAW:
+-		if (!(test_bit(ATH10K_FLAG_RAW_MODE, &ar->dev_flags) ||
+-		      (skb_cb->flags & ATH10K_SKB_F_RAW_TX) ||
++		if ((!test_bit(ATH10K_FLAG_RAW_MODE, &ar->dev_flags) ||
++		      
+ 		      /* Any CT firmware recent enough to support rate-mask should be able to do
+ 		       * at least some raw-tx too.  Works on recent 10.1 firmware with non-encrypted
+ 		       * frames transmitted on a monitor device, at least.
+ 		       */
+-		      test_bit(ATH10K_FW_FEATURE_CT_RATEMASK, ar->running_fw->fw_file.fw_features))) {
++		      !test_bit(ATH10K_FW_FEATURE_CT_RATEMASK, ar->running_fw->fw_file.fw_features)) && 
++		      !(skb_cb->flags & ATH10K_SKB_F_RAW_TX)) {
+ 			WARN_ON_ONCE(1);
+ 			ieee80211_free_txskb(hw, skb);
+ 			return -ENOTSUPP;
+-- 
+2.38.1.windows.1
+
-- 
2.38.1.windows.1

