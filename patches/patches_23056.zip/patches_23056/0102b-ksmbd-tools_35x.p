diff --git a/feeds/packages/net/ksmbd-tools/patches/101.patch b/feeds/packages/net/ksmbd-tools/patches/101.patch
new file mode 100644
index 0000000..27a6e98
--- /dev/null
+++ b/feeds/packages/net/ksmbd-tools/patches/101.patch
@@ -0,0 +1,34 @@
+From 3ba0464c372d8ea242dbb3e0680881f76c2b0b44 Mon Sep 17 00:00:00 2001
+From: Namjae Jeon <linkinjeon@kernel.org>
+Date: Fri, 21 Jun 2024 22:58:13 +0900
+Subject: [PATCH] ksmbd-tools: make KSMBD_SHARE_FLAG_WRITEABLE and
+ KSMBD_SHARE_FLAG_READONLY mutually exclusive
+
+Make KSMBD_SHARE_FLAG_WRITEABLE and KSMBD_SHARE_FLAG_READONLY mutually
+exclusive.
+
+Signed-off-by: Namjae Jeon <linkinjeon@kernel.org>
+---
+ tools/management/share.c | 7 +++++--
+ 1 file changed, 5 insertions(+), 2 deletions(-)
+
+diff --git a/tools/management/share.c b/tools/management/share.c
+index 037c5be7..de75599d 100644
+--- a/tools/management/share.c
++++ b/tools/management/share.c
+@@ -550,10 +550,13 @@ static void process_share_conf_kv(struct ksmbd_share *share, char *k, char *v)
+ 	if (shm_share_config(k, KSMBD_SHARE_CONF_WRITE_OK) ||
+ 	    shm_share_config(k, KSMBD_SHARE_CONF_WRITEABLE) ||
+ 	    shm_share_config(k, KSMBD_SHARE_CONF_WRITABLE)) {
+-		if (cp_get_group_kv_bool(v))
++		if (cp_get_group_kv_bool(v)) {
+ 			set_share_flag(share, KSMBD_SHARE_FLAG_WRITEABLE);
+-		else
++			clear_share_flag(share, KSMBD_SHARE_FLAG_READONLY);
++		} else {
+ 			clear_share_flag(share, KSMBD_SHARE_FLAG_WRITEABLE);
++			set_share_flag(share, KSMBD_SHARE_FLAG_READONLY);
++		}
+ 		return;
+ 	}
+ 
diff --git a/feeds/packages/net/ksmbd-tools/patches/102.patch b/feeds/packages/net/ksmbd-tools/patches/102.patch
new file mode 100644
index 0000000..be3d67e
--- /dev/null
+++ b/feeds/packages/net/ksmbd-tools/patches/102.patch
@@ -0,0 +1,48 @@
+From 288b813489663cea1a499459ea9f579dd6599656 Mon Sep 17 00:00:00 2001
+From: =?UTF-8?q?Atte=20Heikkil=C3=A4?= <atteh.mailbox@gmail.com>
+Date: Thu, 27 Jun 2024 23:36:04 +0300
+Subject: [PATCH] ksmbd-tools: fix prompting when built against musl libc
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+The output stream flushing schemes of GNU libc and musl libc differ,
+resulting in addshare and adduser prompting incorrectly when built
+against the latter. Fix this by flushing explicitly with fflush(3).
+
+Signed-off-by: Atte Heikkilä <atteh.mailbox@gmail.com>
+Signed-off-by: Namjae Jeon <linkinjeon@kernel.org>
+---
+ addshare/share_admin.c | 1 +
+ adduser/user_admin.c   | 4 +++-
+ 2 files changed, 4 insertions(+), 1 deletion(-)
+
+diff --git a/addshare/share_admin.c b/addshare/share_admin.c
+index 575f5fa9..fd2c593c 100644
+--- a/addshare/share_admin.c
++++ b/addshare/share_admin.c
+@@ -122,6 +122,7 @@ static void __load_conf(enum KSMBD_SHARE_CONF conf,
+ 	}
+ 
+ 	printf("\r" "\e[2K" "%s%s" "\e[6n", option, buf);
++	fflush(stdout);
+ 
+ 	if (option != options[conf])
+ 		g_free(option);
+diff --git a/adduser/user_admin.c b/adduser/user_admin.c
+index 1abfb8a1..59c13360 100644
+--- a/adduser/user_admin.c
++++ b/adduser/user_admin.c
+@@ -42,9 +42,11 @@ static void __prompt_password_stdin(char *password, size_t *sz)
+ 	     buflen = 0, password[buflen] = buf[buflen] = 0x00;;) {
+ 		int c;
+ 
+-		if (!buflen)
++		if (!buflen) {
+ 			printf("\r" "\e[2K" "%s password: ",
+ 			       *password == 0x00 ? "New" : "Retype");
++			fflush(stdout);
++		}
+ 
+ 		c = getchar();
+ 		if (c == EOF || c == 0x04)
-- 
2.38.1.windows.1

