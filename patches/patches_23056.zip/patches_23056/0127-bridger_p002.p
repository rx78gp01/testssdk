diff --git a/package/network/services/bridger/patches/002.patch b/package/network/services/bridger/patches/002.patch
new file mode 100644
index 0000000..8682776
--- /dev/null
+++ b/package/network/services/bridger/patches/002.patch
@@ -0,0 +1,39 @@
+From 2d74a362c9c32d01b9506d23b635bb79771f3bfc Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Tue, 23 Sep 2025 16:55:06 +0200
+Subject: [PATCH] nl: always return NL_SKIP in bridge_nl_error_cb
+
+Avoid aborting request processing too early and leaving
+messages unprocessed
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ nl.c | 6 +++---
+ 1 file changed, 3 insertions(+), 3 deletions(-)
+
+diff --git a/nl.c b/nl.c
+index e5e22e9..ba4fb8d 100644
+--- a/nl.c
++++ b/nl.c
+@@ -827,10 +827,10 @@ bridge_nl_error_cb(struct sockaddr_nl *nla, struct nlmsgerr *err,
+ 	const char *errstr = "(unknown)";
+ 
+ 	if (ignore_errors)
+-		return NL_STOP;
++		return NL_SKIP;
+ 
+ 	if (!(nlh->nlmsg_flags & NLM_F_ACK_TLVS))
+-		return NL_STOP;
++		return NL_SKIP;
+ 
+ 	if (!(nlh->nlmsg_flags & NLM_F_CAPPED))
+ 		ack_len += err->msg.nlmsg_len - sizeof(*nlh);
+@@ -844,7 +844,7 @@ bridge_nl_error_cb(struct sockaddr_nl *nla, struct nlmsgerr *err,
+ 
+ 	D("Netlink error(%d): %s\n", err->error, errstr);
+ 
+-	return NL_STOP;
++	return NL_SKIP;
+ }
+ 
+ struct nl_sock *
-- 
2.46.2.windows.1

