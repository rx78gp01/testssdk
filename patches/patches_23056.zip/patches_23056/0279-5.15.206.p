diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .197
-LINUX_KERNEL_HASH-5.15.197 = fd218df8e2107a4443b6c29fef7f95aad167031e0fbdbc7a858ae8471360668a
+LINUX_VERSION-5.15 = .198
+LINUX_KERNEL_HASH-5.15.198 = 5d4c0994580dd3bbd5ffc5fcb81c22dd305b844c9d8c7b176cc41b28f7e29743
