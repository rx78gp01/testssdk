From 8f80acfac027622ca88945c34067ea68aadc0faa Mon Sep 17 00:00:00 2001
From: Shiji Yang <yangshiji66@outlook.com>
Date: Sat, 10 May 2025 17:19:18 +0800
Subject: [PATCH] vrx518_ep: fix macro redefined build error on 6.12 kernel

Add LANTIQ prefix to avoid name conflicts.

Signed-off-by: Shiji Yang <yangshiji66@outlook.com>
Link: https://github.com/openwrt/openwrt/pull/18744
Signed-off-by: Robert Marko <robimarko@gmail.com>
---
 ...o-definition-conflicts-on-6.12-kerne.patch | 34 +++++++++++++++++++
 1 file changed, 34 insertions(+)
 create mode 100644 package/kernel/lantiq/vrx518_ep/patches/101-Fix-version-macro-definition-conflicts-on-6.12-kerne.patch

diff --git a/package/kernel/lantiq/vrx518_ep/patches/101-Fix-version-macro-definition-conflicts-on-6.12-kerne.patch b/package/kernel/lantiq/vrx518_ep/patches/101-Fix-version-macro-definition-conflicts-on-6.12-kerne.patch
new file mode 100644
index 00000000000000..3b108e613b1c38
--- /dev/null
+++ b/package/kernel/lantiq/vrx518_ep/patches/101-Fix-version-macro-definition-conflicts-on-6.12-kerne.patch
@@ -0,0 +1,34 @@
+From: Shiji Yang <yangshiji66@outlook.com>
+Date: Wed, 7 May 2025 19:16:16 +0800
+Subject: [PATCH] fix version macro definition conflicts on 6.12 kernel
+
+Add LANTIQ prefix to version variable names to fix:
+
+/home/db/owrt/build_dir/target-arm_cortex-a7+neon-vfpv4_musl_eabi/linux-ipq40xx_generic/vrx518_ep-2.1.0/ep.c:45:9: error: "MIN" redefined [-Werror]
+   45 | #define MIN     1
+      |         ^~~
+./include/linux/minmax.h:329:9: note: this is the location of the previous definition
+  329 | #define MIN(a,b) __cmp(min,a,b)
+      |         ^~~
+
+Signed-off-by: Shiji Yang <yangshiji66@outlook.com>
+---
+ ep.c | 6 +++---
+ 1 file changed, 3 insertions(+), 3 deletions(-)
+
+--- a/ep.c
++++ b/ep.c
+@@ -42,10 +42,10 @@
+ 
+ #define DC_EP_DBG
+ 
+-#define MAJ	2
+-#define MIN	1
++#define LANTIQ_MAJ	2
++#define LANTIQ_MIN	1
+ #define BUILD	0
+-#define DRV_VERSION __stringify(MAJ) "." __stringify(MIN) "." \
++#define DRV_VERSION __stringify(LANTIQ_MAJ) "." __stringify(LANTIQ_MIN) "." \
+ 	__stringify(BUILD) "-k"
+ 
+ static bool pcie_switch_exist;
