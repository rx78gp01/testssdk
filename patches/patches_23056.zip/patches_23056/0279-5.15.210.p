diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .209
-LINUX_KERNEL_HASH-5.15.209 = 346d77c7eac2cd8d719a2530b4f858bf99bc956b25f80995fd214f8aef821eb4
+LINUX_VERSION-5.15 = .210
+LINUX_KERNEL_HASH-5.15.210 = 910ba46ae15e7495a9624f89d7f11b24ccc8bc1ee4b3abdd502e75b055290a01
