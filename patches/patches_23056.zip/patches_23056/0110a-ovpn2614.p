From 0eedafdbda61696249ad12db39ff591209830fac Mon Sep 17 00:00:00 2001
From: Martin Schiller <ms@dev.tdt.de>
Date: Wed, 28 Jun 2023 09:13:19 +0200
Subject: [PATCH] openvpn: update to 2.6.13 and add DCO support

This commit updates openvpn to version 2.6.13 and add DCO support.

There are several changes:

- Starting with version 2.6.0, the sources are only provided as .tar.gz
  file.

- removed OPENVPN_<variant>_ENABLE_MULTIHOME:
  multihome support is always included and cannot be disabled anymore
  with 2.6.x.

- removed OPENVPN_<variant>_ENABLE_DEF_AUTH:
  deferred auth support is always included and cannot be disabled
  anymore with 2.6.x.

- removed OPENVPN_<variant>_ENABLE_PF:
  PF (packet filtering) support was removed in 2.6.x.

- The internal lz4 library was removed in 2.6.x; we now use the liblz4
  package if needed

- To increase reproducibility, _DATE_ is only used for development
  builds and not in release builds in 2.6.x.

- wolfSSL support was integrated into upstream openvpn

- DES support was removed from openvpn

The first two wolfSSL patches were created following these 2 commits:
https://github.com/OpenVPN/openvpn/commit/4cf01c8e4381403998341aa32f79f4bf24c7ccb1
https://github.com/OpenVPN/openvpn/commit/028b501734b4a57dc53edb8b11a4b370f5b99e38

Signed-off-by: Martin Schiller <ms@dev.tdt.de>
---
 net/openvpn/Config-mbedtls.in                 |  20 +-
 net/openvpn/Config-openssl.in                 |  20 +-
 net/openvpn/Config-wolfssl.in                 |  20 +-
 net/openvpn/Makefile                          |  16 +-
 net/openvpn/files/openvpn.options             |   1 -
 .../001-reproducible-remove_DATE.patch        |  10 -
 .../patches/002-add-wolfssl-support.patch     | 190 ------------------
 ...bedtls-disable-runtime-version-check.patch |   2 +-
 ...P_PKEY_CTX_-compilation-with-wolfSSL.patch |  20 ++
 ...y-support-when-building-with-wolfSSL.patch |  20 ++
 ...3-define-LN_serialNumber-for-wolfSSL.patch |  12 ++
 .../210-build_always_use_internal_lz4.patch   |  74 -------
 net/openvpn/patches/220-disable_des.patch     |  74 -------
 13 files changed, 84 insertions(+), 395 deletions(-)
 delete mode 100644 net/openvpn/patches/001-reproducible-remove_DATE.patch
 delete mode 100644 net/openvpn/patches/002-add-wolfssl-support.patch
 create mode 100644 net/openvpn/patches/101-Fix-EVP_PKEY_CTX_-compilation-with-wolfSSL.patch
 create mode 100644 net/openvpn/patches/102-Disable-external-ec-key-support-when-building-with-wolfSSL.patch
 create mode 100644 net/openvpn/patches/103-define-LN_serialNumber-for-wolfSSL.patch
 delete mode 100644 net/openvpn/patches/210-build_always_use_internal_lz4.patch
 delete mode 100644 net/openvpn/patches/220-disable_des.patch

diff --git a/feeds/packages/net/openvpn/Config-mbedtls.in b/feeds/packages/net/openvpn/Config-mbedtls.in
index 3cf233b8f7b39..edcfbdf9d707a 100644
--- a/feeds/packages/net/openvpn/Config-mbedtls.in
+++ b/feeds/packages/net/openvpn/Config-mbedtls.in
@@ -24,26 +24,22 @@ config OPENVPN_mbedtls_ENABLE_FRAGMENT
 	bool "Enable internal fragmentation support (--fragment)"
 	default y
 
-config OPENVPN_mbedtls_ENABLE_MULTIHOME
-	bool "Enable multi-homed UDP server support (--multihome)"
-	default y
-
 config OPENVPN_mbedtls_ENABLE_PORT_SHARE
 	bool "Enable TCP server port-share support (--port-share)"
 	default y
 
-config OPENVPN_mbedtls_ENABLE_DEF_AUTH
-	bool "Enable deferred authentication"
-	default y
-
-config OPENVPN_mbedtls_ENABLE_PF
-	bool "Enable internal packet filter"
-	default y
-
 config OPENVPN_mbedtls_ENABLE_IPROUTE2
 	bool "Enable support for iproute2"
 	default n
 
+config OPENVPN_mbedtls_ENABLE_DCO
+	depends on !OPENVPN_mbedtls_ENABLE_IPROUTE2
+	bool "Enable support for data channel offload"
+	default n if OPENVPN_mbedtls_ENABLE_IPROUTE2
+	help
+	  enable data channel offload support
+	  using the ovpn-dco-v2 kernel module
+
 config OPENVPN_mbedtls_ENABLE_SMALL
 	bool "Enable size optimization"
 	default y
diff --git a/feeds/packages/net/openvpn/Config-openssl.in b/feeds/packages/net/openvpn/Config-openssl.in
index 7a7be74db9b15..c09b45e10d32f 100644
--- a/feeds/packages/net/openvpn/Config-openssl.in
+++ b/feeds/packages/net/openvpn/Config-openssl.in
@@ -28,26 +28,22 @@ config OPENVPN_openssl_ENABLE_FRAGMENT
 	bool "Enable internal fragmentation support (--fragment)"
 	default y
 
-config OPENVPN_openssl_ENABLE_MULTIHOME
-	bool "Enable multi-homed UDP server support (--multihome)"
-	default y
-
 config OPENVPN_openssl_ENABLE_PORT_SHARE
 	bool "Enable TCP server port-share support (--port-share)"
 	default y
 
-config OPENVPN_openssl_ENABLE_DEF_AUTH
-	bool "Enable deferred authentication"
-	default y
-
-config OPENVPN_openssl_ENABLE_PF
-	bool "Enable internal packet filter"
-	default y
-
 config OPENVPN_openssl_ENABLE_IPROUTE2
 	bool "Enable support for iproute2"
 	default n
 
+config OPENVPN_openssl_ENABLE_DCO
+	depends on !OPENVPN_openssl_ENABLE_IPROUTE2
+	bool "Enable support for data channel offload"
+	default n if OPENVPN_openssl_ENABLE_IPROUTE2
+	help
+	  enable data channel offload support
+	  using the ovpn-dco-v2 kernel module
+
 config OPENVPN_openssl_ENABLE_SMALL
 	bool "Enable size optimization"
 	default y
diff --git a/feeds/packages/net/openvpn/Config-wolfssl.in b/feeds/packages/net/openvpn/Config-wolfssl.in
index ef8b9dcb34096..bd076460a29c5 100644
--- a/feeds/packages/net/openvpn/Config-wolfssl.in
+++ b/feeds/packages/net/openvpn/Config-wolfssl.in
@@ -33,26 +33,22 @@ config OPENVPN_wolfssl_ENABLE_FRAGMENT
 	bool "Enable internal fragmentation support (--fragment)"
 	default y
 
-config OPENVPN_wolfssl_ENABLE_MULTIHOME
-	bool "Enable multi-homed UDP server support (--multihome)"
-	default y
-
 config OPENVPN_wolfssl_ENABLE_PORT_SHARE
 	bool "Enable TCP server port-share support (--port-share)"
 	default y
 
-config OPENVPN_wolfssl_ENABLE_DEF_AUTH
-	bool "Enable deferred authentication"
-	default y
-
-config OPENVPN_wolfssl_ENABLE_PF
-	bool "Enable internal packet filter"
-	default y
-
 config OPENVPN_wolfssl_ENABLE_IPROUTE2
 	bool "Enable support for iproute2"
 	default n
 
+config OPENVPN_wolfssl_ENABLE_DCO
+	depends on !OPENVPN_wolfssl_ENABLE_IPROUTE2
+	bool "Enable support for data channel offload"
+	default n if OPENVPN_openssl_ENABLE_IPROUTE2
+	help
+	  enable data channel offload support
+	  using the ovpn-dco-v2 kernel module
+
 config OPENVPN_wolfssl_ENABLE_SMALL
 	bool "Enable size optimization"
 	default y
diff --git a/feeds/packages/net/openvpn/Makefile b/feeds/packages/net/openvpn/Makefile
index ac76841b8b946..752d385351939 100644
--- a/feeds/packages/net/openvpn/Makefile
+++ b/feeds/packages/net/openvpn/Makefile
@@ -9,14 +9,14 @@ include $(TOPDIR)/rules.mk
 
 PKG_NAME:=openvpn
 
-PKG_VERSION:=2.5.8
-PKG_RELEASE:=5
+PKG_VERSION:=2.6.14
+PKG_RELEASE:=1
 
 PKG_SOURCE_URL:=\
 	https://build.openvpn.net/downloads/releases/ \
 	https://swupdate.openvpn.net/community/releases/
-PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.xz
-PKG_HASH:=2bbd0026469902037ee6499b68283d5ab36c74e36cae3112082cfdf6c77a0c57
+PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.gz
+PKG_HASH:=9eb6a6618352f9e7b771a9d38ae1631b5edfeed6d40233e243e602ddf2195e7a
 
 PKG_MAINTAINER:=Magnus Kroken <mkroken@gmail.com>
 
@@ -36,14 +36,15 @@ define Package/openvpn/Default
   URL:=http://openvpn.net
   SUBMENU:=VPN
   MENU:=1
-  DEPENDS:=+kmod-tun +OPENVPN_$(1)_ENABLE_LZO:liblzo +OPENVPN_$(1)_ENABLE_IPROUTE2:ip $(3)
+  DEPENDS:=+kmod-tun +libcap-ng +OPENVPN_$(1)_ENABLE_LZO:liblzo +OPENVPN_$(1)_ENABLE_LZ4:liblz4 +OPENVPN_$(1)_ENABLE_IPROUTE2:ip \
+	+OPENVPN_$(1)_ENABLE_DCO:libnl-genl +OPENVPN_$(1)_ENABLE_DCO:kmod-ovpn-dco-v2 $(3)
   VARIANT:=$(1)
   PROVIDES:=openvpn openvpn-crypto
 endef
 
 Package/openvpn-openssl=$(call Package/openvpn/Default,openssl,OpenSSL,+PACKAGE_openvpn-openssl:libopenssl)
 Package/openvpn-mbedtls=$(call Package/openvpn/Default,mbedtls,mbedTLS,+PACKAGE_openvpn-mbedtls:libmbedtls)
-Package/openvpn-wolfssl=$(call Package/openvpn/Default,wolfssl,WolfSSL \(experimental\),+PACKAGE_openvpn-wolfssl:libwolfssl)
+Package/openvpn-wolfssl=$(call Package/openvpn/Default,wolfssl,WolfSSL,+PACKAGE_openvpn-wolfssl:libwolfssl)
 
 define Package/openvpn/config/Default
 	source "$(SOURCE)/Config-$(1).in"
@@ -80,11 +80,9 @@ define Build/Configure
 		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_X509_ALT_USERNAME),--enable,--disable)-x509-alt-username \
 		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_MANAGEMENT),--enable,--disable)-management \
 		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_FRAGMENT),--enable,--disable)-fragment \
-		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_MULTIHOME),--enable,--disable)-multihome \
 		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_IPROUTE2),--enable,--disable)-iproute2 \
-		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_DEF_AUTH),--enable,--disable)-def-auth \
-		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_PF),--enable,--disable)-pf \
 		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_PORT_SHARE),--enable,--disable)-port-share \
+		$(if $(CONFIG_OPENVPN_$(BUILD_VARIANT)_ENABLE_DCO),--enable,--disable)-dco \
 		$(if $(CONFIG_OPENVPN_OPENSSL),--with-crypto-library=openssl --with-openssl-engine=no) \
 		$(if $(CONFIG_OPENVPN_MBEDTLS),--with-crypto-library=mbedtls) \
 		$(if $(CONFIG_OPENVPN_WOLFSSL),--with-crypto-library=wolfssl) \
diff --git a/feeds/packages/net/openvpn/files/openvpn.options b/feeds/packages/net/openvpn/files/openvpn.options
index 5a7c756f7d962..7e3aedb0dc2b8 100644
--- a/feeds/packages/net/openvpn/files/openvpn.options
+++ b/feeds/packages/net/openvpn/files/openvpn.options
@@ -54,7 +54,6 @@ iroute_ipv6
 keepalive
 key
 key_direction
-keysize
 learn_address
 link_mtu
 lladdr
@@ -149,6 +149,7 @@ client
 client_to_client
 comp_noadapt
 disable
+disable_dco
 disable_occ
 down_pre
 duplicate_cn
diff --git a/feeds/packages/net/openvpn/patches/001-reproducible-remove_DATE.patch b/feeds/packages/net/openvpn/patches/001-reproducible-remove_DATE.patch
deleted file mode 100644
index e4e6d39413584..0000000000000
--- a/feeds/packages/net/openvpn/patches/001-reproducible-remove_DATE.patch
+++ /dev/null
@@ -1,10 +0,0 @@
---- a/src/openvpn/options.c
-+++ b/src/openvpn/options.c
-@@ -105,7 +105,6 @@ const char title_string[] =
- #endif
- #endif
-     " [AEAD]"
--    " built on " __DATE__
- ;
- 
- #ifndef ENABLE_SMALL
diff --git a/feeds/packages/net/openvpn/patches/002-add-wolfssl-support.patch b/feeds/packages/net/openvpn/patches/002-add-wolfssl-support.patch
deleted file mode 100644
index 7311a36eb375a..0000000000000
--- a/feeds/packages/net/openvpn/patches/002-add-wolfssl-support.patch
+++ /dev/null
@@ -1,190 +0,0 @@
-From: Gert Doering <gert@greenie.muc.de>
-
-Support for wolfSSL in OpenVPN
-
-This patch adds support for wolfSSL in OpenVPN. Support is added by using
-wolfSSL's OpenSSL compatibility layer. Function calls are left unchanged
-and instead the OpenSSL includes point to wolfSSL headers and OpenVPN is
-linked against the wolfSSL library. The wolfSSL installation directory is
-detected using pkg-config.
-
-As requested by OpenVPN maintainers, this patch does not include
-wolfssl/options.h on its own. By defining the macro EXTERNAL_OPTS_OPENVPN
-in the configure script wolfSSL will include wolfssl/options.h on its own
-(change added in wolfSSL/wolfssl#2825). The patch
-adds an option '--disable-wolfssl-options-h' in case the user would like
-to supply their own settings file for wolfSSL.
-
-wolfSSL:
-Support added in: wolfSSL/wolfssl#2503
-
-git clone https://github.com/wolfSSL/wolfssl.git
-cd wolfssl
-./autogen.sh
-./configure --enable-openvpn
-make
-sudo make install
-
-OpenVPN:
-
-autoreconf -i -v -f
-./configure --with-crypto-library=wolfssl
-make
-make check
-sudo make install
-
-Signed-off-by: Juliusz Sosinowicz <juliusz@wolfssl.com>
-Acked-by: Arne Schwabe <arne@rfc2549.org>
-Message-Id: <20210317181153.83716-1-juliusz@wolfssl.com>
-URL: https://www.mail-archive.com/openvpn-devel@lists.sourceforge.net/msg21686.html
-Signed-off-by: Gert Doering <gert@greenie.muc.de>
----
- configure.ac | 110 ++++++++++++++++++++++++++++++++++++++++++++++++++++++-
- src/openvpn/syshead.h | 3 ++-
- 2 files changed, 110 insertions(+), 3 deletions(-)
---- a/configure.ac
-+++ b/configure.ac
-@@ -271,16 +271,23 @@ AC_ARG_WITH(
- 
- AC_ARG_WITH(
- 	[crypto-library],
--	[AS_HELP_STRING([--with-crypto-library=library], [build with the given crypto library, TYPE=openssl|mbedtls @<:@default=openssl@:>@])],
-+	[AS_HELP_STRING([--with-crypto-library=library], [build with the given crypto library, TYPE=openssl|mbedtls|wolfssl @<:@default=openssl@:>@])],
- 	[
- 		case "${withval}" in
--			openssl|mbedtls) ;;
-+			openssl|mbedtls|wolfssl) ;;
- 			*) AC_MSG_ERROR([bad value ${withval} for --with-crypto-library]) ;;
- 		esac
- 	],
- 	[with_crypto_library="openssl"]
- )
- 
-+AC_ARG_ENABLE(
-+	[wolfssl-options-h],
-+	[AS_HELP_STRING([--disable-wolfssl-options-h], [Disable including options.h in wolfSSL @<:@default=yes@:>@])],
-+	,
-+	[enable_wolfssl_options_h="yes"]
-+)
-+
- AC_ARG_WITH(
- 	[openssl-engine],
- 	[AS_HELP_STRING([--with-openssl-engine], [enable engine support with OpenSSL. Default enabled for OpenSSL < 3.0, auto,yes,no @<:@default=auto@:>@])],
-@@ -1054,6 +1061,105 @@ elif test "${with_crypto_library}" = "mb
- 	AC_DEFINE([ENABLE_CRYPTO_MBEDTLS], [1], [Use mbed TLS library])
- 	CRYPTO_CFLAGS="${MBEDTLS_CFLAGS}"
- 	CRYPTO_LIBS="${MBEDTLS_LIBS}"
-+
-+elif test "${with_crypto_library}" = "wolfssl"; then
-+	AC_ARG_VAR([WOLFSSL_CFLAGS], [C compiler flags for wolfssl. The include directory should
-+								  contain the regular wolfSSL header files but also the
-+								  wolfSSL OpenSSL header files. Ex: -I/usr/local/include
-+								  -I/usr/local/include/wolfssl])
-+	AC_ARG_VAR([WOLFSSL_LIBS], [linker flags for wolfssl])
-+
-+	saved_CFLAGS="${CFLAGS}"
-+	saved_LIBS="${LIBS}"
-+
-+	if test -z "${WOLFSSL_CFLAGS}" -a -z "${WOLFSSL_LIBS}"; then
-+		# if the user did not explicitly specify flags, try to autodetect
-+		PKG_CHECK_MODULES(
-+			[WOLFSSL],
-+			[wolfssl],
-+			[],
-+			[AC_MSG_ERROR([Could not find wolfSSL.])]
-+		)
-+		PKG_CHECK_VAR(
-+			[WOLFSSL_INCLUDEDIR],
-+			[wolfssl],
-+			[includedir],
-+			[],
-+			[AC_MSG_ERROR([Could not find wolfSSL includedir variable.])]
-+		)
-+		WOLFSSL_CFLAGS="${WOLFSSL_CFLAGS} -I${WOLFSSL_INCLUDEDIR}/wolfssl"
-+	fi
-+	saved_CFLAGS="${CFLAGS}"
-+	saved_LIBS="${LIBS}"
-+	CFLAGS="${CFLAGS} ${WOLFSSL_CFLAGS}"
-+	LIBS="${LIBS} ${WOLFSSL_LIBS}"
-+
-+	AC_CHECK_LIB(
-+		[wolfssl],
-+		[wolfSSL_Init],
-+		[],
-+		[AC_MSG_ERROR([Could not link wolfSSL library.])]
-+	)
-+	AC_CHECK_HEADER([wolfssl/options.h],,[AC_MSG_ERROR([wolfSSL header wolfssl/options.h not found!])])
-+
-+	# wolfSSL signal EKM support
-+	have_export_keying_material="yes"
-+
-+	AC_DEFINE([HAVE_HMAC_CTX_NEW], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_HMAC_CTX_FREE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_HMAC_CTX_RESET], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_MD_CTX_NEW], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_MD_CTX_FREE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_MD_CTX_RESET], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_CIPHER_CTX_RESET], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_OPENSSL_VERSION], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_SSL_CTX_GET_DEFAULT_PASSWD_CB], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_SSL_CTX_GET_DEFAULT_PASSWD_CB_USERDATA], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_SSL_CTX_SET_SECURITY_LEVEL], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_GET0_NOTBEFORE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_GET0_NOTAFTER], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_GET0_PUBKEY], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_STORE_GET0_OBJECTS], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_OBJECT_FREE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_X509_OBJECT_GET_TYPE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_PKEY_ID], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_PKEY_GET0_RSA], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_PKEY_GET0_DSA], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EVP_PKEY_GET0_EC_KEY], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_SET_FLAGS], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_BITS], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_GET0_KEY], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_SET0_KEY], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_DSA_GET0_PQG], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_DSA_BITS], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_NEW], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_FREE], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_PUB_ENC], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_PUB_DEC], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_PRIV_ENC], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_PRIV_DEC], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_INIT], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_SIGN], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET_FINISH], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_SET0_APP_DATA], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_RSA_METH_GET0_APP_DATA], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+	AC_DEFINE([HAVE_EC_GROUP_ORDER_BITS], [1], [Emulate AC_CHECK_FUNCS since these are defined as macros])
-+
-+	if test "${enable_wolfssl_options_h}" = "yes"; then
-+		AC_DEFINE([EXTERNAL_OPTS_OPENVPN], [1], [Include options.h from wolfSSL library])
-+	else
-+		AC_DEFINE([WOLFSSL_USER_SETTINGS], [1], [Use custom user_settings.h file for wolfSSL library])
-+	fi
-+
-+	have_export_keying_material="yes"
-+
-+	CFLAGS="${saved_CFLAGS}"
-+	LIBS="${saved_LIBS}"
-+
-+	AC_DEFINE([ENABLE_CRYPTO_WOLFSSL], [1], [Use wolfSSL crypto library])
-+	AC_DEFINE([ENABLE_CRYPTO_OPENSSL], [1], [Use wolfSSL openssl compatibility layer])
-+	CRYPTO_CFLAGS="${WOLFSSL_CFLAGS}"
-+	CRYPTO_LIBS="${WOLFSSL_LIBS}"
- else
- 	AC_MSG_ERROR([Invalid crypto library: ${with_crypto_library}])
- fi
---- a/src/openvpn/syshead.h
-+++ b/src/openvpn/syshead.h
-@@ -582,7 +582,8 @@ socket_defined(const socket_descriptor_t
- /*
-  * Do we have CryptoAPI capability?
-  */
--#if defined(_WIN32) && defined(ENABLE_CRYPTO_OPENSSL)
-+#if defined(_WIN32) && defined(ENABLE_CRYPTO_OPENSSL) && \
-+	!defined(ENABLE_CRYPTO_WOLFSSL)
- #define ENABLE_CRYPTOAPI
- #endif
- 
diff --git a/feeds/packages/net/openvpn/patches/100-mbedtls-disable-runtime-version-check.patch b/feeds/packages/net/openvpn/patches/100-mbedtls-disable-runtime-version-check.patch
index 42665db872030..c54277006d067 100644
--- a/feeds/packages/net/openvpn/patches/100-mbedtls-disable-runtime-version-check.patch
+++ b/feeds/packages/net/openvpn/patches/100-mbedtls-disable-runtime-version-check.patch
@@ -1,6 +1,6 @@
 --- a/src/openvpn/ssl_mbedtls.c
 +++ b/src/openvpn/ssl_mbedtls.c
-@@ -1539,7 +1539,7 @@ const char *
+@@ -1612,7 +1612,7 @@ const char *
  get_ssl_library_version(void)
  {
      static char mbedtls_version[30];
diff --git a/feeds/packages/net/openvpn/patches/101-Fix-EVP_PKEY_CTX_-compilation-with-wolfSSL.patch b/feeds/packages/net/openvpn/patches/101-Fix-EVP_PKEY_CTX_-compilation-with-wolfSSL.patch
new file mode 100644
index 0000000000000..81c09c1e89c59
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/101-Fix-EVP_PKEY_CTX_-compilation-with-wolfSSL.patch
@@ -0,0 +1,20 @@
+--- a/src/openvpn/crypto_openssl.c
++++ b/src/openvpn/crypto_openssl.c
+@@ -49,7 +49,7 @@
+ #include <openssl/rand.h>
+ #include <openssl/ssl.h>
+ 
+-#if (OPENSSL_VERSION_NUMBER >= 0x10100000L) && !defined(LIBRESSL_VERSION_NUMBER)
++#if (OPENSSL_VERSION_NUMBER >= 0x10100000L) && !defined(ENABLE_CRYPTO_WOLFSSL) && !defined(LIBRESSL_VERSION_NUMBER)
+ #include <openssl/kdf.h>
+ #endif
+ #if OPENSSL_VERSION_NUMBER >= 0x30000000L
+@@ -1374,7 +1374,7 @@ memcmp_constant_time(const void *a, cons
+     return CRYPTO_memcmp(a, b, size);
+ }
+ 
+-#if (OPENSSL_VERSION_NUMBER >= 0x10100000L) && !defined(LIBRESSL_VERSION_NUMBER)
++#if (OPENSSL_VERSION_NUMBER >= 0x10100000L) && !defined(ENABLE_CRYPTO_WOLFSSL) && !defined(LIBRESSL_VERSION_NUMBER)
+ bool
+ ssl_tls1_PRF(const uint8_t *seed, int seed_len, const uint8_t *secret,
+              int secret_len, uint8_t *output, int output_len)
diff --git a/feeds/packages/net/openvpn/patches/102-Disable-external-ec-key-support-when-building-with-wolfSSL.patch b/feeds/packages/net/openvpn/patches/102-Disable-external-ec-key-support-when-building-with-wolfSSL.patch
new file mode 100644
index 0000000000000..f0e7361f2565b
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/102-Disable-external-ec-key-support-when-building-with-wolfSSL.patch
@@ -0,0 +1,20 @@
+--- a/src/openvpn/ssl_openssl.c
++++ b/src/openvpn/ssl_openssl.c
+@@ -1347,7 +1347,7 @@ err:
+     return 0;
+ }
+ 
+-#if OPENSSL_VERSION_NUMBER > 0x10100000L && !defined(OPENSSL_NO_EC)
++#if OPENSSL_VERSION_NUMBER > 0x10100000L && !defined(OPENSSL_NO_EC) && !defined(ENABLE_CRYPTO_WOLFSSL)
+ 
+ /* called when EC_KEY is destroyed */
+ static void
+@@ -1508,7 +1508,7 @@ tls_ctx_use_management_external_key(stru
+             goto cleanup;
+         }
+     }
+-#if (OPENSSL_VERSION_NUMBER > 0x10100000L) && !defined(OPENSSL_NO_EC)
++#if (OPENSSL_VERSION_NUMBER > 0x10100000L) && !defined(OPENSSL_NO_EC) && !defined(ENABLE_CRYPTO_WOLFSSL)
+ #if OPENSSL_VERSION_NUMBER < 0x30000000L
+     else if (EVP_PKEY_id(pkey) == EVP_PKEY_EC)
+ #else /* OPENSSL_VERSION_NUMBER < 0x30000000L */
diff --git a/feeds/packages/net/openvpn/patches/103-define-LN_serialNumber-for-wolfSSL.patch b/feeds/packages/net/openvpn/patches/103-define-LN_serialNumber-for-wolfSSL.patch
new file mode 100644
index 0000000000000..30e1822a1ce2a
--- /dev/null
+++ b/feeds/packages/net/openvpn/patches/103-define-LN_serialNumber-for-wolfSSL.patch
@@ -0,0 +1,12 @@
+--- a/src/openvpn/ssl_verify_openssl.c
++++ b/src/openvpn/ssl_verify_openssl.c
+@@ -267,6 +267,9 @@ backend_x509_get_username(char *common_n
+             return FAILURE;
+         }
+     }
++#if defined(ENABLE_CRYPTO_WOLFSSL)
++ #define LN_serialNumber "serialNumber"
++#endif
+     else if (strcmp(LN_serialNumber, x509_username_field) == 0)
+     {
+         ASN1_INTEGER *asn1_i = X509_get_serialNumber(peer_cert);
diff --git a/feeds/packages/net/openvpn/patches/210-build_always_use_internal_lz4.patch b/feeds/packages/net/openvpn/patches/210-build_always_use_internal_lz4.patch
deleted file mode 100644
index b5f675adec8eb..0000000000000
--- a/feeds/packages/net/openvpn/patches/210-build_always_use_internal_lz4.patch
+++ /dev/null
@@ -1,74 +0,0 @@
---- a/configure.ac
-+++ b/configure.ac
-@@ -1211,68 +1211,15 @@ dnl
- AC_ARG_VAR([LZ4_CFLAGS], [C compiler flags for lz4])
- AC_ARG_VAR([LZ4_LIBS], [linker flags for lz4])
- if test "$enable_lz4" = "yes" && test "$enable_comp_stub" = "no"; then
--    if test -z "${LZ4_CFLAGS}" -a -z "${LZ4_LIBS}"; then
--	# if the user did not explicitly specify flags, try to autodetect
--	PKG_CHECK_MODULES([LZ4],
--			  [liblz4 >= 1.7.1 liblz4 < 100],
--			  [have_lz4="yes"],
--			  [LZ4_LIBS="-llz4"] # If this fails, we will do another test next.
--					     # We also add set LZ4_LIBS otherwise the
--					     # linker will not know about the lz4 library
--	)
--    fi
- 
-     saved_CFLAGS="${CFLAGS}"
-     saved_LIBS="${LIBS}"
-     CFLAGS="${CFLAGS} ${LZ4_CFLAGS}"
-     LIBS="${LIBS} ${LZ4_LIBS}"
- 
--    # If pkgconfig check failed or LZ4_CFLAGS/LZ4_LIBS env vars
--    # are used, check the version directly in the LZ4 include file
--    if test "${have_lz4}" != "yes"; then
--	AC_CHECK_HEADERS([lz4.h],
--			 [have_lz4h="yes"],
--			 [])
--
--	if test "${have_lz4h}" = "yes" ; then
--	    AC_MSG_CHECKING([additionally if system LZ4 version >= 1.7.1])
--	    AC_COMPILE_IFELSE(
--		[AC_LANG_PROGRAM([[
--#include <lz4.h>
--				 ]],
--				 [[
--/* Version encoding: MMNNPP (Major miNor Patch) - see lz4.h for details */
--#if LZ4_VERSION_NUMBER < 10701L
--#error LZ4 is too old
--#endif
--				 ]]
--				)],
--		[
--		    AC_MSG_RESULT([ok])
--		    have_lz4="yes"
--		],
--		[AC_MSG_RESULT([system LZ4 library is too old])]
--	    )
--	fi
--    fi
--
--    # Double check we have a few needed functions
--    if test "${have_lz4}" = "yes" ; then
--	AC_CHECK_LIB([lz4],
--		     [LZ4_compress_default],
--		     [],
--		     [have_lz4="no"])
--	AC_CHECK_LIB([lz4],
--		     [LZ4_decompress_safe],
--		     [],
--		     [have_lz4="no"])
--    fi
--
--    if test "${have_lz4}" != "yes" ; then
--	AC_MSG_RESULT([		usable LZ4 library or header not found, using version in src/compat/compat-lz4.*])
--	AC_DEFINE([NEED_COMPAT_LZ4], [1], [use copy of LZ4 source in compat/])
--	LZ4_LIBS=""
--    fi
-+    AC_MSG_RESULT([		usable LZ4 library or header not found, using version in src/compat/compat-lz4.*])
-+    AC_DEFINE([NEED_COMPAT_LZ4], [1], [use copy of LZ4 source in compat/])
-+    LZ4_LIBS=""
-     OPTIONAL_LZ4_CFLAGS="${LZ4_CFLAGS}"
-     OPTIONAL_LZ4_LIBS="${LZ4_LIBS}"
-     AC_DEFINE(ENABLE_LZ4, [1], [Enable LZ4 compression library])
diff --git a/feeds/packages/net/openvpn/patches/220-disable_des.patch b/feeds/packages/net/openvpn/patches/220-disable_des.patch
deleted file mode 100644
index a49c463c4d6ab..0000000000000
--- a/feeds/packages/net/openvpn/patches/220-disable_des.patch
+++ /dev/null
@@ -1,74 +0,0 @@
---- a/src/openvpn/syshead.h
-+++ b/src/openvpn/syshead.h
-@@ -572,7 +572,7 @@ socket_defined(const socket_descriptor_t
- /*
-  * Should we include NTLM proxy functionality
-  */
--#define NTLM 1
-+//#define NTLM 1
- 
- /*
-  * Should we include proxy digest auth functionality
---- a/src/openvpn/crypto_mbedtls.c
-+++ b/src/openvpn/crypto_mbedtls.c
-@@ -396,6 +396,7 @@ int
- key_des_num_cblocks(const mbedtls_cipher_info_t *kt)
- {
-     int ret = 0;
-+#ifdef MBEDTLS_DES_C
-     if (kt->type == MBEDTLS_CIPHER_DES_CBC)
-     {
-         ret = 1;
-@@ -408,6 +409,7 @@ key_des_num_cblocks(const mbedtls_cipher
-     {
-         ret = 3;
-     }
-+#endif
- 
-     dmsg(D_CRYPTO_DEBUG, "CRYPTO INFO: n_DES_cblocks=%d", ret);
-     return ret;
-@@ -416,6 +418,7 @@ key_des_num_cblocks(const mbedtls_cipher
- bool
- key_des_check(uint8_t *key, int key_len, int ndc)
- {
-+#ifdef MBEDTLS_DES_C
-     int i;
-     struct buffer b;
- 
-@@ -444,11 +447,15 @@ key_des_check(uint8_t *key, int key_len,
- 
- err:
-     return false;
-+#else
-+    return true;
-+#endif
- }
- 
- void
- key_des_fixup(uint8_t *key, int key_len, int ndc)
- {
-+#ifdef MBEDTLS_DES_C
-     int i;
-     struct buffer b;
- 
-@@ -463,6 +470,7 @@ key_des_fixup(uint8_t *key, int key_len,
-         }
-         mbedtls_des_key_set_parity(key);
-     }
-+#endif
- }
- 
- /*
-@@ -783,10 +791,12 @@ cipher_des_encrypt_ecb(const unsigned ch
-                        unsigned char *src,
-                        unsigned char *dst)
- {
-+#ifdef MBEDTLS_DES_C
-     mbedtls_des_context ctx;
- 
-     ASSERT(mbed_ok(mbedtls_des_setkey_enc(&ctx, key)));
-     ASSERT(mbed_ok(mbedtls_des_crypt_ecb(&ctx, src, dst)));
-+#endif
- }
- 
- 
diff --git a/feeds/packages/net/openvpn/files/openvpn.init b/feeds/packages/net/openvpn/files/openvpn.init
index de0f85aa05c72e..643c323e739dfa 100644
--- a/feeds/packages/net/openvpn/files/openvpn.init
+++ b/feeds/packages/net/openvpn/files/openvpn.init
@@ -154,17 +154,24 @@ openvpn_add_instance() {
 		--syslog "openvpn($name)" \
 		--status "/var/run/openvpn.$name.status" \
 		--cd "$dir" \
-		--config "$conf" \
-		--up "/usr/libexec/openvpn-hotplug up $name" \
-		--down "/usr/libexec/openvpn-hotplug down $name" \
-		--route-up "/usr/libexec/openvpn-hotplug route-up $name" \
-		--route-pre-down "/usr/libexec/openvpn-hotplug route-pre-down $name" \
-		${client:+--ipchange "/usr/libexec/openvpn-hotplug ipchange $name"} \
-		${up:+--setenv user_up "$up"} \
-		${down:+--setenv user_down "$down"} \
-		${route_up:+--setenv user_route_up "$route_up"} \
-		${route_pre_down:+--setenv user_route_pre_down "$route_pre_down"} \
-		${client:+${ipchange:+--setenv user_ipchange "$ipchange"}} \
+		--config "$conf"
+	# external scripts can only be called on script-security 2 or higher
+	if [ "${security:-2}" -lt 2 ]; then
+		logger -t "openvpn(${name})" "not adding hotplug scripts due to script-security ${security:-2}"
+	else
+		procd_append_param command \
+			--up "/usr/libexec/openvpn-hotplug up $name" \
+			--down "/usr/libexec/openvpn-hotplug down $name" \
+			--route-up "/usr/libexec/openvpn-hotplug route-up $name" \
+			--route-pre-down "/usr/libexec/openvpn-hotplug route-pre-down $name" \
+			${client:+--ipchange "/usr/libexec/openvpn-hotplug ipchange $name"} \
+			${up:+--setenv user_up "$up"} \
+			${down:+--setenv user_down "$down"} \
+			${route_up:+--setenv user_route_up "$route_up"} \
+			${route_pre_down:+--setenv user_route_pre_down "$route_pre_down"} \
+			${client:+${ipchange:+--setenv user_ipchange "$ipchange"}}
+	fi
+	procd_append_param command \
 		--script-security "${security:-2}" \
 		$(openvpn_get_dev "$name" "$conf") \
 		$(openvpn_get_credentials "$name" "$conf")
