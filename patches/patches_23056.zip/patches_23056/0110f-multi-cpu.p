diff --git a/feeds/packages/kernel/ovpn-dco/patches/0002-multi-cpu.patch b/feeds/packages/kernel/ovpn-dco/patches/0002-multi-cpu.patch
new file mode 100644
index 0000000..c2b0cab
--- /dev/null
+++ b/feeds/packages/kernel/ovpn-dco/patches/0002-multi-cpu.patch
@@ -0,0 +1,189 @@
+From bf4c3d96dd48bdcef012036c20d77531b84a68a1 Mon Sep 17 00:00:00 2001
+From: Ilia Ponetaev <ilia.ponetaev@keenetic.com>
+Date: Wed, 6 Nov 2024 12:08:13 +0300
+Subject: [PATCH] add multi-cpu processing mode
+
+---
+ drivers/net/ovpn-dco/ovpn.c | 18 +++++++++++-------
+ drivers/net/ovpn-dco/peer.c | 33 +++++++++++++++++++++++++++++----
+ drivers/net/ovpn-dco/peer.h | 21 +++++++++++++++++++--
+ 3 files changed, 59 insertions(+), 13 deletions(-)
+
+diff --git a/drivers/net/ovpn-dco/ovpn.c b/drivers/net/ovpn-dco/ovpn.c
+index f5fa750..2c16988 100644
+--- a/drivers/net/ovpn-dco/ovpn.c
++++ b/drivers/net/ovpn-dco/ovpn.c
+@@ -160,10 +160,12 @@ int ovpn_napi_poll(struct napi_struct *napi, int budget)
+  */
+ int ovpn_recv(struct ovpn_struct *ovpn, struct ovpn_peer *peer, struct sk_buff *skb)
+ {
++	const int cpu = ovpn_peer_cpumask_next_online(&peer->last_cpu_decrypt);
++
+ 	if (unlikely(ptr_ring_produce_bh(&peer->rx_ring, skb) < 0))
+ 		return -ENOSPC;
+ 
+-	if (!queue_work(ovpn->crypto_wq, &peer->decrypt_work))
++	if (!queue_work_on(cpu, ovpn->crypto_wq, &per_cpu_ptr(peer->packet_decrypt_work, cpu)->work))
+ 		ovpn_peer_put(peer);
+ 
+ 	return 0;
+@@ -295,10 +297,10 @@ static int ovpn_decrypt_one(struct ovpn_peer *peer, struct sk_buff *skb)
+ /* pick packet from RX queue, decrypt and forward it to the tun device */
+ void ovpn_decrypt_work(struct work_struct *work)
+ {
+-	struct ovpn_peer *peer;
++	struct ovpn_peer *peer = container_of(work, struct multicore_worker,
++						 work)->ptr;
+ 	struct sk_buff *skb;
+ 
+-	peer = container_of(work, struct ovpn_peer, decrypt_work);
+ 	while ((skb = ptr_ring_consume_bh(&peer->rx_ring))) {
+ 		if (likely(ovpn_decrypt_one(peer, skb) == 0)) {
+ 			/* if a packet has been enqueued for NAPI, signal
+@@ -377,9 +379,9 @@ static bool ovpn_encrypt_one(struct ovpn_peer *peer, struct sk_buff *skb)
+ void ovpn_encrypt_work(struct work_struct *work)
+ {
+ 	struct sk_buff *skb, *curr, *next;
+-	struct ovpn_peer *peer;
++	struct ovpn_peer *peer = container_of(work, struct multicore_worker,
++						 work)->ptr;
+ 
+-	peer = container_of(work, struct ovpn_peer, encrypt_work);
+ 	while ((skb = ptr_ring_consume_bh(&peer->tx_ring))) {
+ 		/* this might be a GSO-segmented skb list: process each skb
+ 		 * independently
+@@ -428,7 +430,7 @@ void ovpn_encrypt_work(struct work_struct *work)
+ /* Put skb into TX queue and schedule a consumer */
+ static void ovpn_queue_skb(struct ovpn_struct *ovpn, struct sk_buff *skb, struct ovpn_peer *peer)
+ {
+-	int ret;
++	int ret, cpu;
+ 
+ 	if (likely(!peer))
+ 		peer = ovpn_peer_lookup_vpn_addr(ovpn, skb, false);
+@@ -443,7 +445,9 @@ static void ovpn_queue_skb(struct ovpn_struct *ovpn, struct sk_buff *skb, struct
+ 		goto drop;
+ 	}
+ 
+-	if (!queue_work(ovpn->crypto_wq, &peer->encrypt_work))
++	cpu = ovpn_peer_cpumask_next_online(&peer->last_cpu_encrypt);
++
++	if (!queue_work_on(cpu, ovpn->crypto_wq, &per_cpu_ptr(peer->packet_encrypt_work, cpu)->work))
+ 		ovpn_peer_put(peer);
+ 
+ 	return;
+diff --git a/drivers/net/ovpn-dco/peer.c b/drivers/net/ovpn-dco/peer.c
+index 9378d19..35b2c9d 100644
+--- a/drivers/net/ovpn-dco/peer.c
++++ b/drivers/net/ovpn-dco/peer.c
+@@ -42,7 +42,7 @@ static void ovpn_peer_expire(struct timer_list *t)
+ static struct ovpn_peer *ovpn_peer_create(struct ovpn_struct *ovpn, u32 id)
+ {
+ 	struct ovpn_peer *peer;
+-	int ret;
++	int ret, cpu;
+ 
+ 	/* alloc and init peer object */
+ 	peer = kzalloc(sizeof(*peer), GFP_KERNEL);
+@@ -63,13 +63,31 @@ static struct ovpn_peer *ovpn_peer_create(struct ovpn_struct *ovpn, u32 id)
+ 	ovpn_peer_stats_init(&peer->vpn_stats);
+ 	ovpn_peer_stats_init(&peer->link_stats);
+ 
+-	INIT_WORK(&peer->encrypt_work, ovpn_encrypt_work);
+-	INIT_WORK(&peer->decrypt_work, ovpn_decrypt_work);
++	peer->packet_encrypt_work = alloc_percpu(struct multicore_worker);
++
++	if (!peer->packet_encrypt_work) {
++		netdev_err(ovpn->dev, "%s: cannot allocate encrypt work\n", __func__);
++		goto err;
++	}
++
++	peer->packet_decrypt_work = alloc_percpu(struct multicore_worker);
++
++	if (!peer->packet_decrypt_work) {
++		netdev_err(ovpn->dev, "%s: cannot allocate decrypt work\n", __func__);
++		goto err_enc_work;
++	}
++
++	for_each_possible_cpu(cpu) {
++		per_cpu_ptr(peer->packet_encrypt_work, cpu)->ptr = peer;
++		per_cpu_ptr(peer->packet_decrypt_work, cpu)->ptr = peer;
++		INIT_WORK(&per_cpu_ptr(peer->packet_encrypt_work, cpu)->work, ovpn_encrypt_work);
++		INIT_WORK(&per_cpu_ptr(peer->packet_decrypt_work, cpu)->work, ovpn_decrypt_work);
++	}
+ 
+ 	ret = dst_cache_init(&peer->dst_cache, GFP_KERNEL);
+ 	if (ret < 0) {
+ 		netdev_err(ovpn->dev, "%s: cannot initialize dst cache\n", __func__);
+-		goto err;
++		goto err_dec_work;
+ 	}
+ 
+ 	ret = ptr_ring_init(&peer->tx_ring, OVPN_QUEUE_LEN, GFP_KERNEL);
+@@ -107,6 +125,10 @@ static struct ovpn_peer *ovpn_peer_create(struct ovpn_struct *ovpn, u32 id)
+ 	ptr_ring_cleanup(&peer->tx_ring, NULL);
+ err_dst_cache:
+ 	dst_cache_destroy(&peer->dst_cache);
++err_dec_work:
++	free_percpu(peer->packet_decrypt_work);
++err_enc_work:
++	free_percpu(peer->packet_encrypt_work);
+ err:
+ 	kfree(peer);
+ 	return ERR_PTR(ret);
+@@ -202,6 +224,9 @@ static void ovpn_peer_free(struct ovpn_peer *peer)
+ 	ovpn_bind_reset(peer, NULL);
+ 	ovpn_peer_timer_delete_all(peer);
+ 
++	free_percpu(peer->packet_decrypt_work);
++	free_percpu(peer->packet_encrypt_work);
++
+ 	WARN_ON(!__ptr_ring_empty(&peer->tx_ring));
+ 	ptr_ring_cleanup(&peer->tx_ring, NULL);
+ 	WARN_ON(!__ptr_ring_empty(&peer->rx_ring));
+diff --git a/drivers/net/ovpn-dco/peer.h b/drivers/net/ovpn-dco/peer.h
+index b66b1dd..a069e60 100644
+--- a/drivers/net/ovpn-dco/peer.h
++++ b/drivers/net/ovpn-dco/peer.h
+@@ -19,6 +19,11 @@
+ #include <linux/ptr_ring.h>
+ #include <net/dst_cache.h>
+ 
++struct multicore_worker {
++	void *ptr;
++	struct work_struct work;
++};
++
+ struct ovpn_peer {
+ 	struct ovpn_struct *ovpn;
+ 
+@@ -37,8 +42,10 @@ struct ovpn_peer {
+ 	/* work objects to handle encryption/decryption of packets.
+ 	 * these works are queued on the ovpn->crypt_wq workqueue.
+ 	 */
+-	struct work_struct encrypt_work;
+-	struct work_struct decrypt_work;
++	struct multicore_worker __percpu *packet_encrypt_work;
++	struct multicore_worker __percpu *packet_decrypt_work;
++	int last_cpu_encrypt;
++	int last_cpu_decrypt;
+ 
+ 	struct ptr_ring tx_ring;
+ 	struct ptr_ring rx_ring;
+@@ -152,6 +159,16 @@ static inline void ovpn_peer_keepalive_xmit_reset(struct ovpn_peer *peer)
+ 	mod_timer(&peer->keepalive_xmit, jiffies + delta);
+ }
+ 
++static inline int ovpn_peer_cpumask_next_online(int *next)
++{
++	int cpu = *next;
++
++	while (unlikely(!cpumask_test_cpu(cpu, cpu_online_mask)))
++		cpu = cpumask_next(cpu, cpu_online_mask) % nr_cpumask_bits;
++	*next = cpumask_next(cpu, cpu_online_mask) % nr_cpumask_bits;
++	return cpu;
++}
++
+ struct ovpn_peer *ovpn_peer_new(struct ovpn_struct *ovpn, const struct sockaddr_storage *sa,
+ 				struct socket *sock, u32 id, uint8_t *local_ip);
+ 
-- 
2.46.2.windows.1

