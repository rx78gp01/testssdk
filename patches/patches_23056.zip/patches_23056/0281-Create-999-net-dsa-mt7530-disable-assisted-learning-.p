From c5d7ac12690120dbb529bd427f7e0c572fd7684b Mon Sep 17 00:00:00 2001
From: Rany Hany <rany_hany@riseup.net>
Date: Sat, 1 Feb 2025 09:54:32 +0000
Subject: [PATCH] generic: 5.15: add patch to fix fdb learning bug in mt7530

As mt7530 switch is used in mt7621 and mt7622 target, we need
to apply this patch to generic. This patch was initially shared
in the OpenWRT bug report[1] reporting this issue and it does
work in my testing. The source for the updated patch I used is [2].

[1]: https://github.com/openwrt/openwrt/issues/9706#issuecomment-1098774526
[2]: https://github.com/openwrt/openwrt/issues/11650#issuecomment-2626024289

---
 ...isable-assisted-learning-on-cpu-port.patch | 52 +++++++++++++++++++
 1 file changed, 52 insertions(+)
 create mode 100644 target/linux/generic/hack-5.15/999-net-dsa-mt7530-disable-assisted-learning-on-cpu-port.patch

diff --git a/target/linux/generic/hack-5.15/999-net-dsa-mt7530-disable-assisted-learning-on-cpu-port.patch b/target/linux/generic/hack-5.15/999-net-dsa-mt7530-disable-assisted-learning-on-cpu-port.patch
new file mode 100644
index 0000000..68df572
--- /dev/null
+++ b/target/linux/generic/hack-5.15/999-net-dsa-mt7530-disable-assisted-learning-on-cpu-port.patch
@@ -0,0 +1,52 @@
+--- a/drivers/net/dsa/mt7530.c
++++ b/drivers/net/dsa/mt7530.c
+@@ -1164,11 +1164,11 @@ mt7530_port_bridge_flags(struct dsa_swit
+ 			 struct netlink_ext_ack *extack)
+ {
+ 	struct mt7530_priv *priv = ds->priv;
+-
++#if 0
+ 	if (flags.mask & BR_LEARNING)
+ 		mt7530_rmw(priv, MT7530_PSC_P(port), SA_DIS,
+ 			   flags.val & BR_LEARNING ? 0 : SA_DIS);
+-
++#endif
+ 	if (flags.mask & BR_FLOOD)
+ 		mt7530_rmw(priv, MT7530_MFC, UNU_FFP(BIT(port)),
+ 			   flags.val & BR_FLOOD ? UNU_FFP(BIT(port)) : 0);
+@@ -2093,7 +2093,7 @@ mt7530_setup(struct dsa_switch *ds)
+ 		return -EINVAL;
+ 	}
+ 
+-	ds->assisted_learning_on_cpu_port = true;
++	//ds->assisted_learning_on_cpu_port = true;
+ 	ds->mtu_enforcement_ingress = true;
+ 
+ 	if (priv->id == ID_MT7530) {
+@@ -2165,7 +2165,7 @@ mt7530_setup(struct dsa_switch *ds)
+ 			   PCR_MATRIX_CLR);
+ 
+ 		/* Disable learning by default on all ports */
+-		mt7530_set(priv, MT7530_PSC_P(i), SA_DIS);
++		//mt7530_set(priv, MT7530_PSC_P(i), SA_DIS);
+ 
+ 		if (dsa_is_cpu_port(ds, i)) {
+ 			ret = mt753x_cpu_port_enable(ds, i);
+@@ -2339,7 +2339,7 @@ mt7531_setup(struct dsa_switch *ds)
+ 			   PCR_MATRIX_CLR);
+ 
+ 		/* Disable learning by default on all ports */
+-		mt7530_set(priv, MT7530_PSC_P(i), SA_DIS);
++		//mt7530_set(priv, MT7530_PSC_P(i), SA_DIS);
+ 
+ 		mt7530_set(priv, MT7531_DBG_CNT(i), MT7531_DIS_CLR);
+ 
+@@ -2365,7 +2365,7 @@ mt7531_setup(struct dsa_switch *ds)
+ 	if (ret)
+ 		return ret;
+ 
+-	ds->assisted_learning_on_cpu_port = true;
++	//ds->assisted_learning_on_cpu_port = true;
+ 	ds->mtu_enforcement_ingress = true;
+ 
+ 	/* Flush the FDB table */
-- 
2.46.2.windows.1

