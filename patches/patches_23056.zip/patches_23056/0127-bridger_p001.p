diff --git a/package/network/services/bridger/patches/001.patch b/package/network/services/bridger/patches/001.patch
new file mode 100644
index 0000000..183f47a
--- /dev/null
+++ b/package/network/services/bridger/patches/001.patch
@@ -0,0 +1,23 @@
+From f6afcb04f2ef1af2677ce0b1e136118c4d4dd764 Mon Sep 17 00:00:00 2001
+From: Felix Fietkau <nbd@nbd.name>
+Date: Mon, 1 Sep 2025 19:39:27 +0200
+Subject: [PATCH] nl: add missing dump flag for RTM_GETTFILTER
+
+Signed-off-by: Felix Fietkau <nbd@nbd.name>
+---
+ nl.c | 2 ++
+ 1 file changed, 2 insertions(+)
+
+diff --git a/nl.c b/nl.c
+index b64b32d..e5e22e9 100644
+--- a/nl.c
++++ b/nl.c
+@@ -576,6 +576,8 @@ bridger_nl_flow_offload_msg(struct bridger_flow *flow, int ifindex, int cmd)
+ 
+ 	if (cmd == RTM_NEWTFILTER)
+ 		flags |= NLM_F_CREATE | NLM_F_EXCL;
++	else if (cmd == RTM_GETTFILTER)
++		flags |= NLM_F_DUMP;
+ 
+ 	msg = nlmsg_alloc_simple(cmd, flags);
+ 	nlmsg_append(msg, &tcmsg, sizeof(tcmsg), NLMSG_ALIGNTO);
-- 
2.46.2.windows.1

