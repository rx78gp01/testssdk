diff --git a/target/linux/generic/backport-5.15/895-v6.15-0006.patch b/target/linux/generic/backport-5.15/895-v6.15-0006.patch
new file mode 100644
index 0000000..d27dc75
--- /dev/null
+++ b/target/linux/generic/backport-5.15/895-v6.15-0006.patch
@@ -0,0 +1,92 @@
+From 890a5d423ef0a7bd13447ceaffad21189f557301 Mon Sep 17 00:00:00 2001
+From: William Liu <will@willsroot.io>
+Date: Thu, 17 Jul 2025 02:28:38 +0000
+Subject: [PATCH] net/sched: Return NULL when htb_lookup_leaf encounters an
+ empty rbtree
+
+[ Upstream commit 0e1d5d9b5c5966e2e42e298670808590db5ed628 ]
+
+htb_lookup_leaf has a BUG_ON that can trigger with the following:
+
+tc qdisc del dev lo root
+tc qdisc add dev lo root handle 1: htb default 1
+tc class add dev lo parent 1: classid 1:1 htb rate 64bit
+tc qdisc add dev lo parent 1:1 handle 2: netem
+tc qdisc add dev lo parent 2:1 handle 3: blackhole
+ping -I lo -c1 -W0.001 127.0.0.1
+
+The root cause is the following:
+
+1. htb_dequeue calls htb_dequeue_tree which calls the dequeue handler on
+   the selected leaf qdisc
+2. netem_dequeue calls enqueue on the child qdisc
+3. blackhole_enqueue drops the packet and returns a value that is not
+   just NET_XMIT_SUCCESS
+4. Because of this, netem_dequeue calls qdisc_tree_reduce_backlog, and
+   since qlen is now 0, it calls htb_qlen_notify -> htb_deactivate ->
+   htb_deactiviate_prios -> htb_remove_class_from_row -> htb_safe_rb_erase
+5. As this is the only class in the selected hprio rbtree,
+   __rb_change_child in __rb_erase_augmented sets the rb_root pointer to
+   NULL
+6. Because blackhole_dequeue returns NULL, netem_dequeue returns NULL,
+   which causes htb_dequeue_tree to call htb_lookup_leaf with the same
+   hprio rbtree, and fail the BUG_ON
+
+The function graph for this scenario is shown here:
+ 0)               |  htb_enqueue() {
+ 0) + 13.635 us   |    netem_enqueue();
+ 0)   4.719 us    |    htb_activate_prios();
+ 0) # 2249.199 us |  }
+ 0)               |  htb_dequeue() {
+ 0)   2.355 us    |    htb_lookup_leaf();
+ 0)               |    netem_dequeue() {
+ 0) + 11.061 us   |      blackhole_enqueue();
+ 0)               |      qdisc_tree_reduce_backlog() {
+ 0)               |        qdisc_lookup_rcu() {
+ 0)   1.873 us    |          qdisc_match_from_root();
+ 0)   6.292 us    |        }
+ 0)   1.894 us    |        htb_search();
+ 0)               |        htb_qlen_notify() {
+ 0)   2.655 us    |          htb_deactivate_prios();
+ 0)   6.933 us    |        }
+ 0) + 25.227 us   |      }
+ 0)   1.983 us    |      blackhole_dequeue();
+ 0) + 86.553 us   |    }
+ 0) # 2932.761 us |    qdisc_warn_nonwc();
+ 0)               |    htb_lookup_leaf() {
+ 0)               |      BUG_ON();
+ ------------------------------------------
+
+The full original bug report can be seen here [1].
+
+We can fix this just by returning NULL instead of the BUG_ON,
+as htb_dequeue_tree returns NULL when htb_lookup_leaf returns
+NULL.
+
+[1] https://lore.kernel.org/netdev/pF5XOOIim0IuEfhI-SOxTgRvNoDwuux7UHKnE_Y5-zVd4wmGvNk2ceHjKb8ORnzw0cGwfmVu42g9dL7XyJLf1NEzaztboTWcm0Ogxuojoeo=@willsroot.io/
+
+Fixes: 512bb43eb542 ("pkt_sched: sch_htb: Optimize WARN_ONs in htb_dequeue_tree() etc.")
+Signed-off-by: William Liu <will@willsroot.io>
+Signed-off-by: Savino Dicanosa <savy@syst3mfailure.io>
+Link: https://patch.msgid.link/20250717022816.221364-1-will@willsroot.io
+Signed-off-by: Jakub Kicinski <kuba@kernel.org>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/sched/sch_htb.c | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/net/sched/sch_htb.c b/net/sched/sch_htb.c
+index 29f394fe39987..1e19d3ffbf219 100644
+--- a/net/sched/sch_htb.c
++++ b/net/sched/sch_htb.c
+@@ -818,7 +818,9 @@ static struct htb_class *htb_lookup_leaf(struct htb_prio *hprio, const int prio)
+ 		u32 *pid;
+ 	} stk[TC_HTB_MAXDEPTH], *sp = stk;
+ 
+-	BUG_ON(!hprio->row.rb_node);
++	if (unlikely(!hprio->row.rb_node))
++		return NULL;
++
+ 	sp->root = hprio->row.rb_node;
+ 	sp->pptr = &hprio->ptr;
+ 	sp->pid = &hprio->last_ptr_id;
-- 
2.46.2.windows.1

