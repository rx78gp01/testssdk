diff --git a/package/network/config/firewall4/patches/0001-Revert-fw4-perform-strict-validation-of-zone-and-set.patch b/package/network/config/firewall4/patches/0001-Revert-fw4-perform-strict-validation-of-zone-and-set.patch
new file mode 100644
index 0000000..8117899
--- /dev/null
+++ b/package/network/config/firewall4/patches/0001-Revert-fw4-perform-strict-validation-of-zone-and-set.patch
@@ -0,0 +1,45 @@
+diff --git a/root/usr/share/ucode/fw4.uc b/root/usr/share/ucode/fw4.uc
+index 2d77146..f0fd55a 100644
+--- a/root/usr/share/ucode/fw4.uc
++++ b/root/usr/share/ucode/fw4.uc
+@@ -1596,10 +1596,6 @@ return {
+ 		]), "postpend", "append");
+ 	},
+ 
+-	parse_identifier: function(val) {
+-		return match(val, /^[a-zA-Z_.][a-zA-Z0-9\/_.-]*$/)?.[0];
+-	},
+-
+ 	parse_string: function(val) {
+ 		return "" + val;
+ 	},
+@@ -1987,7 +1983,7 @@ return {
+ 		let zone = this.parse_options(data, {
+ 			enabled: [ "bool", "1" ],
+ 
+-			name: [ "identifier", null, REQUIRED ],
++			name: [ "string", null, REQUIRED ],
+ 			family: [ "family" ],
+ 
+ 			network: [ "device", null, PARSE_LIST ],
+@@ -3214,7 +3210,7 @@ return {
+ 			reload: [ "bool", null, UNSUPPORTED ],
+ 
+ 			position: [ "includeposition" ],
+-			chain: [ "identifier" ]
++			chain: [ "string" ]
+ 		});
+ 
+ 		if (!inc.enabled) {
+@@ -3276,7 +3272,7 @@ return {
+ 			counters: [ "bool" ],
+ 			comment: [ "string" ],
+ 
+-			name: [ "identifier", null, REQUIRED ],
++			name: [ "string", null, REQUIRED ],
+ 			family: [ "family", "4" ],
+ 
+ 			storage: [ "string", null, UNSUPPORTED ],
+-- 
+2.38.1.windows.1
+
-- 
2.38.1.windows.1

