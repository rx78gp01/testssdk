diff --git a/package/libs/openssl/patches/500-e_devcrypto-default-to-not-use-digests-in-engine.patch b/package/libs/openssl/patches/500-e_devcrypto-default-to-not-use-digests-in-engine.patch
index f183263..18075c0 100644
--- a/package/libs/openssl/patches/500-e_devcrypto-default-to-not-use-digests-in-engine.patch
+++ b/package/libs/openssl/patches/500-e_devcrypto-default-to-not-use-digests-in-engine.patch
@@ -23,7 +23,7 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
 +++ b/engines/e_devcrypto.c
 @@ -905,7 +905,7 @@ static void prepare_digest_methods(void)
      for (i = 0, known_digest_nids_amount = 0; i < OSSL_NELEM(digest_data);
-          i++) {
+         i++) {
  
 -        selected_digests[i] = 1;
 +        selected_digests[i] = 0;
@@ -32,10 +32,10 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
           * Check that the digest is usable
 @@ -1119,7 +1119,7 @@ static const ENGINE_CMD_DEFN devcrypto_c
  #ifdef IMPLEMENT_DIGEST
-    {DEVCRYPTO_CMD_DIGESTS,
-     "DIGESTS",
--    "either ALL, NONE, or a comma-separated list of digests to enable [default=ALL]",
-+    "either ALL, NONE, or a comma-separated list of digests to enable [default=NONE]",
-     ENGINE_CMD_FLAG_STRING},
+     { DEVCRYPTO_CMD_DIGESTS,
+         "DIGESTS",
+-        "either ALL, NONE, or a comma-separated list of digests to enable [default=ALL]",
++        "either ALL, NONE, or a comma-separated list of digests to enable [default=NONE]",
+         ENGINE_CMD_FLAG_STRING },
  #endif
  
diff --git a/package/libs/openssl/patches/510-e_devcrypto-ignore-error-when-closing-session.patch b/package/libs/openssl/patches/510-e_devcrypto-ignore-error-when-closing-session.patch
index 40b1dc7..50327b8 100644
--- a/package/libs/openssl/patches/510-e_devcrypto-ignore-error-when-closing-session.patch
+++ b/package/libs/openssl/patches/510-e_devcrypto-ignore-error-when-closing-session.patch
@@ -10,12 +10,11 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
 
 --- a/engines/e_devcrypto.c
 +++ b/engines/e_devcrypto.c
-@@ -211,9 +211,8 @@ static int cipher_init(EVP_CIPHER_CTX *c
+@@ -211,8 +211,8 @@ static int cipher_init(EVP_CIPHER_CTX *c
      int ret;
  
      /* cleanup a previous session */
--    if (cipher_ctx->sess.ses != 0 &&
--        clean_devcrypto_session(&cipher_ctx->sess) == 0)
+-    if (cipher_ctx->sess.ses != 0 && clean_devcrypto_session(&cipher_ctx->sess) == 0)
 -        return 0;
 +    if (cipher_ctx->sess.ses != 0)
 +        clean_devcrypto_session(&cipher_ctx->sess);
-- 
2.46.2.windows.1

