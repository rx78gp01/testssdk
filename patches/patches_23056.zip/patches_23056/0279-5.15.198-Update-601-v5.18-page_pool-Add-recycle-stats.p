diff --git a/target/linux/generic/backport-5.15/601-v5.18-page_pool-Add-recycle-stats.patch b/target/linux/generic/backport-5.15/601-v5.18-page_pool-Add-recycle-stats.patch
index b425b78..9f3bcf5 100644
--- a/target/linux/generic/backport-5.15/601-v5.18-page_pool-Add-recycle-stats.patch
+++ b/target/linux/generic/backport-5.15/601-v5.18-page_pool-Add-recycle-stats.patch
@@ -83,10 +83,10 @@ Signed-off-by: David S. Miller <davem@davemloft.net>
  		return -ENOMEM;
  
 @@ -435,7 +448,12 @@ static bool page_pool_recycle_in_ring(st
- 	else
- 		ret = ptr_ring_produce_bh(&pool->ring, page);
+ 	ret = !__ptr_ring_produce(&pool->ring, page);
+ 	page_pool_producer_unlock(pool, in_softirq);
  
--	return (ret == 0) ? true : false;
+-	return ret;
 +	if (!ret) {
 +		recycle_stat_inc(pool, ring);
 +		return true;
-- 
2.46.2.windows.1

