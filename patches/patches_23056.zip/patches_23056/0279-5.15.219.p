diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .212
-LINUX_KERNEL_HASH-5.15.212 = c396aeebc90c7aecb7f7abdf504c19b372c9926eb0cf0e91f9f09d7d870b65fe
+LINUX_VERSION-5.15 = .219
+LINUX_KERNEL_HASH-5.15.219 = d04a4f798cc26f81170b5ecb27a3d8c8b4838f3aaf2a431b577043e2ead05ca4
