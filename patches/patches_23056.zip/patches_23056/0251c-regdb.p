From b1a8250c292ec964dd30325b4063bf40f6f3cad2 Mon Sep 17 00:00:00 2001
From: Hauke Mehrtens <hauke@hauke-m.de>
Date: Sun, 20 Jul 2025 17:46:05 +0200
Subject: [PATCH] wireless-regdb: Update to version 2025.07.10

6953f19 wireless-regdb: Update regulatory info for Indonesia (ID) for 2025
2e8214e wireless-regdb: Permit 320 MHz bandwidth in 6 GHz band for GB
a94f685 wireless-regdb: Update regulatory info for Egypt (EG) for 2024
7628ce2 wireless-regdb: Update regulatory rules for Brazil (BR) on 6GHz
4411b39 wireless-regdb: Update regulatory info for Vietnam (VN) for 2025
490f136 wireless-regdb: Update regulatory info for Estonia (EE) for 2024
c56c663 wireless-regdb: update regulatory rules for Paraguay (PY) on 6 GHz for 2025
5a8ced5 wireless-regdb: Update regulatory info for CEPT countries for 6GHz listed by WiFi Alliance
5fd8ee3 wireless-regdb: update regulatory rules for Bosnia and Herzegovina (BA) for 6 GHz
e05260a wireless-regdb: update regulatory database based on preceding changes

Signed-off-by: Hauke Mehrtens <hauke@hauke-m.de>
---
 package/firmware/wireless-regdb/Makefile | 4 ++--
 1 file changed, 2 insertions(+), 2 deletions(-)

diff --git a/package/firmware/wireless-regdb/Makefile b/package/firmware/wireless-regdb/Makefile
index 7055b12bfa12ef..d45c95e5e3d4f0 100644
--- a/package/firmware/wireless-regdb/Makefile
+++ b/package/firmware/wireless-regdb/Makefile
@@ -1,14 +1,14 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=wireless-regdb
-PKG_VERSION:=2025.02.20
+PKG_VERSION:=2025.07.10
 PKG_RELEASE:=1
 PKG_LICENSE:=ISC
 PKG_LICENSE_FILES:=LICENSE
 
 PKG_SOURCE:=$(PKG_NAME)-$(PKG_VERSION).tar.xz
 PKG_SOURCE_URL:=@KERNEL/software/network/wireless-regdb/
-PKG_HASH:=57f8e7721cf5a880c13ae0c202edbb21092a060d45f9e9c59bcd2a8272bfa456
+PKG_HASH:=a8340bcdcd1b5db6c79149879d122b170f3bb075381718d4f429ad831a6fa28d
 
 PKG_MAINTAINER:=Felix Fietkau <nbd@nbd.name>
 
