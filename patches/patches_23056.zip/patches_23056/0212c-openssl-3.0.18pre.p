diff --git a/package/libs/openssl/patches/0001-Prepare-for-3.0.18.patch b/package/libs/openssl/patches/0001-Prepare-for-3.0.18.patch
new file mode 100644
index 0000000..dab7b56
--- /dev/null
+++ b/package/libs/openssl/patches/0001-Prepare-for-3.0.18.patch
@@ -0,0 +1,62 @@
+From f243be83804ed301f365f1976550c905e9fc4f96 Mon Sep 17 00:00:00 2001
+From: openssl-machine <openssl-machine@openssl.org>
+Date: Tue, 1 Jul 2025 12:11:17 +0000
+Subject: [PATCH 01/31] Prepare for 3.0.18
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Release: yes
+---
+ CHANGES.md  | 4 ++++
+ NEWS.md     | 4 ++++
+ VERSION.dat | 6 +++---
+ 3 files changed, 11 insertions(+), 3 deletions(-)
+
+diff --git a/CHANGES.md b/CHANGES.md
+index d3958d762a..491cc94f69 100644
+--- a/CHANGES.md
++++ b/CHANGES.md
+@@ -28,6 +28,10 @@ breaking changes, and mappings for the large list of deprecated functions.
+ 
+ [Migration guide]: https://github.com/openssl/openssl/tree/master/doc/man7/migration_guide.pod
+ 
++### Changes between 3.0.17 and 3.0.18 [xx XXX xxxx]
++
++ * none yet
++
+ ### Changes between 3.0.16 and 3.0.17 [1 Jul 2025]
+ 
+  * none yet
+diff --git a/NEWS.md b/NEWS.md
+index 87fd6d8153..d51e92d60f 100644
+--- a/NEWS.md
++++ b/NEWS.md
+@@ -18,6 +18,10 @@ OpenSSL Releases
+ OpenSSL 3.0
+ -----------
+ 
++### Major changes between OpenSSL 3.0.17 and OpenSSL 3.0.18 [under development]
++
++  * none
++
+ ### Major changes between OpenSSL 3.0.16 and OpenSSL 3.0.17 [1 Jul 2025]
+ 
+ OpenSSL 3.0.17 is a bug fix release.
+diff --git a/VERSION.dat b/VERSION.dat
+index 344a35bc5f..ee5ef9d053 100644
+--- a/VERSION.dat
++++ b/VERSION.dat
+@@ -1,7 +1,7 @@
+ MAJOR=3
+ MINOR=0
+-PATCH=17
+-PRE_RELEASE_TAG=
++PATCH=18
++PRE_RELEASE_TAG=dev
+ BUILD_METADATA=
+-RELEASE_DATE="1 Jul 2025"
++RELEASE_DATE=""
+ SHLIB_VERSION=3
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0002-demos-cms-cms_ddec.c-Replace-in-with-dcont-to-correc.patch b/package/libs/openssl/patches/0002-demos-cms-cms_ddec.c-Replace-in-with-dcont-to-correc.patch
new file mode 100644
index 0000000..2a8b821
--- /dev/null
+++ b/package/libs/openssl/patches/0002-demos-cms-cms_ddec.c-Replace-in-with-dcont-to-correc.patch
@@ -0,0 +1,36 @@
+From c829030da5c7d550c6335fc6d250d10965139eb6 Mon Sep 17 00:00:00 2001
+From: Jiasheng Jiang <jiashengjiangcool@gmail.com>
+Date: Fri, 27 Jun 2025 15:59:13 +0000
+Subject: [PATCH 02/31] demos/cms/cms_ddec.c: Replace "in" with "dcont" to
+ correctly check the success of BIO_new_file()
+
+Replace "in" with "dcont" to properly check the return value of BIO_new_file().
+
+Fixes: 1728756 ("Detached encrypt/decrypt example, fix decrypt sample.")
+Signed-off-by: Jiasheng Jiang <jiashengjiangcool@gmail.com>
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27896)
+
+(cherry picked from commit 8a7545607e872ccaff3018e2cd201cce65e615ec)
+---
+ demos/cms/cms_ddec.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/demos/cms/cms_ddec.c b/demos/cms/cms_ddec.c
+index cb6c2694c6..bacc38e13b 100644
+--- a/demos/cms/cms_ddec.c
++++ b/demos/cms/cms_ddec.c
+@@ -57,7 +57,7 @@ int main(int argc, char **argv)
+     /* Open file containing detached content */
+     dcont = BIO_new_file("smencr.out", "rb");
+ 
+-    if (!in)
++    if (dcont == NULL)
+         goto err;
+ 
+     out = BIO_new_file("encrout.txt", "w");
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0003-demos-cms-cms_denc.c-Add-check-for-BIO_new_file.patch b/package/libs/openssl/patches/0003-demos-cms-cms_denc.c-Add-check-for-BIO_new_file.patch
new file mode 100644
index 0000000..e29a9bb
--- /dev/null
+++ b/package/libs/openssl/patches/0003-demos-cms-cms_denc.c-Add-check-for-BIO_new_file.patch
@@ -0,0 +1,36 @@
+From 5389e3fe01cdfdc91655cf53713399ed86cc75e3 Mon Sep 17 00:00:00 2001
+From: Jiasheng Jiang <jiashengjiangcool@gmail.com>
+Date: Wed, 25 Jun 2025 23:06:59 +0000
+Subject: [PATCH 03/31] demos/cms/cms_denc.c: Add check for BIO_new_file()
+
+Add check for the return value of BIO_new_file().
+
+Fixes: 1728756 ("Detached encrypt/decrypt example, fix decrypt sample.")
+Signed-off-by: Jiasheng Jiang <jiashengjiangcool@gmail.com>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27897)
+
+(cherry picked from commit 881ff0c225356a0f28bd55cea5a4c5204b7b7b8a)
+---
+ demos/cms/cms_denc.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/demos/cms/cms_denc.c b/demos/cms/cms_denc.c
+index 60b0aa192b..45d18dc7a4 100644
+--- a/demos/cms/cms_denc.c
++++ b/demos/cms/cms_denc.c
+@@ -57,7 +57,7 @@ int main(int argc, char **argv)
+ 
+     dout = BIO_new_file("smencr.out", "wb");
+ 
+-    if (!in)
++    if (in == NULL || dout == NULL)
+         goto err;
+ 
+     /* encrypt content */
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0004-PEM_read_CMS.pod-Correct-the-deprecation-notice.patch b/package/libs/openssl/patches/0004-PEM_read_CMS.pod-Correct-the-deprecation-notice.patch
new file mode 100644
index 0000000..0ce9b1a
--- /dev/null
+++ b/package/libs/openssl/patches/0004-PEM_read_CMS.pod-Correct-the-deprecation-notice.patch
@@ -0,0 +1,36 @@
+From 2da032657004d5e966577adea7f7a49908489f04 Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Fri, 20 Jun 2025 17:07:19 +0200
+Subject: [PATCH 04/31] PEM_read_CMS.pod: Correct the deprecation notice
+
+Fixes #27863
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27865)
+
+(cherry picked from commit 9a6376dd75961c44232dae42943ceac10795a060)
+---
+ doc/man3/PEM_read_CMS.pod | 6 +++---
+ 1 file changed, 3 insertions(+), 3 deletions(-)
+
+diff --git a/doc/man3/PEM_read_CMS.pod b/doc/man3/PEM_read_CMS.pod
+index dbccf26cd8..1e6d80e5b1 100644
+--- a/doc/man3/PEM_read_CMS.pod
++++ b/doc/man3/PEM_read_CMS.pod
+@@ -84,9 +84,9 @@ see L<openssl_user_macros(7)>:
+ 
+ =head1 DESCRIPTION
+ 
+-All of the functions described on this page are deprecated.
+-Applications should use OSSL_ENCODER_to_bio() and OSSL_DECODER_from_bio()
+-instead.
++To replace the deprecated functions listed above, applications should use the
++B<EVP_PKEY> type and OSSL_DECODER_from_bio() and OSSL_ENCODER_to_bio() to
++read and write PEM data containing key parameters or private and public keys.
+ 
+ In the description below, B<I<TYPE>> is used
+ as a placeholder for any of the OpenSSL datatypes, such as B<X509>.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0005-Add-note-about-use-of-EVP_PKEY-in-different-libctxs.patch b/package/libs/openssl/patches/0005-Add-note-about-use-of-EVP_PKEY-in-different-libctxs.patch
new file mode 100644
index 0000000..841d62a
--- /dev/null
+++ b/package/libs/openssl/patches/0005-Add-note-about-use-of-EVP_PKEY-in-different-libctxs.patch
@@ -0,0 +1,44 @@
+From 290ec08c21611a5782297fdc5bc343d08505cae5 Mon Sep 17 00:00:00 2001
+From: Michael Baentsch <57787676+baentsch@users.noreply.github.com>
+Date: Mon, 30 Jun 2025 09:33:46 +0200
+Subject: [PATCH 05/31] Add note about use of EVP_PKEY in different libctxs
+
+Co-authored-by: Shane Lontis <slontis@oracle.com>
+
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/26309)
+
+(cherry picked from commit b2ac43b0d89b5b528941ad9d233b4cb4f99a7cca)
+---
+ doc/man3/EVP_PKEY_new.pod | 14 +++++++++++++-
+ 1 file changed, 13 insertions(+), 1 deletion(-)
+
+diff --git a/doc/man3/EVP_PKEY_new.pod b/doc/man3/EVP_PKEY_new.pod
+index 1c75c75719..b32d3fc6c5 100644
+--- a/doc/man3/EVP_PKEY_new.pod
++++ b/doc/man3/EVP_PKEY_new.pod
+@@ -168,7 +168,19 @@ general private key without reference to any particular algorithm.
+ The structure returned by EVP_PKEY_new() is empty. To add a private or public
+ key to this empty structure use the appropriate functions described in
+ L<EVP_PKEY_set1_RSA(3)>, L<EVP_PKEY_set1_DSA(3)>, L<EVP_PKEY_set1_DH(3)> or
+-L<EVP_PKEY_set1_EC_KEY(3)>.
++L<EVP_PKEY_set1_EC_KEY(3)> for legacy key types implemented in internal
++OpenSSL providers.
++
++For fully provider-managed key types (see L<provider-keymgmt(7)>),
++possibly implemented in external providers, use functions such as
++L<EVP_PKEY_set1_encoded_public_key(3)> or L<EVP_PKEY_fromdata(3)>
++to populate key data.
++
++Generally caution is advised for using an B<EVP_PKEY> structure across
++different library contexts: In order for an B<EVP_PKEY> to be shared by
++multiple library contexts the providers associated with the library contexts
++must have key managers that support the key type and implement the
++OSSL_FUNC_keymgmt_import() and OSSL_FUNC_keymgmt_export() functions.
+ 
+ =head1 RETURN VALUES
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0006-sec_mem-add-note-about-the-perf-implications.patch b/package/libs/openssl/patches/0006-sec_mem-add-note-about-the-perf-implications.patch
new file mode 100644
index 0000000..02d79b2
--- /dev/null
+++ b/package/libs/openssl/patches/0006-sec_mem-add-note-about-the-perf-implications.patch
@@ -0,0 +1,69 @@
+From c23a71635261dd69f802bcf8205d0e5016684d11 Mon Sep 17 00:00:00 2001
+From: Nikola Pajkovsky <nikolap@openssl.org>
+Date: Thu, 10 Jul 2025 09:03:38 +0200
+Subject: [PATCH 06/31] sec_mem: add note about the perf implications
+
+Testing secure storage for ml-kem/dsa [1] shows performace penalty
+when secure storage is enabled.
+
+| Threads | baseline usec/handshake | secmem usec/handshake |
+|---------+-------------------------+-----------------------|
+|       1 |              586.784756 |            588.306131 |
+|       2 |              599.537648 |            601.007393 |
+|       4 |              610.663361 |            613.600663 |
+|       8 |              649.347376 |            869.693358 |
+|      16 |             1176.402781 |           2487.335286 |
+|      32 |             2345.594618 |           5155.747515 |
+|      64 |             4697.556045 |          11170.627031 |
+
+the test shows that sec mem is ok-ish up to the number of available cores,
+and when the sec mem lock gets contended, performance goes down rapidly.
+Tested on Apple M4 Pro.
+
+[1] https://github.com/openssl/openssl/pull/27625
+
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+Reviewed-by: Kurt Roeckx <kurt@roeckx.be>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28011)
+
+(cherry picked from commit b8cc32766060757254f31139d6c521465d796d0d)
+---
+ doc/man3/OPENSSL_secure_malloc.pod | 9 +++++++--
+ 1 file changed, 7 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man3/OPENSSL_secure_malloc.pod b/doc/man3/OPENSSL_secure_malloc.pod
+index 1bddd77370..dbc7073aac 100644
+--- a/doc/man3/OPENSSL_secure_malloc.pod
++++ b/doc/man3/OPENSSL_secure_malloc.pod
+@@ -45,7 +45,12 @@ the program's dynamic memory area, where keys and other sensitive
+ information might be stored, OpenSSL supports the concept of a "secure heap."
+ The level and type of security guarantees depend on the operating system.
+ It is a good idea to review the code and see if it addresses your
+-threat model and concerns.
++threat model and concerns. It should be noted that the secure heap
++uses a single read/write lock, and therefore any operations
++that involve allocation or freeing of secure heap memory are serialised,
++blocking other threads. With that in mind, highly concurrent applications
++should enable the secure heap with caution and be aware of the performance
++implications for multi-threaded code.
+ 
+ If a secure heap is used, then private key B<BIGNUM> values are stored there.
+ This protects long-term storage of private keys, but will not necessarily
+@@ -135,7 +140,7 @@ a B<size_t> in OpenSSL 3.0.
+ 
+ =head1 COPYRIGHT
+ 
+-Copyright 2015-2024 The OpenSSL Project Authors. All Rights Reserved.
++Copyright 2015-2025 The OpenSSL Project Authors. All Rights Reserved.
+ 
+ Licensed under the Apache License 2.0 (the "License").  You may not use
+ this file except in compliance with the License.  You can obtain a copy
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0009-Support-decode-SM2-parameters.patch b/package/libs/openssl/patches/0009-Support-decode-SM2-parameters.patch
new file mode 100644
index 0000000..0ea16cd
--- /dev/null
+++ b/package/libs/openssl/patches/0009-Support-decode-SM2-parameters.patch
@@ -0,0 +1,175 @@
+From c87e6b0eb24fba8b11a522ce7e3b0ac4fdd1c711 Mon Sep 17 00:00:00 2001
+From: K1 <dongbeiouba@gmail.com>
+Date: Tue, 19 Jul 2022 01:18:12 +0800
+Subject: [PATCH 09/31] Support decode SM2 parameters
+
+Reviewed-by: Hugo Landau <hlandau@openssl.org>
+Reviewed-by: Paul Dale <pauli@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/27999)
+---
+ apps/ecparam.c                                       | 12 ++++++++++--
+ include/openssl/pem.h                                |  1 +
+ providers/decoders.inc                               |  1 +
+ .../implementations/encode_decode/decode_der2key.c   |  1 +
+ .../implementations/encode_decode/decode_pem2der.c   |  1 +
+ .../implementations/encode_decode/encode_key2text.c  |  8 +++++---
+ .../implementations/include/prov/implementations.h   |  1 +
+ test/recipes/15-test_ecparam.t                       |  4 ++++
+ .../15-test_ecparam_data/valid/sm2-explicit.pem      |  7 +++++++
+ .../recipes/15-test_ecparam_data/valid/sm2-named.pem |  3 +++
+ 10 files changed, 34 insertions(+), 5 deletions(-)
+ create mode 100644 test/recipes/15-test_ecparam_data/valid/sm2-explicit.pem
+ create mode 100644 test/recipes/15-test_ecparam_data/valid/sm2-named.pem
+
+diff --git a/apps/ecparam.c b/apps/ecparam.c
+index 9e9ad13683..ea92017060 100644
+--- a/apps/ecparam.c
++++ b/apps/ecparam.c
+@@ -243,9 +243,17 @@ int ecparam_main(int argc, char **argv)
+             goto end;
+         }
+     } else {
+-        params_key = load_keyparams(infile, informat, 1, "EC", "EC parameters");
+-        if (params_key == NULL || !EVP_PKEY_is_a(params_key, "EC"))
++        params_key = load_keyparams_suppress(infile, informat, 1, "EC",
++                                             "EC parameters", 1);
++        if (params_key == NULL)
++            params_key = load_keyparams_suppress(infile, informat, 1, "SM2",
++                                                 "SM2 parameters", 1);
++
++        if (params_key == NULL) {
++            BIO_printf(bio_err, "Unable to load parameters from %s\n", infile);
+             goto end;
++        }
++
+         if (point_format
+             && !EVP_PKEY_set_utf8_string_param(
+                     params_key, OSSL_PKEY_PARAM_EC_POINT_CONVERSION_FORMAT,
+diff --git a/include/openssl/pem.h b/include/openssl/pem.h
+index 80940dfa96..3d61961e0d 100644
+--- a/include/openssl/pem.h
++++ b/include/openssl/pem.h
+@@ -54,6 +54,7 @@ extern "C" {
+ # define PEM_STRING_ECPRIVATEKEY "EC PRIVATE KEY"
+ # define PEM_STRING_PARAMETERS   "PARAMETERS"
+ # define PEM_STRING_CMS          "CMS"
++# define PEM_STRING_SM2PARAMETERS "SM2 PARAMETERS"
+ 
+ # define PEM_TYPE_ENCRYPTED      10
+ # define PEM_TYPE_MIC_ONLY       20
+diff --git a/providers/decoders.inc b/providers/decoders.inc
+index 2772aad05d..edca39ea36 100644
+--- a/providers/decoders.inc
++++ b/providers/decoders.inc
+@@ -69,6 +69,7 @@ DECODER_w_structure("X448", der, SubjectPublicKeyInfo, x448, yes),
+ # ifndef OPENSSL_NO_SM2
+ DECODER_w_structure("SM2", der, PrivateKeyInfo, sm2, no),
+ DECODER_w_structure("SM2", der, SubjectPublicKeyInfo, sm2, no),
++DECODER_w_structure("SM2", der, type_specific_no_pub, sm2, no),
+ # endif
+ #endif
+ DECODER_w_structure("RSA", der, PrivateKeyInfo, rsa, yes),
+diff --git a/providers/implementations/encode_decode/decode_der2key.c b/providers/implementations/encode_decode/decode_der2key.c
+index f2d9d82556..32914c8472 100644
+--- a/providers/implementations/encode_decode/decode_der2key.c
++++ b/providers/implementations/encode_decode/decode_der2key.c
+@@ -806,6 +806,7 @@ MAKE_DECODER("ED448", ed448, ecx, SubjectPublicKeyInfo);
+ # ifndef OPENSSL_NO_SM2
+ MAKE_DECODER("SM2", sm2, ec, PrivateKeyInfo);
+ MAKE_DECODER("SM2", sm2, ec, SubjectPublicKeyInfo);
++MAKE_DECODER("SM2", sm2, sm2, type_specific_no_pub);
+ # endif
+ #endif
+ MAKE_DECODER("RSA", rsa, rsa, PrivateKeyInfo);
+diff --git a/providers/implementations/encode_decode/decode_pem2der.c b/providers/implementations/encode_decode/decode_pem2der.c
+index bc937ffb9d..648ecd4584 100644
+--- a/providers/implementations/encode_decode/decode_pem2der.c
++++ b/providers/implementations/encode_decode/decode_pem2der.c
+@@ -119,6 +119,7 @@ static int pem2der_decode(void *vctx, OSSL_CORE_BIO *cin, int selection,
+         { PEM_STRING_DSAPARAMS, OSSL_OBJECT_PKEY, "DSA", "type-specific" },
+         { PEM_STRING_ECPRIVATEKEY, OSSL_OBJECT_PKEY, "EC", "type-specific" },
+         { PEM_STRING_ECPARAMETERS, OSSL_OBJECT_PKEY, "EC", "type-specific" },
++        { PEM_STRING_SM2PARAMETERS, OSSL_OBJECT_PKEY, "SM2", "type-specific" },
+         { PEM_STRING_RSA, OSSL_OBJECT_PKEY, "RSA", "type-specific" },
+         { PEM_STRING_RSA_PUBLIC, OSSL_OBJECT_PKEY, "RSA", "type-specific" },
+ 
+diff --git a/providers/implementations/encode_decode/encode_key2text.c b/providers/implementations/encode_decode/encode_key2text.c
+index 637fcf6a12..89c3e7eb70 100644
+--- a/providers/implementations/encode_decode/encode_key2text.c
++++ b/providers/implementations/encode_decode/encode_key2text.c
+@@ -513,7 +513,8 @@ static int ec_to_text(BIO *out, const void *key, int selection)
+     else if ((selection & OSSL_KEYMGMT_SELECT_PUBLIC_KEY) != 0)
+         type_label = "Public-Key";
+     else if ((selection & OSSL_KEYMGMT_SELECT_DOMAIN_PARAMETERS) != 0)
+-        type_label = "EC-Parameters";
++        if (EC_GROUP_get_curve_name(group) != NID_sm2)
++            type_label = "EC-Parameters";
+ 
+     if ((selection & OSSL_KEYMGMT_SELECT_PRIVATE_KEY) != 0) {
+         const BIGNUM *priv_key = EC_KEY_get0_private_key(ec);
+@@ -539,8 +540,9 @@ static int ec_to_text(BIO *out, const void *key, int selection)
+             goto err;
+     }
+ 
+-    if (BIO_printf(out, "%s: (%d bit)\n", type_label,
+-                   EC_GROUP_order_bits(group)) <= 0)
++    if (type_label != NULL
++        && BIO_printf(out, "%s: (%d bit)\n", type_label,
++                      EC_GROUP_order_bits(group)) <= 0)
+         goto err;
+     if (priv != NULL
+         && !print_labeled_buf(out, "priv:", priv, priv_len))
+diff --git a/providers/implementations/include/prov/implementations.h b/providers/implementations/include/prov/implementations.h
+index 3f6dd7ee16..665ec385cb 100644
+--- a/providers/implementations/include/prov/implementations.h
++++ b/providers/implementations/include/prov/implementations.h
+@@ -498,6 +498,7 @@ extern const OSSL_DISPATCH ossl_SubjectPublicKeyInfo_der_to_ed448_decoder_functi
+ #ifndef OPENSSL_NO_SM2
+ extern const OSSL_DISPATCH ossl_PrivateKeyInfo_der_to_sm2_decoder_functions[];
+ extern const OSSL_DISPATCH ossl_SubjectPublicKeyInfo_der_to_sm2_decoder_functions[];
++extern const OSSL_DISPATCH ossl_type_specific_no_pub_der_to_sm2_decoder_functions[];
+ #endif
+ 
+ extern const OSSL_DISPATCH ossl_PrivateKeyInfo_der_to_rsa_decoder_functions[];
+diff --git a/test/recipes/15-test_ecparam.t b/test/recipes/15-test_ecparam.t
+index 37bf620f35..5dba866378 100644
+--- a/test/recipes/15-test_ecparam.t
++++ b/test/recipes/15-test_ecparam.t
+@@ -25,6 +25,10 @@ my @valid = glob(data_file("valid", "*.pem"));
+ my @noncanon = glob(data_file("noncanon", "*.pem"));
+ my @invalid = glob(data_file("invalid", "*.pem"));
+ 
++if (disabled("sm2")) {
++    @valid = grep { !/sm2-.*\.pem/} @valid;
++}
++
+ plan tests => 12;
+ 
+ sub checkload {
+diff --git a/test/recipes/15-test_ecparam_data/valid/sm2-explicit.pem b/test/recipes/15-test_ecparam_data/valid/sm2-explicit.pem
+new file mode 100644
+index 0000000000..bd07654ea4
+--- /dev/null
++++ b/test/recipes/15-test_ecparam_data/valid/sm2-explicit.pem
+@@ -0,0 +1,7 @@
++-----BEGIN SM2 PARAMETERS-----
++MIHgAgEBMCwGByqGSM49AQECIQD////+/////////////////////wAAAAD/////
++/////zBEBCD////+/////////////////////wAAAAD//////////AQgKOn6np2f
++XjRNWp5Lz2UJp/OXifUVq4+S3by9QU2UDpMEQQQyxK4sHxmBGV+ZBEZqOcmUj+ML
++v/JmC+FxWkWJM0x0x7w3NqL09necWb3O42tpIVPQqYd8xipHQALfMuUhOfCgAiEA
++/////v///////////////3ID32shxgUrU7v0CTnVQSMCAQE=
++-----END SM2 PARAMETERS-----
+diff --git a/test/recipes/15-test_ecparam_data/valid/sm2-named.pem b/test/recipes/15-test_ecparam_data/valid/sm2-named.pem
+new file mode 100644
+index 0000000000..d6e280f6c2
+--- /dev/null
++++ b/test/recipes/15-test_ecparam_data/valid/sm2-named.pem
+@@ -0,0 +1,3 @@
++-----BEGIN SM2 PARAMETERS-----
++BggqgRzPVQGCLQ==
++-----END SM2 PARAMETERS-----
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0010-fix-SM2-privatekey-decode-PEM-format-ECPrivateKey.patch b/package/libs/openssl/patches/0010-fix-SM2-privatekey-decode-PEM-format-ECPrivateKey.patch
new file mode 100644
index 0000000..a49dddc
--- /dev/null
+++ b/package/libs/openssl/patches/0010-fix-SM2-privatekey-decode-PEM-format-ECPrivateKey.patch
@@ -0,0 +1,78 @@
+From 037b41ff92f5e285545e0a0246732090518b17b5 Mon Sep 17 00:00:00 2001
+From: Alen Yan <yzpgryx@163.com>
+Date: Wed, 9 Jul 2025 09:23:00 +0800
+Subject: [PATCH 10/31] fix SM2 privatekey decode(PEM format, ECPrivateKey).
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/27999)
+---
+ include/openssl/pem.h                                    | 1 +
+ providers/implementations/encode_decode/decode_pem2der.c | 1 +
+ test/recipes/15-test_ec.t                                | 6 +++++-
+ test/testec-sm2.pem                                      | 5 +++++
+ 4 files changed, 12 insertions(+), 1 deletion(-)
+ create mode 100644 test/testec-sm2.pem
+
+diff --git a/include/openssl/pem.h b/include/openssl/pem.h
+index 3d61961e0d..ab1e971443 100644
+--- a/include/openssl/pem.h
++++ b/include/openssl/pem.h
+@@ -54,6 +54,7 @@ extern "C" {
+ # define PEM_STRING_ECPRIVATEKEY "EC PRIVATE KEY"
+ # define PEM_STRING_PARAMETERS   "PARAMETERS"
+ # define PEM_STRING_CMS          "CMS"
++# define PEM_STRING_SM2PRIVATEKEY "SM2 PRIVATE KEY"
+ # define PEM_STRING_SM2PARAMETERS "SM2 PARAMETERS"
+ 
+ # define PEM_TYPE_ENCRYPTED      10
+diff --git a/providers/implementations/encode_decode/decode_pem2der.c b/providers/implementations/encode_decode/decode_pem2der.c
+index 648ecd4584..1f7ddb5620 100644
+--- a/providers/implementations/encode_decode/decode_pem2der.c
++++ b/providers/implementations/encode_decode/decode_pem2der.c
+@@ -119,6 +119,7 @@ static int pem2der_decode(void *vctx, OSSL_CORE_BIO *cin, int selection,
+         { PEM_STRING_DSAPARAMS, OSSL_OBJECT_PKEY, "DSA", "type-specific" },
+         { PEM_STRING_ECPRIVATEKEY, OSSL_OBJECT_PKEY, "EC", "type-specific" },
+         { PEM_STRING_ECPARAMETERS, OSSL_OBJECT_PKEY, "EC", "type-specific" },
++        { PEM_STRING_SM2PRIVATEKEY, OSSL_OBJECT_PKEY, "SM2", "type-specific" },
+         { PEM_STRING_SM2PARAMETERS, OSSL_OBJECT_PKEY, "SM2", "type-specific" },
+         { PEM_STRING_RSA, OSSL_OBJECT_PKEY, "RSA", "type-specific" },
+         { PEM_STRING_RSA_PUBLIC, OSSL_OBJECT_PKEY, "RSA", "type-specific" },
+diff --git a/test/recipes/15-test_ec.t b/test/recipes/15-test_ec.t
+index 0638d626e7..92f763f4c5 100644
+--- a/test/recipes/15-test_ec.t
++++ b/test/recipes/15-test_ec.t
+@@ -18,7 +18,7 @@ setup("test_ec");
+ 
+ plan skip_all => 'EC is not supported in this build' if disabled('ec');
+ 
+-plan tests => 15;
++plan tests => 16;
+ 
+ my $no_fips = disabled('fips') || ($ENV{NO_FIPS} // 0);
+ 
+@@ -33,6 +33,10 @@ subtest 'EC conversions -- private key' => sub {
+     tconversion( -type => 'ec', -prefix => 'ec-priv',
+                  -in => srctop_file("test","testec-p256.pem") );
+ };
++subtest 'EC conversions -- private key' => sub {
++    tconversion( -type => 'ec', -prefix => 'sm2-priv',
++                 -in => srctop_file("test","testec-sm2.pem") );
++};
+ subtest 'EC conversions -- private key PKCS#8' => sub {
+     tconversion( -type => 'ec', -prefix => 'ec-pkcs8',
+                  -in => srctop_file("test","testec-p256.pem"),
+diff --git a/test/testec-sm2.pem b/test/testec-sm2.pem
+new file mode 100644
+index 0000000000..30e25613b3
+--- /dev/null
++++ b/test/testec-sm2.pem
+@@ -0,0 +1,5 @@
++-----BEGIN SM2 PRIVATE KEY-----
++MHcCAQEEIKPB7gEYKGAwAkz0MfGwQm0BXclgzvSTxQG9bm4RCAxXoAoGCCqBHM9V
++AYItoUQDQgAE+FuibOpfjVfj716O3LglhK4HzjUR82mgn8kTZinQsEafw3FFZzZJ
++vwHIGHUsSKxVTRIEs+BICQDBg99OA3VU/Q==
++-----END SM2 PRIVATE KEY-----
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0011-sm2-sm2_sign.c-check-EC_KEY_get0_private_key-for-NUL.patch b/package/libs/openssl/patches/0011-sm2-sm2_sign.c-check-EC_KEY_get0_private_key-for-NUL.patch
new file mode 100644
index 0000000..c7fce3c
--- /dev/null
+++ b/package/libs/openssl/patches/0011-sm2-sm2_sign.c-check-EC_KEY_get0_private_key-for-NUL.patch
@@ -0,0 +1,47 @@
+From 2a80bafe7c6c057765adbb89703317051eb351bd Mon Sep 17 00:00:00 2001
+From: AntonMoryakov <ant.v.moryakov@gmail.com>
+Date: Mon, 2 Jun 2025 13:14:28 +0300
+Subject: [PATCH 11/31] sm2: sm2_sign.c: check EC_KEY_get0_private_key() for
+ NULL in sm2_sig_gen()
+
+Static analysis revealed that sm2_sig_gen() dereferences the return value
+of EC_KEY_get0_private_key() without checking for NULL. This could lead to
+a crash if the private key is unset.
+
+This patch adds a NULL check and raises ERR_R_PASSED_NULL_PARAMETER if the
+key is missing.
+
+Issue found by static analyzer:
+> Return value of EC_KEY_get0_private_key() is dereferenced without checking for NULL (11/12 checked)
+
+CLA: trivial
+Signed-off-by: Anton Moryakov <ant.v.moryakov@gmail.com>
+
+Reviewed-by: Nicola Tuveri <nic.tuv@gmail.com>
+Reviewed-by: Tom Cosgrove <tom.cosgrove@arm.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27741)
+
+(cherry picked from commit c108ead2840a76a59fe02c049d08322a02b24761)
+---
+ crypto/sm2/sm2_sign.c | 4 ++++
+ 1 file changed, 4 insertions(+)
+
+diff --git a/crypto/sm2/sm2_sign.c b/crypto/sm2/sm2_sign.c
+index 2097cd2fca..4f78cd9ac2 100644
+--- a/crypto/sm2/sm2_sign.c
++++ b/crypto/sm2/sm2_sign.c
+@@ -217,6 +217,10 @@ static ECDSA_SIG *sm2_sig_gen(const EC_KEY *key, const BIGNUM *e)
+     BIGNUM *tmp = NULL;
+     OSSL_LIB_CTX *libctx = ossl_ec_key_get_libctx(key);
+ 
++    if (dA == NULL) {
++        ERR_raise(ERR_LIB_SM2, SM2_R_INVALID_PRIVATE_KEY);
++        goto done;
++    }
+     kG = EC_POINT_new(group);
+     ctx = BN_CTX_new_ex(libctx);
+     if (kG == NULL || ctx == NULL) {
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0012-Fix-OSSL_STORE-to-consider-cached-info-in-the-EOF-ch.patch b/package/libs/openssl/patches/0012-Fix-OSSL_STORE-to-consider-cached-info-in-the-EOF-ch.patch
new file mode 100644
index 0000000..c2039ca
--- /dev/null
+++ b/package/libs/openssl/patches/0012-Fix-OSSL_STORE-to-consider-cached-info-in-the-EOF-ch.patch
@@ -0,0 +1,75 @@
+From 54d399a1281de2588b11ea6a7635f737553689f6 Mon Sep 17 00:00:00 2001
+From: Richard Levitte <levitte@openssl.org>
+Date: Thu, 10 Jul 2025 17:55:50 +0200
+Subject: [PATCH 12/31] Fix OSSL_STORE to consider cached info in the EOF
+ check.
+
+OSSL_STORE_load() called OSSL_STORE_eof() before checking if there is
+cached OSSL_STORE_INFO to consider.  To fix this issue, the cached info
+check is moved to OSSL_STORE_eof(), as that seems to make most common
+sense.
+
+This solves an issue with PKCS#12 files, where the cached info was never
+considered because the underlying file IO layer signaled that EOF is
+reached.
+
+Fixes #28010
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: David von Oheimb <david.von.oheimb@siemens.com>
+(Merged from https://github.com/openssl/openssl/pull/28016)
+
+(cherry picked from commit 1f3af48c312a5f94612e9a822b78a3afdadc27c1)
+---
+ crypto/store/store_lib.c | 25 ++++++++++++++-----------
+ 1 file changed, 14 insertions(+), 11 deletions(-)
+
+diff --git a/crypto/store/store_lib.c b/crypto/store/store_lib.c
+index bc12d8dd13..c5891a853c 100644
+--- a/crypto/store/store_lib.c
++++ b/crypto/store/store_lib.c
+@@ -410,12 +410,6 @@ OSSL_STORE_INFO *OSSL_STORE_load(OSSL_STORE_CTX *ctx)
+     if (ctx->loader != NULL)
+         OSSL_TRACE(STORE, "Loading next object\n");
+ 
+-    if (ctx->cached_info != NULL
+-        && sk_OSSL_STORE_INFO_num(ctx->cached_info) == 0) {
+-        sk_OSSL_STORE_INFO_free(ctx->cached_info);
+-        ctx->cached_info = NULL;
+-    }
+-
+     if (ctx->cached_info != NULL) {
+         v = sk_OSSL_STORE_INFO_shift(ctx->cached_info);
+     } else {
+@@ -491,14 +485,23 @@ int OSSL_STORE_error(OSSL_STORE_CTX *ctx)
+ 
+ int OSSL_STORE_eof(OSSL_STORE_CTX *ctx)
+ {
+-    int ret = 1;
++    int ret = 0;
+ 
+-    if (ctx->fetched_loader != NULL)
+-        ret = ctx->loader->p_eof(ctx->loader_ctx);
++    if (ctx->cached_info != NULL
++        && sk_OSSL_STORE_INFO_num(ctx->cached_info) == 0) {
++        sk_OSSL_STORE_INFO_free(ctx->cached_info);
++        ctx->cached_info = NULL;
++    }
++
++    if (ctx->cached_info == NULL) {
++        ret = 1;
++        if (ctx->fetched_loader != NULL)
++            ret = ctx->loader->p_eof(ctx->loader_ctx);
+ #ifndef OPENSSL_NO_DEPRECATED_3_0
+-    if (ctx->fetched_loader == NULL)
+-        ret = ctx->loader->eof(ctx->loader_ctx);
++        if (ctx->fetched_loader == NULL)
++            ret = ctx->loader->eof(ctx->loader_ctx);
+ #endif
++    }
+     return ret != 0;
+ }
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0014-test-ec-Skip-SM2-key-import-test-if-SM2-is-disabled.patch b/package/libs/openssl/patches/0014-test-ec-Skip-SM2-key-import-test-if-SM2-is-disabled.patch
new file mode 100644
index 0000000..37c8e6c
--- /dev/null
+++ b/package/libs/openssl/patches/0014-test-ec-Skip-SM2-key-import-test-if-SM2-is-disabled.patch
@@ -0,0 +1,45 @@
+From 39ea2b686545605dcba767ed4047c7f2e905748a Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Mon, 28 Jul 2025 11:13:06 +0200
+Subject: [PATCH 14/31] test-ec: Skip SM2 key import test if SM2 is disabled
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28106)
+
+(cherry picked from commit 981d6776a339bebbb1aa4a38b940dd1526ab3508)
+---
+ test/recipes/15-test_ec.t | 14 ++++++++++----
+ 1 file changed, 10 insertions(+), 4 deletions(-)
+
+diff --git a/test/recipes/15-test_ec.t b/test/recipes/15-test_ec.t
+index 92f763f4c5..106da47231 100644
+--- a/test/recipes/15-test_ec.t
++++ b/test/recipes/15-test_ec.t
+@@ -33,10 +33,16 @@ subtest 'EC conversions -- private key' => sub {
+     tconversion( -type => 'ec', -prefix => 'ec-priv',
+                  -in => srctop_file("test","testec-p256.pem") );
+ };
+-subtest 'EC conversions -- private key' => sub {
+-    tconversion( -type => 'ec', -prefix => 'sm2-priv',
+-                 -in => srctop_file("test","testec-sm2.pem") );
+-};
++
++SKIP: {
++    skip "SM2 is not supported by this OpenSSL build", 1
++        if disabled("sm2");
++    subtest 'EC conversions -- private key' => sub {
++        tconversion( -type => 'ec', -prefix => 'sm2-priv',
++                     -in => srctop_file("test","testec-sm2.pem") );
++    };
++}
++
+ subtest 'EC conversions -- private key PKCS#8' => sub {
+     tconversion( -type => 'ec', -prefix => 'ec-pkcs8',
+                  -in => srctop_file("test","testec-p256.pem"),
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0015-apps-asn1parse.c-correct-help-text-order-for-genstr-.patch b/package/libs/openssl/patches/0015-apps-asn1parse.c-correct-help-text-order-for-genstr-.patch
new file mode 100644
index 0000000..b08c70a
--- /dev/null
+++ b/package/libs/openssl/patches/0015-apps-asn1parse.c-correct-help-text-order-for-genstr-.patch
@@ -0,0 +1,34 @@
+From af31cc62caaa75f54ed9275d2c2d4eccffa40324 Mon Sep 17 00:00:00 2001
+From: Saurabh Kushwah <110624181+Saurabh825@users.noreply.github.com>
+Date: Wed, 30 Jul 2025 18:06:57 +0530
+Subject: [PATCH 15/31] apps/asn1parse.c: correct help text order for -genstr
+ option
+
+CLA: trivial
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28123)
+
+(cherry picked from commit eac588ac360ca16e0f9979b6c70708f1e8991b4f)
+---
+ apps/asn1parse.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/apps/asn1parse.c b/apps/asn1parse.c
+index 129b867c8c..04263eeb03 100644
+--- a/apps/asn1parse.c
++++ b/apps/asn1parse.c
+@@ -40,8 +40,8 @@ const OPTIONS asn1parse_options[] = {
+     {"length", OPT_LENGTH, 'p', "length of section in file"},
+     {"strparse", OPT_STRPARSE, 'p',
+      "offset; a series of these can be used to 'dig'"},
+-    {"genstr", OPT_GENSTR, 's', "string to generate ASN1 structure from"},
+     {OPT_MORE_STR, 0, 0, "into multiple ASN1 blob wrappings"},
++    {"genstr", OPT_GENSTR, 's', "string to generate ASN1 structure from"},
+     {"genconf", OPT_GENCONF, 's', "file to generate ASN1 structure from"},
+     {"strictpem", OPT_STRICTPEM, 0,
+      "do not attempt base64 decode outside PEM markers"},
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0016-Fix-RSA-key-size-validation-in-EVP_PKEY_RSA_keygen-d.patch b/package/libs/openssl/patches/0016-Fix-RSA-key-size-validation-in-EVP_PKEY_RSA_keygen-d.patch
new file mode 100644
index 0000000..4bbecaf
--- /dev/null
+++ b/package/libs/openssl/patches/0016-Fix-RSA-key-size-validation-in-EVP_PKEY_RSA_keygen-d.patch
@@ -0,0 +1,36 @@
+From 1a8d833db5bdb16d9016bc477664c2480706f8d0 Mon Sep 17 00:00:00 2001
+From: Quin-Darcy <pohmsuindraguli@gmail.com>
+Date: Thu, 31 Jul 2025 09:07:46 -0500
+Subject: [PATCH 16/31] Fix RSA key size validation in EVP_PKEY_RSA_keygen demo
+
+The validation was checking the default 'bits' value (4096) instead of
+the parsed 'bits_i' from the command line arguments, allowing invalid
+key sizes to bypass the 512-bit minimum.
+
+CLA: trivial
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+(Merged from https://github.com/openssl/openssl/pull/28139)
+
+(cherry picked from commit c79e1b212a616b8dca194a77e7698b886000fcb0)
+---
+ demos/pkey/EVP_PKEY_RSA_keygen.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/demos/pkey/EVP_PKEY_RSA_keygen.c b/demos/pkey/EVP_PKEY_RSA_keygen.c
+index fbecfb6bdb..7a546fee99 100644
+--- a/demos/pkey/EVP_PKEY_RSA_keygen.c
++++ b/demos/pkey/EVP_PKEY_RSA_keygen.c
+@@ -254,7 +254,7 @@ int main(int argc, char **argv)
+ 
+     if (argc > 1) {
+         bits_i = atoi(argv[1]);
+-        if (bits < 512) {
++        if (bits_i < 512) {
+             fprintf(stderr, "Invalid RSA key size\n");
+             return 1;
+         }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0017-Fix-memory-leak-on-EVP_CIPHER_param_to_asn1-failure.patch b/package/libs/openssl/patches/0017-Fix-memory-leak-on-EVP_CIPHER_param_to_asn1-failure.patch
new file mode 100644
index 0000000..00ffe17
--- /dev/null
+++ b/package/libs/openssl/patches/0017-Fix-memory-leak-on-EVP_CIPHER_param_to_asn1-failure.patch
@@ -0,0 +1,41 @@
+From 7a63362eacfbe5e8f4d667c02538b913aa50f69e Mon Sep 17 00:00:00 2001
+From: 77tiann <27392025k@gmail.com>
+Date: Wed, 30 Jul 2025 17:47:06 -0700
+Subject: [PATCH 17/31] Fix memory leak on EVP_CIPHER_param_to_asn1 failure
+
+When EVP_CIPHER_param_to_asn1() fails, xalg->parameter was not freed,
+leading to a memory leak. This patch adds proper cleanup for that case.
+CLA: trivial
+
+Signed-off-by: 77tiann <27392025k@gmail.com>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28131)
+
+(cherry picked from commit bda2473a44e4534c3c640ce89a0971874165c6df)
+---
+ crypto/pkcs7/pk7_doit.c | 5 ++++-
+ 1 file changed, 4 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/pkcs7/pk7_doit.c b/crypto/pkcs7/pk7_doit.c
+index e9de097da1..3052f343fb 100644
+--- a/crypto/pkcs7/pk7_doit.c
++++ b/crypto/pkcs7/pk7_doit.c
+@@ -334,8 +334,11 @@ BIO *PKCS7_dataInit(PKCS7 *p7, BIO *bio)
+                 if (xalg->parameter == NULL)
+                     goto err;
+             }
+-            if (EVP_CIPHER_param_to_asn1(ctx, xalg->parameter) <= 0)
++            if (EVP_CIPHER_param_to_asn1(ctx, xalg->parameter) <= 0) {
++                ASN1_TYPE_free(xalg->parameter);
++                xalg->parameter = NULL;
+                 goto err;
++            }
+         }
+ 
+         /* Lets do the pub key stuff :-) */
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0018-Correct-the-synthetisized-OPENSSL_VERSION_NUMBER.patch b/package/libs/openssl/patches/0018-Correct-the-synthetisized-OPENSSL_VERSION_NUMBER.patch
new file mode 100644
index 0000000..d23e3ee
--- /dev/null
+++ b/package/libs/openssl/patches/0018-Correct-the-synthetisized-OPENSSL_VERSION_NUMBER.patch
@@ -0,0 +1,44 @@
+From 80c46795ea2c2bd581d91640eea251f1c5085ec2 Mon Sep 17 00:00:00 2001
+From: Richard Levitte <levitte@openssl.org>
+Date: Mon, 11 Aug 2025 20:57:44 +0200
+Subject: [PATCH 18/31] Correct the synthetisized OPENSSL_VERSION_NUMBER
+
+The last hex digit always became 0x0L, even of OPENSSL_VERSION_PRE_RELEASE
+was the empty string.
+
+Resolves: https://github.com/openssl/openssl/issues/28227
+
+Reviewed-by: Paul Yang <kaishen.yy@antfin.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28230)
+
+(cherry picked from commit ba2c314a60d9f42d1d2e63ea0f791cc04e03005b)
+---
+ include/openssl/opensslv.h.in | 7 +------
+ 1 file changed, 1 insertion(+), 6 deletions(-)
+
+diff --git a/include/openssl/opensslv.h.in b/include/openssl/opensslv.h.in
+index 3f47a2ac08..d15cce412f 100644
+--- a/include/openssl/opensslv.h.in
++++ b/include/openssl/opensslv.h.in
+@@ -90,16 +90,11 @@ extern "C" {
+ # define OPENSSL_VERSION_TEXT "OpenSSL {- "$config{full_version} $config{release_date}" -}"
+ 
+ /* Synthesize OPENSSL_VERSION_NUMBER with the layout 0xMNN00PPSL */
+-# ifdef OPENSSL_VERSION_PRE_RELEASE
+-#  define _OPENSSL_VERSION_PRE_RELEASE 0x0L
+-# else
+-#  define _OPENSSL_VERSION_PRE_RELEASE 0xfL
+-# endif
+ # define OPENSSL_VERSION_NUMBER          \
+     ( (OPENSSL_VERSION_MAJOR<<28)        \
+       |(OPENSSL_VERSION_MINOR<<20)       \
+       |(OPENSSL_VERSION_PATCH<<4)        \
+-      |_OPENSSL_VERSION_PRE_RELEASE )
++      |{- @config{prerelease} ? "0x0L" : "0xfL" -} )
+ 
+ # ifdef  __cplusplus
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0019-DH-private-key-size-was-one-bit-too-large.patch b/package/libs/openssl/patches/0019-DH-private-key-size-was-one-bit-too-large.patch
new file mode 100644
index 0000000..3b81ab6
--- /dev/null
+++ b/package/libs/openssl/patches/0019-DH-private-key-size-was-one-bit-too-large.patch
@@ -0,0 +1,57 @@
+From bde5b413a79c774882103718fbed4c3474abf3d4 Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Sat, 21 Jun 2025 12:53:56 +0200
+Subject: [PATCH 19/31] DH private key size was one bit too large
+
+In the case when no q parameter was given,
+the function generate_key in dh_key.c did create
+one bit too much, so the priv_key value was exceeding
+the DH group size q = (p-1)/2.
+When the length is used in this case the limit is also
+one bit too high, but for backward compatibility this
+limit was left as is, instead we have to silently reduce
+the value by one.
+
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27870)
+
+(cherry picked from commit d6510d99ae4a8a23f54fdfb1473af6a920da8345)
+---
+ crypto/dh/dh_key.c | 12 +++++++-----
+ 1 file changed, 7 insertions(+), 5 deletions(-)
+
+diff --git a/crypto/dh/dh_key.c b/crypto/dh/dh_key.c
+index afc49f5cdc..6a640fc5c7 100644
+--- a/crypto/dh/dh_key.c
++++ b/crypto/dh/dh_key.c
+@@ -263,7 +263,7 @@ static int generate_key(DH *dh)
+     int ok = 0;
+     int generate_new_key = 0;
+ #ifndef FIPS_MODULE
+-    unsigned l;
++    int l;
+ #endif
+     BN_CTX *ctx = NULL;
+     BIGNUM *pub_key = NULL, *priv_key = NULL;
+@@ -323,11 +323,13 @@ static int generate_key(DH *dh)
+                 goto err;
+ #else
+             if (dh->params.q == NULL) {
+-                /* secret exponent length, must satisfy 2^(l-1) <= p */
+-                if (dh->length != 0
+-                    && dh->length >= BN_num_bits(dh->params.p))
++                /* secret exponent length, must satisfy 2^l < (p-1)/2 */
++                l = BN_num_bits(dh->params.p);
++                if (dh->length >= l)
+                     goto err;
+-                l = dh->length ? dh->length : BN_num_bits(dh->params.p) - 1;
++                l -= 2;
++                if (dh->length != 0 && dh->length < l)
++                    l = dh->length;
+                 if (!BN_priv_rand_ex(priv_key, l, BN_RAND_TOP_ONE,
+                                      BN_RAND_BOTTOM_ANY, 0, ctx))
+                     goto err;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0020-Add-test-coverage-for-PKCS7_TEXT-mode.patch b/package/libs/openssl/patches/0020-Add-test-coverage-for-PKCS7_TEXT-mode.patch
new file mode 100644
index 0000000..bc00e4c
--- /dev/null
+++ b/package/libs/openssl/patches/0020-Add-test-coverage-for-PKCS7_TEXT-mode.patch
@@ -0,0 +1,62 @@
+From cfcb0e1e5daa972bdb33c728359cdaa118e269c3 Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Sun, 10 Aug 2025 18:50:37 +0200
+Subject: [PATCH 20/31] Add test coverage for PKCS7_TEXT mode
+
+This was inspired by the following commit
+9882d389df71 ("crypto/pkcs7/pk7_smime.c: Add BIO_free() to avoid memory leak")
+which discovered a bug in PKCS7_verify(..., PKCS7_TEXT).
+While there is some test coverage for PKCS_verify by
+./test/pkcs7_test.c, there is no test coverage whatsoever
+of the PKCS7_TEXT flag for PKCS7_sign, PKCS7_encrypt and
+PKCS7_decrypt.
+So this adds some test coverage for those functions as well.
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28223)
+
+(cherry picked from commit d582adc672bca4bc71a7766bb692558086efdd69)
+---
+ test/recipes/80-test_cms.t | 17 +++++++++++++++++
+ 1 file changed, 17 insertions(+)
+
+diff --git a/test/recipes/80-test_cms.t b/test/recipes/80-test_cms.t
+index df8e7e6144..8c58152759 100644
+--- a/test/recipes/80-test_cms.t
++++ b/test/recipes/80-test_cms.t
+@@ -83,6 +83,15 @@ my @smime_pkcs7_tests = (
+       \&final_compare
+     ],
+ 
++    [ "signed text content DER format, RSA key",
++      [ "{cmd1}", @prov, "-sign", "-in", $smcont, "-outform", "DER", "-nodetach",
++        "-certfile", $smroot, "-signer", $smrsa1, "-text",
++        "-out", "{output}.cms" ],
++      [ "{cmd2}",  @prov, "-verify", "-in", "{output}.cms", "-inform", "DER",
++        "-text", "-CAfile", $smroot, "-out", "{output}.txt" ],
++      \&final_compare
++    ],
++
+     [ "signed detached content DER format, RSA key",
+       [ "{cmd1}", @prov, "-sign", "-in", $smcont, "-outform", "DER",
+         "-signer", $smrsa1, "-out", "{output}.cms" ],
+@@ -216,6 +225,14 @@ my @smime_pkcs7_tests = (
+       \&final_compare
+     ],
+ 
++    [ "enveloped text content streaming S/MIME format, DES, 1 recipient",
++      [ "{cmd1}", @defaultprov, "-encrypt", "-in", $smcont,
++        "-stream", "-text", "-out", "{output}.cms", $smrsa1 ],
++      [ "{cmd2}", @defaultprov, "-decrypt", "-recip", $smrsa1,
++        "-in", "{output}.cms", "-text", "-out", "{output}.txt" ],
++      \&final_compare
++    ],
++
+     [ "enveloped content test streaming S/MIME format, DES, 3 recipients, 3rd used",
+       [ "{cmd1}", @defaultprov, "-encrypt", "-in", $smcont,
+         "-stream", "-out", "{output}.cms",
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0021-apps-cms.c-add-missing-error-message-on-error-writin.patch b/package/libs/openssl/patches/0021-apps-cms.c-add-missing-error-message-on-error-writin.patch
new file mode 100644
index 0000000..71ba8c6
--- /dev/null
+++ b/package/libs/openssl/patches/0021-apps-cms.c-add-missing-error-message-on-error-writin.patch
@@ -0,0 +1,30 @@
+From 04674ce8c4be6a1a7a10a9cf9ffbca3752146133 Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Mon, 14 Apr 2025 20:08:54 +0200
+Subject: [PATCH 21/31] apps/cms.c: add missing error message on error writing
+ CMS output (ret == 6)
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27567)
+
+(cherry picked from commit 3c7812decde2368168c6cba557ec8c03f973c892)
+---
+ apps/cms.c | 1 +
+ 1 file changed, 1 insertion(+)
+
+diff --git a/apps/cms.c b/apps/cms.c
+index 185396ca7b..6184f7143f 100644
+--- a/apps/cms.c
++++ b/apps/cms.c
+@@ -1246,6 +1246,7 @@ int cms_main(int argc, char **argv)
+             goto end;
+         }
+         if (ret <= 0) {
++            BIO_printf(bio_err, "Error writing CMS output\n");
+             ret = 6;
+             goto end;
+         }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0022-fix-asn1_write_micalg-in-asn_mime.c-on-GostR3411-and.patch b/package/libs/openssl/patches/0022-fix-asn1_write_micalg-in-asn_mime.c-on-GostR3411-and.patch
new file mode 100644
index 0000000..a3cb500
--- /dev/null
+++ b/package/libs/openssl/patches/0022-fix-asn1_write_micalg-in-asn_mime.c-on-GostR3411-and.patch
@@ -0,0 +1,71 @@
+From 236180bf161ff38db89babca2ed3e5e296acc312 Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Sun, 13 Apr 2025 17:21:27 +0200
+Subject: [PATCH 22/31] fix asn1_write_micalg() in asn_mime.c on GostR3411 and
+ SHAKE
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27567)
+
+(cherry picked from commit e4c515833d51a3473078ce0a5da9e184e11d9660)
+---
+ crypto/asn1/asn_mime.c | 22 ++++++++++++++++++----
+ 1 file changed, 18 insertions(+), 4 deletions(-)
+
+diff --git a/crypto/asn1/asn_mime.c b/crypto/asn1/asn_mime.c
+index c50665914e..f744398fd6 100644
+--- a/crypto/asn1/asn_mime.c
++++ b/crypto/asn1/asn_mime.c
+@@ -168,6 +168,19 @@ static int asn1_write_micalg(BIO *out, STACK_OF(X509_ALGOR) *mdalgs)
+             BIO_write(out, ",", 1);
+         write_comma = 1;
+         md_nid = OBJ_obj2nid(sk_X509_ALGOR_value(mdalgs, i)->algorithm);
++
++        /* RFC 8702 does not define a micalg for SHAKE, assuming "shake-<bitlen>" */
++        if (md_nid == NID_shake128) {
++            if (BIO_puts(out, "shake-128") < 0)
++                goto err;
++            continue;
++        }
++        if (md_nid == NID_shake256) {
++            if (BIO_puts(out, "shake-256") < 0)
++                goto err;
++            continue;
++        }
++
+         md = EVP_get_digestbynid(md_nid);
+         if (md && md->md_ctrl) {
+             int rv;
+@@ -204,15 +217,15 @@ static int asn1_write_micalg(BIO *out, STACK_OF(X509_ALGOR) *mdalgs)
+ 
+         case NID_id_GostR3411_94:
+             BIO_puts(out, "gostr3411-94");
+-            goto err;
++            break;
+ 
+         case NID_id_GostR3411_2012_256:
+             BIO_puts(out, "gostr3411-2012-256");
+-            goto err;
++            break;
+ 
+         case NID_id_GostR3411_2012_512:
+             BIO_puts(out, "gostr3411-2012-512");
+-            goto err;
++            break;
+ 
+         default:
+             if (have_unknown) {
+@@ -272,7 +285,8 @@ int SMIME_write_ASN1_ex(BIO *bio, ASN1_VALUE *val, BIO *data, int flags,
+         BIO_printf(bio, "Content-Type: multipart/signed;");
+         BIO_printf(bio, " protocol=\"%ssignature\";", mime_prefix);
+         BIO_puts(bio, " micalg=\"");
+-        asn1_write_micalg(bio, mdalgs);
++        if (!asn1_write_micalg(bio, mdalgs))
++            return 0;
+         BIO_printf(bio, "\"; boundary=\"----%s\"%s%s",
+                    bound, mime_eol, mime_eol);
+         BIO_printf(bio, "This is an S/MIME signed message%s%s",
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0023-d2i_X509.pod-add-missing-doc-of-return-value-of-i2d_.patch b/package/libs/openssl/patches/0023-d2i_X509.pod-add-missing-doc-of-return-value-of-i2d_.patch
new file mode 100644
index 0000000..defdf94
--- /dev/null
+++ b/package/libs/openssl/patches/0023-d2i_X509.pod-add-missing-doc-of-return-value-of-i2d_.patch
@@ -0,0 +1,34 @@
+From b43e6a6a75563c29d7478bca55761f27b3e0fd79 Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Mon, 14 Apr 2025 11:20:18 +0200
+Subject: [PATCH 23/31] d2i_X509.pod: add missing doc of return value of
+ i2d_ASN1_bio_stream()
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/27567)
+
+(cherry picked from commit 4376c9571a3e4729743f5806ee453c704355a030)
+---
+ doc/man3/d2i_X509.pod | 5 +++--
+ 1 file changed, 3 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man3/d2i_X509.pod b/doc/man3/d2i_X509.pod
+index c4b589dd89..34796fb73a 100644
+--- a/doc/man3/d2i_X509.pod
++++ b/doc/man3/d2i_X509.pod
+@@ -500,8 +500,9 @@ freed in the event of error and I<*a> is set to NULL.
+ B<i2d_I<TYPE>>() returns the number of bytes successfully encoded or a negative
+ value if an error occurs.
+ 
+-B<i2d_I<TYPE>_bio>() and B<i2d_I<TYPE>_fp>() return 1 for success and 0 if an
+-error occurs.
++B<i2d_I<TYPE>_bio>() and B<i2d_I<TYPE>_fp>(),
++as well as i2d_ASN1_bio_stream(),
++return 1 for success and 0 if an error occurs.
+ 
+ =head1 EXAMPLES
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0024-BIO_dgram-Fix-BIO_CTRL_DGRAM_QUERY_MTU-for-IPv4-mapp.patch b/package/libs/openssl/patches/0024-BIO_dgram-Fix-BIO_CTRL_DGRAM_QUERY_MTU-for-IPv4-mapp.patch
new file mode 100644
index 0000000..e4c7ba5
--- /dev/null
+++ b/package/libs/openssl/patches/0024-BIO_dgram-Fix-BIO_CTRL_DGRAM_QUERY_MTU-for-IPv4-mapp.patch
@@ -0,0 +1,100 @@
+From 7c593bf97ef08b556da81f17c81b2b0e3645ab80 Mon Sep 17 00:00:00 2001
+From: Nikolas Gauder <nikolas.gauder@tum.de>
+Date: Thu, 24 Jul 2025 22:00:49 +0200
+Subject: [PATCH 24/31] BIO_dgram: Fix BIO_CTRL_DGRAM_QUERY_MTU for IPv4-mapped
+ IPv6 addresses
+
+Ensure the correct IP header size is subtracted by reusing
+dgram_get_mtu_overhead(), which handles address families properly.
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Frederik Wedel-Heinen <fwh.openssl@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28088)
+
+(cherry picked from commit a71b4fae432796a49c3b9d32ae29354b23809c1f)
+---
+ crypto/bio/bss_dgram.c | 25 +++++++++----------------
+ 1 file changed, 9 insertions(+), 16 deletions(-)
+
+diff --git a/crypto/bio/bss_dgram.c b/crypto/bio/bss_dgram.c
+index 8ca1cf64ed..4292d805a1 100644
+--- a/crypto/bio/bss_dgram.c
++++ b/crypto/bio/bss_dgram.c
+@@ -1,5 +1,5 @@
+ /*
+- * Copyright 2005-2022 The OpenSSL Project Authors. All Rights Reserved.
++ * Copyright 2005-2025 The OpenSSL Project Authors. All Rights Reserved.
+  *
+  * Licensed under the Apache License 2.0 (the "License").  You may not use
+  * this file except in compliance with the License.  You can obtain a copy
+@@ -349,11 +349,11 @@ static int dgram_write(BIO *b, const char *in, int inl)
+     return ret;
+ }
+ 
+-static long dgram_get_mtu_overhead(bio_dgram_data *data)
++static long dgram_get_mtu_overhead(BIO_ADDR *addr)
+ {
+     long ret;
+ 
+-    switch (BIO_ADDR_family(&data->peer)) {
++    switch (BIO_ADDR_family(addr)) {
+     case AF_INET:
+         /*
+          * Assume this is UDP - 20 bytes for IP, 8 bytes for UDP
+@@ -365,7 +365,8 @@ static long dgram_get_mtu_overhead(bio_dgram_data *data)
+         {
+ #  ifdef IN6_IS_ADDR_V4MAPPED
+             struct in6_addr tmp_addr;
+-            if (BIO_ADDR_rawaddress(&data->peer, &tmp_addr, NULL)
++
++            if (BIO_ADDR_rawaddress(addr, &tmp_addr, NULL)
+                 && IN6_IS_ADDR_V4MAPPED(&tmp_addr))
+                 /*
+                  * Assume this is UDP - 20 bytes for IP, 8 bytes for UDP
+@@ -492,11 +493,7 @@ static long dgram_ctrl(BIO *b, int cmd, long num, void *ptr)
+                             &sockopt_len)) < 0 || sockopt_val < 0) {
+                 ret = 0;
+             } else {
+-                /*
+-                 * we assume that the transport protocol is UDP and no IP
+-                 * options are used.
+-                 */
+-                data->mtu = sockopt_val - 8 - 20;
++                data->mtu = sockopt_val - dgram_get_mtu_overhead(&addr);
+                 ret = data->mtu;
+             }
+             break;
+@@ -508,11 +505,7 @@ static long dgram_ctrl(BIO *b, int cmd, long num, void *ptr)
+                 || sockopt_val < 0) {
+                 ret = 0;
+             } else {
+-                /*
+-                 * we assume that the transport protocol is UDP and no IPV6
+-                 * options are used.
+-                 */
+-                data->mtu = sockopt_val - 8 - 40;
++                data->mtu = sockopt_val - dgram_get_mtu_overhead(&addr);
+                 ret = data->mtu;
+             }
+             break;
+@@ -526,7 +519,7 @@ static long dgram_ctrl(BIO *b, int cmd, long num, void *ptr)
+ # endif
+         break;
+     case BIO_CTRL_DGRAM_GET_FALLBACK_MTU:
+-        ret = -dgram_get_mtu_overhead(data);
++        ret = -dgram_get_mtu_overhead(&data->peer);
+         switch (BIO_ADDR_family(&data->peer)) {
+         case AF_INET:
+             ret += 576;
+@@ -760,7 +753,7 @@ static long dgram_ctrl(BIO *b, int cmd, long num, void *ptr)
+         }
+         break;
+     case BIO_CTRL_DGRAM_GET_MTU_OVERHEAD:
+-        ret = dgram_get_mtu_overhead(data);
++        ret = dgram_get_mtu_overhead(&data->peer);
+         break;
+ 
+     /*
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0025-Fix-null-pointer-check-in-pkey_dh_derive-to-ensure-b.patch b/package/libs/openssl/patches/0025-Fix-null-pointer-check-in-pkey_dh_derive-to-ensure-b.patch
new file mode 100644
index 0000000..44394d4
--- /dev/null
+++ b/package/libs/openssl/patches/0025-Fix-null-pointer-check-in-pkey_dh_derive-to-ensure-b.patch
@@ -0,0 +1,39 @@
+From 1d83477c666b5a760db40c61aeeb81476309ba8c Mon Sep 17 00:00:00 2001
+From: ritoban23 <ankudutt101@gmail.com>
+Date: Thu, 14 Aug 2025 01:49:17 +0530
+Subject: [PATCH 25/31] Fix null pointer check in pkey_dh_derive to ensure both
+ keys are set
+
+CLA: trivial
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+Reviewed-by: Todd Short <todd.short@me.com>
+(Merged from https://github.com/openssl/openssl/pull/28259)
+
+(cherry picked from commit fc84d46d7227886152be00618889a521e9132ef3)
+(cherry picked from commit 0163c6ad1f7cec08f59e9f736d36073d01ae7ae5)
+(cherry picked from commit 257c3dd6cdbe9b1bde353fa45445b1319de6ffc3)
+(cherry picked from commit eb1e036728bac6e450b2e42372487cf5e3e7a175)
+(cherry picked from commit 1aa1863056c02e4b062010ac2782f8eccc178b23)
+---
+ crypto/dh/dh_pmeth.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/dh/dh_pmeth.c b/crypto/dh/dh_pmeth.c
+index fd6c852302..931e1b88ec 100644
+--- a/crypto/dh/dh_pmeth.c
++++ b/crypto/dh/dh_pmeth.c
+@@ -410,7 +410,7 @@ static int pkey_dh_derive(EVP_PKEY_CTX *ctx, unsigned char *key,
+     }
+     dh = (DH *)EVP_PKEY_get0_DH(ctx->pkey);
+     dhpub = EVP_PKEY_get0_DH(ctx->peerkey);
+-    if (dhpub == NULL) {
++    if (dhpub == NULL || dh == NULL) {
+         ERR_raise(ERR_LIB_DH, DH_R_KEYS_NOT_SET);
+         return 0;
+     }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0026-Fix-Add-free-to-avoid-memory-leak.patch b/package/libs/openssl/patches/0026-Fix-Add-free-to-avoid-memory-leak.patch
new file mode 100644
index 0000000..cb5b9fc
--- /dev/null
+++ b/package/libs/openssl/patches/0026-Fix-Add-free-to-avoid-memory-leak.patch
@@ -0,0 +1,142 @@
+From 53a7773b5d7b458af0e6ca9b64e3d2eead3d771b Mon Sep 17 00:00:00 2001
+From: Nachel72 <Nachel72@outlook.com>
+Date: Sun, 17 Aug 2025 14:08:38 +0800
+Subject: [PATCH 26/31] Fix: Add free to avoid memory leak.
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28289)
+
+(cherry picked from commit f9afb3a07eb72428b98e3e31384380564a236700)
+---
+ demos/bio/saccept.c     | 5 ++++-
+ demos/bio/server-arg.c  | 5 ++++-
+ demos/bio/server-cmod.c | 5 ++++-
+ demos/bio/server-conf.c | 5 ++++-
+ 4 files changed, 16 insertions(+), 4 deletions(-)
+
+diff --git a/demos/bio/saccept.c b/demos/bio/saccept.c
+index 6da22ea440..a539e4de31 100644
+--- a/demos/bio/saccept.c
++++ b/demos/bio/saccept.c
+@@ -49,7 +49,8 @@ int main(int argc, char *argv[])
+ {
+     char *port = NULL;
+     BIO *in = NULL;
+-    BIO *ssl_bio, *tmp;
++    BIO *ssl_bio = NULL;
++    BIO *tmp;
+     SSL_CTX *ctx;
+     char buf[512];
+     int ret = EXIT_FAILURE, i;
+@@ -79,6 +80,7 @@ int main(int argc, char *argv[])
+      * Basically it means the SSL BIO will be automatically setup
+      */
+     BIO_set_accept_bios(in, ssl_bio);
++    ssl_bio = NULL;
+ 
+     /* Arrange to leave server loop on interrupt */
+     sigsetup();
+@@ -117,5 +119,6 @@ int main(int argc, char *argv[])
+     if (ret != EXIT_SUCCESS)
+         ERR_print_errors_fp(stderr);
+     BIO_free(in);
++    BIO_free_all(ssl_bio);
+     return ret;
+ }
+diff --git a/demos/bio/server-arg.c b/demos/bio/server-arg.c
+index 60a87725a9..166e714078 100644
+--- a/demos/bio/server-arg.c
++++ b/demos/bio/server-arg.c
+@@ -23,7 +23,8 @@
+ int main(int argc, char *argv[])
+ {
+     char *port = "*:4433";
+-    BIO *ssl_bio, *tmp;
++    BIO *ssl_bio = NULL;
++    BIO *tmp;
+     SSL_CTX *ctx;
+     SSL_CONF_CTX *cctx;
+     char buf[512];
+@@ -105,6 +106,7 @@ int main(int argc, char *argv[])
+      * Basically it means the SSL BIO will be automatically setup
+      */
+     BIO_set_accept_bios(in, ssl_bio);
++    ssl_bio = NULL;
+ 
+  again:
+     /*
+@@ -140,5 +142,6 @@ int main(int argc, char *argv[])
+     if (ret != EXIT_SUCCESS)
+         ERR_print_errors_fp(stderr);
+     BIO_free(in);
++    BIO_free_all(ssl_bio);
+     return ret;
+ }
+diff --git a/demos/bio/server-cmod.c b/demos/bio/server-cmod.c
+index 3642fbacf6..cb9cb9dc0c 100644
+--- a/demos/bio/server-cmod.c
++++ b/demos/bio/server-cmod.c
+@@ -24,7 +24,8 @@ int main(int argc, char *argv[])
+     unsigned char buf[512];
+     char *port = "*:4433";
+     BIO *in = NULL;
+-    BIO *ssl_bio, *tmp;
++    BIO *ssl_bio = NULL;
++    BIO *tmp;
+     SSL_CTX *ctx;
+     int ret = EXIT_FAILURE, i;
+ 
+@@ -52,6 +53,7 @@ int main(int argc, char *argv[])
+      * Basically it means the SSL BIO will be automatically setup
+      */
+     BIO_set_accept_bios(in, ssl_bio);
++    ssl_bio = NULL;
+ 
+  again:
+     /*
+@@ -90,5 +92,6 @@ int main(int argc, char *argv[])
+     if (ret != EXIT_SUCCESS)
+         ERR_print_errors_fp(stderr);
+     BIO_free(in);
++    BIO_free_all(ssl_bio);
+     return ret;
+ }
+diff --git a/demos/bio/server-conf.c b/demos/bio/server-conf.c
+index 5e07a15e7b..7b8bcf6bff 100644
+--- a/demos/bio/server-conf.c
++++ b/demos/bio/server-conf.c
+@@ -25,7 +25,8 @@ int main(int argc, char *argv[])
+ {
+     char *port = "*:4433";
+     BIO *in = NULL;
+-    BIO *ssl_bio, *tmp;
++    BIO *ssl_bio = NULL;
++    BIO *tmp;
+     SSL_CTX *ctx;
+     SSL_CONF_CTX *cctx = NULL;
+     CONF *conf = NULL;
+@@ -97,6 +98,7 @@ int main(int argc, char *argv[])
+      * Basically it means the SSL BIO will be automatically setup
+      */
+     BIO_set_accept_bios(in, ssl_bio);
++    ssl_bio = NULL;
+ 
+  again:
+     /*
+@@ -135,5 +137,6 @@ int main(int argc, char *argv[])
+     if (ret != EXIT_SUCCESS)
+         ERR_print_errors_fp(stderr);
+     BIO_free(in);
++    BIO_free_all(ssl_bio);
+     return ret;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0027-aes-s390x.pl-Initialize-reserved-and-unused-memory.patch b/package/libs/openssl/patches/0027-aes-s390x.pl-Initialize-reserved-and-unused-memory.patch
new file mode 100644
index 0000000..32147e2
--- /dev/null
+++ b/package/libs/openssl/patches/0027-aes-s390x.pl-Initialize-reserved-and-unused-memory.patch
@@ -0,0 +1,50 @@
+From 247233a459e559ba00e35bad14abeeb13e121bc1 Mon Sep 17 00:00:00 2001
+From: Holger Dengler <dengler@linux.ibm.com>
+Date: Wed, 20 Aug 2025 17:55:43 +0200
+Subject: [PATCH 27/31] aes-s390x.pl: Initialize reserved and unused memory
+
+The reserved bytes in the parameter block (bytes 0-11) for the KMA
+instruction should be set to zero to be compatible in case of future
+architecture changes.
+
+While at it, also the following unused parts of the parameter block
+(bytes 48-63) are also cleared to avoid false positives with various
+memory checkers like valgrind.
+
+As it makes - performance wise - no difference to process 12, 48 or 64
+bytes with one XC call, but two XC calls are slower than one call, the
+first 64 bytes of the parameter block will be cleared with a single XC
+call. This will also initialize the counter in the parameter block
+(bytes 12-15), although it is not strictly necessary.
+
+Co-developed-by: Juergen Christ <jchrist@linux.ibm.com>
+Signed-off-by: Juergen Christ <jchrist@linux.ibm.com>
+Signed-off-by: Holger Dengler <dengler@linux.ibm.com>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28315)
+
+(cherry picked from commit 899623b29caa02f25e069acbcef581d19fe0a64e)
+---
+ crypto/aes/asm/aes-s390x.pl | 3 +++
+ 1 file changed, 3 insertions(+)
+
+diff --git a/crypto/aes/asm/aes-s390x.pl b/crypto/aes/asm/aes-s390x.pl
+index 5d1283f576..8cc21638e7 100644
+--- a/crypto/aes/asm/aes-s390x.pl
++++ b/crypto/aes/asm/aes-s390x.pl
+@@ -1431,6 +1431,9 @@ $code.=<<___ if (!$softonly);
+ 	st${g}	$s3,0($sp)			# backchain
+ 	la	%r1,$stdframe($sp)
+ 
++	xc	$stdframe+0(64,$sp),$stdframe+0($sp)	# clear reserved/unused
++							# in parameter block
++
+ 	lmg	$s2,$s3,0($key)			# copy key
+ 	stg	$s2,$stdframe+80($sp)
+ 	stg	$s3,$stdframe+88($sp)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0028-X509_VERIFY_PARAM_get0-add-check-to-defend-on-out-of.patch b/package/libs/openssl/patches/0028-X509_VERIFY_PARAM_get0-add-check-to-defend-on-out-of.patch
new file mode 100644
index 0000000..211d9cb
--- /dev/null
+++ b/package/libs/openssl/patches/0028-X509_VERIFY_PARAM_get0-add-check-to-defend-on-out-of.patch
@@ -0,0 +1,34 @@
+From 89ce0ef97ef85b4f0b8069ee51a79632320670c9 Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Thu, 28 Aug 2025 18:33:06 +0200
+Subject: [PATCH 28/31] X509_VERIFY_PARAM_get0(): add check to defend on
+ out-of-bound table access
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28404)
+
+(cherry picked from commit 4ed6cfce586f7a78c0e7e3d314c2b785ac16f1a9)
+---
+ crypto/x509/x509_vpm.c | 5 +++++
+ 1 file changed, 5 insertions(+)
+
+diff --git a/crypto/x509/x509_vpm.c b/crypto/x509/x509_vpm.c
+index 998ce8ac1b..c263880495 100644
+--- a/crypto/x509/x509_vpm.c
++++ b/crypto/x509/x509_vpm.c
+@@ -614,6 +614,11 @@ const X509_VERIFY_PARAM *X509_VERIFY_PARAM_get0(int id)
+ {
+     int num = OSSL_NELEM(default_table);
+ 
++    if (id < 0) {
++        ERR_raise(ERR_LIB_X509, ERR_R_PASSED_INVALID_ARGUMENT);
++        return NULL;
++    }
++
+     if (id < num)
+         return default_table + id;
+     return sk_X509_VERIFY_PARAM_value(param_table, id - num);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0029-Don-t-keep-the-store-open-in-by_store_ctrl_ex.patch b/package/libs/openssl/patches/0029-Don-t-keep-the-store-open-in-by_store_ctrl_ex.patch
new file mode 100644
index 0000000..c494dd7
--- /dev/null
+++ b/package/libs/openssl/patches/0029-Don-t-keep-the-store-open-in-by_store_ctrl_ex.patch
@@ -0,0 +1,132 @@
+From c0d968f0ac56ad507ab0101e537e7d530e9f0448 Mon Sep 17 00:00:00 2001
+From: Matt Caswell <matt@openssl.org>
+Date: Thu, 7 Aug 2025 17:50:17 +0100
+Subject: [PATCH 29/31] Don't keep the store open in by_store_ctrl_ex
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Previously #27529 made a change to `by_store_ctrl_ex` in order to open
+the OSSL_STORE early. The reason given in that PR is:
+
+"This way, we can call OSSL_STORE_open_ex() in by_store_ctrl_ex(), and
+get to see possible errors when the URI is loaded"
+
+That PR then kept the store open until cache_objects is called and then
+reused it. Unfortunately by the time cache_objects() is called we could be
+in a multi-threaded scenario where the X509_STORE is being shared by
+multiple threads. We then get a race condition where multiple threads are
+all using (and ultimately closing) the same `OSSL_STORE_CTX`.
+
+The purpose of keeping the `OSSL_STORE` object between by_store_ctrl_ex()
+and `cache_objects` is presumably an optimisation to avoid having to open
+the store twice. But this does not work because of the above issue.
+
+We just take the hit and open it again.
+
+Fixes #28171
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28385)
+---
+ crypto/x509/by_store.c | 26 +++++++++++++-------------
+ 1 file changed, 13 insertions(+), 13 deletions(-)
+
+diff --git a/crypto/x509/by_store.c b/crypto/x509/by_store.c
+index e486fb0a9d..c9ef0b6a4e 100644
+--- a/crypto/x509/by_store.c
++++ b/crypto/x509/by_store.c
+@@ -17,7 +17,6 @@ typedef struct cached_store_st {
+     char *uri;
+     OSSL_LIB_CTX *libctx;
+     char *propq;
+-    OSSL_STORE_CTX *ctx;
+ } CACHED_STORE;
+ 
+ DEFINE_STACK_OF(CACHED_STORE)
+@@ -27,14 +26,12 @@ static int cache_objects(X509_LOOKUP *lctx, CACHED_STORE *store,
+                          const OSSL_STORE_SEARCH *criterion, int depth)
+ {
+     int ok = 0;
+-    OSSL_STORE_CTX *ctx = store->ctx;
++    OSSL_STORE_CTX *ctx;
+     X509_STORE *xstore = X509_LOOKUP_get_store(lctx);
+ 
+-    if (ctx == NULL
+-        && (ctx = OSSL_STORE_open_ex(store->uri, store->libctx, store->propq,
+-                                     NULL, NULL, NULL, NULL, NULL)) == NULL)
++    if ((ctx = OSSL_STORE_open_ex(store->uri, store->libctx, store->propq,
++                                  NULL, NULL, NULL, NULL, NULL)) == NULL)
+         return 0;
+-    store->ctx = ctx;
+ 
+     /*
+      * We try to set the criterion, but don't care if it was valid or not.
+@@ -79,7 +76,6 @@ static int cache_objects(X509_LOOKUP *lctx, CACHED_STORE *store,
+                 substore.uri = (char *)OSSL_STORE_INFO_get0_NAME(info);
+                 substore.libctx = store->libctx;
+                 substore.propq = store->propq;
+-                substore.ctx = NULL;
+                 ok = cache_objects(lctx, &substore, criterion, depth - 1);
+             }
+         } else {
+@@ -105,7 +101,6 @@ static int cache_objects(X509_LOOKUP *lctx, CACHED_STORE *store,
+             break;
+     }
+     OSSL_STORE_close(ctx);
+-    store->ctx = NULL;
+ 
+     return ok;
+ }
+@@ -114,7 +109,6 @@ static int cache_objects(X509_LOOKUP *lctx, CACHED_STORE *store,
+ static void free_store(CACHED_STORE *store)
+ {
+     if (store != NULL) {
+-        OSSL_STORE_close(store->ctx);
+         OPENSSL_free(store->uri);
+         OPENSSL_free(store->propq);
+         OPENSSL_free(store);
+@@ -148,6 +142,7 @@ static int by_store_ctrl_ex(X509_LOOKUP *ctx, int cmd, const char *argp,
+         {
+             STACK_OF(CACHED_STORE) *stores = X509_LOOKUP_get_method_data(ctx);
+             CACHED_STORE *store = OPENSSL_zalloc(sizeof(*store));
++            OSSL_STORE_CTX *sctx;
+ 
+             if (store == NULL) {
+                 return 0;
+@@ -157,14 +152,20 @@ static int by_store_ctrl_ex(X509_LOOKUP *ctx, int cmd, const char *argp,
+             store->libctx = libctx;
+             if (propq != NULL)
+                 store->propq = OPENSSL_strdup(propq);
+-            store->ctx = OSSL_STORE_open_ex(argp, libctx, propq, NULL, NULL,
+-                                           NULL, NULL, NULL);
+-            if (store->ctx == NULL
++            /*
++             * We open this to check for errors now - so we can report those
++             * errors early.
++             */
++            sctx = OSSL_STORE_open_ex(argp, libctx, propq, NULL, NULL,
++                                      NULL, NULL, NULL);
++            if (sctx == NULL
+                 || (propq != NULL && store->propq == NULL)
+                 || store->uri == NULL) {
++                OSSL_STORE_close(sctx);
+                 free_store(store);
+                 return use_default;
+             }
++            OSSL_STORE_close(sctx);
+ 
+             if (stores == NULL) {
+                 stores = sk_CACHED_STORE_new_null();
+@@ -184,7 +185,6 @@ static int by_store_ctrl_ex(X509_LOOKUP *ctx, int cmd, const char *argp,
+         store.uri = (char *)argp;
+         store.libctx = libctx;
+         store.propq = (char *)propq;
+-        store.ctx = NULL;
+         return cache_objects(ctx, &store, NULL, 0);
+     }
+     default:
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0030-Add-a-test-for-accessing-an-X509_STORE-from-multiple.patch b/package/libs/openssl/patches/0030-Add-a-test-for-accessing-an-X509_STORE-from-multiple.patch
new file mode 100644
index 0000000..2945a9f
--- /dev/null
+++ b/package/libs/openssl/patches/0030-Add-a-test-for-accessing-an-X509_STORE-from-multiple.patch
@@ -0,0 +1,187 @@
+From 170f5759fc33d65a8f90272dfa0ee86d9daef26a Mon Sep 17 00:00:00 2001
+From: Matt Caswell <matt@openssl.org>
+Date: Tue, 19 Aug 2025 08:38:07 +0100
+Subject: [PATCH 30/31] Add a test for accessing an X509_STORE from multiple
+ threads
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Check we don't have any threading issues when accessing an X509_STORE
+simultaneously
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28385)
+---
+ .../90-test_threads_data/store/.gitignore     |  3 +
+ .../90-test_threads_data/store/8489a545.0     | 19 ++++++
+ test/threadstest.c                            | 68 +++++++++++++++++--
+ 3 files changed, 84 insertions(+), 6 deletions(-)
+ create mode 100644 test/recipes/90-test_threads_data/store/.gitignore
+ create mode 100644 test/recipes/90-test_threads_data/store/8489a545.0
+
+diff --git a/test/recipes/90-test_threads_data/store/.gitignore b/test/recipes/90-test_threads_data/store/.gitignore
+new file mode 100644
+index 0000000000..9127784286
+--- /dev/null
++++ b/test/recipes/90-test_threads_data/store/.gitignore
+@@ -0,0 +1,3 @@
++#The top level .gitignore ignores certificate files with the .0 extension
++#But we actually want them in this directory, so we override the top level rule
++!*.0
+diff --git a/test/recipes/90-test_threads_data/store/8489a545.0 b/test/recipes/90-test_threads_data/store/8489a545.0
+new file mode 100644
+index 0000000000..7fd65dfe92
+--- /dev/null
++++ b/test/recipes/90-test_threads_data/store/8489a545.0
+@@ -0,0 +1,19 @@
++-----BEGIN CERTIFICATE-----
++MIIDFjCCAf6gAwIBAgIBATANBgkqhkiG9w0BAQsFADASMRAwDgYDVQQDDAdSb290
++IENBMCAXDTIwMTIxMjIwMTEzN1oYDzIxMjAxMjEzMjAxMTM3WjASMRAwDgYDVQQD
++DAdSb290IENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4eYA9Qa8
++oEY4eQ8/HnEZE20C3yubdmv8rLAh7daRCEI7pWM17FJboKJKxdYAlAOXWj25ZyjS
++feMhXKTtxjyNjoTRnVTDPdl0opZ2Z3H5xhpQd7P9eO5b4OOMiSPCmiLsPtQ3ngfN
++wCtVERc6NEIcaQ06GLDtFZRexv2eh8Yc55QaksBfBcFzQ+UD3gmRySTO2I6Lfi7g
++MUjRhipqVSZ66As2Tpex4KTJ2lxpSwOACFaDox+yKrjBTP7FsU3UwAGq7b7OJb3u
++aa32B81uK6GJVPVo65gJ7clgZsszYkoDsGjWDqtfwTVVfv1G7rrr3Laio+2Ff3ff
++tWgiQ35mJCOvxQIDAQABo3UwczAPBgNVHRMBAf8EBTADAQH/MAsGA1UdDwQEAwIB
++BjAdBgNVHQ4EFgQUjvUlrx6ba4Q9fICayVOcTXL3o1IwHwYDVR0jBBgwFoAUjvUl
++rx6ba4Q9fICayVOcTXL3o1IwEwYDVR0lBAwwCgYIKwYBBQUHAwEwDQYJKoZIhvcN
++AQELBQADggEBABWUjaqtkdRDhVAJZTxkJVgohjRrBwp86Y0JZWdCDua/sErmEaGu
++nQVxWWFWIgu6sb8tyQo3/7dBIQl3Rpij9bsgKhToO1OzoG3Oi3d0+zRDHfY6xNrj
++TUE00FeLHGNWsgZSIvu99DrGApT/+uPdWfJgMu5szillqW+4hcCUPLjG9ekVNt1s
++KhdEklo6PrP6eMbm6s22EIVUxqGE6xxAmrvyhlY1zJH9BJ23Ps+xabjG6OeMRZzT
++0F/fU7XIFieSO7rqUcjgo1eYc3ghsDxNUJ6TPBgv5z4SPnstoOBj59rjpJ7Qkpyd
++L17VfEadezat37Cpeha7vGDduCsyMfN4kiw=
++-----END CERTIFICATE-----
+diff --git a/test/threadstest.c b/test/threadstest.c
+index 046a9eb802..c3ab0745fb 100644
+--- a/test/threadstest.c
++++ b/test/threadstest.c
+@@ -30,6 +30,7 @@
+ 
+ static int do_fips = 0;
+ static char *privkey;
++static char *storedir;
+ static char *config_file = NULL;
+ static int multidefault_run = 0;
+ static const char *default_provider[] = { "default", NULL };
+@@ -582,7 +583,6 @@ static int test_multi_default(void)
+ {
+     thread_t thread1, thread2;
+     int testresult = 0;
+-    OSSL_PROVIDER *prov = NULL;
+ 
+     /* Avoid running this test twice */
+     if (multidefault_run) {
+@@ -593,9 +593,6 @@ static int test_multi_default(void)
+ 
+     multi_success = 1;
+     multi_libctx = NULL;
+-    prov = OSSL_PROVIDER_load(multi_libctx, "default");
+-    if (!TEST_ptr(prov))
+-        goto err;
+ 
+     if (!TEST_true(run_thread(&thread1, thread_multi_simple_fetch))
+             || !TEST_true(run_thread(&thread2, thread_multi_simple_fetch)))
+@@ -611,7 +608,6 @@ static int test_multi_default(void)
+     testresult = 1;
+ 
+  err:
+-    OSSL_PROVIDER_unload(prov);
+     return testresult;
+ }
+ 
+@@ -663,6 +659,62 @@ static int test_lib_ctx_load_config(void)
+                            1, default_provider);
+ }
+ 
++static X509_STORE *store = NULL;
++
++static void test_x509_store_by_subject(void)
++{
++    X509_STORE_CTX *ctx;
++    X509_OBJECT *obj = NULL;
++    X509_NAME *name = NULL;
++    int success = 0;
++
++    ctx = X509_STORE_CTX_new();
++    if (!TEST_ptr(ctx))
++        goto err;
++
++    if (!TEST_true(X509_STORE_CTX_init(ctx, store, NULL, NULL)))
++        goto err;
++
++    name = X509_NAME_new();
++    if (!TEST_ptr(name))
++        goto err;
++    if (!TEST_true(X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
++                                              (unsigned char *)"Root CA",
++                                              -1, -1, 0)))
++        goto err;
++    obj = X509_STORE_CTX_get_obj_by_subject(ctx, X509_LU_X509, name);
++    if (!TEST_ptr(obj))
++        goto err;
++
++    success = 1;
++ err:
++    X509_OBJECT_free(obj);
++    X509_STORE_CTX_free(ctx);
++    X509_NAME_free(name);
++    if (!success)
++        multi_success = 0;
++}
++
++/* Test accessing an X509_STORE from multiple threads */
++static int test_x509_store(void)
++{
++    int ret = 0;
++
++    store = X509_STORE_new();
++    if (!TEST_ptr(store))
++        return 0;
++    if (!TEST_true(X509_STORE_load_store(store, storedir)))
++        goto err;
++
++    ret = thread_run_test(&test_x509_store_by_subject, MAXIMUM_THREADS,
++                          &test_x509_store_by_subject, 0, NULL);
++
++ err:
++    X509_STORE_free(store);
++    store = NULL;
++    return ret;
++}
++
+ typedef enum OPTION_choice {
+     OPT_ERR = -1,
+     OPT_EOF = 0,
+@@ -709,20 +761,24 @@ int setup_tests(void)
+     if (!TEST_ptr(privkey))
+         return 0;
+ 
++    storedir = test_mk_file_path(datadir, "store");
++
+     /* Keep first to validate auto creation of default library context */
+     ADD_TEST(test_multi_default);
+-
+     ADD_TEST(test_lock);
+     ADD_TEST(test_once);
+     ADD_TEST(test_thread_local);
+     ADD_TEST(test_atomic);
+     ADD_TEST(test_multi_load);
++
+     ADD_ALL_TESTS(test_multi, 6);
+     ADD_TEST(test_lib_ctx_load_config);
++    ADD_TEST(test_x509_store);
+     return 1;
+ }
+ 
+ void cleanup_tests(void)
+ {
+     OPENSSL_free(privkey);
++    OPENSSL_free(storedir);
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0031-Fix-a-race-in-by_store_subject.patch b/package/libs/openssl/patches/0031-Fix-a-race-in-by_store_subject.patch
new file mode 100644
index 0000000..03ddd37
--- /dev/null
+++ b/package/libs/openssl/patches/0031-Fix-a-race-in-by_store_subject.patch
@@ -0,0 +1,44 @@
+From c87359d22f5e92964976a91b17bda68b131b4ecc Mon Sep 17 00:00:00 2001
+From: Matt Caswell <matt@openssl.org>
+Date: Tue, 19 Aug 2025 13:27:50 +0100
+Subject: [PATCH 31/31] Fix a race in by_store_subject
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+When looking in the stack of objects in the store we need to ensure we
+are holding a read lock for the store.
+
+Issue detected via thread sanitizer after the test from the previous
+commit was added.
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28385)
+---
+ crypto/x509/by_store.c | 8 +++++++-
+ 1 file changed, 7 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/x509/by_store.c b/crypto/x509/by_store.c
+index c9ef0b6a4e..a00fc2c735 100644
+--- a/crypto/x509/by_store.c
++++ b/crypto/x509/by_store.c
+@@ -230,8 +230,14 @@ static int by_store_subject(X509_LOOKUP *ctx, X509_LOOKUP_TYPE type,
+ 
+     OSSL_STORE_SEARCH_free(criterion);
+ 
+-    if (ok)
++    if (ok) {
++        X509_STORE *store = X509_LOOKUP_get_store(ctx);
++
++        if (!X509_STORE_lock(store))
++            return 0;
+         tmp = X509_OBJECT_retrieve_by_subject(store_objects, type, name);
++        X509_STORE_unlock(store);
++    }
+ 
+     ok = 0;
+     if (tmp != NULL) {
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

