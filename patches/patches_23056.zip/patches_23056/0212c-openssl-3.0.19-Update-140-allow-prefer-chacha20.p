diff --git a/package/libs/openssl/patches/140-allow-prefer-chacha20.patch b/package/libs/openssl/patches/140-allow-prefer-chacha20.patch
index fb7bc84..84e7bad 100644
--- a/package/libs/openssl/patches/140-allow-prefer-chacha20.patch
+++ b/package/libs/openssl/patches/140-allow-prefer-chacha20.patch
@@ -18,7 +18,7 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
 +++ b/ssl/ssl_ciph.c
 @@ -1506,11 +1506,29 @@ STACK_OF(SSL_CIPHER) *ssl_create_cipher_
      ssl_cipher_apply_rule(0, SSL_kECDHE, 0, 0, 0, 0, 0, CIPHER_DEL, -1, &head,
-                           &tail);
+         &tail);
  
 +    /*
 +     * If OPENSSL_PREFER_CHACHA_OVER_GCM is defined, ChaCha20_Poly1305
@@ -33,15 +33,15 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
 +
 +#ifdef OPENSSL_PREFER_CHACHA_OVER_GCM
 +    ssl_cipher_apply_rule(0, 0, 0, SSL_CHACHA20, 0, 0, 0, CIPHER_ADD, -1,
-+                          &head, &tail);
++        &head, &tail);
 +    ssl_cipher_apply_rule(0, 0, 0, SSL_AESGCM, 0, 0, 0, CIPHER_ADD, -1,
-+                          &head, &tail);
++        &head, &tail);
 +#else
      /* Within each strength group, we prefer GCM over CHACHA... */
      ssl_cipher_apply_rule(0, 0, 0, SSL_AESGCM, 0, 0, 0, CIPHER_ADD, -1,
-                           &head, &tail);
+         &head, &tail);
      ssl_cipher_apply_rule(0, 0, 0, SSL_CHACHA20, 0, 0, 0, CIPHER_ADD, -1,
-                           &head, &tail);
+         &head, &tail);
 +#endif
  
      /*
@@ -75,18 +75,18 @@ Signed-off-by: Eneas U de Queiroz <cote2004-github@yahoo.com>
   * DEPRECATED IN 3.0.0, in favor of OSSL_default_ciphersuites()
   * Update both macro and function simultaneously
   */
--#  define TLS_DEFAULT_CIPHERSUITES "TLS_AES_256_GCM_SHA384:" \
--                                   "TLS_CHACHA20_POLY1305_SHA256:" \
--                                   "TLS_AES_128_GCM_SHA256"
-+#  ifdef OPENSSL_PREFER_CHACHA_OVER_GCM
-+#   define TLS_DEFAULT_CIPHERSUITES "TLS_CHACHA20_POLY1305_SHA256:" \
-+                                    "TLS_AES_256_GCM_SHA384:" \
-+                                    "TLS_AES_128_GCM_SHA256"
-+#  else
-+#   define TLS_DEFAULT_CIPHERSUITES "TLS_AES_256_GCM_SHA384:" \
-+                                    "TLS_CHACHA20_POLY1305_SHA256:" \
-+                                    "TLS_AES_128_GCM_SHA256"
-+#  endif
- # endif
+-#define TLS_DEFAULT_CIPHERSUITES "TLS_AES_256_GCM_SHA384:"       \
+-                                 "TLS_CHACHA20_POLY1305_SHA256:" \
+-                                 "TLS_AES_128_GCM_SHA256"
++#ifdef OPENSSL_PREFER_CHACHA_OVER_GCM
++#define TLS_DEFAULT_CIPHERSUITES "TLS_CHACHA20_POLY1305_SHA256:" \
++                                 "TLS_AES_256_GCM_SHA384:"       \
++                                 "TLS_AES_128_GCM_SHA256"
++#else
++#define TLS_DEFAULT_CIPHERSUITES "TLS_AES_256_GCM_SHA384:"       \
++                                 "TLS_CHACHA20_POLY1305_SHA256:" \
++                                 "TLS_AES_128_GCM_SHA256"
++#endif
+ #endif
  /*
   * As of OpenSSL 1.0.0, ssl_create_cipher_list() in ssl/ssl_ciph.c always
--
2.46.2.windows.1

