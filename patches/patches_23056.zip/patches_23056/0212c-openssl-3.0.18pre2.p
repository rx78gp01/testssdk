diff --git a/package/libs/openssl/patches/0032-apps-enc.c-avoid-signed-integer-overflow-on-bufsize-.patch b/package/libs/openssl/patches/0032-apps-enc.c-avoid-signed-integer-overflow-on-bufsize-.patch
new file mode 100644
index 0000000..3e3563a
--- /dev/null
+++ b/package/libs/openssl/patches/0032-apps-enc.c-avoid-signed-integer-overflow-on-bufsize-.patch
@@ -0,0 +1,54 @@
+From d51cf71869f39a68d44ab4bde077913c9f9295b3 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 1 Sep 2025 14:05:33 +0200
+Subject: [PATCH 32/46] apps/enc.c: avoid signed integer overflow on bufsize
+ assignment
+
+The calculated option value, while being long-typed, is not checked
+for fitting into int-sized bufsize.  Avoid overflow by throwing error
+if it is bigger than INT_MAX and document that behaviour.
+
+Fixes: 7e1b7485706c "Big apps cleanup (option-parsing, etc)"
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665149
+References: https://github.com/openssl/project/issues/1362
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28408)
+
+(cherry picked from commit 98cb959999e4db9be524a972dccaf6b0c8167431)
+---
+ apps/enc.c                  | 2 ++
+ doc/man1/openssl-enc.pod.in | 1 +
+ 2 files changed, 3 insertions(+)
+
+diff --git a/apps/enc.c b/apps/enc.c
+index c275046cf5..bda719b915 100644
+--- a/apps/enc.c
++++ b/apps/enc.c
+@@ -234,6 +234,8 @@ int enc_main(int argc, char **argv)
+                 goto opthelp;
+             if (k)
+                 n *= 1024;
++            if (n > INT_MAX)
++                goto opthelp;
+             bsize = (int)n;
+             break;
+         case OPT_K:
+diff --git a/doc/man1/openssl-enc.pod.in b/doc/man1/openssl-enc.pod.in
+index a47e783e2d..4612ab0a7e 100644
+--- a/doc/man1/openssl-enc.pod.in
++++ b/doc/man1/openssl-enc.pod.in
+@@ -183,6 +183,7 @@ or decryption.
+ =item B<-bufsize> I<number>
+ 
+ Set the buffer size for I/O.
++The maximum size that can be specified is B<2^31-1> (2147483647) bytes.
+ 
+ =item B<-nopad>
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0033-doc-man1-openssl-enc.pod.in-document-k-handling-for-.patch b/package/libs/openssl/patches/0033-doc-man1-openssl-enc.pod.in-document-k-handling-for-.patch
new file mode 100644
index 0000000..74ec4bc
--- /dev/null
+++ b/package/libs/openssl/patches/0033-doc-man1-openssl-enc.pod.in-document-k-handling-for-.patch
@@ -0,0 +1,44 @@
+From d69ea5bb0d1b655138568999e16fc32ed35f02a4 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 1 Sep 2025 14:08:08 +0200
+Subject: [PATCH 33/46] doc/man1/openssl-enc.pod.in: document 'k' handling for
+ -bufsize
+
+Apparently, '-bufsize' option parser can handle the 'k' suffix
+(and treat is as the value being provided in the multiples of 1024).
+Document that.
+
+Complements: d02b48c63a58 "Import of old SSLeay release: SSLeay 0.8.1b"
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28408)
+
+(cherry picked from commit 05902818236f65de43c48d60353f989530a5e7b9)
+---
+ doc/man1/openssl-enc.pod.in | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/doc/man1/openssl-enc.pod.in b/doc/man1/openssl-enc.pod.in
+index 4612ab0a7e..194f6890f1 100644
+--- a/doc/man1/openssl-enc.pod.in
++++ b/doc/man1/openssl-enc.pod.in
+@@ -180,10 +180,12 @@ Print out the key and IV used.
+ Print out the key and IV used then immediately exit: don't do any encryption
+ or decryption.
+ 
+-=item B<-bufsize> I<number>
++=item B<-bufsize> I<number>[B<k>]
+ 
+ Set the buffer size for I/O.
+ The maximum size that can be specified is B<2^31-1> (2147483647) bytes.
++The B<k> suffix can be specified to indicate that I<number> is provided
++in kibibytes (multiples of 1024 bytes).
+ 
+ =item B<-nopad>
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0034-crypto-x509-t_req.c-avoid-exts-leaking-on-error-path.patch b/package/libs/openssl/patches/0034-crypto-x509-t_req.c-avoid-exts-leaking-on-error-path.patch
new file mode 100644
index 0000000..12db463
--- /dev/null
+++ b/package/libs/openssl/patches/0034-crypto-x509-t_req.c-avoid-exts-leaking-on-error-path.patch
@@ -0,0 +1,58 @@
+From a526582d1b3224ee43187f7a23836b130146c6a9 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 1 Sep 2025 16:34:34 +0200
+Subject: [PATCH 34/46] crypto/x509/t_req.c: avoid exts leaking on error paths
+
+If an error occurred and jump to the "err" label is performed after
+exts has been allocated, it can leak.  Avoid that by adding
+sk_X509_EXTENSION_pop_free() on the error path and setting exts to NULL
+after sk_X509_EXTENSION_pop_free() in the normal handling.
+
+Fixes: ae880ae6719e "Fix error handling in X509_REQ_print_ex"
+Fixes: 87c49f622e7f "Support for parsing of certificate extensions in PKCS#10 requests: these are"
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665161
+References: https://github.com/openssl/project/issues/1362
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28408)
+
+(cherry picked from commit 3b83a7183c71395cdc70eacddce21f4d2d9d2b88)
+---
+ crypto/x509/t_req.c | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/x509/t_req.c b/crypto/x509/t_req.c
+index 63626c0d98..1c5f41d676 100644
+--- a/crypto/x509/t_req.c
++++ b/crypto/x509/t_req.c
+@@ -40,7 +40,7 @@ int X509_REQ_print_ex(BIO *bp, X509_REQ *x, unsigned long nmflags,
+     long l;
+     int i;
+     EVP_PKEY *pkey;
+-    STACK_OF(X509_EXTENSION) *exts;
++    STACK_OF(X509_EXTENSION) *exts = NULL;
+     char mlch = ' ';
+     int nmindent = 0, printok = 0;
+ 
+@@ -191,6 +191,7 @@ int X509_REQ_print_ex(BIO *bp, X509_REQ *x, unsigned long nmflags,
+                     goto err;
+             }
+             sk_X509_EXTENSION_pop_free(exts, X509_EXTENSION_free);
++            exts = NULL;
+         }
+     }
+ 
+@@ -204,6 +205,7 @@ int X509_REQ_print_ex(BIO *bp, X509_REQ *x, unsigned long nmflags,
+ 
+     return 1;
+  err:
++    sk_X509_EXTENSION_pop_free(exts, X509_EXTENSION_free);
+     ERR_raise(ERR_LIB_X509, ERR_R_BUF_LIB);
+     return 0;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0035-apps-ocsp.c-avoid-using-NULL-resp.patch b/package/libs/openssl/patches/0035-apps-ocsp.c-avoid-using-NULL-resp.patch
new file mode 100644
index 0000000..325c05f
--- /dev/null
+++ b/package/libs/openssl/patches/0035-apps-ocsp.c-avoid-using-NULL-resp.patch
@@ -0,0 +1,69 @@
+From 6275039f099f5f09be7d4d82ecd8f7e332c5ef35 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 1 Sep 2025 16:42:15 +0200
+Subject: [PATCH 35/46] apps/ocsp.c: avoid using NULL resp
+
+There are some code paths where resp is used without a previous check
+for being non-NULL (specifically, OCSP_response_create() can return
+NULL, and do_responder() can return -1, that would also lead to resp
+being NULL).  Avoid hitting NULL dereferences by wrapping the code that
+uses resp in "if (resp != NULL)".
+
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665155
+References: https://github.com/openssl/project/issues/1362
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28408)
+
+(cherry picked from commit e59fa197bafa0dbbff33ce2dee772539a6e70e9e)
+---
+ apps/ocsp.c | 21 ++++++++++++---------
+ 1 file changed, 12 insertions(+), 9 deletions(-)
+
+diff --git a/apps/ocsp.c b/apps/ocsp.c
+index 26340805c2..355adf92bf 100644
+--- a/apps/ocsp.c
++++ b/apps/ocsp.c
+@@ -666,7 +666,8 @@ redo_accept:
+                 resp =
+                     OCSP_response_create(OCSP_RESPONSE_STATUS_MALFORMEDREQUEST,
+                                          NULL);
+-                send_ocsp_response(cbio, resp);
++                if (resp != NULL)
++                    send_ocsp_response(cbio, resp);
+             }
+             goto done_resp;
+         }
+@@ -764,16 +765,18 @@ redo_accept:
+         BIO_free(derbio);
+     }
+ 
+-    i = OCSP_response_status(resp);
+-    if (i != OCSP_RESPONSE_STATUS_SUCCESSFUL) {
+-        BIO_printf(out, "Responder Error: %s (%d)\n",
+-                   OCSP_response_status_str(i), i);
+-        if (!ignore_err)
++    if (resp != NULL) {
++        i = OCSP_response_status(resp);
++        if (i != OCSP_RESPONSE_STATUS_SUCCESSFUL) {
++            BIO_printf(out, "Responder Error: %s (%d)\n",
++                       OCSP_response_status_str(i), i);
++            if (!ignore_err)
+                 goto end;
+-    }
++        }
+ 
+-    if (resp_text)
+-        OCSP_RESPONSE_print(out, resp, 0);
++        if (resp_text)
++            OCSP_RESPONSE_print(out, resp, 0);
++    }
+ 
+     /* If running as responder don't verify our own response */
+     if (cbio != NULL) {
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0036-hmac-stop-using-secure-memory-for-the-HMAC-key.patch b/package/libs/openssl/patches/0036-hmac-stop-using-secure-memory-for-the-HMAC-key.patch
new file mode 100644
index 0000000..db23c4a
--- /dev/null
+++ b/package/libs/openssl/patches/0036-hmac-stop-using-secure-memory-for-the-HMAC-key.patch
@@ -0,0 +1,73 @@
+From 6d689012dd64cfb3f370b9e4f558a9bacd5b885b Mon Sep 17 00:00:00 2001
+From: Pauli <ppzgs1@gmail.com>
+Date: Tue, 2 Sep 2025 08:48:06 +1000
+Subject: [PATCH 36/46] hmac: stop using secure memory for the HMAC key
+
+Secure memory is design for long term storage of private material.
+HMAC keys are not this.
+
+Secure memory use was introduced in July 2020 by commit
+3fddbb264e87a8cef2903cbd7b02b8e1a39a2a99.
+
+Fixes #28346
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28412)
+
+(cherry picked from commit 8e3c76085fd163e2d0c4d54ac8105407c54daff6)
+---
+ providers/implementations/macs/hmac_prov.c | 16 +++++++++-------
+ 1 file changed, 9 insertions(+), 7 deletions(-)
+
+diff --git a/providers/implementations/macs/hmac_prov.c b/providers/implementations/macs/hmac_prov.c
+index 52ebb08b8f..b050d9007f 100644
+--- a/providers/implementations/macs/hmac_prov.c
++++ b/providers/implementations/macs/hmac_prov.c
+@@ -94,7 +94,7 @@ static void hmac_free(void *vmacctx)
+     if (macctx != NULL) {
+         HMAC_CTX_free(macctx->ctx);
+         ossl_prov_digest_reset(&macctx->digest);
+-        OPENSSL_secure_clear_free(macctx->key, macctx->keylen);
++        OPENSSL_clear_free(macctx->key, macctx->keylen);
+         OPENSSL_free(macctx);
+     }
+ }
+@@ -123,13 +123,13 @@ static void *hmac_dup(void *vsrc)
+         return NULL;
+     }
+     if (src->key != NULL) {
+-        /* There is no "secure" OPENSSL_memdup */
+-        dst->key = OPENSSL_secure_malloc(src->keylen > 0 ? src->keylen : 1);
++        dst->key = OPENSSL_malloc(src->keylen > 0 ? src->keylen : 1);
+         if (dst->key == NULL) {
+             hmac_free(dst);
+             return 0;
+         }
+-        memcpy(dst->key, src->key, src->keylen);
++        if (src->keylen > 0)
++            memcpy(dst->key, src->key, src->keylen);
+     }
+     return dst;
+ }
+@@ -154,12 +154,14 @@ static int hmac_setkey(struct hmac_data_st *macctx,
+     const EVP_MD *digest;
+ 
+     if (macctx->key != NULL)
+-        OPENSSL_secure_clear_free(macctx->key, macctx->keylen);
++        OPENSSL_clear_free(macctx->key, macctx->keylen);
+     /* Keep a copy of the key in case we need it for TLS HMAC */
+-    macctx->key = OPENSSL_secure_malloc(keylen > 0 ? keylen : 1);
++    macctx->key = OPENSSL_malloc(keylen > 0 ? keylen : 1);
+     if (macctx->key == NULL)
+         return 0;
+-    memcpy(macctx->key, key, keylen);
++
++    if (keylen > 0)
++        memcpy(macctx->key, key, keylen);
+     macctx->keylen = keylen;
+ 
+     digest = ossl_prov_digest_md(&macctx->digest);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0037-apps-remove-chopup_args.patch b/package/libs/openssl/patches/0037-apps-remove-chopup_args.patch
new file mode 100644
index 0000000..ffcb1e5
--- /dev/null
+++ b/package/libs/openssl/patches/0037-apps-remove-chopup_args.patch
@@ -0,0 +1,96 @@
+From 416c27e09991bf53a6522e885732eb53300a0a1a Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Thu, 4 Sep 2025 16:37:02 +0200
+Subject: [PATCH 37/46] apps: remove chopup_args()
+
+The last (and only?) user has been removed in commit eca471391378 "APPS:
+Drop interactive mode in the 'openssl' program".
+
+Complements: eca471391378 "APPS: Drop interactive mode in the 'openssl' program"
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Dmitry Belyavskiy <beldmit@gmail.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28441)
+
+(cherry picked from commit 3f77491cb336df843984139fbb6fb16f47daf876)
+---
+ apps/include/apps.h |  1 -
+ apps/lib/apps.c     | 48 ---------------------------------------------
+ 2 files changed, 49 deletions(-)
+
+diff --git a/apps/include/apps.h b/apps/include/apps.h
+index baacd0025d..d63b33f1b9 100644
+--- a/apps/include/apps.h
++++ b/apps/include/apps.h
+@@ -94,7 +94,6 @@ typedef struct args_st {
+ /* We need both wrap and the "real" function because libcrypto uses both. */
+ int wrap_password_callback(char *buf, int bufsiz, int verify, void *cb_data);
+ 
+-int chopup_args(ARGS *arg, char *buf);
+ void dump_cert_text(BIO *out, X509 *x);
+ void print_name(BIO *out, const char *title, const X509_NAME *nm);
+ void print_bignum_var(BIO *, const BIGNUM *, const char*,
+diff --git a/apps/lib/apps.c b/apps/lib/apps.c
+index b4c4148c2e..ea827464dd 100644
+--- a/apps/lib/apps.c
++++ b/apps/lib/apps.c
+@@ -90,54 +90,6 @@ int load_key_certs_crls_suppress(const char *uri, int format, int maybe_stdin,
+ 
+ int app_init(long mesgwin);
+ 
+-int chopup_args(ARGS *arg, char *buf)
+-{
+-    int quoted;
+-    char c = '\0', *p = NULL;
+-
+-    arg->argc = 0;
+-    if (arg->size == 0) {
+-        arg->size = 20;
+-        arg->argv = app_malloc(sizeof(*arg->argv) * arg->size, "argv space");
+-    }
+-
+-    for (p = buf;;) {
+-        /* Skip whitespace. */
+-        while (*p && isspace(_UC(*p)))
+-            p++;
+-        if (*p == '\0')
+-            break;
+-
+-        /* The start of something good :-) */
+-        if (arg->argc >= arg->size) {
+-            char **tmp;
+-            arg->size += 20;
+-            tmp = OPENSSL_realloc(arg->argv, sizeof(*arg->argv) * arg->size);
+-            if (tmp == NULL)
+-                return 0;
+-            arg->argv = tmp;
+-        }
+-        quoted = *p == '\'' || *p == '"';
+-        if (quoted)
+-            c = *p++;
+-        arg->argv[arg->argc++] = p;
+-
+-        /* now look for the end of this */
+-        if (quoted) {
+-            while (*p && *p != c)
+-                p++;
+-            *p++ = '\0';
+-        } else {
+-            while (*p && !isspace(_UC(*p)))
+-                p++;
+-            if (*p)
+-                *p++ = '\0';
+-        }
+-    }
+-    arg->argv[arg->argc] = NULL;
+-    return 1;
+-}
+-
+ #ifndef APP_INIT
+ int app_init(long mesgwin)
+ {
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0038-docs-Be-case-specific-with-links-to-man-headers.patch b/package/libs/openssl/patches/0038-docs-Be-case-specific-with-links-to-man-headers.patch
new file mode 100644
index 0000000..1e43987
--- /dev/null
+++ b/package/libs/openssl/patches/0038-docs-Be-case-specific-with-links-to-man-headers.patch
@@ -0,0 +1,75 @@
+From 918d1724425232722e2038bebebe1fe7482a4e90 Mon Sep 17 00:00:00 2001
+From: Norbert Pocs <norbertp@openssl.org>
+Date: Wed, 27 Aug 2025 15:45:45 +0200
+Subject: [PATCH 38/46] docs: Be case specific with links to man headers
+
+Signed-off-by: Norbert Pocs <norbertp@openssl.org>
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28356)
+
+(cherry picked from commit 56ce30abb7bdf88a020557e70e0489eff541d097)
+---
+ doc/man3/EVP_EncryptInit.pod  | 2 +-
+ doc/man3/EVP_aes_128_gcm.pod  | 2 +-
+ doc/man3/EVP_aria_128_gcm.pod | 2 +-
+ doc/man3/EVP_chacha20.pod     | 2 +-
+ 4 files changed, 4 insertions(+), 4 deletions(-)
+
+diff --git a/doc/man3/EVP_EncryptInit.pod b/doc/man3/EVP_EncryptInit.pod
+index a4635f994c..5cee56e418 100644
+--- a/doc/man3/EVP_EncryptInit.pod
++++ b/doc/man3/EVP_EncryptInit.pod
+@@ -744,7 +744,7 @@ See also EVP_CIPHER_CTX_get_key_length() and EVP_CIPHER_CTX_set_key_length().
+ =item "tag" (B<OSSL_CIPHER_PARAM_AEAD_TAG>) <octet string>
+ 
+ Gets or sets the AEAD tag for the associated cipher context I<ctx>.
+-See L<EVP_EncryptInit(3)/AEAD Interface>.
++See L<EVP_EncryptInit(3)/AEAD INTERFACE>.
+ 
+ =item "keybits" (B<OSSL_CIPHER_PARAM_RC2_KEYBITS>) <unsigned integer>
+ 
+diff --git a/doc/man3/EVP_aes_128_gcm.pod b/doc/man3/EVP_aes_128_gcm.pod
+index 485705ea78..707c1bd90b 100644
+--- a/doc/man3/EVP_aes_128_gcm.pod
++++ b/doc/man3/EVP_aes_128_gcm.pod
+@@ -127,7 +127,7 @@ EVP_aes_256_ocb()
+ 
+ AES for 128, 192 and 256 bit keys in CBC-MAC Mode (CCM), Galois Counter Mode
+ (GCM) and OCB Mode respectively. These ciphers require additional control
+-operations to function correctly, see the L<EVP_EncryptInit(3)/AEAD Interface>
++operations to function correctly, see the L<EVP_EncryptInit(3)/AEAD INTERFACE>
+ section for details.
+ 
+ =item EVP_aes_128_wrap(),
+diff --git a/doc/man3/EVP_aria_128_gcm.pod b/doc/man3/EVP_aria_128_gcm.pod
+index 91aa75ec38..9a8f9abb76 100644
+--- a/doc/man3/EVP_aria_128_gcm.pod
++++ b/doc/man3/EVP_aria_128_gcm.pod
+@@ -88,7 +88,7 @@ EVP_aria_256_gcm(),
+ 
+ ARIA for 128, 192 and 256 bit keys in CBC-MAC Mode (CCM) and Galois Counter
+ Mode (GCM). These ciphers require additional control operations to function
+-correctly, see the L<EVP_EncryptInit(3)/AEAD Interface> section for details.
++correctly, see the L<EVP_EncryptInit(3)/AEAD INTERFACE> section for details.
+ 
+ =back
+ 
+diff --git a/doc/man3/EVP_chacha20.pod b/doc/man3/EVP_chacha20.pod
+index 7e80c8de40..54fb5a49f8 100644
+--- a/doc/man3/EVP_chacha20.pod
++++ b/doc/man3/EVP_chacha20.pod
+@@ -36,7 +36,7 @@ With an initial counter of 42 (2a in hex) would be expressed as:
+ Authenticated encryption with ChaCha20-Poly1305. Like EVP_chacha20(), the key
+ is 256 bits and the IV is 96 bits. This supports additional authenticated data
+ (AAD) and produces a 128-bit authentication tag. See the
+-L<EVP_EncryptInit(3)/AEAD Interface> section for more information.
++L<EVP_EncryptInit(3)/AEAD INTERFACE> section for more information.
+ 
+ =back
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0039-doc-Update-documentation-of-SSL_CTX_set_dh_auto.patch b/package/libs/openssl/patches/0039-doc-Update-documentation-of-SSL_CTX_set_dh_auto.patch
new file mode 100644
index 0000000..5d88ae3
--- /dev/null
+++ b/package/libs/openssl/patches/0039-doc-Update-documentation-of-SSL_CTX_set_dh_auto.patch
@@ -0,0 +1,41 @@
+From 42d539b9318787d65a4ce3545b7d820ba40cb5a4 Mon Sep 17 00:00:00 2001
+From: Ryan Hooper <ryhooper@cisco.com>
+Date: Thu, 28 Aug 2025 09:12:39 -0400
+Subject: [PATCH 39/46] doc: Update documentation of SSL_CTX_set_dh_auto()
+
+Update the documentation of the dh_tmp_auto argument in
+regards to its behavior when the argument value is 2.
+
+Fixes #27606
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28366)
+
+(cherry picked from commit 7600608eab0cd0a633e4d989d634590831b48a5d)
+---
+ doc/man3/SSL_CTX_set_tmp_dh_callback.pod | 8 +++++---
+ 1 file changed, 5 insertions(+), 3 deletions(-)
+
+diff --git a/doc/man3/SSL_CTX_set_tmp_dh_callback.pod b/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
+index 4799ada684..b4a35318fa 100644
+--- a/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
++++ b/doc/man3/SSL_CTX_set_tmp_dh_callback.pod
+@@ -58,9 +58,11 @@ the actual key is newly generated during the negotiation.
+ Typically applications should use well known DH parameters that have built-in
+ support in OpenSSL. The macros SSL_CTX_set_dh_auto() and SSL_set_dh_auto()
+ configure OpenSSL to use the default built-in DH parameters for the B<SSL_CTX>
+-and B<SSL> objects respectively. Passing a value of 1 in the I<onoff> parameter
+-switches the feature on, and passing a value of 0 switches it off. The default
+-setting is off.
++and B<SSL> objects respectively. Passing a value of 2 or 1 in the I<onoff>
++parameter switches it on. If the I<onoff> parameter is set to 2, it will force
++the DH key size to 1024 if the B<SSL_CTX> or B<SSL> security level
++L<SSL_CTX_set_security_level(3)> is 0 or 1. Passing a value of 0 switches
++it off. The default setting is off.
+ 
+ If "auto" DH parameters are switched on then the parameters will be selected to
+ be consistent with the size of the key associated with the server's certificate.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0040-Fix-typo-in-BN_generate_prime-docs.patch b/package/libs/openssl/patches/0040-Fix-typo-in-BN_generate_prime-docs.patch
new file mode 100644
index 0000000..9122507
--- /dev/null
+++ b/package/libs/openssl/patches/0040-Fix-typo-in-BN_generate_prime-docs.patch
@@ -0,0 +1,42 @@
+From ca495584f492d7c7ccea58f98081cf786bbeafee Mon Sep 17 00:00:00 2001
+From: Viperinius <41393831+Viperinius@users.noreply.github.com>
+Date: Sun, 31 Aug 2025 16:09:11 +0000
+Subject: [PATCH 40/46] Fix typo in BN_generate_prime docs
+
+CLA: trivial
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Kurt Roeckx <kurt@roeckx.be>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28395)
+
+(cherry picked from commit b64ac3cb8330d417a7fa859fe74e0bd41805a6db)
+---
+ doc/man3/BN_generate_prime.pod | 4 ++--
+ 1 file changed, 2 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man3/BN_generate_prime.pod b/doc/man3/BN_generate_prime.pod
+index accc8a749f..005c25fd7c 100644
+--- a/doc/man3/BN_generate_prime.pod
++++ b/doc/man3/BN_generate_prime.pod
+@@ -130,7 +130,7 @@ or all the tests passed.
+ If B<p> passes all these tests, it is considered a probable prime.
+ 
+ The test performed on B<p> are trial division by a number of small primes
+-and rounds of the of the Miller-Rabin probabilistic primality test.
++and rounds of the Miller-Rabin probabilistic primality test.
+ 
+ The functions do at least 64 rounds of the Miller-Rabin test giving a maximum
+ false positive rate of 2^-128.
+@@ -148,7 +148,7 @@ and BN_is_prime_fasttest() are deprecated.
+ 
+ BN_is_prime_fasttest() and BN_is_prime() behave just like
+ BN_is_prime_fasttest_ex() and BN_is_prime_ex() respectively, but with the old
+-style call back.
++style callback.
+ 
+ B<ctx> is a preallocated B<BN_CTX> (to save the overhead of allocating and
+ freeing the structure in a loop), or B<NULL>.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0041-Clear-the-extension-list-when-removing-the-last-exte.patch b/package/libs/openssl/patches/0041-Clear-the-extension-list-when-removing-the-last-exte.patch
new file mode 100644
index 0000000..80e286e
--- /dev/null
+++ b/package/libs/openssl/patches/0041-Clear-the-extension-list-when-removing-the-last-exte.patch
@@ -0,0 +1,96 @@
+From ed20a5ee3cacf1ee8f376e9744bd360bf2975bde Mon Sep 17 00:00:00 2001
+From: David Benjamin <davidben@google.com>
+Date: Sun, 31 Aug 2025 17:25:40 -0400
+Subject: [PATCH 41/46] Clear the extension list when removing the last
+ extension
+
+The extensions list in a certificate, CRL, and CRL entry is defined as:
+
+    ... extensions      [3]  EXPLICIT Extensions OPTIONAL ...
+    ... crlEntryExtensions      Extensions OPTIONAL ...
+    ... crlExtensions           [0]  EXPLICIT Extensions OPTIONAL ...
+
+    Extensions  ::=  SEQUENCE SIZE (1..MAX) OF Extension
+
+This means that a present but empty extensions list is actually invalid.
+Rather, if you have no extensions to encode, you are meant to omit the
+list altogether. Fix the delete_ext functions to handle this correctly.
+
+This would mostly be moot, as an application adding extensions only to
+delete them all would be unusual. However, #13658 implemented a slightly
+roundabout design where, to omit SKID/AKID, the library first puts them
+in and then the command-line tool detects some placeholder values and
+deletes the extension again.
+
+Fixes #28397
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28398)
+
+(cherry picked from commit 9a8d7dc14201aeeed1e77d54208e4af96916fc4f)
+---
+ crypto/x509/x509_ext.c | 31 ++++++++++++++++++++++++++++---
+ 1 file changed, 28 insertions(+), 3 deletions(-)
+
+diff --git a/crypto/x509/x509_ext.c b/crypto/x509/x509_ext.c
+index a7b85857bd..bed20bd5ae 100644
+--- a/crypto/x509/x509_ext.c
++++ b/crypto/x509/x509_ext.c
+@@ -44,7 +44,15 @@ X509_EXTENSION *X509_CRL_get_ext(const X509_CRL *x, int loc)
+ 
+ X509_EXTENSION *X509_CRL_delete_ext(X509_CRL *x, int loc)
+ {
+-    return X509v3_delete_ext(x->crl.extensions, loc);
++    X509_EXTENSION *ret = X509v3_delete_ext(x->crl.extensions, loc);
++
++    /* Empty extension lists are omitted. */
++    if (x->crl.extensions != NULL &&
++        sk_X509_EXTENSION_num(x->crl.extensions) == 0) {
++        sk_X509_EXTENSION_pop_free(x->crl.extensions, X509_EXTENSION_free);
++        x->crl.extensions = NULL;
++    }
++    return ret;
+ }
+ 
+ void *X509_CRL_get_ext_d2i(const X509_CRL *x, int nid, int *crit, int *idx)
+@@ -91,7 +99,16 @@ X509_EXTENSION *X509_get_ext(const X509 *x, int loc)
+ 
+ X509_EXTENSION *X509_delete_ext(X509 *x, int loc)
+ {
+-    return X509v3_delete_ext(x->cert_info.extensions, loc);
++    X509_EXTENSION *ret = X509v3_delete_ext(x->cert_info.extensions, loc);
++
++    /* Empty extension lists are omitted. */
++    if (x->cert_info.extensions != NULL &&
++        sk_X509_EXTENSION_num(x->cert_info.extensions) == 0) {
++        sk_X509_EXTENSION_pop_free(x->cert_info.extensions,
++                                   X509_EXTENSION_free);
++        x->cert_info.extensions = NULL;
++    }
++    return ret;
+ }
+ 
+ int X509_add_ext(X509 *x, X509_EXTENSION *ex, int loc)
+@@ -139,7 +156,15 @@ X509_EXTENSION *X509_REVOKED_get_ext(const X509_REVOKED *x, int loc)
+ 
+ X509_EXTENSION *X509_REVOKED_delete_ext(X509_REVOKED *x, int loc)
+ {
+-    return X509v3_delete_ext(x->extensions, loc);
++    X509_EXTENSION *ret = X509v3_delete_ext(x->extensions, loc);
++
++    /* Empty extension lists are omitted. */
++    if (x->extensions != NULL &&
++        sk_X509_EXTENSION_num(x->extensions) == 0) {
++        sk_X509_EXTENSION_pop_free(x->extensions, X509_EXTENSION_free);
++        x->extensions = NULL;
++    }
++    return ret;
+ }
+ 
+ int X509_REVOKED_add_ext(X509_REVOKED *x, X509_EXTENSION *ex, int loc)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0042-Add-a-helper-function-to-delete-the-extension-list.patch b/package/libs/openssl/patches/0042-Add-a-helper-function-to-delete-the-extension-list.patch
new file mode 100644
index 0000000..2c39cf0
--- /dev/null
+++ b/package/libs/openssl/patches/0042-Add-a-helper-function-to-delete-the-extension-list.patch
@@ -0,0 +1,88 @@
+From b546ccb4123d1260edb2a5074d06f626eb15febb Mon Sep 17 00:00:00 2001
+From: David Benjamin <davidben@google.com>
+Date: Sun, 31 Aug 2025 18:09:52 -0400
+Subject: [PATCH 42/46] Add a helper function to delete the extension list
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28398)
+
+(cherry picked from commit 9e8898b6b6032a69f1002ab823a1cc0bba109b50)
+---
+ crypto/x509/x509_ext.c | 37 ++++++++++++-------------------------
+ 1 file changed, 12 insertions(+), 25 deletions(-)
+
+diff --git a/crypto/x509/x509_ext.c b/crypto/x509/x509_ext.c
+index bed20bd5ae..e004a07d88 100644
+--- a/crypto/x509/x509_ext.c
++++ b/crypto/x509/x509_ext.c
+@@ -42,19 +42,23 @@ X509_EXTENSION *X509_CRL_get_ext(const X509_CRL *x, int loc)
+     return X509v3_get_ext(x->crl.extensions, loc);
+ }
+ 
+-X509_EXTENSION *X509_CRL_delete_ext(X509_CRL *x, int loc)
++static X509_EXTENSION *delete_ext(STACK_OF(X509_EXTENSION) **sk, int loc)
+ {
+-    X509_EXTENSION *ret = X509v3_delete_ext(x->crl.extensions, loc);
++    X509_EXTENSION *ret = X509v3_delete_ext(*sk, loc);
+ 
+     /* Empty extension lists are omitted. */
+-    if (x->crl.extensions != NULL &&
+-        sk_X509_EXTENSION_num(x->crl.extensions) == 0) {
+-        sk_X509_EXTENSION_pop_free(x->crl.extensions, X509_EXTENSION_free);
+-        x->crl.extensions = NULL;
++    if (*sk != NULL && sk_X509_EXTENSION_num(*sk) == 0) {
++        sk_X509_EXTENSION_pop_free(*sk, X509_EXTENSION_free);
++        *sk = NULL;
+     }
+     return ret;
+ }
+ 
++X509_EXTENSION *X509_CRL_delete_ext(X509_CRL *x, int loc)
++{
++    return delete_ext(&x->crl.extensions, loc);
++}
++
+ void *X509_CRL_get_ext_d2i(const X509_CRL *x, int nid, int *crit, int *idx)
+ {
+     return X509V3_get_d2i(x->crl.extensions, nid, crit, idx);
+@@ -99,16 +103,7 @@ X509_EXTENSION *X509_get_ext(const X509 *x, int loc)
+ 
+ X509_EXTENSION *X509_delete_ext(X509 *x, int loc)
+ {
+-    X509_EXTENSION *ret = X509v3_delete_ext(x->cert_info.extensions, loc);
+-
+-    /* Empty extension lists are omitted. */
+-    if (x->cert_info.extensions != NULL &&
+-        sk_X509_EXTENSION_num(x->cert_info.extensions) == 0) {
+-        sk_X509_EXTENSION_pop_free(x->cert_info.extensions,
+-                                   X509_EXTENSION_free);
+-        x->cert_info.extensions = NULL;
+-    }
+-    return ret;
++    return delete_ext(&x->cert_info.extensions, loc);
+ }
+ 
+ int X509_add_ext(X509 *x, X509_EXTENSION *ex, int loc)
+@@ -156,15 +151,7 @@ X509_EXTENSION *X509_REVOKED_get_ext(const X509_REVOKED *x, int loc)
+ 
+ X509_EXTENSION *X509_REVOKED_delete_ext(X509_REVOKED *x, int loc)
+ {
+-    X509_EXTENSION *ret = X509v3_delete_ext(x->extensions, loc);
+-
+-    /* Empty extension lists are omitted. */
+-    if (x->extensions != NULL &&
+-        sk_X509_EXTENSION_num(x->extensions) == 0) {
+-        sk_X509_EXTENSION_pop_free(x->extensions, X509_EXTENSION_free);
+-        x->extensions = NULL;
+-    }
+-    return ret;
++    return delete_ext(&x->extensions, loc);
+ }
+ 
+ int X509_REVOKED_add_ext(X509_REVOKED *x, X509_EXTENSION *ex, int loc)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0043-openssl-enc.pod.in-We-actually-use-PKCS-7-padding.patch b/package/libs/openssl/patches/0043-openssl-enc.pod.in-We-actually-use-PKCS-7-padding.patch
new file mode 100644
index 0000000..baaba6f
--- /dev/null
+++ b/package/libs/openssl/patches/0043-openssl-enc.pod.in-We-actually-use-PKCS-7-padding.patch
@@ -0,0 +1,34 @@
+From 5ffa68a16e025f2ebf893e7d9f5c674777e023b5 Mon Sep 17 00:00:00 2001
+From: "Sergey G. Brester" <github@sebres.de>
+Date: Thu, 28 Aug 2025 00:26:11 +0200
+Subject: [PATCH 43/46] openssl-enc.pod.in: We actually use PKCS#7 padding
+
+PKCS#5 padding is a subset for 8-bytes block ciphers only.
+
+CLA: trivial
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28359)
+
+(cherry picked from commit 4e0c2d02a9a415823babf74106985352e7bbcdae)
+---
+ doc/man1/openssl-enc.pod.in | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/doc/man1/openssl-enc.pod.in b/doc/man1/openssl-enc.pod.in
+index 194f6890f1..5200d294c6 100644
+--- a/doc/man1/openssl-enc.pod.in
++++ b/doc/man1/openssl-enc.pod.in
+@@ -254,7 +254,7 @@ Some of the ciphers do not have large keys and others have security
+ implications if not used correctly. A beginner is advised to just use
+ a strong block cipher, such as AES, in CBC mode.
+ 
+-All the block ciphers normally use PKCS#5 padding, also known as standard
++All the block ciphers normally use PKCS#7 padding, also known as standard
+ block padding. This allows a rudimentary integrity or password check to
+ be performed. However, since the chance of random data passing the test
+ is better than 1 in 256 it isn't a very good test.
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0044-Make-the-Unix-build-process-more-repeatable.patch b/package/libs/openssl/patches/0044-Make-the-Unix-build-process-more-repeatable.patch
new file mode 100644
index 0000000..39e3bf4
--- /dev/null
+++ b/package/libs/openssl/patches/0044-Make-the-Unix-build-process-more-repeatable.patch
@@ -0,0 +1,78 @@
+From 71ec8700ebc761bced7a86bb6570a120dc63c448 Mon Sep 17 00:00:00 2001
+From: Enji Cooper <yaneurabeya@gmail.com>
+Date: Thu, 4 Sep 2025 20:22:00 -0700
+Subject: [PATCH 44/46] Make the Unix build process more repeatable
+
+Before this change all manpages would contain the date when pod2man was
+run. This resulted in outputs that differed between builds--or
+potentially across a single build if the host clock "ticked" to the next
+day when the build was being run.
+
+This commit modifies the manpage generation process as follows:
+- The date all manpages were generated will be normalized to a single
+  date.
+- The release date specified in `VERSION.dat` is used instead of the
+  date/time when `pod2man` was executed OR--in the event a date isn't
+  specified in `VERSION.dat`--the time when the Makefiles were last
+  regenerated.
+
+Embedding a consistent date into the generated manpages helps ensure that
+the build process as a whole is more repeatable and helps ensure that
+release versions of OpenSSL create artifacts consistent with the date
+that the official release was cut.
+
+Co-authored-by: Richard Levitte <levitte@openssl.org>
+Signed-off-by: Enji Cooper <yaneurabeya@gmail.com>
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28449)
+
+(cherry picked from commit 2c0c9c83b292fdba001d968a8219db4083294003)
+---
+ Configurations/unix-Makefile.tmpl | 14 +++++++++++++-
+ 1 file changed, 13 insertions(+), 1 deletion(-)
+
+diff --git a/Configurations/unix-Makefile.tmpl b/Configurations/unix-Makefile.tmpl
+index d2b0797a7e..a68ae9f26f 100644
+--- a/Configurations/unix-Makefile.tmpl
++++ b/Configurations/unix-Makefile.tmpl
+@@ -3,6 +3,8 @@
+ ##
+ ## {- join("\n## ", @autowarntext) -}
+ {-
++     use Time::Piece;
++
+      use OpenSSL::Util;
+ 
+      our $makedep_scheme = $config{makedep_scheme};
+@@ -68,6 +70,15 @@ FIPSKEY={- $config{FIPSKEY} -}
+ 
+ VERSION={- "$config{full_version}" -}
+ VERSION_NUMBER={- "$config{version}" -}
++RELEASE_DATE={- my $t = localtime;
++		if ($config{"release_date"}) {
++			# Provide the user with a more meaningful error message
++			# than the default internal parsing error from
++			# `Time::Piece->strptime(..)`.
++			eval { $t = Time::Piece->strptime($config{"release_date"}, "%d %b %Y"); } ||
++				die "Parsing \$config{release_date} ('$config{release_date}') failed: $@";
++		}
++		$t->strftime("%Y-%m-%d") -}
+ MAJOR={- $config{major} -}
+ MINOR={- $config{minor} -}
+ SHLIB_VERSION_NUMBER={- $config{shlib_version} -}
+@@ -1540,7 +1551,8 @@ EOF
+           return <<"EOF";
+ $args{src}: $pod
+ 	pod2man --name=$name --section=$section\$(MANSUFFIX) --center=OpenSSL \\
+-		--release=\$(VERSION) $pod >\$\@
++		--date=\$(RELEASE_DATE) --release=\$(VERSION) \\
++		$pod >\$\@
+ EOF
+       } elsif (platform->isdef($args{src})) {
+           #
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0045-crypto-rand-randfile.c-avoid-signed-integer-overflow.patch b/package/libs/openssl/patches/0045-crypto-rand-randfile.c-avoid-signed-integer-overflow.patch
new file mode 100644
index 0000000..ddc35bc
--- /dev/null
+++ b/package/libs/openssl/patches/0045-crypto-rand-randfile.c-avoid-signed-integer-overflow.patch
@@ -0,0 +1,60 @@
+From 3c5c22eb77b95c66e54e174b0330223866982d38 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Fri, 29 Aug 2025 10:02:39 +0200
+Subject: [PATCH 45/46] crypto/rand/randfile.c: avoid signed integer overflow
+ in RAND_load_file
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+If a file supplied to RAND_load_file is too big (more than INT_MAX bytes),
+it is possible to trigger a signer integer overflow during ret calculation.
+Avoid it by returning early when we are about to hit it on the next
+iteration.
+
+Reported-by: Liu-Ermeng <liuermeng2@huawei.com>
+Resolves: https://github.com/openssl/openssl/issues/28375
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28379)
+
+(cherry picked from commit 35db6a15d436aa4d981ebcd581eded55fc8c8fb6)
+---
+ crypto/rand/randfile.c      | 4 ++++
+ doc/man3/RAND_load_file.pod | 2 ++
+ 2 files changed, 6 insertions(+)
+
+diff --git a/crypto/rand/randfile.c b/crypto/rand/randfile.c
+index b4854a4c4e..5a9d3639e0 100644
+--- a/crypto/rand/randfile.c
++++ b/crypto/rand/randfile.c
+@@ -167,6 +167,10 @@ int RAND_load_file(const char *file, long bytes)
+         /* If given a bytecount, and we did it, break. */
+         if (bytes > 0 && (bytes -= i) <= 0)
+             break;
++
++        /* We can hit a signed integer overflow on the next iteration */
++        if (ret > INT_MAX - RAND_LOAD_BUF_SIZE)
++            break;
+     }
+ 
+     OPENSSL_cleanse(buf, sizeof(buf));
+diff --git a/doc/man3/RAND_load_file.pod b/doc/man3/RAND_load_file.pod
+index baca54cb3c..fd00bf883d 100644
+--- a/doc/man3/RAND_load_file.pod
++++ b/doc/man3/RAND_load_file.pod
+@@ -20,6 +20,8 @@ RAND_load_file() reads a number of bytes from file B<filename> and
+ adds them to the PRNG. If B<max_bytes> is nonnegative,
+ up to B<max_bytes> are read;
+ if B<max_bytes> is -1, the complete file is read.
++RAND_load_file() can read less than the complete file or the requested number
++of bytes if it doesn't fit in the return value type.
+ Do not load the same file multiple times unless its contents have
+ been updated by RAND_write_file() between reads.
+ Also, note that B<filename> should be adequately protected so that an
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0046-doc-man3-RAND_load_file.pod-RAND_load_file-on-non-re.patch b/package/libs/openssl/patches/0046-doc-man3-RAND_load_file.pod-RAND_load_file-on-non-re.patch
new file mode 100644
index 0000000..270c0e2
--- /dev/null
+++ b/package/libs/openssl/patches/0046-doc-man3-RAND_load_file.pod-RAND_load_file-on-non-re.patch
@@ -0,0 +1,43 @@
+From 43e04e180be80b69a3c457d6e14b296a3bf9cdcd Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Fri, 29 Aug 2025 10:29:26 +0200
+Subject: [PATCH 46/46] doc/man3/RAND_load_file.pod: RAND_load_file on
+ non-regular files with bytes=-1
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Mention that RAND_load_file attempts to read only RAND_DRBG_STRENGTH
+bytes on non-regular files if the number of bytes to be read
+is not specified explicitly.
+
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28379)
+
+(cherry picked from commit 0daaf33275196dd5af9535d69b0d521b9e4d03de)
+---
+ doc/man3/RAND_load_file.pod | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/doc/man3/RAND_load_file.pod b/doc/man3/RAND_load_file.pod
+index fd00bf883d..9fad4d7175 100644
+--- a/doc/man3/RAND_load_file.pod
++++ b/doc/man3/RAND_load_file.pod
+@@ -19,7 +19,9 @@ RAND_load_file, RAND_write_file, RAND_file_name - PRNG seed file
+ RAND_load_file() reads a number of bytes from file B<filename> and
+ adds them to the PRNG. If B<max_bytes> is nonnegative,
+ up to B<max_bytes> are read;
+-if B<max_bytes> is -1, the complete file is read.
++if B<max_bytes> is -1, the complete file is read (unless the file
++is not a regular file, in that case a fixed number of bytes,
++256 in the current implementation, is attempted to be read).
+ RAND_load_file() can read less than the complete file or the requested number
+ of bytes if it doesn't fit in the return value type.
+ Do not load the same file multiple times unless its contents have
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

