diff --git a/package/libs/openssl/patches/0059-x509-fix-mem-leak-on-error-path.patch b/package/libs/openssl/patches/0059-x509-fix-mem-leak-on-error-path.patch
new file mode 100644
index 0000000..acccaa4
--- /dev/null
+++ b/package/libs/openssl/patches/0059-x509-fix-mem-leak-on-error-path.patch
@@ -0,0 +1,37 @@
+From a6d7417f0ca6ac262493c76084fe5f2dafc936e9 Mon Sep 17 00:00:00 2001
+From: Nikola Pajkovsky <nikolap@openssl.org>
+Date: Mon, 22 Sep 2025 12:17:16 +0200
+Subject: [PATCH 59/68] x509: fix mem leak on error path
+
+The x509_store_add() creates X509_OBJECT wrapping either X509 or
+X509_CRL. However, if you set the type to X509_LU_NONE before
+X509_OBJECT_free then it skips the free on the wrapped type and just
+calls OPENSSL_free on the object itself. Hence, leaking wrapped
+object.
+
+Signed-off-by: Nikola Pajkovsky <nikolap@openssl.org>
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28631)
+
+(cherry picked from commit 8a4ef31f3ab9c8e512d29600ccc833cf03533b9e)
+---
+ crypto/x509/x509_lu.c | 1 -
+ 1 file changed, 1 deletion(-)
+
+diff --git a/crypto/x509/x509_lu.c b/crypto/x509/x509_lu.c
+index d8927bda07..6959e9c24a 100644
+--- a/crypto/x509/x509_lu.c
++++ b/crypto/x509/x509_lu.c
+@@ -374,7 +374,6 @@ static int x509_store_add(X509_STORE *store, void *x, int crl) {
+     }
+ 
+     if (!X509_STORE_lock(store)) {
+-        obj->type = X509_LU_NONE;
+         X509_OBJECT_free(obj);
+         return 0;
+     }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0060-Print-PowerPC-CPUINFO.patch b/package/libs/openssl/patches/0060-Print-PowerPC-CPUINFO.patch
new file mode 100644
index 0000000..9aee53d
--- /dev/null
+++ b/package/libs/openssl/patches/0060-Print-PowerPC-CPUINFO.patch
@@ -0,0 +1,48 @@
+From bde96f0483921b83eb78c73a42cd84b721ca0403 Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Sat, 13 Sep 2025 12:45:00 +0200
+Subject: [PATCH 60/68] Print PowerPC CPUINFO
+
+Reviewed-by: Richard Levitte <levitte@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28535)
+
+(cherry picked from commit 03a9584499589f14363de758fdfb887cbef84790)
+---
+ crypto/info.c | 12 ++++++++++++
+ 1 file changed, 12 insertions(+)
+
+diff --git a/crypto/info.c b/crypto/info.c
+index a0dc2e8013..c40338acaa 100644
+--- a/crypto/info.c
++++ b/crypto/info.c
+@@ -18,6 +18,9 @@
+ #if defined(__arm__) || defined(__arm) || defined(__aarch64__)
+ # include "arm_arch.h"
+ # define CPU_INFO_STR_LEN 128
++#elif defined(__powerpc__) || defined(__POWERPC__) || defined(_ARCH_PPC)
++# include "crypto/ppc_arch.h"
++# define CPU_INFO_STR_LEN 128
+ #elif defined(__s390__) || defined(__s390x__)
+ # include "s390x_arch.h"
+ # define CPU_INFO_STR_LEN 2048
+@@ -62,6 +65,15 @@ DEFINE_RUN_ONCE_STATIC(init_info_strings)
+         BIO_snprintf(ossl_cpu_info_str + strlen(ossl_cpu_info_str),
+                      sizeof(ossl_cpu_info_str) - strlen(ossl_cpu_info_str),
+                      " env:%s", env);
++# elif defined(__powerpc__) || defined(__POWERPC__) || defined(_ARCH_PPC)
++    const char *env;
++
++    BIO_snprintf(ossl_cpu_info_str, sizeof(ossl_cpu_info_str),
++                 CPUINFO_PREFIX "OPENSSL_ppccap=0x%x", OPENSSL_ppccap_P);
++    if ((env = getenv("OPENSSL_ppccap")) != NULL)
++        BIO_snprintf(ossl_cpu_info_str + strlen(ossl_cpu_info_str),
++                     sizeof(ossl_cpu_info_str) - strlen(ossl_cpu_info_str),
++                     " env:%s", env);
+ # elif defined(__s390__) || defined(__s390x__)
+     const char *env;
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0061-disable-rwlocks-on-nonstop-klt-model.patch b/package/libs/openssl/patches/0061-disable-rwlocks-on-nonstop-klt-model.patch
new file mode 100644
index 0000000..1e8a186
--- /dev/null
+++ b/package/libs/openssl/patches/0061-disable-rwlocks-on-nonstop-klt-model.patch
@@ -0,0 +1,39 @@
+From a4727cf2543792a6adae2461f2fe9ac3b9b6dd39 Mon Sep 17 00:00:00 2001
+From: Neil Horman <nhorman@openssl.org>
+Date: Mon, 29 Jul 2024 15:17:07 -0400
+Subject: [PATCH 61/68] disable rwlocks on nonstop klt model
+
+It appears nonstops new threading model defines some level of rwlock
+pthread api, but its not working properly.  Disable rwlocks for
+_KLT_MODEL_ for now
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Tom Cosgrove <tom.cosgrove@arm.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28635)
+
+(cherry picked from commit d8ecbb37dcfcee24c4f6c8e46e1e0caefb940187)
+---
+ crypto/threads_pthread.c | 6 +++++-
+ 1 file changed, 5 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/threads_pthread.c b/crypto/threads_pthread.c
+index 303f481bef..b0278eacd6 100644
+--- a/crypto/threads_pthread.c
++++ b/crypto/threads_pthread.c
+@@ -38,7 +38,11 @@
+ 
+ # include <assert.h>
+ 
+-# ifdef PTHREAD_RWLOCK_INITIALIZER
++/*
++ * The Non-Stop KLT thread model currently seems broken in its rwlock
++ * implementation
++ */
++# if defined(PTHREAD_RWLOCK_INITIALIZER) && !defined(_KLT_MODEL_)
+ #  define USE_RWLOCK
+ # endif
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0062-Do-not-use-RW-mutexes-on-RISC-V-arch.patch b/package/libs/openssl/patches/0062-Do-not-use-RW-mutexes-on-RISC-V-arch.patch
new file mode 100644
index 0000000..cf58c23
--- /dev/null
+++ b/package/libs/openssl/patches/0062-Do-not-use-RW-mutexes-on-RISC-V-arch.patch
@@ -0,0 +1,39 @@
+From 50bdc4fc7cdcfbcca257ea70158f1a899ba16cab Mon Sep 17 00:00:00 2001
+From: Bernd Edlinger <bernd.edlinger@hotmail.de>
+Date: Fri, 19 Sep 2025 08:52:24 +0200
+Subject: [PATCH 62/68] Do not use RW mutexes on RISC-V arch
+
+For unknown reasons using RW mutexes on RISC-V arch
+seems to be broken, at least with glibc.
+
+Fixes #28550
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28635)
+
+(cherry picked from commit 728d5cf9e1b1bed196b31e8c71b8e1d2e398d2ff)
+---
+ crypto/threads_pthread.c | 4 +++-
+ 1 file changed, 3 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/threads_pthread.c b/crypto/threads_pthread.c
+index b0278eacd6..dfa338b117 100644
+--- a/crypto/threads_pthread.c
++++ b/crypto/threads_pthread.c
+@@ -41,8 +41,10 @@
+ /*
+  * The Non-Stop KLT thread model currently seems broken in its rwlock
+  * implementation
++ * Likewise is there a problem with the glibc implementation on riscv.
+  */
+-# if defined(PTHREAD_RWLOCK_INITIALIZER) && !defined(_KLT_MODEL_)
++# if defined(PTHREAD_RWLOCK_INITIALIZER) && !defined(_KLT_MODEL_) \
++                                         && !defined(__riscv)
+ #  define USE_RWLOCK
+ # endif
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0063-Fix-doublefree-after-failure-in-ossl_siv128_init.patch b/package/libs/openssl/patches/0063-Fix-doublefree-after-failure-in-ossl_siv128_init.patch
new file mode 100644
index 0000000..9fc0593
--- /dev/null
+++ b/package/libs/openssl/patches/0063-Fix-doublefree-after-failure-in-ossl_siv128_init.patch
@@ -0,0 +1,37 @@
+From 5bdf35da57d4f37f1bd98c96a0390fb00976b297 Mon Sep 17 00:00:00 2001
+From: Tomas Mraz <tomas@openssl.org>
+Date: Tue, 23 Sep 2025 17:00:00 +0200
+Subject: [PATCH 63/68] Fix doublefree after failure in ossl_siv128_init()
+
+The issue was reported by Ronald Crane from Zippenhop LLC.
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28644)
+
+(cherry picked from commit 3185e2762402dffba569d9a7377d51d5bb0e4382)
+---
+ crypto/modes/siv128.c | 3 +++
+ 1 file changed, 3 insertions(+)
+
+diff --git a/crypto/modes/siv128.c b/crypto/modes/siv128.c
+index e6348a8d37..42d7ecedff 100644
+--- a/crypto/modes/siv128.c
++++ b/crypto/modes/siv128.c
+@@ -202,9 +202,12 @@ int ossl_siv128_init(SIV128_CONTEXT *ctx, const unsigned char *key, int klen,
+             || !EVP_MAC_final(mac_ctx, ctx->d.byte, &out_len,
+                               sizeof(ctx->d.byte))) {
+         EVP_CIPHER_CTX_free(ctx->cipher_ctx);
++        ctx->cipher_ctx = NULL;
+         EVP_MAC_CTX_free(ctx->mac_ctx_init);
++        ctx->mac_ctx_init = NULL;
+         EVP_MAC_CTX_free(mac_ctx);
+         EVP_MAC_free(ctx->mac);
++        ctx->mac = NULL;
+         return 0;
+     }
+     EVP_MAC_CTX_free(mac_ctx);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0064-Fix-EVP_PKEY_can_sign-handling-of-NULL-from-query_op.patch b/package/libs/openssl/patches/0064-Fix-EVP_PKEY_can_sign-handling-of-NULL-from-query_op.patch
new file mode 100644
index 0000000..a05e0f8
--- /dev/null
+++ b/package/libs/openssl/patches/0064-Fix-EVP_PKEY_can_sign-handling-of-NULL-from-query_op.patch
@@ -0,0 +1,186 @@
+From 4951f04a4e46d6bf910500d6d8859b8aa7516ac5 Mon Sep 17 00:00:00 2001
+From: Daniel Kubec <kubec@openssl.org>
+Date: Fri, 19 Sep 2025 15:48:41 +0200
+Subject: [PATCH 64/68] Fix EVP_PKEY_can_sign() handling of NULL from
+ query_operation_name()
+
+EVP_PKEY_can_sign() assumed query_operation_name(OSSL_OP_SIGNATURE)
+always returns a non-NULL string. According to the documentation,
+query_operation_name() may return NULL, in which case
+EVP_KEYMGMT_get0_name() should be used as a fallback.
+
+Fixes #27790
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28641)
+
+(cherry picked from commit 0c2d67f417a2c2e0a63272e8d7753489b4958c0b)
+---
+ crypto/evp/p_lib.c        | 17 +++++----
+ test/fake_rsaprov.c       |  4 ++-
+ test/fake_rsaprov.h       |  9 +++++
+ test/provider_pkey_test.c | 72 +++++++++++++++++++++++++++++++++++++++
+ 4 files changed, 92 insertions(+), 10 deletions(-)
+
+diff --git a/crypto/evp/p_lib.c b/crypto/evp/p_lib.c
+index 6ff7eb7e02..8d0071c3ec 100644
+--- a/crypto/evp/p_lib.c
++++ b/crypto/evp/p_lib.c
+@@ -1095,15 +1095,14 @@ int EVP_PKEY_can_sign(const EVP_PKEY *pkey)
+     } else {
+         const OSSL_PROVIDER *prov = EVP_KEYMGMT_get0_provider(pkey->keymgmt);
+         OSSL_LIB_CTX *libctx = ossl_provider_libctx(prov);
+-        const char *supported_sig =
+-            pkey->keymgmt->query_operation_name != NULL
+-            ? pkey->keymgmt->query_operation_name(OSSL_OP_SIGNATURE)
+-            : EVP_KEYMGMT_get0_name(pkey->keymgmt);
+-        EVP_SIGNATURE *signature = NULL;
+-
+-        signature = EVP_SIGNATURE_fetch(libctx, supported_sig, NULL);
+-        if (signature != NULL) {
+-            EVP_SIGNATURE_free(signature);
++        EVP_SIGNATURE *sig;
++        const char *name;
++
++        name = evp_keymgmt_util_query_operation_name(pkey->keymgmt,
++                                                     OSSL_OP_SIGNATURE);
++        sig = EVP_SIGNATURE_fetch(libctx, name, NULL);
++        if (sig != NULL) {
++            EVP_SIGNATURE_free(sig);
+             return 1;
+         }
+     }
+diff --git a/test/fake_rsaprov.c b/test/fake_rsaprov.c
+index be08bfd399..8b38641684 100644
+--- a/test/fake_rsaprov.c
++++ b/test/fake_rsaprov.c
+@@ -31,6 +31,8 @@ static int imptypes_selection;
+ static int exptypes_selection;
+ static int query_id;
+ 
++unsigned fake_rsa_query_operation_name = 0;
++
+ struct fake_rsa_keydata {
+     int selection;
+     int status;
+@@ -71,7 +73,7 @@ static const char *fake_rsa_keymgmt_query(int id)
+     /* record global for checking */
+     query_id = id;
+ 
+-    return "RSA";
++    return fake_rsa_query_operation_name ? NULL: "RSA";
+ }
+ 
+ static int fake_rsa_keymgmt_import(void *keydata, int selection,
+diff --git a/test/fake_rsaprov.h b/test/fake_rsaprov.h
+index 190c46a285..71a32985c6 100644
+--- a/test/fake_rsaprov.h
++++ b/test/fake_rsaprov.h
+@@ -12,4 +12,13 @@
+ /* Fake RSA provider implementation */
+ OSSL_PROVIDER *fake_rsa_start(OSSL_LIB_CTX *libctx);
+ void fake_rsa_finish(OSSL_PROVIDER *p);
++
+ OSSL_PARAM *fake_rsa_key_params(int priv);
++
++/*
++ * When fake_rsa_query_operation_name is set to a non-zero value,
++ * query_operation_name() will return NULL.
++ *
++ * By default, it is 0, in which case query_operation_name() will return "RSA".
++ */
++extern unsigned fake_rsa_query_operation_name;
+diff --git a/test/provider_pkey_test.c b/test/provider_pkey_test.c
+index 249e9babcf..081457734a 100644
+--- a/test/provider_pkey_test.c
++++ b/test/provider_pkey_test.c
+@@ -237,6 +237,77 @@ end:
+     return ret;
+ }
+ 
++static int test_pkey_can_sign(void)
++{
++    OSSL_PROVIDER *fake_rsa = NULL;
++    EVP_PKEY *pkey_fake = NULL;
++    EVP_PKEY_CTX *ctx = NULL;
++    OSSL_PARAM *params = NULL;
++    int ret = 0;
++
++    if (!TEST_ptr(fake_rsa = fake_rsa_start(libctx)))
++        return 0;
++
++    /*
++     * Ensure other tests did not forget to reset fake_rsa_query_operation_name
++     * to its default value: 0
++     */
++    if (!TEST_int_eq(fake_rsa_query_operation_name, 0))
++        goto end;
++
++    if (!TEST_ptr(params = fake_rsa_key_params(0))
++        || !TEST_ptr(ctx = EVP_PKEY_CTX_new_from_name(libctx, "RSA",
++                                                      "provider=fake-rsa"))
++        || !TEST_true(EVP_PKEY_fromdata_init(ctx))
++        || !TEST_true(EVP_PKEY_fromdata(ctx, &pkey_fake, EVP_PKEY_PUBLIC_KEY,
++                                        params))
++        || !TEST_true(EVP_PKEY_can_sign(pkey_fake))
++        || !TEST_ptr(pkey_fake))
++        goto end;
++
++    EVP_PKEY_CTX_free(ctx);
++    ctx = NULL;
++    EVP_PKEY_free(pkey_fake);
++    pkey_fake = NULL;
++    OSSL_PARAM_free(params);
++    params = NULL;
++
++    /*
++     * Documented behavior for OSSL_FUNC_keymgmt_query_operation_name()
++     * allows it to return NULL, in which case the fallback should be to use
++     * EVP_KEYMGMT_get0_name(). That is exactly the thing we are testing here.
++     */
++    fake_rsa_query_operation_name = 1;
++
++    if (!TEST_ptr(params = fake_rsa_key_params(0))
++        || !TEST_ptr(ctx = EVP_PKEY_CTX_new_from_name(libctx, "RSA",
++                                                      "provider=fake-rsa"))
++        || !TEST_true(EVP_PKEY_fromdata_init(ctx))
++        || !TEST_true(EVP_PKEY_fromdata(ctx, &pkey_fake, EVP_PKEY_PUBLIC_KEY,
++                                        params))
++        || !TEST_true(EVP_PKEY_can_sign(pkey_fake))
++        || !TEST_ptr(pkey_fake))
++        goto end;
++
++    EVP_PKEY_CTX_free(ctx);
++    ctx = NULL;
++    EVP_PKEY_free(pkey_fake);
++    pkey_fake = NULL;
++    OSSL_PARAM_free(params);
++    params = NULL;
++
++    ret = 1;
++end:
++
++    EVP_PKEY_CTX_free(ctx);
++    EVP_PKEY_free(pkey_fake);
++    OSSL_PARAM_free(params);
++    fake_rsa_query_operation_name = 0;
++
++    fake_rsa_finish(fake_rsa);
++    return ret;
++}
++
+ static int test_pkey_store(int idx)
+ {
+     OSSL_PROVIDER *deflt = NULL;
+@@ -297,6 +368,7 @@ int setup_tests(void)
+     ADD_TEST(test_pkey_sig);
+     ADD_TEST(test_alternative_keygen_init);
+     ADD_TEST(test_pkey_eq);
++    ADD_TEST(test_pkey_can_sign);
+     ADD_ALL_TESTS(test_pkey_store, 2);
+ 
+     return 1;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0065-crypto-x509-t_x509.c-check-i2d_X509_NAME-return-valu.patch b/package/libs/openssl/patches/0065-crypto-x509-t_x509.c-check-i2d_X509_NAME-return-valu.patch
new file mode 100644
index 0000000..053e8d2
--- /dev/null
+++ b/package/libs/openssl/patches/0065-crypto-x509-t_x509.c-check-i2d_X509_NAME-return-valu.patch
@@ -0,0 +1,38 @@
+From 8dfc7aa957812c915b60caef0032bed84cebe651 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 15 Sep 2025 03:31:31 +0200
+Subject: [PATCH 65/68] crypto/x509/t_x509.c: check i2d_X509_NAME() return
+ value in X509_ocspid_print()
+
+There is little reason for this call to fail, but there is also little
+reason for not to check for it, and, since Coverity noticed
+that the check is missing, just add it.
+
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665420
+References: https://github.com/openssl/project/issues/1432
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28649)
+---
+ crypto/x509/t_x509.c | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/crypto/x509/t_x509.c b/crypto/x509/t_x509.c
+index 5b0282bc13..3b75780b5d 100644
+--- a/crypto/x509/t_x509.c
++++ b/crypto/x509/t_x509.c
+@@ -243,7 +243,8 @@ int X509_ocspid_print(BIO *bp, X509 *x)
+         goto err;
+     if ((der = dertmp = OPENSSL_malloc(derlen)) == NULL)
+         goto err;
+-    i2d_X509_NAME(subj, &dertmp);
++    if (i2d_X509_NAME(subj, &dertmp) < 0)
++        goto err;
+ 
+     md = EVP_MD_fetch(x->libctx, SN_sha1, x->propq);
+     if (md == NULL)
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0066-crypto-bio-bss_file.c-add-missing-cast-in-format-arg.patch b/package/libs/openssl/patches/0066-crypto-bio-bss_file.c-add-missing-cast-in-format-arg.patch
new file mode 100644
index 0000000..ba76fd2
--- /dev/null
+++ b/package/libs/openssl/patches/0066-crypto-bio-bss_file.c-add-missing-cast-in-format-arg.patch
@@ -0,0 +1,37 @@
+From b920a42b1783d628e199fdbcff636480d273d645 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 15 Sep 2025 04:44:36 +0200
+Subject: [PATCH 66/68] crypto/bio/bss_file.c: add missing cast in format arg
+ in ERR_raise_data()
+
+"%s" conversion specifier requires a "char *" argument, so ptr needs
+to be cast to it there, as Coverity has noted.
+
+Fixes: ff988500c2f39 "Replace FUNCerr with ERR_raise_data"
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665423
+References: https://github.com/openssl/project/issues/1432
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28649)
+---
+ crypto/bio/bss_file.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/bio/bss_file.c b/crypto/bio/bss_file.c
+index a6143b6abc..5a44e94731 100644
+--- a/crypto/bio/bss_file.c
++++ b/crypto/bio/bss_file.c
+@@ -296,7 +296,7 @@ static long file_ctrl(BIO *b, int cmd, long num, void *ptr)
+         if (fp == NULL) {
+             ERR_raise_data(ERR_LIB_SYS, get_last_sys_error(),
+                            "calling fopen(%s, %s)",
+-                           ptr, p);
++                           (const char *)ptr, p);
+             ERR_raise(ERR_LIB_BIO, ERR_R_SYS_LIB);
+             ret = 0;
+             break;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0067-crypto-evp-ctrl_params_translate.c-fix-a-typo-in-the.patch b/package/libs/openssl/patches/0067-crypto-evp-ctrl_params_translate.c-fix-a-typo-in-the.patch
new file mode 100644
index 0000000..367da00
--- /dev/null
+++ b/package/libs/openssl/patches/0067-crypto-evp-ctrl_params_translate.c-fix-a-typo-in-the.patch
@@ -0,0 +1,38 @@
+From 462234e8dd08455d7986bb8867ec638ce12190b0 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 15 Sep 2025 05:05:01 +0200
+Subject: [PATCH 67/68] crypto/evp/ctrl_params_translate.c: fix a typo in the
+ error message
+
+The ERR_raise_data() call on failure to find ctx->p2 in str_value_map
+erroneously refers to ctx->p1 instead;  fix that but supplying the
+correct field and casting it to the supposed const char * type.
+
+Fixes: 9a1c4e41e8d3 "EVP: Implement data-driven translation between known ctrl and OSSL_PARAMs"
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665427
+References: https://github.com/openssl/project/issues/1432
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28649)
+---
+ crypto/evp/ctrl_params_translate.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/evp/ctrl_params_translate.c b/crypto/evp/ctrl_params_translate.c
+index cbf02dc5f8..6f9f1ce682 100644
+--- a/crypto/evp/ctrl_params_translate.c
++++ b/crypto/evp/ctrl_params_translate.c
+@@ -1355,7 +1355,7 @@ static int fix_rsa_padding_mode(enum state state,
+         if (i == OSSL_NELEM(str_value_map)) {
+             ERR_raise_data(ERR_LIB_RSA, RSA_R_UNKNOWN_PADDING_TYPE,
+                            "[action:%d, state:%d] padding name %s",
+-                           ctx->action_type, state, ctx->p1);
++                           ctx->action_type, state, (const char *)ctx->p2);
+             ctx->p1 = ret = -2;
+         } else if (state == POST_CTRL_TO_PARAMS) {
+             /* EVP_PKEY_CTRL_GET_RSA_PADDING weirdness explained further up */
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0068-apps-storeutl.c-avoid-signed-integer-overflow-in-ind.patch b/package/libs/openssl/patches/0068-apps-storeutl.c-avoid-signed-integer-overflow-in-ind.patch
new file mode 100644
index 0000000..bd31286
--- /dev/null
+++ b/package/libs/openssl/patches/0068-apps-storeutl.c-avoid-signed-integer-overflow-in-ind.patch
@@ -0,0 +1,55 @@
+From 88728d4928d4a3576ed91425e82c9c839aa07516 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Mon, 15 Sep 2025 05:14:09 +0200
+Subject: [PATCH 68/68] apps/storeutl.c: avoid signed integer overflow in
+ indent_printf()
+
+As two arbitrarily large printf return values can trigger signed integer
+overflow, rewrite the return value handling to avoid it.
+
+Fixes: fb43ddceda79 "Add a recursive option to 'openssl storeutl'"
+Resolves: https://scan5.scan.coverity.com/#/project-view/65248/10222?selectedIssue=1665428
+References: https://github.com/openssl/project/issues/1432
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28649)
+---
+ apps/storeutl.c | 16 ++++++++++++----
+ 1 file changed, 12 insertions(+), 4 deletions(-)
+
+diff --git a/apps/storeutl.c b/apps/storeutl.c
+index 96b943bf6d..e7e6148337 100644
+--- a/apps/storeutl.c
++++ b/apps/storeutl.c
+@@ -335,14 +335,22 @@ int storeutl_main(int argc, char *argv[])
+ static int indent_printf(int indent, BIO *bio, const char *format, ...)
+ {
+     va_list args;
+-    int ret;
++    int ret, vret;
++
++    ret = BIO_printf(bio, "%*s", indent, "");
++    if (ret < 0)
++        return ret;
+ 
+     va_start(args, format);
++    vret = BIO_vprintf(bio, format, args);
++    va_end(args);
+ 
+-    ret = BIO_printf(bio, "%*s", indent, "") + BIO_vprintf(bio, format, args);
++    if (vret < 0)
++        return vret;
++    if (vret > INT_MAX - ret)
++        return INT_MAX;
+ 
+-    va_end(args);
+-    return ret;
++    return ret + vret;
+ }
+ 
+ static int process(const char *uri, const UI_METHOD *uimeth, PW_CB_DATA *uidata,
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

