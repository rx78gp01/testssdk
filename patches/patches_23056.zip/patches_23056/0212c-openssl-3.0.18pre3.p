diff --git a/package/libs/openssl/patches/0047-doc-Add-missing-commas.patch b/package/libs/openssl/patches/0047-doc-Add-missing-commas.patch
new file mode 100644
index 0000000..d631d7e
--- /dev/null
+++ b/package/libs/openssl/patches/0047-doc-Add-missing-commas.patch
@@ -0,0 +1,47 @@
+From f4ca0e811d562139cf392f1dd858a62168c5e888 Mon Sep 17 00:00:00 2001
+From: Jakub Jelen <jjelen@redhat.com>
+Date: Tue, 9 Sep 2025 18:10:30 +0200
+Subject: [PATCH 47/55] doc: Add missing commas
+
+CLA: trivial
+Signed-off-by: Jakub Jelen <jjelen@redhat.com>
+
+Reviewed-by: Paul Yang <paulyang.inf@gmail.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28493)
+
+(cherry picked from commit 1199882de69bf41225002603a8c3634c401ff99a)
+---
+ doc/man7/EVP_PKEY-DSA.pod | 2 +-
+ doc/man7/EVP_PKEY-FFC.pod | 2 +-
+ 2 files changed, 2 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man7/EVP_PKEY-DSA.pod b/doc/man7/EVP_PKEY-DSA.pod
+index cdafc0edad..c66264f6d5 100644
+--- a/doc/man7/EVP_PKEY-DSA.pod
++++ b/doc/man7/EVP_PKEY-DSA.pod
+@@ -104,7 +104,7 @@ The following sections of FIPS186-4:
+ =head1 SEE ALSO
+ 
+ L<EVP_PKEY-FFC(7)>,
+-L<EVP_SIGNATURE-DSA(7)>
++L<EVP_SIGNATURE-DSA(7)>,
+ L<EVP_PKEY(3)>,
+ L<provider-keymgmt(7)>,
+ L<EVP_KEYMGMT(3)>,
+diff --git a/doc/man7/EVP_PKEY-FFC.pod b/doc/man7/EVP_PKEY-FFC.pod
+index 0b96bc24a6..d3c1018455 100644
+--- a/doc/man7/EVP_PKEY-FFC.pod
++++ b/doc/man7/EVP_PKEY-FFC.pod
+@@ -213,7 +213,7 @@ The following sections of FIPS186-4:
+ L<EVP_PKEY-DSA(7)>,
+ L<EVP_PKEY-DH(7)>,
+ L<EVP_SIGNATURE-DSA(7)>,
+-L<EVP_KEYEXCH-DH(7)>
++L<EVP_KEYEXCH-DH(7)>,
+ L<EVP_KEYMGMT(3)>,
+ L<EVP_PKEY(3)>,
+ L<provider-keymgmt(7)>,
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0048-Change-HPE-NonStop-PUT-configuration-to-explicitly-n.patch b/package/libs/openssl/patches/0048-Change-HPE-NonStop-PUT-configuration-to-explicitly-n.patch
new file mode 100644
index 0000000..14154bf
--- /dev/null
+++ b/package/libs/openssl/patches/0048-Change-HPE-NonStop-PUT-configuration-to-explicitly-n.patch
@@ -0,0 +1,41 @@
+From 6f0e8f916bff2f85f63626e0c45e319481b18e2b Mon Sep 17 00:00:00 2001
+From: "Randall S. Becker" <randall.becker@nexbridge.ca>
+Date: Wed, 10 Sep 2025 23:09:52 +0100
+Subject: [PATCH 48/55] Change HPE NonStop PUT configuration to explicitly not
+ use secure memory.
+
+Fixes: #28498
+
+Signed-off-by: Randall S. Becker <randall.becker@nexbridge.ca>
+
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+Reviewed-by: Tim Hudson <tjh@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28515)
+---
+ Configurations/50-nonstop.conf | 2 ++
+ 1 file changed, 2 insertions(+)
+
+diff --git a/Configurations/50-nonstop.conf b/Configurations/50-nonstop.conf
+index ed3fe828b3..b131ca602b 100644
+--- a/Configurations/50-nonstop.conf
++++ b/Configurations/50-nonstop.conf
+@@ -167,12 +167,14 @@
+     # Build models
+     'nonstop-model-put' => {
+         template         => 1,
++        disable          => [ 'secure-memory' ],
+         defines          => ['_PUT_MODEL_',
+                              '_REENTRANT', '_THREAD_SUPPORT_FUNCTIONS'],
+         ex_libs          => '-lput',
+     },
+     'nonstop-model-spt' => {
+         template         => 1,
++        disable          => [ 'secure-memory' ],
+         defines          => ['_SPT_MODEL_',
+                              '_REENTRANT', '_ENABLE_FLOSS_THREADS'],
+         ex_libs          => '-lspt',
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0049-Harden-RSA-public-encrypt.patch b/package/libs/openssl/patches/0049-Harden-RSA-public-encrypt.patch
new file mode 100644
index 0000000..542baee
--- /dev/null
+++ b/package/libs/openssl/patches/0049-Harden-RSA-public-encrypt.patch
@@ -0,0 +1,108 @@
+From aae23e43c6d87e5dfa1f679a620b74e580158a15 Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <openssl-users@dukhovni.org>
+Date: Thu, 11 Sep 2025 18:50:44 +1000
+Subject: [PATCH 49/55] Harden RSA public encrypt
+
+Check the that the indicated output buffer length is large enough.
+
+Fix EVP_SealInit() to initialise the output buffer length to the RSA
+modulus length, not the input KEK length.
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28536)
+---
+ CHANGES.md                                      | 13 ++++++++++++-
+ crypto/evp/p_seal.c                             |  5 +++--
+ providers/implementations/asymciphers/rsa_enc.c | 17 +++++++++++------
+ 3 files changed, 26 insertions(+), 9 deletions(-)
+
+diff --git a/CHANGES.md b/CHANGES.md
+index 491cc94f69..4a68af1435 100644
+--- a/CHANGES.md
++++ b/CHANGES.md
+@@ -30,7 +30,18 @@ breaking changes, and mappings for the large list of deprecated functions.
+ 
+ ### Changes between 3.0.17 and 3.0.18 [xx XXX xxxx]
+ 
+- * none yet
++ * Hardened the provider implementation of the RSA public key "encrypt"
++   operation to add a missing check that the caller-indicated output buffer
++   size is at least as large as the byte count of the RSA modulus.  The issue
++   was reported by Arash Ale Ebrahim from SYSPWN.
++
++   This operation is typically invoked via `EVP_PKEY_encrypt(3)`.  Callers that
++   in fact provide a sufficiently large buffer, but fail to correctly indicate
++   its size may now encounter unexpected errors.  In applications that attempt
++   RSA public encryption into a buffer that is too small, an out-of-bounds
++   write is now avoided and an error is reported instead.
++
++   *Viktor Dukhovni*
+ 
+ ### Changes between 3.0.16 and 3.0.17 [1 Jul 2025]
+ 
+diff --git a/crypto/evp/p_seal.c b/crypto/evp/p_seal.c
+index 475082d431..426b0ee9f2 100644
+--- a/crypto/evp/p_seal.c
++++ b/crypto/evp/p_seal.c
+@@ -56,6 +56,7 @@ int EVP_SealInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type,
+ 
+     for (i = 0; i < npubk; i++) {
+         size_t keylen = len;
++        size_t outlen = EVP_PKEY_get_size(pubk[i]);
+ 
+         pctx = EVP_PKEY_CTX_new_from_pkey(libctx, pubk[i], NULL);
+         if (pctx == NULL) {
+@@ -64,9 +65,9 @@ int EVP_SealInit(EVP_CIPHER_CTX *ctx, const EVP_CIPHER *type,
+         }
+ 
+         if (EVP_PKEY_encrypt_init(pctx) <= 0
+-            || EVP_PKEY_encrypt(pctx, ek[i], &keylen, key, keylen) <= 0)
++            || EVP_PKEY_encrypt(pctx, ek[i], &outlen, key, keylen) <= 0)
+             goto err;
+-        ekl[i] = (int)keylen;
++        ekl[i] = (int)outlen;
+         EVP_PKEY_CTX_free(pctx);
+     }
+     pctx = NULL;
+diff --git a/providers/implementations/asymciphers/rsa_enc.c b/providers/implementations/asymciphers/rsa_enc.c
+index c8921acd6e..f4ca96ebea 100644
+--- a/providers/implementations/asymciphers/rsa_enc.c
++++ b/providers/implementations/asymciphers/rsa_enc.c
+@@ -136,22 +136,27 @@ static int rsa_encrypt(void *vprsactx, unsigned char *out, size_t *outlen,
+                        size_t outsize, const unsigned char *in, size_t inlen)
+ {
+     PROV_RSA_CTX *prsactx = (PROV_RSA_CTX *)vprsactx;
++    size_t len = RSA_size(prsactx->rsa);
+     int ret;
+ 
+     if (!ossl_prov_is_running())
+         return 0;
+ 
+-    if (out == NULL) {
+-        size_t len = RSA_size(prsactx->rsa);
++    if (len == 0) {
++        ERR_raise(ERR_LIB_PROV, PROV_R_INVALID_KEY);
++        return 0;
++    }
+ 
+-        if (len == 0) {
+-            ERR_raise(ERR_LIB_PROV, PROV_R_INVALID_KEY);
+-            return 0;
+-        }
++    if (out == NULL) {
+         *outlen = len;
+         return 1;
+     }
+ 
++    if (outsize < len) {
++        ERR_raise(ERR_LIB_PROV, PROV_R_OUTPUT_BUFFER_TOO_SMALL);
++        return 0;
++    }
++
+     if (prsactx->pad_mode == RSA_PKCS1_OAEP_PADDING) {
+         int rsasize = RSA_size(prsactx->rsa);
+         unsigned char *tbuf;
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0050-Test-failure-of-rsa_encrypt-when-buffer-too-short.patch b/package/libs/openssl/patches/0050-Test-failure-of-rsa_encrypt-when-buffer-too-short.patch
new file mode 100644
index 0000000..bd0b8ba
--- /dev/null
+++ b/package/libs/openssl/patches/0050-Test-failure-of-rsa_encrypt-when-buffer-too-short.patch
@@ -0,0 +1,76 @@
+From f19648b84b5499197947e2be5d08d952e7e7fe0e Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <openssl-users@dukhovni.org>
+Date: Sat, 13 Sep 2025 12:52:42 +1000
+Subject: [PATCH 50/55] Test failure of rsa_encrypt when buffer too short
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28536)
+---
+ test/evp_extra_test.c | 43 +++++++++++++++++++++++++++++++++++++++++++
+ 1 file changed, 43 insertions(+)
+
+diff --git a/test/evp_extra_test.c b/test/evp_extra_test.c
+index c626829fdf..b783ee4518 100644
+--- a/test/evp_extra_test.c
++++ b/test/evp_extra_test.c
+@@ -3010,6 +3010,48 @@ static int test_RSA_OAEP_set_null_label(void)
+     return ret;
+ }
+ 
++static int test_RSA_encrypt(void)
++{
++    int ret = 0;
++    EVP_PKEY *pkey = NULL;
++    EVP_PKEY_CTX *pctx = NULL;
++    unsigned char *cbuf = NULL, *pbuf = NULL;
++    size_t clen = 0, plen = 0;
++
++    if (!TEST_ptr(pkey = load_example_rsa_key())
++        || !TEST_ptr(pctx = EVP_PKEY_CTX_new_from_pkey(testctx,
++                                                       pkey, testpropq))
++        || !TEST_int_gt(EVP_PKEY_encrypt_init(pctx), 0)
++        || !TEST_int_gt(EVP_PKEY_encrypt(pctx, cbuf, &clen, kMsg, sizeof(kMsg)), 0)
++        || !TEST_ptr(cbuf = OPENSSL_malloc(clen))
++        || !TEST_int_gt(EVP_PKEY_encrypt(pctx, cbuf, &clen, kMsg, sizeof(kMsg)), 0))
++        goto done;
++
++    /* Require failure when the output buffer is too small */
++    plen = clen - 1;
++    if (!TEST_int_le(EVP_PKEY_encrypt(pctx, cbuf, &plen, kMsg, sizeof(kMsg)), 0))
++        goto done;
++    /* flush error stack */
++    TEST_openssl_errors();
++
++    /* Check decryption of encrypted result */
++    if (!TEST_int_gt(EVP_PKEY_decrypt_init(pctx), 0)
++        || !TEST_int_gt(EVP_PKEY_decrypt(pctx, pbuf, &plen, cbuf, clen), 0)
++        || !TEST_ptr(pbuf = OPENSSL_malloc(plen))
++        || !TEST_int_gt(EVP_PKEY_decrypt(pctx, pbuf, &plen, cbuf, clen), 0)
++        || !TEST_mem_eq(pbuf, plen, kMsg, sizeof(kMsg))
++        || !TEST_int_gt(EVP_PKEY_encrypt_init(pctx), 0))
++        goto done;
++
++    ret = 1;
++done:
++    EVP_PKEY_CTX_free(pctx);
++    EVP_PKEY_free(pkey);
++    OPENSSL_free(cbuf);
++    OPENSSL_free(pbuf);
++    return ret;
++}
++
+ #if !defined(OPENSSL_NO_CHACHA) && !defined(OPENSSL_NO_POLY1305)
+ static int test_decrypt_null_chunks(void)
+ {
+@@ -5464,6 +5506,7 @@ int setup_tests(void)
+     ADD_TEST(test_RSA_get_set_params);
+     ADD_TEST(test_RSA_OAEP_set_get_params);
+     ADD_TEST(test_RSA_OAEP_set_null_label);
++    ADD_TEST(test_RSA_encrypt);
+ #if !defined(OPENSSL_NO_CHACHA) && !defined(OPENSSL_NO_POLY1305)
+     ADD_TEST(test_decrypt_null_chunks);
+ #endif
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0051-25-test_verify.t-fix-partly-case-sensitive-matching-.patch b/package/libs/openssl/patches/0051-25-test_verify.t-fix-partly-case-sensitive-matching-.patch
new file mode 100644
index 0000000..00e5985
--- /dev/null
+++ b/package/libs/openssl/patches/0051-25-test_verify.t-fix-partly-case-sensitive-matching-.patch
@@ -0,0 +1,37 @@
+From ed625fdde8edd4c429f8b8c653d657967acfdf1f Mon Sep 17 00:00:00 2001
+From: "Dr. David von Oheimb" <dev@ddvo.net>
+Date: Sat, 26 Jul 2025 10:46:21 +0200
+Subject: [PATCH 51/55] 25-test_verify.t: fix partly case-sensitive matching
+ for Windows OS: s/MsWin32/MSWin32/
+
+Fixes #27984
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Tom Cosgrove <tom.cosgrove@arm.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28098)
+
+(cherry picked from commit ee16664f6a1887048638e3d645fac38fb9c7f0d2)
+---
+ test/recipes/25-test_verify.t | 3 ++-
+ 1 file changed, 2 insertions(+), 1 deletion(-)
+
+diff --git a/test/recipes/25-test_verify.t b/test/recipes/25-test_verify.t
+index 7bada5186d..1c025ac94f 100644
+--- a/test/recipes/25-test_verify.t
++++ b/test/recipes/25-test_verify.t
+@@ -537,9 +537,10 @@ ok(vfy_root("-CAfile", $rootcert), "CAfile");
+ ok(vfy_root("-CAstore", $rootcert), "CAstore");
+ ok(vfy_root("-CAstore", $rootcert, "-CAfile", $rootcert), "CAfile and existing CAstore");
+ ok(!vfy_root("-CAstore", "non-existing", "-CAfile", $rootcert), "CAfile and non-existing CAstore");
++
+ SKIP: {
+     skip "file names with colons aren't supported on Windows and VMS", 2
+-        if $^O =~ /^(MsWin32|VMS)$/;
++        if $^O =~ /^(MSWin32|VMS)$/;
+     my $foo_file = "foo:cert.pem";
+     copy($rootcert, $foo_file);
+     ok(vfy_root("-CAstore", $foo_file), "CAstore foo:file");
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0052-test-recipes-25-test_verify.t-correct-the-number-of-.patch b/package/libs/openssl/patches/0052-test-recipes-25-test_verify.t-correct-the-number-of-.patch
new file mode 100644
index 0000000..b06bcd8
--- /dev/null
+++ b/package/libs/openssl/patches/0052-test-recipes-25-test_verify.t-correct-the-number-of-.patch
@@ -0,0 +1,40 @@
+From a92545416d8339ae783bd3b22dd89138f1e7e2e6 Mon Sep 17 00:00:00 2001
+From: Eugene Syromiatnikov <esyr@openssl.org>
+Date: Thu, 18 Sep 2025 02:29:10 +0200
+Subject: [PATCH 52/55] test/recipes/25-test_verify.t: correct the number of
+ skipped tests on Win/VMS
+
+On 3.5, there is one test fewer to be skipped due to absence of support
+of colon in filenames after the commit b3e7dad7ac08 "Fix
+test/recipes/25-test_verify.t [3.5]", provide the correct number
+in the skip call.
+
+Fixes: b3e7dad7ac08 "Fix test/recipes/25-test_verify.t [3.5]"
+Signed-off-by: Eugene Syromiatnikov <esyr@openssl.org>
+
+Reviewed-by: Neil Horman <nhorman@openssl.org>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28591)
+
+(cherry picked from commit b18f44902c5c48080a06c63972a13f8cb6d5c5d2)
+---
+ test/recipes/25-test_verify.t | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/test/recipes/25-test_verify.t b/test/recipes/25-test_verify.t
+index 1c025ac94f..19c528f0b8 100644
+--- a/test/recipes/25-test_verify.t
++++ b/test/recipes/25-test_verify.t
+@@ -539,7 +539,7 @@ ok(vfy_root("-CAstore", $rootcert, "-CAfile", $rootcert), "CAfile and existing C
+ ok(!vfy_root("-CAstore", "non-existing", "-CAfile", $rootcert), "CAfile and non-existing CAstore");
+ 
+ SKIP: {
+-    skip "file names with colons aren't supported on Windows and VMS", 2
++    skip "file names with colons aren't supported on Windows and VMS", 1
+         if $^O =~ /^(MSWin32|VMS)$/;
+     my $foo_file = "foo:cert.pem";
+     copy($rootcert, $foo_file);
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0053-doc-clarify-SSL_SESSION_get0_hostname-DESCRIPTION.patch b/package/libs/openssl/patches/0053-doc-clarify-SSL_SESSION_get0_hostname-DESCRIPTION.patch
new file mode 100644
index 0000000..f0aeffb
--- /dev/null
+++ b/package/libs/openssl/patches/0053-doc-clarify-SSL_SESSION_get0_hostname-DESCRIPTION.patch
@@ -0,0 +1,51 @@
+From 108f257a4df5e9f78cccb2924a25e605b62dd8b8 Mon Sep 17 00:00:00 2001
+From: Ritesh Kudkelwar <ritesh.kumar0793@gmail.com>
+Date: Thu, 11 Sep 2025 10:08:34 +0530
+Subject: [PATCH 53/55] doc: clarify SSL_SESSION_get0_hostname() DESCRIPTION
+MIME-Version: 1.0
+Content-Type: text/plain; charset=UTF-8
+Content-Transfer-Encoding: 8bit
+
+Also refine RETURN VALUES.
+
+Reviewed-by: Viktor Dukhovni <viktor@openssl.org>
+Reviewed-by: Saša Nedvědický <sashan@openssl.org>
+Reviewed-by: Matt Caswell <matt@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28393)
+
+(cherry picked from commit 32ec97521397597764f72d4e7c279c4e815352ee)
+---
+ doc/man3/SSL_SESSION_get0_hostname.pod | 10 +++++-----
+ 1 file changed, 5 insertions(+), 5 deletions(-)
+
+diff --git a/doc/man3/SSL_SESSION_get0_hostname.pod b/doc/man3/SSL_SESSION_get0_hostname.pod
+index f7add16d7b..0140deee9a 100644
+--- a/doc/man3/SSL_SESSION_get0_hostname.pod
++++ b/doc/man3/SSL_SESSION_get0_hostname.pod
+@@ -23,9 +23,10 @@ SSL_SESSION_set1_alpn_selected
+ 
+ =head1 DESCRIPTION
+ 
+-SSL_SESSION_get0_hostname() retrieves the SNI value that was sent by the
+-client when the session was created if it was accepted by the server. Otherwise
+-NULL is returned.
++SSL_SESSION_get0_hostname() retrieves the Server Name Indication (SNI) value
++that was sent by the client when the session was created if the server
++acknowledged the client's SNI extension by including an empty SNI extension
++in response. Otherwise NULL is returned.
+ 
+ The value returned is a pointer to memory maintained within B<s> and
+ should not be free'd.
+@@ -44,8 +45,7 @@ B<alpn>.
+ 
+ =head1 RETURN VALUES
+ 
+-SSL_SESSION_get0_hostname() returns either a string or NULL based on if there
+-is the SNI value sent by client.
++SSL_SESSION_get0_hostname() returns the SNI string if available, or NULL if not.
+ 
+ SSL_SESSION_set1_hostname() returns 1 on success or 0 on error.
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0054-Fix-cipher-protocol-ID-type-in-docs.patch b/package/libs/openssl/patches/0054-Fix-cipher-protocol-ID-type-in-docs.patch
new file mode 100644
index 0000000..caa4dd7
--- /dev/null
+++ b/package/libs/openssl/patches/0054-Fix-cipher-protocol-ID-type-in-docs.patch
@@ -0,0 +1,38 @@
+From 903be0eec32d5958760f04a85278e9217e726551 Mon Sep 17 00:00:00 2001
+From: Grzesiek11 <grzesiek11@stary.pc.pl>
+Date: Thu, 11 Sep 2025 17:13:48 +0200
+Subject: [PATCH 54/55] Fix cipher protocol ID type in docs
+
+The cipher protocol ID, the return type of SSL_CIPHER_get_protocol_id,
+is uint16_t and correctly described in docs to be 2 bytes, however the
+function signature on the same page incorrectly pointed to it being
+uint32_t, which is 4 bytes.
+
+CLA: trivial
+
+Reviewed-by: Matt Caswell <matt@openssl.org>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+(Merged from https://github.com/openssl/openssl/pull/28523)
+
+(cherry picked from commit 9bdf93776d741726895e6a42ffebd63366296e94)
+---
+ doc/man3/SSL_CIPHER_get_name.pod | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/doc/man3/SSL_CIPHER_get_name.pod b/doc/man3/SSL_CIPHER_get_name.pod
+index 09b7280bdd..4a159a68b8 100644
+--- a/doc/man3/SSL_CIPHER_get_name.pod
++++ b/doc/man3/SSL_CIPHER_get_name.pod
+@@ -37,7 +37,7 @@ SSL_CIPHER_get_protocol_id
+  int SSL_CIPHER_is_aead(const SSL_CIPHER *c);
+  const SSL_CIPHER *SSL_CIPHER_find(SSL *ssl, const unsigned char *ptr);
+  uint32_t SSL_CIPHER_get_id(const SSL_CIPHER *c);
+- uint32_t SSL_CIPHER_get_protocol_id(const SSL_CIPHER *c);
++ uint16_t SSL_CIPHER_get_protocol_id(const SSL_CIPHER *c);
+ 
+ =head1 DESCRIPTION
+ 
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0055-Fix-OPENSSL_VERSION_NUMBER-to-always-have-zero-statu.patch b/package/libs/openssl/patches/0055-Fix-OPENSSL_VERSION_NUMBER-to-always-have-zero-statu.patch
new file mode 100644
index 0000000..41cd0ef
--- /dev/null
+++ b/package/libs/openssl/patches/0055-Fix-OPENSSL_VERSION_NUMBER-to-always-have-zero-statu.patch
@@ -0,0 +1,66 @@
+From 5e38dda197f234b16830c4ec69380e52fc83eb3d Mon Sep 17 00:00:00 2001
+From: Richard Levitte <levitte@openssl.org>
+Date: Thu, 18 Sep 2025 07:14:13 +0200
+Subject: [PATCH 55/55] Fix OPENSSL_VERSION_NUMBER to always have zero status
+ bits
+
+The documentation suggested that they were always zero, while the
+implementation in <openssl/opensslv.h> suggested that it could be
+0xf in OpenSSL releases...  which (almost) never happened because
+of a bug in said implementation.
+
+Therefore, we solidify that the status bits are indeed always zero,
+at least in all OpenSSL 3 versions.
+
+Resolves: https://github.com/openssl/project/issues/1621
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28603)
+
+(cherry picked from commit 60c4feacce6faf0e98167dc2ab2a1c2e85882049)
+---
+ doc/man3/OpenSSL_version.pod  | 7 +++++++
+ include/openssl/opensslv.h.in | 4 ++--
+ 2 files changed, 9 insertions(+), 2 deletions(-)
+
+diff --git a/doc/man3/OpenSSL_version.pod b/doc/man3/OpenSSL_version.pod
+index e1cf16e2a1..d1bd234bdd 100644
+--- a/doc/man3/OpenSSL_version.pod
++++ b/doc/man3/OpenSSL_version.pod
+@@ -238,6 +238,13 @@ L<crypto(7)>
+ The macros and functions described here were added in OpenSSL 3.0,
+ except for OPENSSL_VERSION_NUMBER and OpenSSL_version_num().
+ 
++=head1 BUGS
++
++There was a discrepancy between this manual and commentary + code
++in F<< <openssl/opensslv.h> >>, where the latter suggested that the
++four least significant bits of B<OPENSSL_VERSION_NUMBER> could be
++C<0x0f> in released OpenSSL versions.
++
+ =head1 COPYRIGHT
+ 
+ Copyright 2018-2022 The OpenSSL Project Authors. All Rights Reserved.
+diff --git a/include/openssl/opensslv.h.in b/include/openssl/opensslv.h.in
+index d15cce412f..f6ef0963e3 100644
+--- a/include/openssl/opensslv.h.in
++++ b/include/openssl/opensslv.h.in
+@@ -89,12 +89,12 @@ extern "C" {
+ 
+ # define OPENSSL_VERSION_TEXT "OpenSSL {- "$config{full_version} $config{release_date}" -}"
+ 
+-/* Synthesize OPENSSL_VERSION_NUMBER with the layout 0xMNN00PPSL */
++/* Synthesize OPENSSL_VERSION_NUMBER with the layout 0xMNN00PP0L */
+ # define OPENSSL_VERSION_NUMBER          \
+     ( (OPENSSL_VERSION_MAJOR<<28)        \
+       |(OPENSSL_VERSION_MINOR<<20)       \
+       |(OPENSSL_VERSION_PATCH<<4)        \
+-      |{- @config{prerelease} ? "0x0L" : "0xfL" -} )
++      |0x0L )
+ 
+ # ifdef  __cplusplus
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0056-Harden-property-put_str-helper-corner-case.patch b/package/libs/openssl/patches/0056-Harden-property-put_str-helper-corner-case.patch
new file mode 100644
index 0000000..843d2d2
--- /dev/null
+++ b/package/libs/openssl/patches/0056-Harden-property-put_str-helper-corner-case.patch
@@ -0,0 +1,47 @@
+From 95d70375bafc4c82663cae2dd67ddde853f63de6 Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <openssl-users@dukhovni.org>
+Date: Sat, 20 Sep 2025 14:02:52 +1000
+Subject: [PATCH 56/58] Harden property put_str() helper corner case
+
+The put_str() helper of the internal ossl_property_list_to_string()
+function failed to correctly check the remaining buffer length in a
+corner case in which a property name or string value needs quoting,
+and exactly one byte of unused space remained in the output buffer.
+
+The only potentially affected calling code is conditionally compiled
+(disabled by default) provider "QUERY" tracing that is executed only
+when also requested at runtime.  An initial fragment of the property
+list encoding would need to use up exactly 511 bytes, leaving just 1
+byte for the next string which requires quoting.  Bug reported by
+
+    Aniruddhan Murali (@ashamedbit)
+    Noble Saji Mathews (@NobleMathews)
+
+both from the University of Waterloo.
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tom Cosgrove <tom.cosgrove@arm.com>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+(Merged from https://github.com/openssl/openssl/pull/28624)
+
+(cherry picked from commit c6e44fa347aabfc279ec2e50a02fd764c2e8e241)
+---
+ crypto/property/property_parse.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/crypto/property/property_parse.c b/crypto/property/property_parse.c
+index 45c798f1b5..c3f4a7d0e9 100644
+--- a/crypto/property/property_parse.c
++++ b/crypto/property/property_parse.c
+@@ -642,7 +642,7 @@ static void put_str(const char *str, char **buf, size_t *remain, size_t *needed)
+         }
+ 
+     quotes = quote != '\0';
+-    if (*remain == 0) {
++    if (*remain <= (size_t)quotes) {
+         *needed += 2 * quotes;
+         return;
+     }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0057-Added-test-suggested-by-Shane-Lontis.patch b/package/libs/openssl/patches/0057-Added-test-suggested-by-Shane-Lontis.patch
new file mode 100644
index 0000000..03190d6
--- /dev/null
+++ b/package/libs/openssl/patches/0057-Added-test-suggested-by-Shane-Lontis.patch
@@ -0,0 +1,52 @@
+From da2e2872f181581a3a4c11b82eb30713eeea4256 Mon Sep 17 00:00:00 2001
+From: Viktor Dukhovni <openssl-users@dukhovni.org>
+Date: Mon, 22 Sep 2025 15:02:28 +1000
+Subject: [PATCH 57/58] Added test suggested by Shane Lontis
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tom Cosgrove <tom.cosgrove@arm.com>
+Reviewed-by: Shane Lontis <shane.lontis@oracle.com>
+(Merged from https://github.com/openssl/openssl/pull/28624)
+
+(cherry picked from commit 38e8981004308ed6d7cdbd3178c826989a30e31a)
+---
+ test/property_test.c | 17 +++++++++++++++++
+ 1 file changed, 17 insertions(+)
+
+diff --git a/test/property_test.c b/test/property_test.c
+index 1f1171ad90..f3fd0291b9 100644
+--- a/test/property_test.c
++++ b/test/property_test.c
+@@ -665,6 +665,22 @@ static int test_property_list_to_string(int i)
+     return ret;
+ }
+ 
++static int test_property_list_to_string_bounds(void)
++{
++    OSSL_PROPERTY_LIST *pl = NULL;
++    char buf[16];
++    int ret = 0;
++
++    if (!TEST_ptr(pl = ossl_parse_query(NULL, "provider='$1'", 1)))
++        goto err;
++    if (!TEST_size_t_eq(ossl_property_list_to_string(NULL, pl, buf, 10), 14))
++        goto err;
++    ret = 1;
++ err:
++    ossl_property_free(pl);
++    return ret;
++}
++
+ int setup_tests(void)
+ {
+     ADD_TEST(test_property_string);
+@@ -679,5 +695,6 @@ int setup_tests(void)
+     ADD_TEST(test_query_cache_stochastic);
+     ADD_TEST(test_fips_mode);
+     ADD_ALL_TESTS(test_property_list_to_string, OSSL_NELEM(to_string_tests));
++    ADD_TEST(test_property_list_to_string_bounds);
+     return 1;
+ }
+-- 
+2.46.2.windows.1
+
diff --git a/package/libs/openssl/patches/0058-bio_ok.c-Integer-Overflow-in-BIO_f_reliable-record-p.patch b/package/libs/openssl/patches/0058-bio_ok.c-Integer-Overflow-in-BIO_f_reliable-record-p.patch
new file mode 100644
index 0000000..4ee64cb
--- /dev/null
+++ b/package/libs/openssl/patches/0058-bio_ok.c-Integer-Overflow-in-BIO_f_reliable-record-p.patch
@@ -0,0 +1,68 @@
+From 967d3ce72c450f6bf75a65ef5955c4464500e17d Mon Sep 17 00:00:00 2001
+From: Luigino Camastra <luigino.camastra@aisle.com>
+Date: Wed, 10 Sep 2025 12:13:11 +0200
+Subject: [PATCH 58/58] bio_ok.c: Integer Overflow in BIO_f_reliable record
+ parser leads to Out-of-Bounds Read
+
+Reviewed-by: Paul Dale <ppzgs1@gmail.com>
+Reviewed-by: Tomas Mraz <tomas@openssl.org>
+(Merged from https://github.com/openssl/openssl/pull/28504)
+
+(cherry picked from commit 312904b216f917646ad1909ce8bca8bf8a52e5d7)
+---
+ crypto/evp/bio_ok.c | 25 ++++++++++++++-----------
+ 1 file changed, 14 insertions(+), 11 deletions(-)
+
+diff --git a/crypto/evp/bio_ok.c b/crypto/evp/bio_ok.c
+index 97e67fcb68..88b376efeb 100644
+--- a/crypto/evp/bio_ok.c
++++ b/crypto/evp/bio_ok.c
+@@ -557,7 +557,7 @@ static int block_in(BIO *b)
+ {
+     BIO_OK_CTX *ctx;
+     EVP_MD_CTX *md;
+-    unsigned long tl = 0;
++    size_t tl = 0;
+     unsigned char tmp[EVP_MAX_MD_SIZE];
+     int md_size;
+ 
+@@ -568,15 +568,18 @@ static int block_in(BIO *b)
+         goto berr;
+ 
+     assert(sizeof(tl) >= OK_BLOCK_BLOCK); /* always true */
+-    tl = ctx->buf[0];
+-    tl <<= 8;
+-    tl |= ctx->buf[1];
+-    tl <<= 8;
+-    tl |= ctx->buf[2];
+-    tl <<= 8;
+-    tl |= ctx->buf[3];
+-
+-    if (ctx->buf_len < tl + OK_BLOCK_BLOCK + md_size)
++    tl = ((size_t)ctx->buf[0] << 24)
++           | ((size_t)ctx->buf[1] << 16)
++           | ((size_t)ctx->buf[2] << 8)
++           | ((size_t)ctx->buf[3]);
++
++    if (tl > OK_BLOCK_SIZE)
++        goto berr;
++
++    if (tl > SIZE_MAX - OK_BLOCK_BLOCK - (size_t)md_size)
++        goto berr;
++
++    if (ctx->buf_len < tl + OK_BLOCK_BLOCK + (size_t)md_size)
+         return 1;
+ 
+     if (!EVP_DigestUpdate(md,
+@@ -584,7 +587,7 @@ static int block_in(BIO *b)
+         goto berr;
+     if (!EVP_DigestFinal_ex(md, tmp, NULL))
+         goto berr;
+-    if (memcmp(&(ctx->buf[tl + OK_BLOCK_BLOCK]), tmp, md_size) == 0) {
++    if (memcmp(&(ctx->buf[tl + OK_BLOCK_BLOCK]), tmp, (size_t)md_size) == 0) {
+         /* there might be parts from next block lurking around ! */
+         ctx->buf_off_save = tl + OK_BLOCK_BLOCK + md_size;
+         ctx->buf_len_save = ctx->buf_len;
+-- 
+2.46.2.windows.1
+
-- 
2.46.2.windows.1

