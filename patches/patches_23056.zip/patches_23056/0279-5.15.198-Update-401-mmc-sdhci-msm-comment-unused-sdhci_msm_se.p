diff --git a/target/linux/ipq40xx/patches-5.15/401-mmc-sdhci-msm-comment-unused-sdhci_msm_set_clock.patch b/target/linux/ipq40xx/patches-5.15/401-mmc-sdhci-msm-comment-unused-sdhci_msm_set_clock.patch
index 4290f8a..0db3f12 100644
--- a/target/linux/ipq40xx/patches-5.15/401-mmc-sdhci-msm-comment-unused-sdhci_msm_set_clock.patch
+++ b/target/linux/ipq40xx/patches-5.15/401-mmc-sdhci-msm-comment-unused-sdhci_msm_set_clock.patch
@@ -13,7 +13,7 @@ Signed-off-by: Christian Marangi <ansuelsmth@gmail.com>
 
 --- a/drivers/mmc/host/sdhci-msm.c
 +++ b/drivers/mmc/host/sdhci-msm.c
-@@ -1800,49 +1800,49 @@ static unsigned int sdhci_msm_get_min_cl
+@@ -1800,50 +1800,50 @@ static unsigned int sdhci_msm_get_min_cl
  	return SDHCI_MSM_MIN_CLOCK;
  }
  
@@ -48,6 +48,7 @@ Signed-off-by: Christian Marangi <ansuelsmth@gmail.com>
 -{
 -	struct sdhci_pltfm_host *pltfm_host = sdhci_priv(host);
 -	struct sdhci_msm_host *msm_host = sdhci_pltfm_priv(pltfm_host);
+-	struct mmc_ios ios = host->mmc->ios;
 -
 -	if (!clock) {
 -		host->mmc->actual_clock = msm_host->clk_rate = 0;
@@ -56,7 +57,7 @@ Signed-off-by: Christian Marangi <ansuelsmth@gmail.com>
 -
 -	sdhci_msm_hc_select_mode(host);
 -
--	msm_set_clock_rate_for_bus_mode(host, clock);
+-	msm_set_clock_rate_for_bus_mode(host, ios.clock, ios.timing);
 -out:
 -	__sdhci_msm_set_clock(host, clock);
 -}
@@ -91,6 +92,7 @@ Signed-off-by: Christian Marangi <ansuelsmth@gmail.com>
 +// {
 +// 	struct sdhci_pltfm_host *pltfm_host = sdhci_priv(host);
 +// 	struct sdhci_msm_host *msm_host = sdhci_pltfm_priv(pltfm_host);
++// 	struct mmc_ios ios = host->mmc->ios;
 +
 +// 	if (!clock) {
 +// 		host->mmc->actual_clock = msm_host->clk_rate = 0;
@@ -99,7 +101,7 @@ Signed-off-by: Christian Marangi <ansuelsmth@gmail.com>
 +
 +// 	sdhci_msm_hc_select_mode(host);
 +
-+// 	msm_set_clock_rate_for_bus_mode(host, clock);
++// 	msm_set_clock_rate_for_bus_mode(host, ios.clock, ios.timing);
 +// out:
 +// 	__sdhci_msm_set_clock(host, clock);
 +// }
-- 
2.46.2.windows.1

