diff --git a/include/kernel-5.15 b/include/kernel-5.15
index b90abee943879f..09e76b7f10ad25 100644
--- a/include/kernel-5.15
+++ b/include/kernel-5.15
@@ -1,2 +1,2 @@
-LINUX_VERSION-5.15 = .212
-LINUX_KERNEL_HASH-5.15.212 = c396aeebc90c7aecb7f7abdf504c19b372c9926eb0cf0e91f9f09d7d870b65fe
+LINUX_VERSION-5.15 = .213
+LINUX_KERNEL_HASH-5.15.213 = c4721b4b8535f3e418ee579c70645fbfd5ddfba4943c31b919e8c9522371e1d8
