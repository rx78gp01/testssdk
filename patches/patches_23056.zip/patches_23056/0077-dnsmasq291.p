diff --git a/package/network/services/dnsmasq/Makefile b/package/network/services/dnsmasq/Makefile
index 47a5ae54ae7f5c..5290f1e4681663 100644
--- a/package/network/services/dnsmasq/Makefile
+++ b/package/network/services/dnsmasq/Makefile
@@ -8,13 +8,13 @@
 include $(TOPDIR)/rules.mk
 
 PKG_NAME:=dnsmasq
-PKG_UPSTREAM_VERSION:=2.90
+PKG_UPSTREAM_VERSION:=2.91
 PKG_VERSION:=$(subst test,~~test,$(subst rc,~rc,$(PKG_UPSTREAM_VERSION)))
-PKG_RELEASE:=2
+PKG_RELEASE:=1
 
 PKG_SOURCE:=$(PKG_NAME)-$(PKG_UPSTREAM_VERSION).tar.xz
 PKG_SOURCE_URL:=https://thekelleys.org.uk/dnsmasq/
-PKG_HASH:=8e50309bd837bfec9649a812e066c09b6988b73d749b7d293c06c57d46a109e4
+PKG_HASH:=f622682848b33677adb2b6ad08264618a2ae0a01da486a93fd8cd91186b3d153
 
 PKG_LICENSE:=GPL-2.0
 PKG_LICENSE_FILES:=COPYING
diff --git a/package/network/services/dnsmasq/patches/0001-Fix-spurious-resource-limit-exceeded-messages.patch b/package/network/services/dnsmasq/patches/0001-Fix-spurious-resource-limit-exceeded-messages.patch
deleted file mode 100644
index f25ee20413fbfc..00000000000000
--- a/package/network/services/dnsmasq/patches/0001-Fix-spurious-resource-limit-exceeded-messages.patch
+++ /dev/null
@@ -1,43 +0,0 @@
-From 1ed783b8d7343c42910a61f12a8fc6237eb80417 Mon Sep 17 00:00:00 2001
-From: Simon Kelley <simon@thekelleys.org.uk>
-Date: Mon, 19 Feb 2024 12:22:43 +0000
-Subject: Fix spurious "resource limit exceeded" messages.
-
-Replies from upstream with a REFUSED rcode can result in
-log messages stating that a resource limit has been exceeded,
-which is not the case.
-
-Thanks to Dominik Derigs and the Pi-hole project for
-spotting this.
----
- CHANGELOG     | 5 +++++
- src/forward.c | 6 +++---
- 2 files changed, 8 insertions(+), 3 deletions(-)
-
---- a/CHANGELOG
-+++ b/CHANGELOG
-@@ -1,3 +1,8 @@
-+version 2.91
-+	Fix spurious "resource limit exceeded messages". Thanks to 
-+	Dominik Derigs for the bug report.
-+	
-+
- version 2.90
- 	Fix reversion in --rev-server introduced in 2.88 which
- 	caused breakage if the prefix length is not exactly divisible
---- a/src/forward.c
-+++ b/src/forward.c
-@@ -937,10 +937,10 @@ static void dnssec_validate(struct frec
- 	status = dnssec_validate_reply(now, header, plen, daemon->namebuff, daemon->keyname, &forward->class, 
- 				       !option_bool(OPT_DNSSEC_IGN_NS) && (forward->sentto->flags & SERV_DO_DNSSEC),
- 				       NULL, NULL, NULL, &orig->validate_counter);
--    }
- 
--  if (STAT_ISEQUAL(status, STAT_ABANDONED))
--    log_resource = 1;
-+      if (STAT_ISEQUAL(status, STAT_ABANDONED))
-+	log_resource = 1;
-+    }
-   
-   /* Can't validate, as we're missing key data. Put this
-      answer aside, whilst we get that. */     
diff --git a/package/network/services/dnsmasq/patches/0002-PATCH-Fix-error-introduced-in-51471cafa5a4fa44d6fe49.patch b/package/network/services/dnsmasq/patches/0002-PATCH-Fix-error-introduced-in-51471cafa5a4fa44d6fe49.patch
deleted file mode 100644
index 5c50ae84463b30..00000000000000
--- a/package/network/services/dnsmasq/patches/0002-PATCH-Fix-error-introduced-in-51471cafa5a4fa44d6fe49.patch
+++ /dev/null
@@ -1,31 +0,0 @@
-From ccff85ad72d2f858d9743d40525128e4f62d41a8 Mon Sep 17 00:00:00 2001
-From: renmingshuai <renmingshuai@huawei.com>
-Date: Wed, 21 Feb 2024 00:24:25 +0000
-Subject: [PATCH] Fix error introduced in
- 51471cafa5a4fa44d6fe490885d9910bd72a5907
-
-Signed-off-by: renmingshuai <renmingshuai@huawei.com>
----
- src/dnssec.c | 4 ++--
- 1 file changed, 2 insertions(+), 2 deletions(-)
-
---- a/src/dnssec.c
-+++ b/src/dnssec.c
-@@ -1547,7 +1547,7 @@ static int prove_non_existence_nsec3(str
-       nsecs[i] = NULL; /* Speculative, will be restored if OK. */
-       
-       if (!(p = skip_name(nsec3p, header, plen, 15)))
--	return 0; /* bad packet */
-+	return DNSSEC_FAIL_BADPACKET; /* bad packet */
-       
-       p += 10; /* type, class, TTL, rdlen */
-       
-@@ -1640,7 +1640,7 @@ static int prove_non_existence_nsec3(str
-   if (!wildname)
-     {
-       if (!(wildcard = strchr(next_closest, '.')) || wildcard == next_closest)
--	return 0;
-+	return DNSSEC_FAIL_NONSEC;
-       
-       wildcard--;
-       *wildcard = '*';
diff --git a/package/network/services/dnsmasq/patches/200-ubus_dns.patch b/package/network/services/dnsmasq/patches/200-ubus_dns.patch
index 72acbaeba934fe..a1a668818ea433 100644
--- a/package/network/services/dnsmasq/patches/200-ubus_dns.patch
+++ b/package/network/services/dnsmasq/patches/200-ubus_dns.patch
@@ -1,16 +1,16 @@
 --- a/src/dnsmasq.c
 +++ b/src/dnsmasq.c
-@@ -2021,6 +2021,10 @@ static void check_dns_listeners(time_t n
- 		  daemon->pipe_to_parent = pipefd[1];
- 		}
+@@ -2097,6 +2097,10 @@
+       daemon->pipe_to_parent = pipefd[1];
+     }
  
 +#ifdef HAVE_UBUS
-+	      drop_ubus_listeners();
++	  drop_ubus_listeners();
 +#endif
 +
- 	      /* start with no upstream connections. */
- 	      for (s = daemon->servers; s; s = s->next)
- 		 s->tcpfd = -1; 
+   /* The connected socket inherits non-blocking
+      attribute from the listening socket. 
+      Reset that here. */
 --- a/src/dnsmasq.h
 +++ b/src/dnsmasq.h
 @@ -1670,14 +1670,26 @@ void emit_dbus_signal(int action, struct
