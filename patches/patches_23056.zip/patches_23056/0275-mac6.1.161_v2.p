diff --git a/package/kernel/mac80211/patches/subsys/804b.patch b/package/kernel/mac80211/patches/subsys/804b.patch
new file mode 100644
index 0000000..8de46a9
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/804b.patch
@@ -0,0 +1,33 @@
+From f4aec9cc37f0d24bff81a17c3142077c94a78b74 Mon Sep 17 00:00:00 2001
+From: Dan Carpenter <dan.carpenter@linaro.org>
+Date: Wed, 3 Dec 2025 14:14:47 +0300
+Subject: [PATCH] wifi: cfg80211: sme: store capped length in
+ __cfg80211_connect_result()
+
+[ Upstream commit 2b77b9551d1184cb5af8271ff350e6e2c1b3db0d ]
+
+The QGenie AI code review tool says we should store the capped length to
+wdev->u.client.ssid_len.  The AI is correct.
+
+Fixes: 62b635dcd69c ("wifi: cfg80211: sme: cap SSID length in __cfg80211_connect_result()")
+Signed-off-by: Dan Carpenter <dan.carpenter@linaro.org>
+Link: https://patch.msgid.link/aTAbp5RleyH_lnZE@stanley.mountain
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/wireless/sme.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/net/wireless/sme.c b/net/wireless/sme.c
+index ed16e852133e7..26106802b17b7 100644
+--- a/net/wireless/sme.c
++++ b/net/wireless/sme.c
+@@ -896,7 +896,7 @@ void __cfg80211_connect_result(struct net_device *dev,
+ 
+ 			ssid_len = min(ssid->datalen, IEEE80211_MAX_SSID_LEN);
+ 			memcpy(wdev->u.client.ssid, ssid->data, ssid_len);
+-			wdev->u.client.ssid_len = ssid->datalen;
++			wdev->u.client.ssid_len = ssid_len;
+ 			break;
+ 		}
+ 		rcu_read_unlock();
diff --git a/package/kernel/mac80211/patches/subsys/805b.patch b/package/kernel/mac80211/patches/subsys/805b.patch
new file mode 100644
index 0000000..c91ee5e
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/805b.patch
@@ -0,0 +1,289 @@
+From 1108d1134342f7913a7af5e247a63c51d93db713 Mon Sep 17 00:00:00 2001
+From: Avraham Stern <avraham.stern@intel.com>
+Date: Wed, 1 Mar 2023 12:09:21 +0200
+Subject: [PATCH] wifi: nl80211: add a command to enable/disable HW
+ timestamping
+
+[ Upstream commit cbbaf2bb829b6c4ef911d4a725fc9b1fadc1e43f ]
+
+Add a command to enable and disable HW timestamping of TM and FTM
+frames. HW timestamping can be enabled for a specific mac address
+or for all addresses.
+
+The low level driver will indicate how many peers HW timestamping
+can be enabled concurrently, and this information will be passed
+to userspace.
+
+Signed-off-by: Avraham Stern <avraham.stern@intel.com>
+Signed-off-by: Gregory Greenman <gregory.greenman@intel.com>
+Link: https://lore.kernel.org/r/20230301115906.05678d7b1c17.Iccc08869ea8156f1c71a3111a47f86dd56234bd0@changeid
+[switch to needing netdev UP, minor edits]
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Stable-dep-of: a519be2f5d95 ("wifi: mac80211: do not use old MBSSID elements")
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ include/net/cfg80211.h       | 27 ++++++++++++++++++++++++++
+ include/uapi/linux/nl80211.h | 22 +++++++++++++++++++++
+ net/wireless/nl80211.c       | 37 ++++++++++++++++++++++++++++++++++++
+ net/wireless/rdev-ops.h      | 17 +++++++++++++++++
+ net/wireless/trace.h         | 25 ++++++++++++++++++++++++
+ 5 files changed, 128 insertions(+)
+
+diff --git a/include/net/cfg80211.h b/include/net/cfg80211.h
+index 7efa3adf234d0..34709bd733ed2 100644
+--- a/include/net/cfg80211.h
++++ b/include/net/cfg80211.h
+@@ -830,6 +830,18 @@ struct cfg80211_fils_aad {
+ 	const u8 *anonce;
+ };
+ 
++/**
++ * struct cfg80211_set_hw_timestamp - enable/disable HW timestamping
++ * @macaddr: peer MAC address. NULL to enable/disable HW timestamping for all
++ *	addresses.
++ * @enable: if set, enable HW timestamping for the specified MAC address.
++ *	Otherwise disable HW timestamping for the specified MAC address.
++ */
++struct cfg80211_set_hw_timestamp {
++	const u8 *macaddr;
++	bool enable;
++};
++
+ /**
+  * cfg80211_get_chandef_type - return old channel type from chandef
+  * @chandef: the channel definition
+@@ -4291,6 +4303,8 @@ struct mgmt_frame_regs {
+  * @add_link_station: Add a link to a station.
+  * @mod_link_station: Modify a link of a station.
+  * @del_link_station: Remove a link of a station.
++ *
++ * @set_hw_timestamp: Enable/disable HW timestamping of TM/FTM frames.
+  */
+ struct cfg80211_ops {
+ 	int	(*suspend)(struct wiphy *wiphy, struct cfg80211_wowlan *wow);
+@@ -4644,6 +4658,8 @@ struct cfg80211_ops {
+ 				    struct link_station_parameters *params);
+ 	int	(*del_link_station)(struct wiphy *wiphy, struct net_device *dev,
+ 				    struct link_station_del_parameters *params);
++	int	(*set_hw_timestamp)(struct wiphy *wiphy, struct net_device *dev,
++				    struct cfg80211_set_hw_timestamp *hwts);
+ };
+ 
+ /*
+@@ -5099,6 +5115,8 @@ struct wiphy_iftype_akm_suites {
+ 	int n_akm_suites;
+ };
+ 
++#define CFG80211_HW_TIMESTAMP_ALL_PEERS	0xffff
++
+ /**
+  * struct wiphy - wireless hardware description
+  * @mtx: mutex for the data (structures) of this device
+@@ -5308,6 +5326,13 @@ struct wiphy_iftype_akm_suites {
+  *	NL80211_MAX_NR_AKM_SUITES in order to avoid compatibility issues with
+  *	legacy userspace and maximum allowed value is
+  *	CFG80211_MAX_NUM_AKM_SUITES.
++ *
++ * @hw_timestamp_max_peers: maximum number of peers that the driver supports
++ *	enabling HW timestamping for concurrently. Setting this field to a
++ *	non-zero value indicates that the driver supports HW timestamping.
++ *	A value of %CFG80211_HW_TIMESTAMP_ALL_PEERS indicates the driver
++ *	supports enabling HW timestamping for all peers (i.e. no need to
++ *	specify a mac address).
+  */
+ struct wiphy {
+ 	struct mutex mtx;
+@@ -5456,6 +5481,8 @@ struct wiphy {
+ 	u8 ema_max_profile_periodicity;
+ 	u16 max_num_akm_suites;
+ 
++	u16 hw_timestamp_max_peers;
++
+ 	char priv[] __aligned(NETDEV_ALIGN);
+ };
+ 
+diff --git a/include/uapi/linux/nl80211.h b/include/uapi/linux/nl80211.h
+index 173aef8916aeb..274d1b34c9545 100644
+--- a/include/uapi/linux/nl80211.h
++++ b/include/uapi/linux/nl80211.h
+@@ -1281,6 +1281,16 @@
+  * @NL80211_CMD_MODIFY_LINK_STA: Modify a link of an MLD station
+  * @NL80211_CMD_REMOVE_LINK_STA: Remove a link of an MLD station
+  *
++ * @NL80211_CMD_SET_HW_TIMESTAMP: Enable/disable HW timestamping of Timing
++ *	measurement and Fine timing measurement frames. If %NL80211_ATTR_MAC
++ *	is included, enable/disable HW timestamping only for frames to/from the
++ *	specified MAC address. Otherwise enable/disable HW timestamping for
++ *	all TM/FTM frames (including ones that were enabled with specific MAC
++ *	address). If %NL80211_ATTR_HW_TIMESTAMP_ENABLED is not included, disable
++ *	HW timestamping.
++ *	The number of peers that HW timestamping can be enabled for concurrently
++ *	is indicated by %NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS.
++ *
+  * @NL80211_CMD_MAX: highest used command number
+  * @__NL80211_CMD_AFTER_LAST: internal use
+  */
+@@ -1532,6 +1542,8 @@ enum nl80211_commands {
+ 	NL80211_CMD_MODIFY_LINK_STA,
+ 	NL80211_CMD_REMOVE_LINK_STA,
+ 
++	NL80211_CMD_SET_HW_TIMESTAMP,
++
+ 	/* add new commands above here */
+ 
+ 	/* used to define NL80211_CMD_MAX below */
+@@ -2757,6 +2769,13 @@ enum nl80211_commands {
+  * @NL80211_ATTR_WIPHY_ANTENNA_GAIN: Configured antenna gain. Used to reduce
+  *	transmit power to stay within regulatory limits. u32, dBi.
+  *
++ * @NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS: Maximum number of peers that HW
++ *	timestamping can be enabled for concurrently (u16), a wiphy attribute.
++ *	A value of 0xffff indicates setting for all peers (i.e. not specifying
++ *	an address with %NL80211_CMD_SET_HW_TIMESTAMP) is supported.
++ * @NL80211_ATTR_HW_TIMESTAMP_ENABLED: Indicates whether HW timestamping should
++ *	be enabled or not (flag attribute).
++ *
+  * @NUM_NL80211_ATTR: total number of nl80211_attrs available
+  * @NL80211_ATTR_MAX: highest attribute number currently defined
+  * @__NL80211_ATTR_AFTER_LAST: internal use
+@@ -3288,6 +3307,9 @@ enum nl80211_attrs {
+ 
+ 	NL80211_ATTR_WIPHY_ANTENNA_GAIN,
+ 
++	NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS,
++	NL80211_ATTR_HW_TIMESTAMP_ENABLED,
++
+ 	/* add attributes here, update the policy in nl80211.c */
+ 
+ 	__NL80211_ATTR_AFTER_LAST,
+diff --git a/net/wireless/nl80211.c b/net/wireless/nl80211.c
+index 0eb8c8e0bf180..5e2b676f5ce03 100644
+--- a/net/wireless/nl80211.c
++++ b/net/wireless/nl80211.c
+@@ -811,6 +811,9 @@ static const struct nla_policy nl80211_policy[NUM_NL80211_ATTR] = {
+ 	[NL80211_ATTR_MAX_NUM_AKM_SUITES] = { .type = NLA_REJECT },
+ 	[NL80211_ATTR_PUNCT_BITMAP] = NLA_POLICY_RANGE(NLA_U8, 0, 0xffff),
+ 	[NL80211_ATTR_WIPHY_ANTENNA_GAIN] = { .type = NLA_U32 },
++
++	[NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS] = { .type = NLA_U16 },
++	[NL80211_ATTR_HW_TIMESTAMP_ENABLED] = { .type = NLA_FLAG },
+ };
+ 
+ /* policy for the key attributes */
+@@ -2965,6 +2968,11 @@ static int nl80211_send_wiphy(struct cfg80211_registered_device *rdev,
+ 		if (rdev->wiphy.flags & WIPHY_FLAG_SUPPORTS_MLO)
+ 			nla_put_flag(msg, NL80211_ATTR_MLO_SUPPORT);
+ 
++		if (rdev->wiphy.hw_timestamp_max_peers &&
++		    nla_put_u16(msg, NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS,
++				rdev->wiphy.hw_timestamp_max_peers))
++			goto nla_put_failure;
++
+ 		/* done */
+ 		state->split_start = 0;
+ 		break;
+@@ -16162,6 +16170,29 @@ nl80211_remove_link_station(struct sk_buff *skb, struct genl_info *info)
+ 	return ret;
+ }
+ 
++static int nl80211_set_hw_timestamp(struct sk_buff *skb,
++				    struct genl_info *info)
++{
++	struct cfg80211_registered_device *rdev = info->user_ptr[0];
++	struct net_device *dev = info->user_ptr[1];
++	struct cfg80211_set_hw_timestamp hwts = {};
++
++	if (!rdev->wiphy.hw_timestamp_max_peers)
++		return -EOPNOTSUPP;
++
++	if (!info->attrs[NL80211_ATTR_MAC] &&
++	    rdev->wiphy.hw_timestamp_max_peers != CFG80211_HW_TIMESTAMP_ALL_PEERS)
++		return -EOPNOTSUPP;
++
++	if (info->attrs[NL80211_ATTR_MAC])
++		hwts.macaddr = nla_data(info->attrs[NL80211_ATTR_MAC]);
++
++	hwts.enable =
++		nla_get_flag(info->attrs[NL80211_ATTR_HW_TIMESTAMP_ENABLED]);
++
++	return rdev_set_hw_timestamp(rdev, dev, &hwts);
++}
++
+ #define NL80211_FLAG_NEED_WIPHY		0x01
+ #define NL80211_FLAG_NEED_NETDEV	0x02
+ #define NL80211_FLAG_NEED_RTNL		0x04
+@@ -17333,6 +17364,12 @@ static const struct genl_small_ops nl80211_small_ops[] = {
+ 		.internal_flags = IFLAGS(NL80211_FLAG_NEED_NETDEV_UP |
+ 					 NL80211_FLAG_MLO_VALID_LINK_ID),
+ 	},
++	{
++		.cmd = NL80211_CMD_SET_HW_TIMESTAMP,
++		.doit = nl80211_set_hw_timestamp,
++		.flags = GENL_UNS_ADMIN_PERM,
++		.internal_flags = IFLAGS(NL80211_FLAG_NEED_NETDEV_UP),
++	},
+ };
+ 
+ static struct genl_family nl80211_fam __ro_after_init = {
+diff --git a/net/wireless/rdev-ops.h b/net/wireless/rdev-ops.h
+index 5f210686c4110..df7f88ca0db38 100644
+--- a/net/wireless/rdev-ops.h
++++ b/net/wireless/rdev-ops.h
+@@ -1498,4 +1498,21 @@ rdev_del_link_station(struct cfg80211_registered_device *rdev,
+ 	return ret;
+ }
+ 
++static inline int
++rdev_set_hw_timestamp(struct cfg80211_registered_device *rdev,
++		      struct net_device *dev,
++		      struct cfg80211_set_hw_timestamp *hwts)
++{
++	struct wiphy *wiphy = &rdev->wiphy;
++	int ret;
++
++	if (!rdev->ops->set_hw_timestamp)
++		return -EOPNOTSUPP;
++
++	trace_rdev_set_hw_timestamp(wiphy, dev, hwts);
++	ret = rdev->ops->set_hw_timestamp(wiphy, dev, hwts);
++	trace_rdev_return_int(wiphy, ret);
++
++	return ret;
++}
+ #endif /* __CFG80211_RDEV_OPS */
+diff --git a/net/wireless/trace.h b/net/wireless/trace.h
+index 137937b1f4b39..f325ca28facea 100644
+--- a/net/wireless/trace.h
++++ b/net/wireless/trace.h
+@@ -3901,6 +3901,31 @@ TRACE_EVENT(rdev_del_link_station,
+ 		  __entry->link_id)
+ );
+ 
++TRACE_EVENT(rdev_set_hw_timestamp,
++	TP_PROTO(struct wiphy *wiphy, struct net_device *netdev,
++		 struct cfg80211_set_hw_timestamp *hwts),
++
++	TP_ARGS(wiphy, netdev, hwts),
++
++	TP_STRUCT__entry(
++		WIPHY_ENTRY
++		NETDEV_ENTRY
++		MAC_ENTRY(macaddr)
++		__field(bool, enable)
++	),
++
++	TP_fast_assign(
++		WIPHY_ASSIGN;
++		NETDEV_ASSIGN;
++		MAC_ASSIGN(macaddr, hwts->macaddr);
++		__entry->enable = hwts->enable;
++	),
++
++	TP_printk(WIPHY_PR_FMT ", " NETDEV_PR_FMT ", mac %pM, enable: %u",
++		  WIPHY_PR_ARG, NETDEV_PR_ARG, __entry->macaddr,
++		  __entry->enable)
++);
++
+ #endif /* !__RDEV_OPS_TRACE || TRACE_HEADER_MULTI_READ */
+ 
+ #undef TRACE_INCLUDE_PATH
diff --git a/package/kernel/mac80211/patches/subsys/807.patch b/package/kernel/mac80211/patches/subsys/807.patch
new file mode 100644
index 0000000..5c188b4
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/807.patch
@@ -0,0 +1,236 @@
+From e5186fb357b3d3287c076f8d4bc48f499f172a9a Mon Sep 17 00:00:00 2001
+From: Aloka Dixit <quic_alokad@quicinc.com>
+Date: Thu, 23 Mar 2023 04:38:01 -0700
+Subject: [PATCH] mac80211: support RNR for EMA AP
+
+[ Upstream commit 68b9bea267bfc1259e195dcac1bf69db0c0c28da ]
+
+Generate EMA beacons, each including MBSSID and RNR elements at a given
+index. If number of stored RNR elements is more than the number of
+MBSSID elements then add those in every EMA beacon.
+
+Signed-off-by: Aloka Dixit <quic_alokad@quicinc.com>
+Link: https://lore.kernel.org/r/20230323113801.6903-3-quic_alokad@quicinc.com
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Stable-dep-of: a519be2f5d95 ("wifi: mac80211: do not use old MBSSID elements")
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/mac80211/cfg.c         | 63 +++++++++++++++++++++++++++++++++++---
+ net/mac80211/ieee80211_i.h | 21 +++++++++++--
+ net/mac80211/tx.c          | 10 ++++++
+ 3 files changed, 86 insertions(+), 8 deletions(-)
+
+diff --git a/net/mac80211/cfg.c b/net/mac80211/cfg.c
+index 72dd534492bfe..a25d647c1c4b6 100644
+--- a/net/mac80211/cfg.c
++++ b/net/mac80211/cfg.c
+@@ -1087,6 +1087,23 @@ ieee80211_copy_mbssid_beacon(u8 *pos, struct cfg80211_mbssid_elems *dst,
+ 	return offset;
+ }
+ 
++static int
++ieee80211_copy_rnr_beacon(u8 *pos, struct cfg80211_rnr_elems *dst,
++			  struct cfg80211_rnr_elems *src)
++{
++	int i, offset = 0;
++
++	for (i = 0; i < src->cnt; i++) {
++		memcpy(pos + offset, src->elem[i].data, src->elem[i].len);
++		dst->elem[i].len = src->elem[i].len;
++		dst->elem[i].data = pos + offset;
++		offset += dst->elem[i].len;
++	}
++	dst->cnt = src->cnt;
++
++	return offset;
++}
++
+ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 				   struct ieee80211_link_data *link,
+ 				   struct cfg80211_beacon_data *params,
+@@ -1094,6 +1111,7 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 				   const struct ieee80211_color_change_settings *cca)
+ {
+ 	struct cfg80211_mbssid_elems *mbssid = NULL;
++	struct cfg80211_rnr_elems *rnr = NULL;
+ 	struct beacon_data *new, *old;
+ 	int new_head_len, new_tail_len;
+ 	int size, err;
+@@ -1125,11 +1143,21 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 	if (params->mbssid_ies) {
+ 		mbssid = params->mbssid_ies;
+ 		size += struct_size(new->mbssid_ies, elem, mbssid->cnt);
+-		size += ieee80211_get_mbssid_beacon_len(mbssid, mbssid->cnt);
++		if (params->rnr_ies) {
++			rnr = params->rnr_ies;
++			size += struct_size(new->rnr_ies, elem, rnr->cnt);
++		}
++		size += ieee80211_get_mbssid_beacon_len(mbssid, rnr,
++							mbssid->cnt);
+ 	} else if (old && old->mbssid_ies) {
+ 		mbssid = old->mbssid_ies;
+ 		size += struct_size(new->mbssid_ies, elem, mbssid->cnt);
+-		size += ieee80211_get_mbssid_beacon_len(mbssid, mbssid->cnt);
++		if (old && old->rnr_ies) {
++			rnr = old->rnr_ies;
++			size += struct_size(new->rnr_ies, elem, rnr->cnt);
++		}
++		size += ieee80211_get_mbssid_beacon_len(mbssid, rnr,
++							mbssid->cnt);
+ 	}
+ 
+ 	new = kzalloc(size, GFP_KERNEL);
+@@ -1140,7 +1168,7 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 
+ 	/*
+ 	 * pointers go into the block we allocated,
+-	 * memory is | beacon_data | head | tail | mbssid_ies
++	 * memory is | beacon_data | head | tail | mbssid_ies | rnr_ies
+ 	 */
+ 	new->head = ((u8 *) new) + sizeof(*new);
+ 	new->tail = new->head + new_head_len;
+@@ -1152,7 +1180,13 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 
+ 		new->mbssid_ies = (void *)pos;
+ 		pos += struct_size(new->mbssid_ies, elem, mbssid->cnt);
+-		ieee80211_copy_mbssid_beacon(pos, new->mbssid_ies, mbssid);
++		pos += ieee80211_copy_mbssid_beacon(pos, new->mbssid_ies,
++						    mbssid);
++		if (rnr) {
++			new->rnr_ies = (void *)pos;
++			pos += struct_size(new->rnr_ies, elem, rnr->cnt);
++			ieee80211_copy_rnr_beacon(pos, new->rnr_ies, rnr);
++		}
+ 		/* update bssid_indicator */
+ 		link_conf->bssid_indicator =
+ 			ilog2(__roundup_pow_of_two(mbssid->cnt + 1));
+@@ -1448,6 +1482,7 @@ static void ieee80211_free_next_beacon(struct ieee80211_link_data *link)
+ 		return;
+ 
+ 	kfree(link->u.ap.next_beacon->mbssid_ies);
++	kfree(link->u.ap.next_beacon->rnr_ies);
+ 	kfree(link->u.ap.next_beacon);
+ 	link->u.ap.next_beacon = NULL;
+ }
+@@ -3360,6 +3395,7 @@ cfg80211_beacon_dup(struct cfg80211_beacon_data *beacon)
+ 
+ 	if (beacon->mbssid_ies)
+ 		len += ieee80211_get_mbssid_beacon_len(beacon->mbssid_ies,
++						       beacon->rnr_ies,
+ 						       beacon->mbssid_ies->cnt);
+ 
+ 	new_beacon = kzalloc(sizeof(*new_beacon) + len, GFP_KERNEL);
+@@ -3375,6 +3411,18 @@ cfg80211_beacon_dup(struct cfg80211_beacon_data *beacon)
+ 			kfree(new_beacon);
+ 			return NULL;
+ 		}
++
++		if (beacon->rnr_ies && beacon->rnr_ies->cnt) {
++			new_beacon->rnr_ies =
++				kzalloc(struct_size(new_beacon->rnr_ies,
++						    elem, beacon->rnr_ies->cnt),
++					GFP_KERNEL);
++			if (!new_beacon->rnr_ies) {
++				kfree(new_beacon->mbssid_ies);
++				kfree(new_beacon);
++				return NULL;
++			}
++		}
+ 	}
+ 
+ 	pos = (u8 *)(new_beacon + 1);
+@@ -3414,10 +3462,15 @@ cfg80211_beacon_dup(struct cfg80211_beacon_data *beacon)
+ 		memcpy(pos, beacon->probe_resp, beacon->probe_resp_len);
+ 		pos += beacon->probe_resp_len;
+ 	}
+-	if (beacon->mbssid_ies && beacon->mbssid_ies->cnt)
++	if (beacon->mbssid_ies && beacon->mbssid_ies->cnt) {
+ 		pos += ieee80211_copy_mbssid_beacon(pos,
+ 						    new_beacon->mbssid_ies,
+ 						    beacon->mbssid_ies);
++		if (beacon->rnr_ies && beacon->rnr_ies->cnt)
++			pos += ieee80211_copy_rnr_beacon(pos,
++							 new_beacon->rnr_ies,
++							 beacon->rnr_ies);
++	}
+ 
+ 	/* might copy -1, meaning no changes requested */
+ 	new_beacon->ftm_responder = beacon->ftm_responder;
+diff --git a/net/mac80211/ieee80211_i.h b/net/mac80211/ieee80211_i.h
+index d08aa09002dfd..64f8d8f2b799f 100644
+--- a/net/mac80211/ieee80211_i.h
++++ b/net/mac80211/ieee80211_i.h
+@@ -269,6 +269,7 @@ struct beacon_data {
+ 	u16 cntdwn_counter_offsets[IEEE80211_MAX_CNTDWN_COUNTERS_NUM];
+ 	u8 cntdwn_current_counter;
+ 	struct cfg80211_mbssid_elems *mbssid_ies;
++	struct cfg80211_rnr_elems *rnr_ies;
+ 	struct rcu_head rcu_head;
+ };
+ 
+@@ -1165,20 +1166,34 @@ ieee80211_vif_get_shift(struct ieee80211_vif *vif)
+ }
+ 
+ static inline int
+-ieee80211_get_mbssid_beacon_len(struct cfg80211_mbssid_elems *elems, u8 i)
++ieee80211_get_mbssid_beacon_len(struct cfg80211_mbssid_elems *elems,
++				struct cfg80211_rnr_elems *rnr_elems,
++				u8 i)
+ {
+ 	int len = 0;
+ 
+ 	if (!elems || !elems->cnt || i > elems->cnt)
+ 		return 0;
+ 
+-	if (i < elems->cnt)
+-		return elems->elem[i].len;
++	if (i < elems->cnt) {
++		len = elems->elem[i].len;
++		if (rnr_elems) {
++			len += rnr_elems->elem[i].len;
++			for (i = elems->cnt; i < rnr_elems->cnt; i++)
++				len += rnr_elems->elem[i].len;
++		}
++		return len;
++	}
+ 
+ 	/* i == elems->cnt, calculate total length of all MBSSID elements */
+ 	for (i = 0; i < elems->cnt; i++)
+ 		len += elems->elem[i].len;
+ 
++	if (rnr_elems) {
++		for (i = 0; i < rnr_elems->cnt; i++)
++			len += rnr_elems->elem[i].len;
++	}
++
+ 	return len;
+ }
+ 
+diff --git a/net/mac80211/tx.c b/net/mac80211/tx.c
+index 854bad6fbe193..5b7587cda8834 100644
+--- a/net/mac80211/tx.c
++++ b/net/mac80211/tx.c
+@@ -5149,6 +5149,15 @@ ieee80211_beacon_add_mbssid(struct sk_buff *skb, struct beacon_data *beacon,
+ 	if (i < beacon->mbssid_ies->cnt) {
+ 		skb_put_data(skb, beacon->mbssid_ies->elem[i].data,
+ 			     beacon->mbssid_ies->elem[i].len);
++
++		if (beacon->rnr_ies && beacon->rnr_ies->cnt) {
++			skb_put_data(skb, beacon->rnr_ies->elem[i].data,
++				     beacon->rnr_ies->elem[i].len);
++
++			for (i = beacon->mbssid_ies->cnt; i < beacon->rnr_ies->cnt; i++)
++				skb_put_data(skb, beacon->rnr_ies->elem[i].data,
++					     beacon->rnr_ies->elem[i].len);
++		}
+ 		return;
+ 	}
+ 
+@@ -5186,6 +5195,7 @@ ieee80211_beacon_get_ap(struct ieee80211_hw *hw,
+ 	 * tail length, maximum TIM length and multiple BSSID length
+ 	 */
+ 	mbssid_len = ieee80211_get_mbssid_beacon_len(beacon->mbssid_ies,
++						     beacon->rnr_ies,
+ 						     ema_index);
+ 
+ 	skb = dev_alloc_skb(local->tx_headroom + beacon->head_len +
diff --git a/package/kernel/mac80211/patches/subsys/808.patch b/package/kernel/mac80211/patches/subsys/808.patch
new file mode 100644
index 0000000..5b191fa
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/808.patch
@@ -0,0 +1,63 @@
+From 435d494aa09cf20ae37363a5f1c7ae86a3ee6563 Mon Sep 17 00:00:00 2001
+From: Aloka Dixit <aloka.dixit@oss.qualcomm.com>
+Date: Mon, 15 Dec 2025 09:46:56 -0800
+Subject: [PATCH] wifi: mac80211: do not use old MBSSID elements
+
+[ Upstream commit a519be2f5d958c5804f2cfd68f1f384291271fab ]
+
+When userspace brings down and deletes a non-transmitted profile,
+it is expected to send a new updated Beacon template for the
+transmitted profile of that multiple BSSID (MBSSID) group which
+does not include the removed profile in MBSSID element. This
+update comes via NL80211_CMD_SET_BEACON.
+
+Such updates work well as long as the group continues to have at
+least one non-transmitted profile as NL80211_ATTR_MBSSID_ELEMS
+is included in the new Beacon template.
+
+But when the last non-trasmitted profile is removed, it still
+gets included in Beacon templates sent to driver. This happens
+because when no MBSSID elements are sent by the userspace,
+ieee80211_assign_beacon() ends up using the element stored from
+earlier Beacon template.
+
+Do not copy old MBSSID elements, instead userspace should always
+include these when applicable.
+
+Fixes: 2b3171c6fe0a ("mac80211: MBSSID beacon handling in AP mode")
+Signed-off-by: Aloka Dixit <aloka.dixit@oss.qualcomm.com>
+Link: https://patch.msgid.link/20251215174656.2866319-2-aloka.dixit@oss.qualcomm.com
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ net/mac80211/cfg.c | 10 ----------
+ 1 file changed, 10 deletions(-)
+
+diff --git a/net/mac80211/cfg.c b/net/mac80211/cfg.c
+index a25d647c1c4b6..0d5ddd3d2c5fc 100644
+--- a/net/mac80211/cfg.c
++++ b/net/mac80211/cfg.c
+@@ -1139,7 +1139,6 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 
+ 	size = sizeof(*new) + new_head_len + new_tail_len;
+ 
+-	/* new or old multiple BSSID elements? */
+ 	if (params->mbssid_ies) {
+ 		mbssid = params->mbssid_ies;
+ 		size += struct_size(new->mbssid_ies, elem, mbssid->cnt);
+@@ -1149,15 +1148,6 @@ static int ieee80211_assign_beacon(struct ieee80211_sub_if_data *sdata,
+ 		}
+ 		size += ieee80211_get_mbssid_beacon_len(mbssid, rnr,
+ 							mbssid->cnt);
+-	} else if (old && old->mbssid_ies) {
+-		mbssid = old->mbssid_ies;
+-		size += struct_size(new->mbssid_ies, elem, mbssid->cnt);
+-		if (old && old->rnr_ies) {
+-			rnr = old->rnr_ies;
+-			size += struct_size(new->rnr_ies, elem, rnr->cnt);
+-		}
+-		size += ieee80211_get_mbssid_beacon_len(mbssid, rnr,
+-							mbssid->cnt);
+ 	}
+ 
+ 	new = kzalloc(size, GFP_KERNEL);
diff --git a/package/kernel/mac80211/patches/subsys/809.patch b/package/kernel/mac80211/patches/subsys/809.patch
new file mode 100644
index 0000000..d1f70e3
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/809.patch
@@ -0,0 +1,60 @@
+From 88aab153d1528bc559292a12fb5105ee97528e1f Mon Sep 17 00:00:00 2001
+From: Jouni Malinen <jouni.malinen@oss.qualcomm.com>
+Date: Tue, 6 Jan 2026 21:34:39 -0500
+Subject: [PATCH] wifi: mac80211: Discard Beacon frames to non-broadcast
+ address
+
+[ Upstream commit 193d18f60588e95d62e0f82b6a53893e5f2f19f8 ]
+
+Beacon frames are required to be sent to the broadcast address, see IEEE
+Std 802.11-2020, 11.1.3.1 ("The Address 1 field of the Beacon .. frame
+shall be set to the broadcast address"). A unicast Beacon frame might be
+used as a targeted attack to get one of the associated STAs to do
+something (e.g., using CSA to move it to another channel). As such, it
+is better have strict filtering for this on the received side and
+discard all Beacon frames that are sent to an unexpected address.
+
+This is even more important for cases where beacon protection is used.
+The current implementation in mac80211 is correctly discarding unicast
+Beacon frames if the Protected Frame bit in the Frame Control field is
+set to 0. However, if that bit is set to 1, the logic used for checking
+for configured BIGTK(s) does not actually work. If the driver does not
+have logic for dropping unicast Beacon frames with Protected Frame bit
+1, these frames would be accepted in mac80211 processing as valid Beacon
+frames even though they are not protected. This would allow beacon
+protection to be bypassed. While the logic for checking beacon
+protection could be extended to cover this corner case, a more generic
+check for discard all Beacon frames based on A1=unicast address covers
+this without needing additional changes.
+
+Address all these issues by dropping received Beacon frames if they are
+sent to a non-broadcast address.
+
+Cc: stable@vger.kernel.org
+Fixes: af2d14b01c32 ("mac80211: Beacon protection using the new BIGTK (STA)")
+Signed-off-by: Jouni Malinen <jouni.malinen@oss.qualcomm.com>
+Link: https://patch.msgid.link/20251215151134.104501-1-jouni.malinen@oss.qualcomm.com
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+[ adapted RX_DROP return value to RX_DROP_MONITOR ]
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+Signed-off-by: Greg Kroah-Hartman <gregkh@linuxfoundation.org>
+---
+ net/mac80211/rx.c | 5 +++++
+ 1 file changed, 5 insertions(+)
+
+diff --git a/net/mac80211/rx.c b/net/mac80211/rx.c
+index 1cd75c200cfe6..42dd7d1dda399 100644
+--- a/net/mac80211/rx.c
++++ b/net/mac80211/rx.c
+@@ -3299,6 +3299,11 @@ ieee80211_rx_h_mgmt_check(struct ieee80211_rx_data *rx)
+ 	if (!ieee80211_is_mgmt(mgmt->frame_control))
+ 		return RX_DROP_MONITOR;
+ 
++	/* Drop non-broadcast Beacon frames */
++	if (ieee80211_is_beacon(mgmt->frame_control) &&
++	    !is_broadcast_ether_addr(mgmt->da))
++		return RX_DROP_MONITOR;
++
+ 	if (rx->sdata->vif.type == NL80211_IFTYPE_AP &&
+ 	    ieee80211_is_beacon(mgmt->frame_control) &&
+ 	    !(rx->flags & IEEE80211_RX_BEACON_REPORTED)) {
diff --git a/package/kernel/mac80211/patches/subsys/810.patch b/package/kernel/mac80211/patches/subsys/810.patch
new file mode 100644
index 0000000..cc7d5fd
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/810.patch
@@ -0,0 +1,58 @@
+From d68acee3fb65f169787e15cdab6364a001233d85 Mon Sep 17 00:00:00 2001
+From: Aditya Kumar Singh <quic_adisi@quicinc.com>
+Date: Wed, 31 May 2023 11:50:12 +0530
+Subject: [PATCH] wifi: mac80211: fix switch count in EMA beacons
+
+commit 1afa18e9e72396d1e1aedd6dbb34681f2413316b upstream.
+
+Currently, whenever an EMA beacon is formed, due to is_template
+argument being false from the caller, the switch count is always
+decremented once which is wrong.
+
+Also if switch count is equal to profile periodicity, this makes
+the switch count to reach till zero which triggers a WARN_ON_ONCE.
+
+[  261.593915] CPU: 1 PID: 800 Comm: kworker/u8:3 Not tainted 5.4.213 #0
+[  261.616143] Hardware name: Qualcomm Technologies, Inc. IPQ9574
+[  261.622666] Workqueue: phy0 ath12k_get_link_bss_conf [ath12k]
+[  261.629771] pstate: 60400005 (nZCv daif +PAN -UAO)
+[  261.635595] pc : ieee80211_next_txq+0x1ac/0x1b8 [mac80211]
+[  261.640282] lr : ieee80211_beacon_update_cntdwn+0x64/0xb4 [mac80211]
+[...]
+[  261.729683] Call trace:
+[  261.734986]  ieee80211_next_txq+0x1ac/0x1b8 [mac80211]
+[  261.737156]  ieee80211_beacon_cntdwn_is_complete+0xa28/0x1194 [mac80211]
+[  261.742365]  ieee80211_beacon_cntdwn_is_complete+0xef4/0x1194 [mac80211]
+[  261.749224]  ieee80211_beacon_get_template_ema_list+0x38/0x5c [mac80211]
+[  261.755908]  ath12k_get_link_bss_conf+0xf8/0x33b4 [ath12k]
+[  261.762590]  ath12k_get_link_bss_conf+0x390/0x33b4 [ath12k]
+[  261.767881]  process_one_work+0x194/0x270
+[  261.773346]  worker_thread+0x200/0x314
+[  261.777514]  kthread+0x140/0x150
+[  261.781158]  ret_from_fork+0x10/0x18
+
+Fix this issue by making the is_template argument as true when fetching
+the EMA beacons.
+
+Fixes: bd54f3c29077 ("wifi: mac80211: generate EMA beacons in AP mode")
+Signed-off-by: Aditya Kumar Singh <quic_adisi@quicinc.com>
+Link: https://lore.kernel.org/r/20230531062012.4537-1-quic_adisi@quicinc.com
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Greg Kroah-Hartman <gregkh@linuxfoundation.org>
+---
+ net/mac80211/tx.c | 2 +-
+ 1 file changed, 1 insertion(+), 1 deletion(-)
+
+diff --git a/net/mac80211/tx.c b/net/mac80211/tx.c
+index 5b7587cda8834..7333e43dfc354 100644
+--- a/net/mac80211/tx.c
++++ b/net/mac80211/tx.c
+@@ -5456,7 +5456,7 @@ ieee80211_beacon_get_template_ema_list(struct ieee80211_hw *hw,
+ {
+ 	struct ieee80211_ema_beacons *ema_beacons = NULL;
+ 
+-	WARN_ON(__ieee80211_beacon_get(hw, vif, NULL, false, link_id, 0,
++	WARN_ON(__ieee80211_beacon_get(hw, vif, NULL, true, link_id, 0,
+ 				       &ema_beacons));
+ 
+ 	return ema_beacons;
diff --git a/package/kernel/mac80211/patches/subsys/806b.patch b/package/kernel/mac80211/patches/subsys/806b.patch
new file mode 100644
index 0000000..6eed885
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/806b.patch
@@ -0,0 +1,298 @@
+From 56189d7bc30531def6b999f27940ee43c6ff2569 Mon Sep 17 00:00:00 2001
+From: Aloka Dixit <quic_alokad@quicinc.com>
+Date: Thu, 23 Mar 2023 04:38:00 -0700
+Subject: [PATCH] cfg80211: support RNR for EMA AP
+
+[ Upstream commit dbbb27e183b1568d5a907ace1cd144b0709ea52a ]
+
+As per IEEE Std 802.11ax-2021, 11.1.3.8.3 Discovery of a nontransmitted
+BSSID profile, an EMA AP that transmits a Beacon frame carrying a partial
+list of nontransmitted BSSID profiles should include in the frame
+a Reduced Neighbor Report element carrying information for at least the
+nontransmitted BSSIDs that are not present in the Multiple BSSID element
+carried in that frame.
+Add new nested attribute NL80211_ATTR_EMA_RNR_ELEMS to support the above.
+Number of RNR elements must be more than or equal to the number of
+MBSSID elements. This attribute can be used only when EMA is enabled.
+Userspace is responsible for splitting the RNR into multiple elements such
+that each element excludes the non-transmitting profiles already included
+in the MBSSID element (%NL80211_ATTR_MBSSID_ELEMS) at the same index.
+Each EMA beacon will be generated by adding MBSSID and RNR elements
+at the same index. If the userspace provides more RNR elements than the
+number of MBSSID elements then these will be added in every EMA beacon.
+
+Signed-off-by: Aloka Dixit <quic_alokad@quicinc.com>
+Link: https://lore.kernel.org/r/20230323113801.6903-2-quic_alokad@quicinc.com
+[Johannes: validate elements]
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Stable-dep-of: a519be2f5d95 ("wifi: mac80211: do not use old MBSSID elements")
+Signed-off-by: Sasha Levin <sashal@kernel.org>
+---
+ include/net/cfg80211.h       | 19 +++++++++
+ include/uapi/linux/nl80211.h | 13 ++++++
+ net/wireless/nl80211.c       | 79 ++++++++++++++++++++++++++++++++----
+ 3 files changed, 104 insertions(+), 7 deletions(-)
+
+diff --git a/include/net/cfg80211.h b/include/net/cfg80211.h
+index 34709bd733ed2..f39a60475c24c 100644
+--- a/include/net/cfg80211.h
++++ b/include/net/cfg80211.h
+@@ -1187,6 +1187,23 @@ struct cfg80211_mbssid_elems {
+ 	} elem[];
+ };
+ 
++/**
++ * struct cfg80211_rnr_elems - Reduced neighbor report (RNR) elements
++ *
++ * @cnt: Number of elements in array %elems.
++ *
++ * @elem: Array of RNR element(s) to be added into Beacon frames.
++ * @elem.data: Data for RNR elements.
++ * @elem.len: Length of data.
++ */
++struct cfg80211_rnr_elems {
++	u8 cnt;
++	struct {
++		const u8 *data;
++		size_t len;
++	} elem[];
++};
++
+ /**
+  * struct cfg80211_beacon_data - beacon data
+  * @link_id: the link ID for the AP MLD link sending this beacon
+@@ -1207,6 +1224,7 @@ struct cfg80211_mbssid_elems {
+  * @probe_resp_len: length of probe response template (@probe_resp)
+  * @probe_resp: probe response template (AP mode only)
+  * @mbssid_ies: multiple BSSID elements
++ * @rnr_ies: reduced neighbor report elements
+  * @ftm_responder: enable FTM responder functionality; -1 for no change
+  *	(which also implies no change in LCI/civic location data)
+  * @lci: Measurement Report element content, starting with Measurement Token
+@@ -1230,6 +1248,7 @@ struct cfg80211_beacon_data {
+ 	const u8 *lci;
+ 	const u8 *civicloc;
+ 	struct cfg80211_mbssid_elems *mbssid_ies;
++	struct cfg80211_rnr_elems *rnr_ies;
+ 	s8 ftm_responder;
+ 
+ 	size_t head_len, tail_len;
+diff --git a/include/uapi/linux/nl80211.h b/include/uapi/linux/nl80211.h
+index 274d1b34c9545..63d7241edd49f 100644
+--- a/include/uapi/linux/nl80211.h
++++ b/include/uapi/linux/nl80211.h
+@@ -2776,6 +2776,17 @@ enum nl80211_commands {
+  * @NL80211_ATTR_HW_TIMESTAMP_ENABLED: Indicates whether HW timestamping should
+  *	be enabled or not (flag attribute).
+  *
++ * @NL80211_ATTR_EMA_RNR_ELEMS: Optional nested attribute for
++ *	reduced neighbor report (RNR) elements. This attribute can be used
++ *	only when NL80211_MBSSID_CONFIG_ATTR_EMA is enabled.
++ *	Userspace is responsible for splitting the RNR into multiple
++ *	elements such that each element excludes the non-transmitting
++ *	profiles already included in the MBSSID element
++ *	(%NL80211_ATTR_MBSSID_ELEMS) at the same index. Each EMA beacon
++ *	will be generated by adding MBSSID and RNR elements at the same
++ *	index. If the userspace includes more RNR elements than number of
++ *	MBSSID elements then these will be added in every EMA beacon.
++ *
+  * @NUM_NL80211_ATTR: total number of nl80211_attrs available
+  * @NL80211_ATTR_MAX: highest attribute number currently defined
+  * @__NL80211_ATTR_AFTER_LAST: internal use
+@@ -3310,6 +3321,8 @@ enum nl80211_attrs {
+ 	NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS,
+ 	NL80211_ATTR_HW_TIMESTAMP_ENABLED,
+ 
++	NL80211_ATTR_EMA_RNR_ELEMS,
++
+ 	/* add attributes here, update the policy in nl80211.c */
+ 
+ 	__NL80211_ATTR_AFTER_LAST,
+diff --git a/net/wireless/nl80211.c b/net/wireless/nl80211.c
+index 5e2b676f5ce03..7a976bd1641f8 100644
+--- a/net/wireless/nl80211.c
++++ b/net/wireless/nl80211.c
+@@ -814,6 +814,7 @@ static const struct nla_policy nl80211_policy[NUM_NL80211_ATTR] = {
+ 
+ 	[NL80211_ATTR_MAX_HW_TIMESTAMP_PEERS] = { .type = NLA_U16 },
+ 	[NL80211_ATTR_HW_TIMESTAMP_ENABLED] = { .type = NLA_FLAG },
++	[NL80211_ATTR_EMA_RNR_ELEMS] = { .type = NLA_NESTED },
+ };
+ 
+ /* policy for the key attributes */
+@@ -5455,6 +5456,38 @@ nl80211_parse_mbssid_elems(struct wiphy *wiphy, struct nlattr *attrs)
+ 	return elems;
+ }
+ 
++static struct cfg80211_rnr_elems *
++nl80211_parse_rnr_elems(struct wiphy *wiphy, struct nlattr *attrs,
++			struct netlink_ext_ack *extack)
++{
++	struct nlattr *nl_elems;
++	struct cfg80211_rnr_elems *elems;
++	int rem_elems;
++	u8 i = 0, num_elems = 0;
++
++	nla_for_each_nested(nl_elems, attrs, rem_elems) {
++		int ret;
++
++		ret = validate_ie_attr(nl_elems, extack);
++		if (ret)
++			return ERR_PTR(ret);
++
++		num_elems++;
++	}
++
++	elems = kzalloc(struct_size(elems, elem, num_elems), GFP_KERNEL);
++	if (!elems)
++		return ERR_PTR(-ENOMEM);
++
++	nla_for_each_nested(nl_elems, attrs, rem_elems) {
++		elems->elem[i].data = nla_data(nl_elems);
++		elems->elem[i].len = nla_len(nl_elems);
++		i++;
++	}
++	elems->cnt = num_elems;
++	return elems;
++}
++
+ static int nl80211_parse_he_bss_color(struct nlattr *attrs,
+ 				      struct cfg80211_he_bss_color *he_bss_color)
+ {
+@@ -5481,7 +5514,8 @@ static int nl80211_parse_he_bss_color(struct nlattr *attrs,
+ 
+ static int nl80211_parse_beacon(struct cfg80211_registered_device *rdev,
+ 				struct nlattr *attrs[],
+-				struct cfg80211_beacon_data *bcn)
++				struct cfg80211_beacon_data *bcn,
++				struct netlink_ext_ack *extack)
+ {
+ 	bool haveinfo = false;
+ 	int err;
+@@ -5578,6 +5612,21 @@ static int nl80211_parse_beacon(struct cfg80211_registered_device *rdev,
+ 			return PTR_ERR(mbssid);
+ 
+ 		bcn->mbssid_ies = mbssid;
++
++		if (bcn->mbssid_ies && attrs[NL80211_ATTR_EMA_RNR_ELEMS]) {
++			struct cfg80211_rnr_elems *rnr =
++				nl80211_parse_rnr_elems(&rdev->wiphy,
++							attrs[NL80211_ATTR_EMA_RNR_ELEMS],
++							extack);
++
++			if (IS_ERR(rnr))
++				return PTR_ERR(rnr);
++
++			if (rnr && rnr->cnt < bcn->mbssid_ies->cnt)
++				return -EINVAL;
++
++			bcn->rnr_ies = rnr;
++		}
+ 	}
+ 
+ 	return 0;
+@@ -5860,7 +5909,8 @@ static int nl80211_start_ap(struct sk_buff *skb, struct genl_info *info)
+ 	if (!params)
+ 		return -ENOMEM;
+ 
+-	err = nl80211_parse_beacon(rdev, info->attrs, &params->beacon);
++	err = nl80211_parse_beacon(rdev, info->attrs, &params->beacon,
++				   info->extack);
+ 	if (err)
+ 		goto out;
+ 
+@@ -6090,6 +6140,11 @@ static int nl80211_start_ap(struct sk_buff *skb, struct genl_info *info)
+ 			goto out_unlock;
+ 	}
+ 
++	if (!params->mbssid_config.ema && params->beacon.rnr_ies) {
++		err = -EINVAL;
++		goto out_unlock;
++	}
++
+ 	err = nl80211_calculate_ap_params(params);
+ 	if (err)
+ 		goto out_unlock;
+@@ -6129,6 +6184,7 @@ static int nl80211_start_ap(struct sk_buff *skb, struct genl_info *info)
+ 	    params->mbssid_config.tx_wdev->netdev &&
+ 	    params->mbssid_config.tx_wdev->netdev != dev)
+ 		dev_put(params->mbssid_config.tx_wdev->netdev);
++	kfree(params->beacon.rnr_ies);
+ 	kfree(params);
+ 
+ 	return err;
+@@ -6153,7 +6209,7 @@ static int nl80211_set_beacon(struct sk_buff *skb, struct genl_info *info)
+ 	if (!wdev->links[link_id].ap.beacon_interval)
+ 		return -EINVAL;
+ 
+-	err = nl80211_parse_beacon(rdev, info->attrs, &params);
++	err = nl80211_parse_beacon(rdev, info->attrs, &params, info->extack);
+ 	if (err)
+ 		goto out;
+ 
+@@ -6163,6 +6219,7 @@ static int nl80211_set_beacon(struct sk_buff *skb, struct genl_info *info)
+ 
+ out:
+ 	kfree(params.mbssid_ies);
++	kfree(params.rnr_ies);
+ 	return err;
+ }
+ 
+@@ -10017,7 +10074,8 @@ static int nl80211_channel_switch(struct sk_buff *skb, struct genl_info *info)
+ 	if (!need_new_beacon)
+ 		goto skip_beacons;
+ 
+-	err = nl80211_parse_beacon(rdev, info->attrs, &params.beacon_after);
++	err = nl80211_parse_beacon(rdev, info->attrs, &params.beacon_after,
++				   info->extack);
+ 	if (err)
+ 		goto free;
+ 
+@@ -10034,7 +10092,8 @@ static int nl80211_channel_switch(struct sk_buff *skb, struct genl_info *info)
+ 	if (err)
+ 		goto free;
+ 
+-	err = nl80211_parse_beacon(rdev, csa_attrs, &params.beacon_csa);
++	err = nl80211_parse_beacon(rdev, csa_attrs, &params.beacon_csa,
++				   info->extack);
+ 	if (err)
+ 		goto free;
+ 
+@@ -10154,6 +10213,8 @@ static int nl80211_channel_switch(struct sk_buff *skb, struct genl_info *info)
+ free:
+ 	kfree(params.beacon_after.mbssid_ies);
+ 	kfree(params.beacon_csa.mbssid_ies);
++	kfree(params.beacon_after.rnr_ies);
++	kfree(params.beacon_csa.rnr_ies);
+ 	kfree(csa_attrs);
+ 	return err;
+ }
+@@ -15880,7 +15941,8 @@ static int nl80211_color_change(struct sk_buff *skb, struct genl_info *info)
+ 	params.count = nla_get_u8(info->attrs[NL80211_ATTR_COLOR_CHANGE_COUNT]);
+ 	params.color = nla_get_u8(info->attrs[NL80211_ATTR_COLOR_CHANGE_COLOR]);
+ 
+-	err = nl80211_parse_beacon(rdev, info->attrs, &params.beacon_next);
++	err = nl80211_parse_beacon(rdev, info->attrs, &params.beacon_next,
++				   info->extack);
+ 	if (err)
+ 		return err;
+ 
+@@ -15894,7 +15956,8 @@ static int nl80211_color_change(struct sk_buff *skb, struct genl_info *info)
+ 	if (err)
+ 		goto out;
+ 
+-	err = nl80211_parse_beacon(rdev, tb, &params.beacon_color_change);
++	err = nl80211_parse_beacon(rdev, tb, &params.beacon_color_change,
++				   info->extack);
+ 	if (err)
+ 		goto out;
+ 
+@@ -15950,6 +16013,8 @@ static int nl80211_color_change(struct sk_buff *skb, struct genl_info *info)
+ out:
+ 	kfree(params.beacon_next.mbssid_ies);
+ 	kfree(params.beacon_color_change.mbssid_ies);
++	kfree(params.beacon_next.rnr_ies);
++	kfree(params.beacon_color_change.rnr_ies);
+ 	kfree(tb);
+ 	return err;
+ }
diff --git a/package/kernel/mac80211/patches/subsys/812.patch b/package/kernel/mac80211/patches/subsys/812.patch
new file mode 100644
index 0000000..07c28d0
--- /dev/null
+++ b/package/kernel/mac80211/patches/subsys/812.patch
@@ -0,0 +1,61 @@
+From 442ceac0393185e9982323f6682a52a53e8462b1 Mon Sep 17 00:00:00 2001
+From: Eric Dumazet <edumazet@google.com>
+Date: Thu, 8 Jan 2026 10:19:27 +0000
+Subject: [PATCH] wifi: avoid kernel-infoleak from struct iw_point
+
+commit 21cbf883d073abbfe09e3924466aa5e0449e7261 upstream.
+
+struct iw_point has a 32bit hole on 64bit arches.
+
+struct iw_point {
+  void __user   *pointer;       /* Pointer to the data  (in user space) */
+  __u16         length;         /* number of fields or size in bytes */
+  __u16         flags;          /* Optional params */
+};
+
+Make sure to zero the structure to avoid disclosing 32bits of kernel data
+to user space.
+
+Fixes: 87de87d5e47f ("wext: Dispatch and handle compat ioctls entirely in net/wireless/wext.c")
+Reported-by: syzbot+bfc7323743ca6dbcc3d3@syzkaller.appspotmail.com
+Closes: https://lore.kernel.org/netdev/695f83f3.050a0220.1c677c.0392.GAE@google.com/T/#u
+Signed-off-by: Eric Dumazet <edumazet@google.com>
+Cc: stable@vger.kernel.org
+Link: https://patch.msgid.link/20260108101927.857582-1-edumazet@google.com
+Signed-off-by: Johannes Berg <johannes.berg@intel.com>
+Signed-off-by: Greg Kroah-Hartman <gregkh@linuxfoundation.org>
+---
+ net/wireless/wext-core.c | 4 ++++
+ net/wireless/wext-priv.c | 4 ++++
+ 2 files changed, 8 insertions(+)
+
+diff --git a/net/wireless/wext-core.c b/net/wireless/wext-core.c
+index 8a4b85f96a13a..f2a3325164559 100644
+--- a/net/wireless/wext-core.c
++++ b/net/wireless/wext-core.c
+@@ -1084,6 +1084,10 @@ static int compat_standard_call(struct net_device	*dev,
+ 		return ioctl_standard_call(dev, iwr, cmd, info, handler);
+ 
+ 	iwp_compat = (struct compat_iw_point *) &iwr->u.data;
++
++	/* struct iw_point has a 32bit hole on 64bit arches. */
++	memset(&iwp, 0, sizeof(iwp));
++
+ 	iwp.pointer = compat_ptr(iwp_compat->pointer);
+ 	iwp.length = iwp_compat->length;
+ 	iwp.flags = iwp_compat->flags;
+diff --git a/net/wireless/wext-priv.c b/net/wireless/wext-priv.c
+index 674d426a9d24f..37d1147019c2b 100644
+--- a/net/wireless/wext-priv.c
++++ b/net/wireless/wext-priv.c
+@@ -228,6 +228,10 @@ int compat_private_call(struct net_device *dev, struct iwreq *iwr,
+ 		struct iw_point iwp;
+ 
+ 		iwp_compat = (struct compat_iw_point *) &iwr->u.data;
++
++		/* struct iw_point has a 32bit hole on 64bit arches. */
++		memset(&iwp, 0, sizeof(iwp));
++
+ 		iwp.pointer = compat_ptr(iwp_compat->pointer);
+ 		iwp.length = iwp_compat->length;
+ 		iwp.flags = iwp_compat->flags;
-- 
2.46.2.windows.1

