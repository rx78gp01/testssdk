From 61330ddef839bf2d03ff651dfa48c88e73b37e3e Mon Sep 17 00:00:00 2001
From: Jo-Philipp Wich <jo@mein.io>
Date: Tue, 21 May 2024 08:59:13 +0200
Subject: [PATCH] firewall4: update to Git HEAD (2024-05-21)

4c01d1ebf99e fw4: substitute double quotes in strings

Fixes: https://github.com/openwrt/luci/issues/7091
Signed-off-by: Jo-Philipp Wich <jo@mein.io>
---
 package/network/config/firewall4/Makefile | 6 +++---
 1 file changed, 3 insertions(+), 3 deletions(-)

diff --git a/package/network/config/firewall4/Makefile b/package/network/config/firewall4/Makefile
index 365a363303fcfd..6aacc05e365b45 100644
--- a/package/network/config/firewall4/Makefile
+++ b/package/network/config/firewall4/Makefile
@@ -9,9 +9,9 @@ PKG_RELEASE:=1
 
 PKG_SOURCE_PROTO:=git
 PKG_SOURCE_URL=$(PROJECT_GIT)/project/firewall4.git
-PKG_SOURCE_DATE:=2023-09-01
-PKG_SOURCE_VERSION:=598d9fbb5179667aa0c525040eaa41bc7f2dc015
-PKG_MIRROR_HASH:=038b5b5611425e3c0fcc3ef4a0aea37296733300766d787909a689d16d4f39b4
+PKG_SOURCE_DATE:=2024-05-21
+PKG_SOURCE_VERSION:=4c01d1ebf99e8ecfa69758a9b4f450ecef7b93cd
+PKG_MIRROR_HASH:=skip
 PKG_MAINTAINER:=Jo-Philipp Wich <jo@mein.io>
 PKG_LICENSE:=ISC
 
